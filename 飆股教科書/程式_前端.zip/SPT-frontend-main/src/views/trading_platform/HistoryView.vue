<script setup>
    import { onMounted } from 'vue'
    import { useTrade } from '@/stores/trade.js'

    const { tradeHistory, loading, fetchHistory } = useTrade()

    // 日期格式化
    const formatDate = (date) => {
        return new Date(date).toLocaleString('zh-TW')
    }

    // 頁面載入時取得交易歷史
    onMounted(() => {
        fetchHistory()
    })
</script>

<template>
    <div>
        <div class="card">
            <h1 class="text-4xl font-bold text-center text-gray-900 mb-6 tracking-wider">
                💰交易歷史
            </h1>

            <div v-if="loading" class="text-center p-10">正在載入交易歷史...</div>

            <div v-else-if="!tradeHistory.length" class="text-center p-10">
                目前沒有任何交易歷史。
            </div>

            <div v-else class="max-w-6xl mx-auto p-6 text-gray-800 hide-scrollbar">
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white rounded-xl shadow">
                        <thead>
                            <tr class="text-2xl text-white bg-custom-purple font-semibold">
                                <th class="px-5 py-5 text-center rounded-tl-xl">時間</th>
                                <th class="px-5 py-5 text-center">股票代碼</th>
                                <th class="px-5 py-5 text-center">交易類型</th>
                                <th class="px-5 py-5 text-center">數量</th>
                                <th class="px-5 py-5 text-center">價格</th>
                                <th class="px-5 py-5 text-center rounded-tr-xl">總金額</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr
                                v-for="(trade, index) in tradeHistory"
                                :key="trade.id"
                                :class="[
                                    index % 2 === 0 ? 'bg-white' : 'bg-gray-50',
                                    'text-lg',
                                    'transition',
                                    'hover:bg-blue-50',
                                ]"
                            >
                                <td class="px-5 py-5 text-center">
                                    {{ formatDate(trade.date) }}
                                </td>
                                <td class="px-5 py-5 text-center">
                                    {{ trade.stock_symbol }}
                                </td>
                                <td
                                    class="px-5 py-5 text-center"
                                    :class="
                                        trade.transaction_type === 'BUY'
                                            ? 'text-green-600 font-bold'
                                            : 'text-red-600 font-bold'
                                    "
                                >
                                    {{ trade.transaction_type === 'BUY' ? '買入' : '賣出' }}
                                </td>
                                <td class="px-5 py-5 text-center">
                                    {{ trade.shares }}
                                </td>
                                <td class="px-5 py-5 text-center">
                                    ${{ Number(trade.price).toFixed(2) }}
                                </td>
                                <td class="px-5 py-5 text-center">
                                    ${{ Number(trade.amount).toLocaleString() }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>
