import api from '@/api/axios'
import qs from 'qs'
import router from '@/router'
import { ref } from 'vue'
import { defineStore } from 'pinia'
import { useToast } from 'primevue/usetoast'

export const useUserStore = defineStore(
    'user',
    () => {
        const accessToken = ref(null)
        const refreshToken = ref(null)
        const userEmail = ref(null)

        /**
         * 註冊新使用者
         * @param {string} username - 使用者名稱
         * @param {string} email - 電子郵件
         * @param {string} password - 密碼
         * @returns {Promise<object|boolean>} - 成功時回傳後端資料並跳轉，失敗時回傳失敗原因
         */

        const toast = useToast()

        async function registerUser(username, email, password) {
            try {
                const url = 'users/register'
                const data = qs.stringify({
                    username: username,
                    email: email,
                    password: password,
                })
                const requestData = await api.post(url, data, {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                })

                addRegisterToast(requestData.status, requestData.data.message)

                router.push({ name: '登入' })
            } catch (error) {
                addRegisterToast(error.response.status, error.response.data.error)

                return error.response
            }
        }

        async function loginUser(email, password) {
            try {
                const url = 'users/login'
                const data = qs.stringify({
                    email: email,
                    password: password,
                })
                const requestData = await api.post(url, data, {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                })

                if (requestData.status === 200) {
                    userEmail.value = email
                    accessToken.value = requestData.data.access
                    refreshToken.value = requestData.data.refresh
                }

                addLoginToast(requestData.status, requestData.data.message)

                const redirectPath = router.currentRoute.value.query.redirect

                if (redirectPath) {
                    router.push(redirectPath)
                } else {
                    router.push({ name: '首頁' })
                }
            } catch (error) {
                addLoginToast(error.response.status, error.response.data.error)

                return error.response
            }
        }

        const getUserInvestments = async () => {
            try {
                const response = await api.get('transaction/investment/')

                return response.data
            } catch (e) {
                toast.add({
                    severity: 'error',
                    summary: '讀取使用者持有資金失敗',
                    detail: e.message || '發生未知錯誤',
                    life: 3000,
                })
                return []
            }
        }

        async function refreshAccessToken() {
            if (!refreshToken.value) {
                return Promise.reject(new Error('No refresh token available.'))
            }

            const url = 'users/token'
            const data = qs.stringify({
                refresh: refreshToken.value,
            })

            const requestData = await api.post(url, data, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            })

            if (requestData.status === 200) {
                accessToken.value = requestData.data.access
                return requestData.data.access
            }
        }

        function logout() {
            userEmail.value = null
            accessToken.value = null
            refreshToken.value = null
            router.push({ name: '首頁' })
            addLogoutToast()
        }

        function addRegisterToast(status, message) {
            if (status === 201) {
                toast.add({
                    severity: 'success',
                    summary: '註冊成功',
                    detail: message,
                    life: 5000,
                })
            } else {
                toast.add({
                    severity: 'error',
                    summary: '註冊失敗',
                    detail: message,
                    life: 3000,
                })
            }
        }

        function addLoginToast(status, message) {
            if (status === 200) {
                toast.add({
                    severity: 'success',
                    summary: '登入成功',
                    detail: message,
                    life: 5000,
                })
            } else {
                toast.add({
                    severity: 'error',
                    summary: '登入失敗',
                    detail: message,
                    life: 3000,
                })
            }
        }

        function addLogoutToast() {
            toast.add({
                severity: 'success',
                summary: '登出成功',
                detail: userEmail.value ? `${userEmail.value} 已成功登出` : '已成功登出',
                life: 5000,
            })
        }

        function showLoginRequiredToast() {
            toast.add({
                severity: 'warn',
                summary: '權限不足',
                detail: '請登入或註冊以存取此功能。',
                life: 4000,
            })
        }

        return {
            registerUser,
            loginUser,
            refreshAccessToken,
            userEmail,
            accessToken,
            refreshToken,
            logout,
            addLogoutToast,
            showLoginRequiredToast,
            getUserInvestments,
        }
    },
    {
        persist: {
            storage: typeof window !== 'undefined' ? localStorage : undefined,
            paths: ['accessToken', 'refreshToken', 'userEmail'],
        },
    },
)
