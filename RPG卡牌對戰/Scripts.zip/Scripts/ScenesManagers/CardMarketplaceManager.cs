using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class CardMarketplaceManager : MonoBehaviour
{
    [Header("Dependencies")]
    [Tooltip("請將您的 Card Art Library 資源拖曳到此處")]
    [SerializeField] private CardArtLibrary cardArtLibrary;
    [Tooltip("請將您的 Card Prefab 拖曳到此處")]
    [SerializeField] private GameObject cardPrefab;

    [Header("Spawn Points")]
    [Tooltip("請在 Inspector 中將 SpawnPoint (1) ~ (10) 依序拖曳到此處")]
    [SerializeField] private List<Transform> spawnPoints = new List<Transform>();

    private void Start()
    {
        if (cardArtLibrary != null)
        {
            CardDatabase.Initialize(cardArtLibrary);
            GenerateMarketCards();
        }
        else
        {
            Debug.LogError("[Marketplace] CardArtLibrary is not assigned. Cannot generate cards.");
        }
    }

    // Fisher-Yates 洗牌算法：用於隨機打亂列表順序
    private void Shuffle<T>(List<T> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            T temp = list[i];
            list[i] = list[j];
            list[j] = temp;
        }
    }

    public void GenerateMarketCards()
    {
        // 確保 Prefab 和生成點存在
        if (cardPrefab == null || spawnPoints.Count == 0)
        {
            Debug.LogError("[Marketplace] Prefab or Spawn Points are missing.");
            return;
        }

        // 1. 清理舊卡片
        foreach (var point in spawnPoints)
        {
            if (point.childCount > 0 && point.GetChild(0).gameObject != null)
            {
                Destroy(point.GetChild(0).gameObject);
            }
        }

        // 2. 獲取所有卡片並隨機選擇 (略過細節)
        List<CardData> allCards = CardDatabase.GetAllCards();
        int maxCards = Mathf.Min(spawnPoints.Count, allCards.Count);

        Shuffle(allCards);
        List<CardData> selectedCards = allCards.Take(maxCards).ToList();

        // 3. 實例化卡片 (按 SpawnPoint 順序)
        for (int i = 0; i < selectedCards.Count; i++)
        {
            CardData cardData = selectedCards[i];
            Transform spawnPoint = spawnPoints[i];

            GameObject cardGO = Instantiate(cardPrefab, spawnPoint.position, spawnPoint.rotation, spawnPoint);

            // ▼▼▼ 尺寸修正邏輯 ▼▼▼
            RectTransform rectTransform = cardGO.GetComponent<RectTransform>();
            if (rectTransform != null)
            {
                // 設置絕對尺寸為 30 寬 x 200 高
                rectTransform.sizeDelta = new Vector2(30f, 200f);
            }

            // 確保縮放是 1 (不進行額外縮放)
            cardGO.transform.localScale = Vector3.one;
            // ▲▲▲ 修正邏輯結束 ▲▲▲

            // Initialization
            CardDisplay cardDisplay = cardGO.GetComponent<CardDisplay>();
            if (cardDisplay != null)
            {
                cardDisplay.Initialize(cardData, spawnPoint);
            }
            else
            {
                Debug.LogError($"[Marketplace] Card Prefab is missing the CardDisplay component on: {cardGO.name}");
            }
        }

        Debug.Log($"[Marketplace] Successfully spawned {selectedCards.Count} random cards, using SpawnPoints 1 to {selectedCards.Count} sequentially.");
    }
}