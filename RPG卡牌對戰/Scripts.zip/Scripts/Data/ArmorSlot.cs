// 檔案路徑: Assets/Scripts/Data/ArmorSlot.cs
using UnityEngine;

[System.Serializable]
public class ArmorSlot
{
    public string slotName;

    public int currentArmor;
    public int maxArmor;
    public bool isBroken = false;
    public int corruptStacks = 0;
    public int corruptTurns = 0;

    public ArmorSlot(string name)
    {
        this.slotName = name;
        this.currentArmor = 0;
        this.maxArmor = 0;
        this.isBroken = false;
        this.corruptStacks = 0;
        this.corruptTurns = 0;
    }

    public void EquipArmor(int defenseValue)
    {
        this.maxArmor = defenseValue;
        this.currentArmor = defenseValue;
        this.isBroken = false;
    }

    public void Repair(int amount)
    {
        if (amount <= 0) return;
        this.currentArmor += amount;
        this.isBroken = false;
    }

    public void ApplyDamage(int damage)
    {
        if (this.isBroken || damage <= 0) return;
        this.currentArmor -= damage;
        if (this.currentArmor <= 0)
        {
            this.currentArmor = 0;
            this.isBroken = true;
        }
    }

    public void AddCorruption(int stacks)
    {
        if (stacks <= 0) return;
        this.corruptStacks += stacks;
        this.corruptTurns = Mathf.Max(this.corruptTurns, 1); // 至少一回合
    }

    public void UpdateCorruption(RPGStatsData data)
    {
        if (data == null || this.corruptStacks <= 0) return;

        int decay = Mathf.CeilToInt(this.corruptStacks * data.corruptionArmorDamageRatio);
        this.currentArmor = Mathf.Max(0, this.currentArmor - decay);

        this.corruptTurns--;
        if (this.corruptTurns <= 0)
        {
            this.corruptStacks = 0;
            this.corruptTurns = 0;
        }

        if (this.currentArmor <= 0)
        {
            this.currentArmor = 0;
            this.isBroken = true;
        }
    }
}