from django.db import transaction
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from transaction.models import Portfolio


@receiver(post_save, sender=Portfolio)
def update_user_portfolio_data(sender, instance, **kwargs):
    """每當 Portfolio 有更新，就更新 User 的持股總值與報酬率"""
    _update_user_portfolio_summary(instance.user)


@receiver(post_delete, sender=Portfolio)
def update_user_portfolio_data_on_delete(sender, instance, **kwargs):
    """當 Portfolio 被刪除（例如賣光）時，同樣更新使用者的總資產與報酬率"""
    _update_user_portfolio_summary(instance.user)


def _update_user_portfolio_summary(user):
    """統一更新使用者的投資總值與報酬率"""
    portfolios = user.portfolio_set.all()
    total_value = sum((p.current_price or 0) * p.shares for p in portfolios)
    total_cost = sum((p.average_price or 0) * p.shares for p in portfolios)

    user.portfolio_value = total_value
    user.total_return_rate = (
        (total_value - total_cost) / total_cost * 100 if total_cost > 0 else 0
    )

    transaction.on_commit(
        lambda: user.save(update_fields=['portfolio_value', 'total_return_rate'])
    )
