import { createRouter, createWebHistory } from 'vue-router'

import HomeView from '../views/HomeView.vue'
import { useUserStore } from '@/stores/user'

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/',
            name: '首頁',
            position: 'left',
            component: HomeView,
        },
        {
            path: '/login',
            name: '登入',
            component: () => import('../views/LoginView.vue'),
        },
        {
            path: '/register',
            name: '註冊',
            component: () => import('../views/RegisterView.vue'),
        },
        {
            path: '/HotStock',
            name: '熱門股',
            position: 'left',
            component: () => import('../views/HotStockView.vue'),
        },
        {
            path: '/watchlist',
            name: '自選股',
            position: 'left',
            meta: { requiresAuth: true },
            component: () => import('../views/WatchlistView.vue'),
        },
        {
            path: '/learning',
            name: '學習股票',
            position: 'left',
            meta: { requiresAuth: true },
            component: () => import('../views/Learning.vue'),
        },
        {
            path: '/trading_platform',
            name: '模擬交易',
            position: 'left',
            meta: { requiresAuth: true },
            component: () => import('@/views/trading_platform/TradingPlatformLayout.vue'),
            children: [
                {
                    path: '',
                    redirect: '/trading_platform/trade',
                },
                {
                    path: 'trade',
                    name: 'TradingTrade',
                    component: () => import('@/views/trading_platform/TradeView.vue'),
                },
                {
                    path: 'portfolio',
                    name: 'TradingPortfolio',
                    component: () => import('@/views/trading_platform/PortfolioView.vue'),
                },
                {
                    path: 'history',
                    name: 'TradingHistory',
                    component: () => import('@/views/trading_platform/HistoryView.vue'),
                },
            ],
        },
        {
            path: '/section/:id',
            name: 'section-detail',
            component: () => import('@/views/SectionDetailView.vue'),
        },
        {
            path: '/stock',
            name: 'DemoStock',
            component: () => import('@/views/DemoStock.vue'),
        },
        {
            path: '/refresh',
            name: 'Refresh',
            component: {
                template: '<div></div>',
            },
        },
        {
            path: '/stock/:stockCode',
            name: 'SearchResult',
            component: () => import('@/views/SearchResultView.vue'),
            props: true,
        },
    ],
})

router.beforeEach((to, from, next) => {
    const userStore = useUserStore()
    const isAuthenticated = !!userStore.accessToken

    if (to.meta.requiresAuth) {
        if (!isAuthenticated) {
            userStore.showLoginRequiredToast()
            next({
                name: 'RequireLoginView',
                query: { redirect: to.fullPath },
            })
        } else {
            next()
        }
    } else if (to.name === 'RequireLoginView' && !isAuthenticated) {
        next()
    } else {
        next()
    }
})

export default router
