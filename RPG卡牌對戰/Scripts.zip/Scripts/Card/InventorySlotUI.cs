using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class InventorySlotUI : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerClickHandler
{
    [Header("UI Elements")]
    public Image iconImage;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI quantityText;
    public TextMeshProUGUI equippedCountText;

    [Header("Status Indicators")]
    public GameObject equippedIndicator;
    public GameObject selectionHighlight;

    private int myIndex;
    private InventoryUI uiManager;
    private Transform originalParent;
    private CanvasGroup canvasGroup;

    public void Setup(InventorySlot slot, int index, InventoryUI ui, bool isSelected)
    {
        myIndex = index;
        uiManager = ui;

        // 1. 顏色
        if (iconImage != null)
        {
            iconImage.sprite = null;
            iconImage.color = slot.itemData.displayColor;
        }

        // 2. ▼▼▼ 【修正】下方背包的數字顯示邏輯 ▼▼▼
        if (quantityText != null)
        {
            // 只有 消耗品 和 特殊物品 需要顯示庫存數量
            bool showQuantity = (slot.itemData.itemType == ItemType.Consumable ||
                                 slot.itemData.itemType == ItemType.Special);

            quantityText.gameObject.SetActive(showQuantity);

            if (showQuantity)
            {
                quantityText.text = slot.quantity.ToString();

                // 強制設定位置：右下角
                RectTransform rt = quantityText.rectTransform;
                if (rt != null)
                {
                    rt.anchorMin = new Vector2(1, 0);
                    rt.anchorMax = new Vector2(1, 0);
                    rt.pivot = new Vector2(1, 0);
                    rt.anchoredPosition = new Vector2(-5, 5);
                    rt.sizeDelta = new Vector2(100, 40);
                    quantityText.fontSize = 32;
                    quantityText.alignment = TextAlignmentOptions.BottomRight;
                    quantityText.color = Color.white;
                }
            }
        }

        // 名稱隱藏
        if (nameText) nameText.gameObject.SetActive(false);
        // 下方背包不需要顯示攜帶量文字 (Loadout區會顯示)
        if (equippedCountText != null) equippedCountText.gameObject.SetActive(false);

        // 3. 狀態顯示 (勾勾)
        if (equippedIndicator)
        {
            // 只要有攜帶就打勾
            equippedIndicator.SetActive(slot.equippedCount > 0);
        }

        if (selectionHighlight) selectionHighlight.SetActive(isSelected);

        canvasGroup = GetComponent<CanvasGroup>();
        if (canvasGroup == null) canvasGroup = gameObject.AddComponent<CanvasGroup>();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        uiManager.OnSlotClicked(myIndex);
    }

    // ... (拖曳邏輯保持不變) ...
    public void OnBeginDrag(PointerEventData eventData) { originalParent = transform.parent; transform.SetParent(transform.root); canvasGroup.blocksRaycasts = false; }
    public void OnDrag(PointerEventData eventData) { transform.position = eventData.position; }
    public void OnEndDrag(PointerEventData eventData)
    {
        transform.SetParent(originalParent);
        transform.localPosition = Vector3.zero;
        canvasGroup.blocksRaycasts = true;
        GameObject hitObject = eventData.pointerCurrentRaycast.gameObject;
        if (hitObject != null)
        {
            InventorySlotUI targetSlot = hitObject.GetComponentInParent<InventorySlotUI>();
            if (targetSlot != null && targetSlot != this)
            {
                InventoryManager.Instance.SwapItems(this.myIndex, targetSlot.myIndex);
                uiManager.RefreshUI();
            }
        }
    }
}