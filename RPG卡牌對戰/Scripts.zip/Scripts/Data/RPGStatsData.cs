// 檔案路徑: Assets/Scripts/RPGStatsData.cs
using UnityEngine;

[CreateAssetMenu(fileName = "RPGStatsData", menuName = "RPG/Character Stats Data")]
public class RPGStatsData : ScriptableObject
{
    [Header("HP 系統")]
    [Tooltip("HP 低於此值進入瀕死 (0<n<10)")]
    public int hpDyingThreshold = 10;

    [Header("MP 系統 (根據 RPG設計.docx v1)")]
    // ▼▼▼ 修正：初始 MP 改為 5 (根據 RPG設計.docx) ▼▼▼
    [Tooltip("角色的初始 MP")]
    public int mpInitial = 5; // <--- 從 30 改為 5
                              // ▲▲▲ 修正結束 ▲▲▲

    // ▼▼▼ 修正：T2=10, T3=15, 上限 30 (根據 RPG設計.docx) ▼▼▼
    [Tooltip("MP 每回合恢復的基數 (T2=10, T3=15...)")]
    public int mpRecoverBase = 5; // (註: 5 * 回合數)
    [Tooltip("MP 每回合恢復的上限")]
    public int mpRecoverCap = 30;
    // ▲▲▲ 修正結束 ▲▲▲

    [Tooltip("多少回合後，MP 恢復量變為 SuperAmount")]
    public int mpRecoverTurnsUntilSuper = 30;
    [Tooltip("超級 MP 恢復量")]
    public int mpRecoverSuperAmount = 60;

    [Header("負載 (Overload) 系統")]
    public int overloadThreshold1 = 200;
    [Tooltip("MP >= 200, 受到傷害轉為 10% 穿刺")]
    public float overloadPierceRatio1 = 0.10f;
    public int overloadThreshold2 = 300;
    [Tooltip("MP >= 300, 受到傷害轉為 15% 穿刺")]
    public float overloadPierceRatio2 = 0.15f;
    public int overloadThreshold3 = 400;
    [Tooltip("MP >= 400, 受到傷害轉為 30% 穿刺")]
    public float overloadPierceRatio3 = 0.30f;

    [Header("穿刺 (Pierce) 系統")]
    [Tooltip("穿刺對護甲造成的傷害比例 (70%)")]
    public float pierceArmorRatio = 0.7f;
    [Tooltip("穿刺對 HP 造成的傷害比例 (30%)")]
    public float pierceHpRatio = 0.3f;
    [Tooltip("穿刺觸發碎甲時，對 HP 造成的額外傷害比例 (60%)")]
    public float pierceBreakDamageRatio = 0.6f;
    [Tooltip("穿刺對 HP 造成的最小傷害")]
    public int pierceMinHpDamage = 1;

    [Header("流血 (Bleed) 狀態")]
    [Tooltip("每層流血在回合開始時造成的 HP 傷害")]
    public int bleedDamagePerStack = 10;
    [Tooltip("每回合自然削減的層數")]
    public int bleedDecayPerTurn = 1;

    [Header("中毒 (Poison) 狀態")]
    [Tooltip("每層中毒在回合開始時造成的 HP 傷害")]
    public int poisonDamagePerStack = 5;
    [Tooltip("中毒層數達到此值，無條件死亡")]
    public int poisonDeathStacks = 10;
    [Tooltip("每回合自然削減的層數")]
    public int poisonDecayPerTurn = 1;

    [Header("腐化 (Corruption) 狀態")]
    [Tooltip("每層腐化在回合開始時對護甲造成的傷害 (x1.3)")]
    public float corruptionArmorDamageRatio = 1.3f;
    [Tooltip("腐化狀態持續多少回合後，無條件碎甲")]
    public int corruptionAutoBreakTurns = 20;
    [Tooltip("每回合自然削減的層數 (你的文件沒寫，我預設為 1)")]
    public int corruptionDecayPerTurn = 1;
}