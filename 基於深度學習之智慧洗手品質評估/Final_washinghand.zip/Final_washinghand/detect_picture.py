import torch
from ultralytics import YOLO
import cv2
import os
import glob  # 用於查找匹配特定模式的文件

# --- 1. 配置與初始化 ---
# 設置設備 (CPU 或 GPU)
device = 'cuda:0' if torch.cuda.is_available() else 'cpu'

# 載入模型
model_path = 'best.pt'  # <<<<<< 請將此處替換為您的 YOLOv10 模型路徑
try:
    model = YOLO(model_path)
    model.to(device)  # 將模型移到指定設備
    print(f"🚀 模型 {model_path} 載入成功，正在使用 {device} 進行推論。")
except Exception as e:
    print(f"❌ 載入模型時發生錯誤：{e}")
    exit()

# 類別名稱與顏色 (請根據您的模型實際類別進行調整)
# 如果您的模型在訓練時定義了類別名稱，可以嘗試使用 model.names
class_names = ['left', 'right', 'all']
colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255)]  # 紅、綠、藍

# 偵測參數
CONF_THRESHOLD = 0.3  # 信心水準閾值
IMG_SIZE = 640  # 推論影像尺寸 (保持與訓練時一致)

# 📌 圖片輸入/輸出資料夾設定
INPUT_DIR = "C:\\Users\\otter\\Desktop\\detect_picture_dataset\\input"  # <<<<<< 包含待偵測圖片的資料夾
OUTPUT_DIR = 'output_results'  # <<<<<< 偵測結果將儲存到此資料夾
# -----------------------------

# 檢查/建立輸出資料夾
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)
    print(f"📁 已建立輸出資料夾：{OUTPUT_DIR}")

# 找出資料夾內所有圖片檔案
image_extensions = ('*.jpg', '*.jpeg', '*.png')
image_files = []
for ext in image_extensions:
    # 使用 os.path.join 確保路徑格式正確
    image_files.extend(glob.glob(os.path.join(INPUT_DIR, ext)))

if not image_files:
    print(f"⚠️ 在資料夾 {INPUT_DIR} 中找不到任何圖片檔案。請檢查路徑或檔案類型。")
    exit()

print(f"🔍 找到 {len(image_files)} 張圖片準備進行偵測...")

# --- 2. 批量推論循環 ---
for i, image_path in enumerate(image_files):
    print(f"--- 處理第 {i + 1}/{len(image_files)} 張圖片：{os.path.basename(image_path)} ---")

    # 讀取圖片
    frame = cv2.imread(image_path)
    if frame is None:
        print(f"❌ 無法讀取圖片：{image_path}，跳過。")
        continue

    # --- 3. YOLOv10 推論 ---
    # 使用 model.predict 進行推論
    results = model.predict(
        source=frame,
        imgsz=IMG_SIZE,
        conf=CONF_THRESHOLD,
        iou=0.45,
        device=device,
        verbose=False  # 禁用詳細輸出
    )

    # 取得第一個結果
    if results:
        res = results[0]
        h, w = frame.shape[:2]

        # 遍歷所有的偵測結果
        for box in res.boxes:
            # 獲取邊界框坐標 (xyxy 格式)
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())

            # 獲取信心水準和類別 ID
            conf = box.conf.item()
            cls = int(box.cls.item())

            # 取得類別名稱與顏色
            cls_name = class_names[cls] if cls < len(class_names) else f"Class {cls}"
            color = colors[cls % len(colors)]  # 根據類別選擇顏色

            # 繪製框與文字
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            label = f"{cls_name} {conf:.2f}"

            # 繪製文字
            text_y = y1 - 10 if y1 > 20 else y2 + 20
            cv2.putText(frame, label, (x1, text_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

    # --- 4. 儲存結果 ---
    # 構建輸出圖片路徑
    output_filename = os.path.basename(image_path)
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    # 儲存結果圖片
    cv2.imwrite(output_path, frame)
    print(f"✅ 偵測結果已儲存至：{output_path}")

print("\n🎉 所有圖片偵測完成！")

# 如果需要顯示最後一張處理的圖片，可以取消註釋以下程式碼
# cv2.imshow('Last Processed Image', frame)
# cv2.waitKey(0)
# cv2.destroyAllWindows()