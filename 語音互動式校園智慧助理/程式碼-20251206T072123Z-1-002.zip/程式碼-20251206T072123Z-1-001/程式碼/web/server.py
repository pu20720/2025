import asyncio
import os
import sys
from pathlib import Path
from typing import Optional
import tempfile

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, File, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn
from starlette.websockets import WebSocketState

# ========= 路徑與子程序設定 =========
ROOT = Path(__file__).parent.resolve()

# LLM+TTS 主程式位置
CHILD_SCRIPT = Path(r"F:\test\llm+tts+unity+http--.py")

PYTHON_EXE = sys.executable

# 設定檔放在 server.py 同資料夾）
CONFIG_PATH = ROOT / "runtime_config.json"

# 子程序啟動指令
CHILD_CMD = [
    PYTHON_EXE,
    "-u",
    str(CHILD_SCRIPT),
    "--config",
    str(CONFIG_PATH),
]
# ===================================


app = FastAPI()
app.mount("/static", StaticFiles(directory=str(ROOT / "static")), name="static")

PROMPT_BANNER = "輸入文字："


@app.get("/")
async def index():
    return FileResponse(ROOT / "index.html")


# ---------------- 狀態管理 ----------------
class AppState:
    def __init__(self):
        self.ready: bool = False          # 模型是否就緒
        self.generating: bool = False     # 是否正在回覆中
        self.accumulated_text: str = ""   # (可選) 緩存 delta，用不到也保留
        self.final_sent: bool = False     # 是否已送過 final
        self.lock = asyncio.Lock()

    async def snapshot(self):
        async with self.lock:
            return {
                "ready": self.ready,
                "generating": self.generating
            }


state = AppState()


# ---------------- WebSocket Hub ----------------
class Hub:
    def __init__(self):
        self.clients: set[WebSocket] = set()

    async def broadcast_json(self, payload: dict):
        stale = []
        for ws in list(self.clients):
            try:
                if ws.application_state == WebSocketState.CONNECTED:
                    await ws.send_json(payload)
                else:
                    stale.append(ws)
            except Exception:
                stale.append(ws)
        for ws in stale:
            self.clients.discard(ws)


hub = Hub()


# ---------------- 子程序 ----------------
class ChildProc:
    def __init__(self, cmd, workdir: Path):
        self.cmd = cmd
        self.workdir = workdir
        self.proc: Optional[asyncio.subprocess.Process] = None
        self._pump_tasks: list[asyncio.Task] = []

    def is_running(self) -> bool:
        return self.proc is not None and self.proc.returncode is None

    async def ensure_started(self):
        if self.is_running():
            return
        env = {
            **os.environ,
            "PYTHONIOENCODING": "utf-8",
            "PYTHONUNBUFFERED": "1",
        }
        print("[bridge] Spawning child process…", flush=True)
        self.proc = await asyncio.create_subprocess_exec(
            *self.cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(self.workdir),  #  固定用 ROOT 當工作目錄
            env=env,
        )
        async with state.lock:
            state.ready = False
            state.generating = False
            state.accumulated_text = ""
            state.final_sent = False
        self._pump_tasks = [
            asyncio.create_task(
                self._pump_stream(self.proc.stdout, "[child][OUT] ", detect_ready=True)
            ),
            asyncio.create_task(
                self._pump_stream(self.proc.stderr, "[child][ERR] ", detect_ready=False)
            ),
        ]

    async def _pump_stream(self, stream: asyncio.StreamReader, prefix: str, detect_ready: bool):
        buf = ""
        try:
            while True:
                chunk = await stream.read(1024)
                if not chunk:
                    break
                try:
                    text = chunk.decode("utf-8", errors="replace")
                except Exception:
                    text = str(chunk)
                print(prefix + text, end="", flush=True)

                if detect_ready:
                    buf += text
                    # 看到 LLM 印出「輸入文字：」就當作 ready
                    if PROMPT_BANNER in buf:
                        async with state.lock:
                            state.ready = True
                            state.generating = False
                        buf = buf[-2048:]
        except Exception as e:
            print(f"[bridge] pump error: {e}", flush=True)
        finally:
            if self.proc and self.proc.returncode is not None:
                print(f"[bridge] child exited with code {self.proc.returncode}", flush=True)
                async with state.lock:
                    state.ready = False
                    state.generating = False
                    state.accumulated_text = ""
                    state.final_sent = False

    async def send_user_text(self, text: str):
        await self.ensure_started()
        if not self.proc or not self.proc.stdin:
            raise RuntimeError("child stdin 不可用")
        line = (text.strip() + "\n").encode("utf-8", errors="ignore")
        self.proc.stdin.write(line)
        await self.proc.stdin.drain()


# 建立子程序管理器（工作目錄用 ROOT）
child = ChildProc(CHILD_CMD, ROOT)


# -------- 啟動時預熱模型 --------
@app.on_event("startup")
async def _prewarm_child():
    await child.ensure_started()
    print("[bridge] child prewarmed at startup.", flush=True)


@app.get("/status")
async def status():
    snap = await state.snapshot()
    return JSONResponse({
        "ready": snap["ready"],
        "generating": snap["generating"],
        "clients": len(hub.clients)
    })


# ---------------- Whisper STT（本地 faster-whisper） ----------------
try:
    from faster_whisper import WhisperModel
    import torch

    print("[whisper] Loading local Whisper model (small)...", flush=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    whisper_model = WhisperModel("small", device=device)
    print(f"[whisper] Model ready on {device}.", flush=True)
except Exception as e:
    whisper_model = None
    print(f"[whisper] Local model load failed: {e}", flush=True)


@app.post("/stt")
async def speech_to_text(file: UploadFile = File(...)):
    if whisper_model is None:
        return {"error": "Whisper model not loaded"}
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    try:
        content = await file.read()
        tmp.write(content)
        tmp.close()
        segments, _ = whisper_model.transcribe(tmp.name, beam_size=5)
        text = "".join([s.text for s in segments]).strip()
        print(f"[whisper] STT result: {text}", flush=True)
        return {"text": text}
    finally:
        try:
            os.remove(tmp.name)
        except Exception:
            pass


# ---------------- LLM 主動推送：用 final 當唯一輸出 ----------------
class PushPayload(BaseModel):
    event: str   # "start" | "delta" | "final" | "done" | "error"
    text: str = ""


@app.post("/push")
async def push(payload: PushPayload, request: Request):
    
    if payload.event in ("start", "delta", "final", "done", "error"):
        preview = payload.text.replace("\n", "\\n")
        if len(preview) > 120:
            preview = preview[:120] + "…"
        print(f"[push] {payload.event}: {preview}", flush=True)

    if payload.event == "start":
        
        async with state.lock:
            state.generating = True
            state.ready = False
            state.accumulated_text = ""
            state.final_sent = False
        return {"ok": True}

    if payload.event == "delta":
        
        async with state.lock:
            state.accumulated_text += payload.text
        return {"ok": True}

    if payload.event == "final":
        
        final_text = payload.text or ""
        ）
        if not final_text:
            async with state.lock:
                final_text = state.accumulated_text
        if final_text:
            await hub.broadcast_json({
                "role": "assistant",
                "event": "delta",
                "text": final_text
            })
        async with state.lock:
            state.final_sent = True
        return {"ok": True}

    if payload.event == "done":
        
        await hub.broadcast_json({
            "role": "assistant",
            "event": "done",
            "text": ""
        })
        async with state.lock:
            state.generating = False
            state.ready = True
            state.accumulated_text = ""
            state.final_sent = False
        return {"ok": True}

    if payload.event == "error":
        # 顯示錯誤並重置狀態
        await hub.broadcast_json({
            "role": "assistant",
            "event": "error",
            "text": payload.text or "發生錯誤"
        })
        async with state.lock:
            state.generating = False
            state.ready = True
            state.accumulated_text = ""
            state.final_sent = False
        return {"ok": True}

    return {"ok": True}


# ---------------- 前端 WebSocket ----------------
@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    client_ip = ws.client.host
    print(f"[bridge] WebSocket connected from {client_ip}", flush=True)

    await ws.accept()
    hub.clients.add(ws)
    await child.ensure_started()
    await ws.send_json({
        "role": "system",
        "event": "info",
        "text": "已連線。輸入訊息以開始。"
    })

    try:
        while True:
            data = await ws.receive_text()
            msg = data.strip()
            if not msg:
                continue
            print(f"[user_msg] {msg}", flush=True)  # 給 launcher 解析用
            snap = await state.snapshot()
            if not snap["ready"]:
                await ws.send_json({
                    "role": "system",
                    "event": "busy",
                    "text": "系統載入或整理中，請稍候…"
                })
                continue
            if snap["generating"]:
                await ws.send_json({
                    "role": "system",
                    "event": "busy",
                    "text": "系統正在回覆中，請稍候…"
                })
                continue

            # 標記開始生成
            async with state.lock:
                if not state.ready or state.generating:
                    await ws.send_json({
                        "role": "system",
                        "event": "busy",
                        "text": "系統忙碌，請稍候…"
                    })
                    continue
                state.generating = True
                state.ready = False
                state.accumulated_text = ""
                state.final_sent = False

            
            await hub.broadcast_json({
                "role": "user",
                "event": "message",
                "text": msg
            })

            # 把訊息寫給子程式（llm+tts 主程式）
            await child.send_user_text(msg)

            # 
            await hub.broadcast_json({
                "role": "assistant",
                "event": "start",
                "text": ""
            })

    except WebSocketDisconnect:
        pass
    finally:
        hub.clients.discard(ws)


# ---------------- 啟動 ----------------
if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,  
        log_level="info",
        access_log=False,
        # ssl_keyfile=r"F:\certs\key.pem",
        # ssl_certfile=r"F:\certs\cert.pem",
    )
