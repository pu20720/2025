package com.example.uimo

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody

// --- UIの状態を表現するクラス ---
sealed class UiState {
    object Idle : UiState()
    object Uploading : UiState()
    data class Processing(val jobId: String) : UiState()
    data class Complete(val resultVideoUrl: String) : UiState()
    data class Error(val message: String) : UiState()
}

class ThirdViewModel : ViewModel() {
    private val apiService = RetrofitClient.instance
    val uiState = mutableStateOf<UiState>(UiState.Idle)



    fun startProcessing(context: Context, videoUri: Uri, cornersJson: String) {
        viewModelScope.launch(Dispatchers.IO) {
            Log.d("ViewModelTrace", "startProcessing called.")
            if (uiState.value is UiState.Uploading || uiState.value is UiState.Processing) {
                return@launch
            }
            uiState.value = UiState.Uploading

            try {
                // 動画を「ByteArray」（バイト配列）としてメモリに読み込む
                val inputStream = context.contentResolver.openInputStream(videoUri)
                val videoBytes = inputStream?.readBytes() ?: run {
                    uiState.value = UiState.Error("動画ファイルの読み込みに失敗しました。")
                    return@launch
                }
                inputStream.close()
                val fileName = getFileName(context, videoUri)
                val videorequestBody = videoBytes.toRequestBody("video/mp4".toMediaTypeOrNull())
                val videoPart = MultipartBody.Part.createFormData("video", fileName, videorequestBody)


                Log.d("ViewModelTrace", "Uploading video now...")


                // 3. 座標JSONをリクエストの「パート」として作成
                val cornersRequestBody = cornersJson.toRequestBody("application/json".toMediaTypeOrNull())

                // 4. APIを呼び出し (引数が videoPart と cornersPart の2つに増える)
                val uploadResponse = apiService.uploadVideo(videoPart, cornersRequestBody)

                if (uploadResponse.isSuccessful && uploadResponse.body() != null) {
                    val jobId = uploadResponse.body()!!.job_id
                    Log.d("ViewModelTrace", "Upload successful. Job ID: $jobId")
                    uiState.value = UiState.Processing(jobId)
                    Log.d("ViewModelTrace", "Starting to poll status...")
                    pollStatus(jobId)
                } else {
                    Log.e("ViewModelTrace", "Upload failed: ${uploadResponse.message()}")
                    uiState.value = UiState.Error("アップロードに失敗: ${uploadResponse.message()}")
                }
            } catch (e: Exception) {
                Log.e("ViewModelTrace", "An exception occurred in startProcessing", e)
                uiState.value = UiState.Error("通信エラー: ${e.message}")
            }
        }
    }

    private fun pollStatus(jobId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            Log.d("ViewModelTrace", "pollStatus function has started for Job ID: $jobId")

            // --- ↓↓↓ ループのロジックを修正 ↓↓↓ ---
            var keepPolling = true
            while (keepPolling) {
                try {
                    val statusResponse = apiService.getStatus(jobId)
                    if (statusResponse.isSuccessful && statusResponse.body() != null) {
                        val status = statusResponse.body()!!
                        // --- ↓↓↓ ここにログを追加 ↓↓↓ ---
                        Log.d("ViewModelTrace", "Polling... Received status: ${status.status}")

                        when (status.status) {
                            "complete" -> {
                                val videoName = status.result_video_name
                                if (videoName != null) {
                                    val resultUrl = "${RetrofitClient.BASE_URL}download/video/$videoName"
                                    Log.d("ViewModelTrace", "Status is complete! URL: $resultUrl")
                                    uiState.value = UiState.Complete(resultUrl)
                                } else {
                                    uiState.value = UiState.Error("分析完了後、結果ファイル名がnullでした。")
                                }
                                keepPolling = false // ループを終了させる
                            }
                            "error" -> {
                                uiState.value = UiState.Error("サーバー分析エラー: ${status.message}")
                                keepPolling = false // ループを終了させる
                            }
                            "processing" -> {
                                // 処理中の場合は何もしない
                            }
                        }
                    } else {
                        uiState.value = UiState.Error("ステータス確認に失敗: ${statusResponse.message()}")
                        keepPolling = false // エラー時もループを終了させる
                    }
                } catch (e: Exception) {
                    Log.e("ViewModelTrace", "An exception occurred during polling", e)
                    uiState.value = UiState.Error("ステータス確認中に通信エラー: ${e.message}")
                    keepPolling = false // 例外発生時もループを終了させる
                }

                if (keepPolling) {
                    delay(15000)
                }
            }
            Log.d("ViewModelTrace", "Polling loop has finished.")
        }
    }

    private fun getFileName(context: Context, uri: Uri): String {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        result = cursor.getString(nameIndex)
                    }
                }
            }
        }
        return result ?: "upload.mp4"
    }
}

