<template>
    <div class="max-w-6xl mx-auto md:p-6 bg-white shadow-lg rounded-xl">
        <div
            class="flex flex-col sm:flex-row items-center justify-between mb-6 space-y-4 sm:space-y-0"
        >
            <div>
                <h1 class="text-3xl md:text-5xl font-bold">
                    {{ company ? company.name : '載入中...' }}
                </h1>
                <h3 class="text-xl md:text-3xl font-bold">
                    股票代碼：{{ company ? company.symbol : '載入中...' }}
                </h3>
                <!-- <p class="text-gray-500 text-sm mt-1">更新時間：{{ lastUpdated }}</p> -->
            </div>
            <div
                @click="goBack"
                class="flex items-center justify-center space-x-2 px-6 py-2 text-black rounded-lg transition duration-150 ease-in-out font-semibold text-lg hover:bg-gray-200 cursor-pointer"
            >
                <svg
                    class="w-5 h-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M10 19l-7-7m0 0l7-7m-7 7h18"
                    ></path>
                </svg>
                <span>返回</span>
            </div>
        </div>
        <!-- K 線圖呈現區塊 -->
        <Stockdata :stockCode="stockCode" />
        <!-- 公司簡介 -->
        <CompanyInfo />
    </div>
</template>

<script setup>
    import { ref, computed, watch } from 'vue'
    import { useRouter, useRoute } from 'vue-router'
    import Stockdata from '@/components/Stock/Stockdata.vue'
    import CompanyInfo from '@/components/Stock/CompanyInfo.vue'
    import { useStockSearch } from '@/stores/stockSearch.js'

    const dates = ref([]) // 由 KLineChart 回傳，共用給 TechIndicatorChart

    const router = useRouter()
    const route = useRoute()

    // 只保留必要的 reactive 狀態
    const stockCode = computed(() => route.params.stockCode)

    // 假設這裡的 lastUpdated 是一個獨立的計時器或由其他資料源提供
    const lastUpdated = new Date().toLocaleString()

    const { getPickedStock } = useStockSearch()

    const company = ref(null)
    const loading = ref(true)

    // 直接監聽路由參數並發送請求
    watch(
        () => route.params.stockCode,
        async (newStockCode) => {
            // 呼叫函式獲取資料，並直接假設成功
            const result = await getPickedStock(newStockCode)

            // 從陣列中取出第一個物件
            company.value = result[0]
            if (company.value) {
                loading.value = false
            }
        },
        { immediate: true },
    )
    function goBack() {
        router.go(-1)
    }
</script>
