<script setup>
    import { ref, computed, watch, onMounted } from 'vue'
    import { useToast } from 'primevue/usetoast'
    import '../assets/scroll.css'

    const toast = useToast()
    const activeTab = ref('learn')

    // 🔹 初始章節資料
    const sections = ref([
        {
            title: '開始投資以前，你需要知道的事',
            points: [
                '開戶前的準備條件',
                '選擇證券商',
                '線上開戶流程',
                '臨櫃開戶流程',
                '開戶完成後建議',
            ],
            completed: false,
        },
        {
            title: '股票基本知識',
            points: ['股票是甚麼', '定義與種類', '股票的三種價值', '股票上市來源分類'],
            completed: false,
        },
        {
            title: '臺灣股票市場',
            points: ['上市上櫃興櫃股票', '三大常見的股票入門相關商品', '股票買賣單位', '三大法人'],
            completed: false,
        },
        {
            title: '股票交易',
            points: ['股票交易時間', '委託條件', '交易種類', '交割制度（T+2）'],
            completed: false,
        },
        {
            title: '股利與權益',
            points: ['股利種類與意義', '除權息與參考價計算'],
            completed: false,
        },
        {
            title: '股票線圖基礎',
            points: ['股票線圖介紹', 'K 線圖基礎', '成交量與均線', '技術指標簡介', '多頭空頭'],
            completed: false,
        },
    ])

    // 🔹 成就清單
    const completedSections = computed(() => sections.value.filter((s) => s.completed))

    // 🔹 完成百分比
    const completionRate = computed(
        () => (completedSections.value.length / sections.value.length) * 100,
    )

    // 🔹 標記章節完成
    const completeSection = (index) => {
        if (!sections.value[index].completed) {
            sections.value[index].completed = true
            toast.add({
                severity: 'success',
                summary: '完成章節',
                detail: `恭喜完成「${sections.value[index].title}」！🎉`,
                life: 2000,
            })
        }
    }

    // 🔹 儲存進度
    watch(
        sections,
        (val) => {
            localStorage.setItem('learnSections', JSON.stringify(val))
        },
        { deep: true },
    )

    // 🔹 載入進度
    onMounted(() => {
        const saved = localStorage.getItem('learnSections')
        if (saved) sections.value = JSON.parse(saved)
    })

    // 🔹 標籤樣式
    const tabClass = (tab) =>
        `px-4 py-2 rounded-full font-semibold ${
            activeTab.value === tab
                ? 'bg-custom-purple text-white text-xl px-6 py-3'
                : 'bg-gray-200 text-gray-700 text-xl px-6 py-3 hover:bg-gray-300'
        }`
</script>

<template>
    <div class="max-w-7xl mx-auto p-6 bg-gray-100 text-gray-800 hide-scrollbar">
        <header class="text-center mb-10">
            <h1 class="text-4xl font-bold mb-2">📈 飆股教科書</h1>
            <p class="text-lg text-gray-600">從零開始，打造你的第一筆股票投資</p>
        </header>

        <!-- 頁籤 -->
        <nav class="flex justify-center mb-8 space-x-6">
            <button @click="activeTab = 'learn'" :class="tabClass('learn')">學習內容</button>
            <button @click="activeTab = 'goals'" :class="tabClass('goals')">成就達成</button>
        </nav>

        <!-- 學習頁 -->
        <section v-if="activeTab === 'learn'" class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div
                v-for="(section, index) in sections"
                :key="index"
                class="bg-white rounded-2xl shadow p-5 flex flex-col justify-between h-[360px]"
            >
                <div>
                    <h2 class="text-2xl font-semibold mb-3">
                        {{ section.title }}
                        <span
                            v-if="section.completed"
                            class="text-green-600 text-sm ml-2 font-medium"
                            >✔ 已完成</span
                        >
                    </h2>
                    <ul class="list-disc pl-5 space-y-1">
                        <li v-for="(point, i) in section.points" :key="i">{{ point }}</li>
                    </ul>
                </div>

                <div class="flex justify-between mt-4">
                    <router-link
                        :to="`/section/${index}`"
                        class="px-4 py-2 rounded bg-custom-purple text-white hover:bg-violet-custom text-center"
                    >
                        進入課程
                    </router-link>
                    <button
                        v-if="!section.completed"
                        @click="completeSection(index)"
                        class="px-4 py-2 rounded bg-green-500 text-white hover:bg-green-600 focus:outline-none"
                    >
                        ✅ 標記完成
                    </button>
                </div>
            </div>
        </section>

        <!-- 成就頁 -->
        <section v-if="activeTab === 'goals'" class="bg-white rounded-2xl shadow p-6">
            <h2 class="text-2xl font-semibold mb-4">📜 已完成項目</h2>

            <!-- 進度條 -->
            <div class="w-full bg-gray-200 h-3 rounded mb-4">
                <div
                    class="bg-green-500 h-3 rounded transition-all duration-500"
                    :style="{ width: `${completionRate}%` }"
                ></div>
            </div>
            <p class="text-sm mb-4 text-gray-500">
                完成進度：{{ completedSections.length }} / {{ sections.length }}
            </p>

            <!-- 已完成清單 -->
            <ul v-if="completedSections.length" class="list-disc pl-5 space-y-1">
                <li v-for="section in completedSections" :key="section.title">
                    {{ section.title }}
                </li>
            </ul>
            <p v-else class="text-gray-500">尚未完成任何學習內容，請從學習頁開始！</p>

            <div v-if="completedSections.length === sections.length" class="mt-6 text-center">
                <p class="text-green-600 font-semibold text-xl">🎉 恭喜完成所有課程！</p>
            </div>
        </section>

        <footer class="mt-10 text-center text-sm text-gray-500">© 2025 股票學習網。</footer>
    </div>

    <Toast position="bottom-left" />
</template>
