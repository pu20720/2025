import logging
from stocks.models import Stock
from transaction.models import Portfolio
from django.core.management.base import BaseCommand
from stocks.services.compute_hotstock import compute_hotstock
from stocks_price.services.import_yesterday_price import import_yesterday_price

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = '匯入昨天股票價格資料'

    def handle(self, *args, **kwargs):
        for stock in Stock.objects.order_by('symbol'):
            symbol = stock.symbol
            result = import_yesterday_price(symbol)
            logger.info(f'[每日匯入]{symbol} 處理結果: {result}')
            self.stdout.write(f'[每日匯入]{symbol} 處理結果: {result}')
        compute_hotstock()
        portfolios = Portfolio.objects.all()
        for p in portfolios:
            p.update_metrics()
