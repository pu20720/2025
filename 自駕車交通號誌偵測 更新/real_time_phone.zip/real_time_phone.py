from ultralytics import YOLO
import cv2
import time
import threading
import os

# ==================== 載入模型 ====================
model_path = r"C:\Users\hnm\Desktop\python\runs\detect\traffic_sign\weights\best.pt"
model = YOLO(model_path)

# ==================== 中文女生語音（最簡單最穩版） ====================
last_spoken = ""  # 記住上次說過的話
speaking = False  # 正在說話中，避免重疊

def speak(text):
    global last_spoken, speaking
    if text == last_spoken or speaking:  # 不重複、不疊加
        return
    last_spoken = text
    speaking = True
    # 只用系統預設中文女生（100% 一定有）
    cmd = f'powershell -Command "Add-Type -AssemblyName System.Speech; ' \
          f'$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer; ' \
          f'$synth.Speak(\'{text}\')"'
    def run():
        global speaking
        os.system(cmd)
        speaking = False
    threading.Thread(target=run, daemon=True).start()

# ==================== 攝像頭與錄影 ====================
cap = cv2.VideoCapture(0)
cap.set(3, 640); cap.set(4, 480)
out = cv2.VideoWriter('報告錄影.avi', cv2.VideoWriter_fourcc(*'MJPG'), 30, (640, 480))

conf_threshold = 0.7
fps_smoothed = 0.0
fps_filter = 0.9
last_detected_set = set()  # 記住上次看到的標誌

print("系統啟動完成！女生語音已準備好～ 按 q 結束")

# ==================== 主迴圈 ====================
while cap.isOpened():
    ret, frame = cap.read()
    if not ret: continue

    start = time.time()

    results = model.predict(frame, imgsz=640, conf=conf_threshold, device="0", verbose=False)
    
    annotated = results[0].plot()
    annotated = cv2.cvtColor(annotated, cv2.COLOR_RGB2BGR)
    annotated = annotated.copy()

    names = []
    stop = False
    if results[0].boxes is not None:
        for box in results[0].boxes:
            name = model.names[int(box.cls[0])]
            names.append(name)
            if "停止" in name:
                stop = True
                x1,y1,x2,y2 = map(int, box.xyxy[0])
                cv2.rectangle(annotated, (x1,y1), (x2,y2), (0,0,255), 8)
                cv2.putText(annotated, "STOP!", (x1, y1-30), 
                           cv2.FONT_HERSHEY_DUPLEX, 2.5, (0,0,255), 6)

    # 語音（只說一次，停止立刻喊）
    current_set = set(names)
    if results[0].boxes is not None and len(results[0].boxes) > 0:
        if stop:
            speak("停止！前方有停止標誌！")
            last_detected_set = current_set
        else:
            if current_set != last_detected_set:
                speak("偵測到" + "、".join(list(current_set)))
                last_detected_set = current_set
    else:
        last_detected_set = set()

    # FPS 小字
    fps = 1.0 / (time.time() - start + 1e-6)
    fps_smoothed = fps_filter * fps_smoothed + (1 - fps_filter) * fps
    cv2.putText(annotated, f"FPS {fps_smoothed:.1f}  Conf {conf_threshold:.2f}", 
                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (100, 255, 100), 2)

    cv2.imshow("交通標誌辨識", annotated)
    out.write(annotated)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'): break
    elif key == ord('+'): conf_threshold = min(1.0, conf_threshold + 0.05)
    elif key == ord('-'): conf_threshold = max(0.1, conf_threshold - 0.05)

# 結束
speak("系統已關閉")
cap.release(); out.release(); cv2.destroyAllWindows()
print("結束！錄影已儲存為「報告錄影.avi」")