package com.example.uimo

import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import androidx.navigation.NavHostController

class CourtSetupViewModel : ViewModel() {

    // ユーザーがタップした座標を保存するリスト
    val courtPoints = mutableStateListOf<Offset>()

    // タップされた点をリストに追加する関数
    fun addCourtPoint(point: Offset) {
        if (courtPoints.size < 4) {
            courtPoints.add(point)
        }
    }

    // ポイントをリセットする関数
    fun resetCourtPoints() {
        courtPoints.clear()
    }

    // ThirdScreenへ遷移する関数
    fun navigateToThirdScreen(navController: NavHostController, videoUri: Uri) {
        if (courtPoints.size != 4) return // 4点でなければ何もしない

        // 1. 座標データをJSON文字列に変換
        val cornersJson = """
            {
                "topLeft": {"x": ${courtPoints[0].x}, "y": ${courtPoints[0].y}},
                "topRight": {"x": ${courtPoints[1].x}, "y": ${courtPoints[1].y}},
                "bottomRight": {"x": ${courtPoints[2].x}, "y": ${courtPoints[2].y}},
                "bottomLeft": {"x": ${courtPoints[3].x}, "y": ${courtPoints[3].y}}
            }
        """.trimIndent()

        // 2. URIとJSONをエンコード（URLに含めるため）
        val encodedVideoUri = Uri.encode(videoUri.toString())
        val encodedCornersJson = Uri.encode(cornersJson)

        // 3. AppNavigationで定義したルートでThirdScreenへ遷移
        navController.navigate("third/$encodedVideoUri/$encodedCornersJson")
    }
}
