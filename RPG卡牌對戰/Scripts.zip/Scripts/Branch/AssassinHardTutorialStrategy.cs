// 檔案路徑: Assets/Scripts/SceneManagers/Branch/AssassinHardTutorialStrategy.cs
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

// (Enum - 完整保留)
public enum AssassinHardTutorialStep
{
    None,
    Start_0_Intro,
    Start_1_PlayerCheck,
    Start_2_PlayerCheck,
    Start_3_Rules,
    Start_4_Rules,
    Start_5_Rules,
    Start_6_PlayerReady,
    Start_7_PlayerAttackIntro,
    Start_8_PlayerAttackIntro,
    WaitForCleave,
    Cleave_1_After,
    Cleave_2_ThreefoldIntro,
    Cleave_3_ThreefoldIntro,
    WaitForThreefold,
    Threefold_1_After,
    Threefold_2_Observe,
    Threefold_3_Observe,
    WaitForEndTurn1,
    Enemy_1_Turn,
    Turn2_0_SharpenIntro,
    Turn2_1_SharpenIntro,
    WaitForSharpen,
    Sharpen_1_After,
    Sharpen_2_BladeIntro,
    Sharpen_3_BladeIntro,
    WaitForSharpBlade,
    Blade_1_After,
    Blade_2_EndTurn,
    WaitForEndTurn2,
    Enemy_2_Turn,
    Turn3_0_PostScratch,
    Turn3_1_CleanseIntro,
    WaitForDivineRadiance,
    Divine_1_After,
    Divine_2_FortifyIntro,
    WaitForFortifyArmor,
    Fortify_1_After,
    FreePlay_0_Intro,
    FreePlay,
    ArmorBreak_0_Advantage,
    ArmorBreak_1_Mechanic,
    Dying_0_Player,
    Dying_1_Player,
    Dying_2_Action,
    Dying_3_Player,
    Dying_4_Enemy,
    LastEnemyStanding
}


public class AssassinHardTutorialStrategy : BranchStrategy
{
    // (保留 Hard 版的變數)
    private List<Character> targetEnemies = new List<Character>();
    private Character currentDyingEnemy = null;
    private AssassinHardTutorialStep currentTutorialStep = AssassinHardTutorialStep.None;

    private bool hasShownLowMPWarning = false;
    private bool hasShownOverloadWarning = false;
    private bool hasTriggeredArmorBreakDialogue = false;
    private bool hasTriggeredDyingSequence = false;
    private bool hasTriggeredLastEnemyDialogue = false;

    // 1. 初始化
    public override void Initialize(BattleManager battleManager, Character player, List<Character> enemies)
    {
        base.Initialize(battleManager, player, enemies);
        this.targetEnemies = enemies.Where(e => e.characterName == "Assassin").ToList();

        foreach (var enemy in this.targetEnemies)
        {
            if (enemy != null && enemy.stats != null)
            {
                enemy.stats.OnDowned += () => OnEnemyDowned(enemy);
            }
        }
    }

    // 2. 事件：戰鬥開始
    public override void OnBattleStart()
    {
        currentTutorialStep = AssassinHardTutorialStep.Start_0_Intro;
        battleManager.ShowTutorialDialogue("Assassin", "Take your junk and prepare to die!");
    }

    // 2. 事件：玩家回合開始
    public override void OnPlayerTurnStart()
    {
        if (currentTutorialStep == AssassinHardTutorialStep.Enemy_1_Turn)
        {
            AdvanceTutorial(currentTutorialStep);
        }
        else if (currentTutorialStep == AssassinHardTutorialStep.Enemy_2_Turn)
        {
            AdvanceTutorial(currentTutorialStep);
        }
    }

    // 2. 事件：敵人行動
    public override void OnEnemyAction(EnemyAI ai, Character playerTarget)
    {
        if (currentTutorialStep == AssassinHardTutorialStep.Enemy_1_Turn)
        {
        }
        else if (currentTutorialStep == AssassinHardTutorialStep.Enemy_2_Turn)
        {
        }
    }


    // 2. 事件：Update
    public override void OnUpdate()
    {
        if (player == null || player.stats == null) return;

        // (低魔力警告)
        CardDisplay selectedCard = battleManager.GetSelectedCardDisplay();
        if (!hasShownLowMPWarning && selectedCard != null)
        {
            CardData card = selectedCard.GetCardData();
            if (card != null && player.stats.mp < card.mpCost)
            {
                hasShownLowMPWarning = true;
                battleManager.ShowTutorialDialogue("Player", "My magic teacher always told me not to use mana recklessly, but I still forget...");
            }
        }

        // (過載警告)
        if (!hasShownOverloadWarning && player.stats.mp >= 200)
        {
            hasShownOverloadWarning = true;
            battleManager.ShowTutorialDialogue("Player", "Overloaded already? You've got to be kidding me. Better play some cards quickly...");
        }

        // (碎甲對話)
        if (!hasTriggeredArmorBreakDialogue && currentTutorialStep == AssassinHardTutorialStep.FreePlay)
        {
            if (targetEnemies.Any(e => e.stats.helmet.isBroken || e.stats.armor.isBroken || e.stats.gauntlets.isBroken || e.stats.legArmor.isBroken))
            {
                hasTriggeredArmorBreakDialogue = true;
                currentTutorialStep = AssassinHardTutorialStep.ArmorBreak_0_Advantage;
                AdvanceTutorial(currentTutorialStep);
            }
        }

        // (最後一個敵人警告)
        if (!hasTriggeredLastEnemyDialogue && currentTutorialStep == AssassinHardTutorialStep.FreePlay)
        {
            if (this.enemies.Count(e => e != null && !e.stats.isDead) == 1)
            {
                hasTriggeredLastEnemyDialogue = true;
                currentTutorialStep = AssassinHardTutorialStep.LastEnemyStanding;
                AdvanceTutorial(currentTutorialStep);

                var lastEnemy = this.enemies.FirstOrDefault(e => e != null && !e.stats.isDead);
                if (lastEnemy != null)
                {
                    var ai = lastEnemy.GetComponent<EnemyAI>();
                    if (ai != null)
                    {
                        ai.SetLastEnemyMode();
                    }
                }
            }
        }
    }


    // 3. 驗證：點擊卡牌 (使用 Knight 的 card.type 邏輯)
    public override bool ValidateCardClick(CardData card)
    {
        switch (currentTutorialStep)
        {
            case AssassinHardTutorialStep.WaitForCleave:
                if (card.type == CardType.Attack) return true;
                break;
            case AssassinHardTutorialStep.WaitForThreefold:
                if (card.type == CardType.Conditional) return true;
                break;
            case AssassinHardTutorialStep.WaitForSharpen:
                if (card.type == CardType.Buff) return true;
                if (card.type == CardType.Weapon && battleManager.GetSelectedCardDisplay() != null && battleManager.GetSelectedCardDisplay().GetCardData().type == CardType.Buff)
                {
                    return true;
                }
                break;
            case AssassinHardTutorialStep.WaitForSharpBlade:
                if (card.type == CardType.Weapon) return true;
                break;
            case AssassinHardTutorialStep.WaitForDivineRadiance:
                if (card.type == CardType.Magic) return true;
                break;
            case AssassinHardTutorialStep.WaitForFortifyArmor:
                if (card.type == CardType.Armor) return true;
                break;
            case AssassinHardTutorialStep.FreePlay:
                return true;
        }

        battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
        return false;
    }

    // 3. 驗證：結束回合
    public override bool ValidateEndTurn()
    {
        if (currentTutorialStep == AssassinHardTutorialStep.WaitForEndTurn1)
        {
            currentTutorialStep = AssassinHardTutorialStep.Enemy_1_Turn;
            return true;
        }
        if (currentTutorialStep == AssassinHardTutorialStep.WaitForEndTurn2)
        {
            currentTutorialStep = AssassinHardTutorialStep.Enemy_2_Turn;
            return true;
        }
        if (currentTutorialStep == AssassinHardTutorialStep.FreePlay)
        {
            return true;
        }

        if (hasTriggeredDyingSequence)
        {
            return false;
        }

        battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
        return false;
    }


    // 4. 覆蓋：點擊目標 (使用 Knight 的 card.type 邏輯)
    public override bool HandleTargetClick(CardData card, TargetIndicator target)
    {
        if (card == null || target == null) return false;

        bool isAttackCard = (card.type == CardType.Attack || card.type == CardType.Weapon);
        bool isInstructionalOrFreeplay =
            (currentTutorialStep >= AssassinHardTutorialStep.WaitForCleave && currentTutorialStep <= AssassinHardTutorialStep.Enemy_2_Turn) ||
            (currentTutorialStep == AssassinHardTutorialStep.WaitForFortifyArmor) ||
            currentTutorialStep == AssassinHardTutorialStep.FreePlay;

        if (isAttackCard && isInstructionalOrFreeplay && target.GetCategory() == TargetCategory.Enemy)
        {
            battleManager.ShowTutorialDialogue("Player", "I don't have the habit to wasting time on this......", true);
            battleManager.DeselectCard();
            return true;
        }

        // (Cleave: 檢查任意護甲槽 - 邏輯正確)
        if (currentTutorialStep == AssassinHardTutorialStep.WaitForCleave && card.type == CardType.Attack)
        {
            if (target.GetCategory() == TargetCategory.EnemyArmorSlot)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinHardTutorialStep.Cleave_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
            battleManager.ShowTutorialDialogue("Player", "I don't have the habit to wasting time on this......", true);
            battleManager.DeselectCard();
            return true;
        }

        if (currentTutorialStep == AssassinHardTutorialStep.WaitForThreefold && card.type == CardType.Conditional)
        {
            if (target.GetCategory() == TargetCategory.Special)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().MoveCardFromHand(battleManager.GetSelectedCardDisplay().gameObject);
                UnityEngine.Object.Destroy(battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinHardTutorialStep.Threefold_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        if (currentTutorialStep == AssassinHardTutorialStep.WaitForSharpen && card.type == CardType.Buff)
        {
            if (target.GetCategory() == TargetCategory.CardInHand && target.GetCardDisplay().GetCardData().type == CardType.Weapon)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinHardTutorialStep.Sharpen_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        // ▼▼▼ 【!!! 您的要求在此 !!!】 ▼▼▼
        if (currentTutorialStep == AssassinHardTutorialStep.WaitForSharpBlade && card.type == CardType.Weapon)
        {
            // (已移除 ArmorPart.Armor 檢查)
            if (target.GetCategory() == TargetCategory.EnemyArmorSlot)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinHardTutorialStep.Blade_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
            else // (保留 else 區塊以攔截錯誤點擊)
            {
                battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
                battleManager.DeselectCard();
                return true;
            }
        }
        // ▲▲▲ 【!!! 修改結束 !!!】 ▲▲▲

        if (currentTutorialStep == AssassinHardTutorialStep.WaitForDivineRadiance && card.type == CardType.Magic)
        {
            if (target.GetCategory() == TargetCategory.Player)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinHardTutorialStep.Divine_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        // (Fortify Armor 邏輯)
        if (currentTutorialStep == AssassinHardTutorialStep.WaitForFortifyArmor && card.type == CardType.Armor)
        {
            var slots = new[] { player.stats.armor, player.stats.helmet, player.stats.gauntlets, player.stats.legArmor };
            int minArmor = slots.Min(s => s.currentArmor);

            ArmorPart correctPart = ArmorPart.Armor;
            if (player.stats.armor.currentArmor == minArmor) correctPart = ArmorPart.Armor;
            else if (player.stats.helmet.currentArmor == minArmor) correctPart = ArmorPart.Helmet;
            else if (player.stats.gauntlets.currentArmor == minArmor) correctPart = ArmorPart.Gauntlets;
            else if (player.stats.legArmor.currentArmor == minArmor) correctPart = ArmorPart.LegArmor;

            if (target.GetCategory() == TargetCategory.PlayerArmorSlot && target.GetArmorPart() == correctPart)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinHardTutorialStep.Fortify_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
            else
            {
                battleManager.ShowTutorialDialogue("Player", "This is not the time to fix other parts.......", true);
                battleManager.DeselectCard();
                return true;
            }
        }

        return false;
    }

    // 5. 勝利/失敗
    public override bool CheckForSpecialBattleEnd(out bool playerWon)
    {
        if (player != null && player.stats.isDead)
        {
            battleManager.StartCoroutine(battleManager.EndTutorialGame(false));
            playerWon = false;
            return true;
        }

        if (targetEnemies.All(e => e != null && e.stats.isDead))
        {
            battleManager.StartCoroutine(battleManager.EndTutorialGame(true));
            playerWon = true;
            return true;
        }

        playerWon = false;
        return false;
    }

    // 6. 抽牌
    public override bool CanDrawCards()
    {
        return (currentTutorialStep == AssassinHardTutorialStep.FreePlay ||
                currentTutorialStep == AssassinHardTutorialStep.Enemy_1_Turn ||
                currentTutorialStep == AssassinHardTutorialStep.Enemy_2_Turn);
    }

    // 7. 狀態機 (Helper Methods)

    private void OnEnemyDowned(Character downedEnemy)
    {
        if (hasTriggeredDyingSequence) return;
        hasTriggeredDyingSequence = true;

        currentDyingEnemy = downedEnemy;

        currentTutorialStep = AssassinHardTutorialStep.Dying_0_Player;
        AdvanceTutorial(currentTutorialStep);
    }

    // (使用 Knight 的 OnDialoguePanelClicked 邏輯)
    public override void OnDialoguePanelClicked()
    {
        bool isInstruction = battleManager.IsDialogueInstructional();

        switch (currentTutorialStep)
        {
            // (所有等待玩家動作的狀態)
            case AssassinHardTutorialStep.WaitForCleave:
            case AssassinHardTutorialStep.WaitForThreefold:
            case AssassinHardTutorialStep.WaitForSharpen:
            case AssassinHardTutorialStep.WaitForSharpBlade:
            case AssassinHardTutorialStep.WaitForDivineRadiance:
            case AssassinHardTutorialStep.WaitForFortifyArmor:
            case AssassinHardTutorialStep.WaitForEndTurn1:
            case AssassinHardTutorialStep.WaitForEndTurn2:
                if (isInstruction)
                {
                    return;
                }
                break;

            case AssassinHardTutorialStep.FreePlay:
                battleManager.ClearTutorialDialogue();
                return;

            // (所有純對話狀態都允許 fall-through)
            case AssassinHardTutorialStep.Start_0_Intro:
            case AssassinHardTutorialStep.Start_1_PlayerCheck:
            case AssassinHardTutorialStep.Start_2_PlayerCheck:
            case AssassinHardTutorialStep.Start_3_Rules:
            case AssassinHardTutorialStep.Start_4_Rules:
            case AssassinHardTutorialStep.Start_5_Rules:
            case AssassinHardTutorialStep.Start_6_PlayerReady:
            case AssassinHardTutorialStep.Start_7_PlayerAttackIntro:
            case AssassinHardTutorialStep.Start_8_PlayerAttackIntro:
            case AssassinHardTutorialStep.Cleave_1_After:
            case AssassinHardTutorialStep.Cleave_2_ThreefoldIntro:
            case AssassinHardTutorialStep.Cleave_3_ThreefoldIntro:
            case AssassinHardTutorialStep.Threefold_1_After:
            case AssassinHardTutorialStep.Threefold_2_Observe:
            case AssassinHardTutorialStep.Threefold_3_Observe:
            case AssassinHardTutorialStep.Turn2_0_SharpenIntro:
            case AssassinHardTutorialStep.Turn2_1_SharpenIntro:
            case AssassinHardTutorialStep.Sharpen_1_After:
            case AssassinHardTutorialStep.Sharpen_2_BladeIntro:
            case AssassinHardTutorialStep.Sharpen_3_BladeIntro:
            case AssassinHardTutorialStep.Blade_1_After:
            case AssassinHardTutorialStep.Blade_2_EndTurn:
            case AssassinHardTutorialStep.Turn3_0_PostScratch:
            case AssassinHardTutorialStep.Turn3_1_CleanseIntro:
            case AssassinHardTutorialStep.Divine_1_After:
            case AssassinHardTutorialStep.Divine_2_FortifyIntro:
            case AssassinHardTutorialStep.Fortify_1_After:
            case AssassinHardTutorialStep.FreePlay_0_Intro:
            case AssassinHardTutorialStep.ArmorBreak_0_Advantage:
            case AssassinHardTutorialStep.ArmorBreak_1_Mechanic:
            case AssassinHardTutorialStep.Dying_0_Player:
            case AssassinHardTutorialStep.Dying_1_Player:
            case AssassinHardTutorialStep.Dying_2_Action:
            case AssassinHardTutorialStep.Dying_3_Player:
            case AssassinHardTutorialStep.Dying_4_Enemy:
            case AssassinHardTutorialStep.LastEnemyStanding:
                break;
        }

        AdvanceTutorial(currentTutorialStep);
    }

    // (使用 Knight 的狀態機推進邏輯)
    private void AdvanceTutorial(AssassinHardTutorialStep requiredStep)
    {
        if (currentTutorialStep != requiredStep) return;

        switch (currentTutorialStep)
        {
            // (開場)
            case AssassinHardTutorialStep.Start_0_Intro:
                currentTutorialStep = AssassinHardTutorialStep.Start_1_PlayerCheck;
                battleManager.ShowTutorialDialogue("Player", "Let me check if I'm prepared first.");
                break;
            case AssassinHardTutorialStep.Start_1_PlayerCheck:
                currentTutorialStep = AssassinHardTutorialStep.Start_2_PlayerCheck;
                battleManager.ShowTutorialDialogue("Player", "I don't want to be like those story protagonists who are missing everything at the start...");
                break;
            case AssassinHardTutorialStep.Start_2_PlayerCheck:
                currentTutorialStep = AssassinHardTutorialStep.Start_3_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "Here is all the basic information.");
                break;
            case AssassinHardTutorialStep.Start_3_Rules:
                currentTutorialStep = AssassinHardTutorialStep.Start_4_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "When any piece of armor on a character (including yourself) is broken, the opponent can deal damage to that character's HP.");
                break;
            case AssassinHardTutorialStep.Start_4_Rules:
                currentTutorialStep = AssassinHardTutorialStep.Start_5_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "The victory goal in a normal game is to reduce the opponent's HP to below 0.");
                break;
            case AssassinHardTutorialStep.Start_5_Rules:
                currentTutorialStep = AssassinHardTutorialStep.Start_6_PlayerReady;
                battleManager.ShowTutorialDialogue("Player", "Great, looks like I can start.");
                break;

            // (Cleave 教學)
            case AssassinHardTutorialStep.Start_6_PlayerReady:
                currentTutorialStep = AssassinHardTutorialStep.Start_7_PlayerAttackIntro;
                battleManager.ShowTutorialDialogue("Player", "If I had to say what I learned best from the military academy, it's attacking.");
                break;
            case AssassinHardTutorialStep.Start_7_PlayerAttackIntro:
                currentTutorialStep = AssassinHardTutorialStep.Start_8_PlayerAttackIntro;
                battleManager.ShowTutorialDialogue("Player", "I'm not bragging, but when everyone else was learning 'Straight Attack', I learned 'Cleave' first.");
                break;
            case AssassinHardTutorialStep.Start_8_PlayerAttackIntro:
                currentTutorialStep = AssassinHardTutorialStep.WaitForCleave;
                battleManager.ShowTutorialDialogue("Narrator", "(Click Cleave, then click the Target's Armor to deal damage)", true);
                battleManager.StartPlayerTurnInternal();
                break;
            case AssassinHardTutorialStep.WaitForCleave:
                break;

            // (Threefold Ward 教學)
            case AssassinHardTutorialStep.Cleave_1_After:
                currentTutorialStep = AssassinHardTutorialStep.Cleave_2_ThreefoldIntro;
                battleManager.ShowTutorialDialogue("Player", "That being said, it doesn't seem very necessary this time...");
                break;
            case AssassinHardTutorialStep.Cleave_2_ThreefoldIntro:
                currentTutorialStep = AssassinHardTutorialStep.Cleave_3_ThreefoldIntro;
                battleManager.ShowTutorialDialogue("Player", "The defense instructor always said, 'Defense is the best offense.'");
                break;
            case AssassinHardTutorialStep.Cleave_3_ThreefoldIntro:
                currentTutorialStep = AssassinHardTutorialStep.WaitForThreefold;
                battleManager.ShowTutorialDialogue("Player", "(Click Threefold Ward, then click the Play Area to pre-block the enemy's attack)", true);
                break;
            case AssassinHardTutorialStep.WaitForThreefold:
                break;

            // (結束回合 1)
            case AssassinHardTutorialStep.Threefold_1_After:
                currentTutorialStep = AssassinHardTutorialStep.Threefold_2_Observe;
                battleManager.ShowTutorialDialogue("Player", "That instructor also taught: 'Observe the enemy, then act.'");
                break;
            case AssassinHardTutorialStep.Threefold_2_Observe:
                currentTutorialStep = AssassinHardTutorialStep.Threefold_3_Observe;
                battleManager.ShowTutorialDialogue("Player", "I've seen him 'Ora Ora' without any hesitation...");
                break;
            case AssassinHardTutorialStep.Threefold_3_Observe:
                currentTutorialStep = AssassinHardTutorialStep.WaitForEndTurn1;
                battleManager.ShowTutorialDialogue("Player", "(Press End Turn to end the turn)", true);
                break;
            case AssassinHardTutorialStep.WaitForEndTurn1:
                break;

            // (敵人回合 1 -> 玩家回合 2)
            case AssassinHardTutorialStep.Enemy_1_Turn:
                currentTutorialStep = AssassinHardTutorialStep.Turn2_0_SharpenIntro;
                AdvanceTutorial(currentTutorialStep);
                break;

            // (Sharpen 教學)
            case AssassinHardTutorialStep.Turn2_0_SharpenIntro:
                currentTutorialStep = AssassinHardTutorialStep.Turn2_1_SharpenIntro;
                battleManager.ShowTutorialDialogue("Player", "The equipment instructor always said, 'To do a good job, one must first sharpen one's tools.'");
                break;
            case AssassinHardTutorialStep.Turn2_1_SharpenIntro:
                currentTutorialStep = AssassinHardTutorialStep.WaitForSharpen;
                battleManager.ShowTutorialDialogue("Player", "(Click Sharpen, then click Sharp Blade to enhance it)", true);
                break;
            case AssassinHardTutorialStep.WaitForSharpen:
                break;

            // (Sharp Blade 教學)
            case AssassinHardTutorialStep.Sharpen_1_After:
                currentTutorialStep = AssassinHardTutorialStep.Sharpen_2_BladeIntro;
                battleManager.ShowTutorialDialogue("Player", "How many throwing knives did I use back then...");
                break;
            case AssassinHardTutorialStep.Sharpen_2_BladeIntro:
                currentTutorialStep = AssassinHardTutorialStep.Sharpen_3_BladeIntro;
                battleManager.ShowTutorialDialogue("Player", "Forget it. Can you count how many loaves of bread you've eaten in your life?");
                break;
            case AssassinHardTutorialStep.Sharpen_3_BladeIntro:
                currentTutorialStep = AssassinHardTutorialStep.WaitForSharpBlade;
                battleManager.ShowTutorialDialogue("Player", "(Click Sharp Blade, then click the opponent to attack)", true);
                break;
            case AssassinHardTutorialStep.WaitForSharpBlade:
                break;

            // (結束回合 2)
            case AssassinHardTutorialStep.Blade_1_After:
                currentTutorialStep = AssassinHardTutorialStep.Blade_2_EndTurn;
                battleManager.ShowTutorialDialogue("Player", "Let's just keep going like this.");
                break;
            case AssassinHardTutorialStep.Blade_2_EndTurn:
                currentTutorialStep = AssassinHardTutorialStep.WaitForEndTurn2;
                battleManager.ShowTutorialDialogue("Player", "(Press End Turn to end the turn)", true);
                break;
            case AssassinHardTutorialStep.WaitForEndTurn2:
                break;

            // (敵人回合 2 -> 玩家回合 3)
            case AssassinHardTutorialStep.Enemy_2_Turn:
                currentTutorialStep = AssassinHardTutorialStep.Turn3_0_PostScratch;
                AdvanceTutorial(currentTutorialStep);
                break;

            // (Cleanse 教學)
            case AssassinHardTutorialStep.Turn3_0_PostScratch:
                currentTutorialStep = AssassinHardTutorialStep.Turn3_1_CleanseIntro;
                battleManager.ShowTutorialDialogue("Player", "Seriously? That dull knife actually got sharpened?");
                break;
            case AssassinHardTutorialStep.Turn3_1_CleanseIntro:
                currentTutorialStep = AssassinHardTutorialStep.WaitForDivineRadiance;
                battleManager.ShowTutorialDialogue("Player", "(Use Divine Radiance to remove the status effect)", true);
                break;
            case AssassinHardTutorialStep.WaitForDivineRadiance:
                break;

            // (Fortify Armor 教學)
            case AssassinHardTutorialStep.Divine_1_After:
                currentTutorialStep = AssassinHardTutorialStep.Divine_2_FortifyIntro;
                battleManager.ShowTutorialDialogue("Player", "My armor isn't in great shape either. Time to patch it up. The equipment instructor was always extra noisy around this time......");
                break;
            case AssassinHardTutorialStep.Divine_2_FortifyIntro:
                currentTutorialStep = AssassinHardTutorialStep.WaitForFortifyArmor; // (仿照 Knight 邏輯)
                battleManager.ShowTutorialDialogue("Narrator", "(Click Fortify Armor, then click the Armor to repair it)", true);
                break;
            case AssassinHardTutorialStep.WaitForFortifyArmor:
                break;

            // (進入 FreePlay)
            case AssassinHardTutorialStep.Fortify_1_After:
                currentTutorialStep = AssassinHardTutorialStep.FreePlay_0_Intro;
                battleManager.ShowTutorialDialogue("Player", "That's about it... With this knowledge, finishing the mission is a piece of cake!");
                break;
            case AssassinHardTutorialStep.FreePlay_0_Intro:
                currentTutorialStep = AssassinHardTutorialStep.FreePlay;
                battleManager.ShowTutorialDialogue("Narrator", "Use what you have learned to defeat the enemy!");
                break;

            case AssassinHardTutorialStep.FreePlay:
                battleManager.ClearTutorialDialogue();
                break;

            // (動態事件：碎甲)
            case AssassinHardTutorialStep.ArmorBreak_0_Advantage:
                currentTutorialStep = AssassinHardTutorialStep.ArmorBreak_1_Mechanic;
                battleManager.ShowTutorialDialogue("Player", "Good, keep suppressing them like this!");
                break;
            case AssassinHardTutorialStep.ArmorBreak_1_Mechanic:
                currentTutorialStep = AssassinHardTutorialStep.FreePlay; // 返回 FreePlay
                battleManager.ShowTutorialDialogue("Narrator", "When this attack breaks armor, the character is immune to HP damage and control effects from it (unless Pierce), but subsequent attacks can target their HP.");
                break;

            // (動態事件：倒地)
            case AssassinHardTutorialStep.Dying_0_Player:
                currentTutorialStep = AssassinHardTutorialStep.Dying_1_Player;
                battleManager.ShowTutorialDialogue("Player", "The opponent can't move. Unfortunately, the situation doesn't allow me to show mercy.");
                break;
            case AssassinHardTutorialStep.Dying_1_Player:
                currentTutorialStep = AssassinHardTutorialStep.Dying_2_Action;
                battleManager.ShowTutorialDialogue("Player", "I'm sorry, but you have to die.");
                break;
            case AssassinHardTutorialStep.Dying_2_Action:
                currentTutorialStep = AssassinHardTutorialStep.Dying_3_Player;
                battleManager.LogAction("Player lands a finishing blow on Assassin, deals 9999 damage!");
                if (currentDyingEnemy != null)
                {
                    currentDyingEnemy.stats.TakeDamage(9999, DamageType.True, ArmorPart.Armor);
                }
                AdvanceTutorial(currentTutorialStep); // 立即推進到下一步
                break;
            case AssassinHardTutorialStep.Dying_3_Player:
                currentTutorialStep = AssassinHardTutorialStep.Dying_4_Enemy;
                battleManager.ShowTutorialDialogue("Player", "If only all my attacks were finishing blows...");
                break;
            case AssassinHardTutorialStep.Dying_4_Enemy:
                currentTutorialStep = AssassinHardTutorialStep.FreePlay; // 返回 FreePlay
                battleManager.ShowTutorialDialogue("Assassin", "Oh! Interesting...");
                break;

            // (動態事件：最後一個敵人)
            case AssassinHardTutorialStep.LastEnemyStanding:
                currentTutorialStep = AssassinHardTutorialStep.FreePlay; // <-- 修正：必須返回 FreePlay
                battleManager.ShowTutorialDialogue("Assassin", "You're in big trouble!");
                break;

            default:
                battleManager.ClearTutorialDialogue();
                break;
        }
    }
    // ▲▲▲ 【!!! 修改結束 !!!】 ▲▲▲

    // 8. 存檔/讀檔
    public override string GetCurrentTutorialStepName()
    {
        return currentTutorialStep.ToString();
    }

    public override void SetCurrentTutorialStep(string stepName)
    {
        if (Enum.TryParse(stepName, out AssassinHardTutorialStep newStep))
        {
            currentTutorialStep = newStep;
            Debug.Log($"[AssassinHardStrategy] SetCurrentTutorialStep:  successfully set to {newStep}");
        }
        else
        {
            Debug.LogError($"[AssassinHardStrategy] SetCurrentTutorialStep: Failed to parse step '{stepName}'!");
            currentTutorialStep = AssassinHardTutorialStep.FreePlay;
        }
    }
}