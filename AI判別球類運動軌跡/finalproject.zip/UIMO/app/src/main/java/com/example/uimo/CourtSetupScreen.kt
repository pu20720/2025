package com.example.uimo.ui.screens

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.example.uimo.CourtSetupViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourtSetupScreen(
    navController: NavHostController,
    videoUri: Uri,
    viewModel: CourtSetupViewModel = viewModel()
) {
    val context = LocalContext.current
    // ViewModelから座標リストを取得
    val courtPoints = viewModel.courtPoints

    // 指示テキストのリストを定義
    val instructions = listOf(
        "コートの左上隅をタッチ",
        "コートの右上隅をタッチ",
        "コートの右下隅をタッチ",
        "コートの左下隅をタッチ",
        "設定完了！ボタンを押してください。"
    )

    // ExoPlayerのセットアップ（最初のフレームで一時停止）
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUri))
            prepare()
            playWhenReady = false // 自動再生オフ
            seekTo(1) // 1ミリ秒目にシークして最初のフレームを表示
        }
    }

    // 画面が破棄されるときにExoPlayerを解放
    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("コート座標の設定") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "戻る")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Boxで動画プレイヤーとCanvasを重ねる
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16 / 9f)
            ) {
                AndroidView(
                    factory = { PlayerView(it).apply { player = exoPlayer } },
                    modifier = Modifier.fillMaxSize()
                )

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { offset: Offset ->
                                // タップされた座標をViewModelに渡す
                                viewModel.addCourtPoint(offset)
                            }
                        }
                ) {
                    // 点を描画
                    courtPoints.forEach { point ->
                        drawCircle(color = Color.Red, radius = 15f, center = point)
                    }

                    // 線を描画
                    if (courtPoints.size > 1) {
                        for (i in 0 until courtPoints.size - 1) {
                            drawLine(color = Color.Yellow, start = courtPoints[i], end = courtPoints[i + 1], strokeWidth = 5f)
                        }
                    }
                    if (courtPoints.size == 4) {
                        drawLine(color = Color.Yellow, start = courtPoints[3], end = courtPoints[0], strokeWidth = 5f)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // 1. 指示テキスト
            Text(
                text = instructions.getOrElse(courtPoints.size) { instructions.last() },
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 2. ボタンの行
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // リセットボタン
                OutlinedButton(
                    onClick = { viewModel.resetCourtPoints() },
                    modifier = Modifier.wrapContentWidth()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "リセット")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("再設定")
                }

                // 設定完了ボタン
                Button(
                    onClick = {
                        // ViewModelに関数を呼び出してもらい、ThirdScreenへ遷移する
                        viewModel.navigateToThirdScreen(navController, videoUri)
                    },
                    modifier = Modifier.weight(1f),
                    enabled = courtPoints.size == 4 // 4点揃うまで押せない
                ) {
                    Text("設定完了", fontSize = 20.sp)
                }
            }
        }
    }
}