import requests
import logging
from stocks.models import Stock

logger = logging.getLogger(__name__)

# 產業代碼對照表
INDUSTRY_MAP = {
    '01': '水泥工業',
    '02': '食品工業',
    '03': '塑膠工業',
    '04': '紡織纖維',
    '05': '電機機械',
    '06': '電器電纜',
    '08': '玻璃陶瓷',
    '09': '造紙工業',
    '10': '鋼鐵工業',
    '11': '橡膠工業',
    '12': '汽車工業',
    '13': '電子工業',
    '14': '建材營造業',
    '15': '航運業',
    '16': '觀光餐旅',
    '17': '金融保險業',
    '18': '貿易百貨業',
    '19': '綜合',
    '20': '其他業',
    '21': '化學工業',
    '22': '生技醫療業',
    '23': '油電燃氣業',
    '24': '半導體業',
    '25': '電腦及週邊設備業',
    '26': '光電業',
    '27': '通信網路業',
    '28': '電子零組件業',
    '29': '電子通路業',
    '30': '資訊服務業',
    '31': '其他電子業',
    '32': '文化創意業',
    '33': '農業科技業',
    '34': '電子商務',
    '35': '綠能環保',
    '36': '數位雲端',
    '37': '運動休閒',
    '38': '居家生活',
}


def import_twse_stock_data() -> dict:
    url = 'https://openapi.twse.com.tw/v1/opendata/t187ap03_L'

    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        fields = {
            '公司代號': 'symbol',
            '公司簡稱': 'name',
            '產業別': 'industry',
            '成立日期': 'founded_date',
            '上市日期': 'listed_date',
            '實收資本額': 'capital',
            '網址': 'website',
        }

        created_count = 0
        skipped_count = 0
        updated_count = 0

        for item in data:
            stock_data = {v: item.get(k, '') for k, v in fields.items()}

            # 轉換產業代碼為名稱
            code = item.get('產業別')
            # get 產業別名稱，若無對應則保留原代碼
            stock_data['industry'] = INDUSTRY_MAP.get(code, code)

            symbol = stock_data['symbol']

            try:
                obj = Stock.objects.get(symbol=symbol)
                # 若已存在，檢查是否需要更新
                has_changes = any(
                    getattr(obj, key) != val for key, val in stock_data.items()
                )
                if has_changes:
                    for key, val in stock_data.items():
                        setattr(obj, key, val)
                    obj.save()
                    updated_count += 1
                else:
                    skipped_count += 1
            except Stock.DoesNotExist:
                Stock.objects.create(**stock_data)
                created_count += 1

        return {
            'created': created_count,
            'updated': updated_count,
            'skipped': skipped_count,
            'total': len(data),
        }

    except requests.RequestException as e:
        logger.error(f'[TWSE] 資料擷取失敗：{e}')
        raise RuntimeError('TWSE API 錯誤')
    except Exception as e:
        logger.error(f'[TWSE] 匯入失敗：{e}')
        raise RuntimeError('資料處理失敗')
