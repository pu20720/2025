using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ShopCardDisplay : MonoBehaviour
{
    [Header("UI Components")]
    public Image cardBackground; // ★ 卡片底圖 (會變色)
    public TextMeshProUGUI priceText;

    [Header("Item Info")]
    public Image itemIcon; // 物品圖示 (可選)
    public TextMeshProUGUI itemNameText; // 物品名稱 (可選)

    private Button _selfButton;
    private ShopCardData _data;
    private ShopManager _manager;

    public ShopCardData Data => _data;

    public void Setup(ShopCardData data, ShopManager manager)
    {
        _data = data;
        _manager = manager;

        // --- 1. 設定顏色 (關鍵修正) ---
        if (cardBackground != null)
        {
            // 使用 ShopCardData 計算好的顏色 (White/Green/Blue/Gold)
            cardBackground.color = _data.cardColor;
        }

        // --- 2. 設定價格與位置 ---
        if (priceText != null)
        {
            priceText.text = $"${_data.price}";
            RectTransform textRect = priceText.GetComponent<RectTransform>();
            if (textRect != null)
            {
                textRect.anchorMin = new Vector2(0.5f, 0);
                textRect.anchorMax = new Vector2(0.5f, 0);
                textRect.pivot = new Vector2(0.5f, 0);
                textRect.sizeDelta = new Vector2(180f, 40f);
                textRect.anchoredPosition = new Vector2(0, -40f);
                priceText.alignment = TextAlignmentOptions.Center;
                priceText.enableAutoSizing = false;
                priceText.fontSize = 40;
            }
        }

        // --- 3. 設定物品資訊 ---
        if (_data.itemRef != null)
        {
            if (itemIcon != null) itemIcon.sprite = _data.itemRef.icon;
            if (itemNameText != null) itemNameText.text = _data.itemRef.itemName;
        }

        // --- 4. 綁定點擊 ---
        _selfButton = GetComponent<Button>();
        if (_selfButton == null) _selfButton = gameObject.AddComponent<Button>();

        _selfButton.onClick.RemoveAllListeners();
        _selfButton.onClick.AddListener(OnCardSelected);
    }

    void OnCardSelected()
    {
        if (_manager != null) _manager.SelectCard(this);
    }

    public void SetSelected(bool isSelected)
    {
        if (cardBackground != null)
        {
            // 選取時稍微變透明或變暗，以此區分
            Color c = _data.cardColor;
            c.a = isSelected ? 0.5f : 1f;
            cardBackground.color = c;
        }
    }
}