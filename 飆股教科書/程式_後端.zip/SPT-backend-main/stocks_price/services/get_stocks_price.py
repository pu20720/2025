import logging
from django.db.models import Q
from stocks_price.models import StockPrices


def get_stocks_prices(keyword=None, date=None):
    logger = logging.getLogger(__name__)
    try:
        queryset = StockPrices.objects.select_related('stock').all()

        if keyword:
            queryset = queryset.filter(
                Q(stock__symbol__icontains=keyword) | Q(stock__name__icontains=keyword)
            )

        if date:
            queryset = queryset.filter(price_date__icontains=date)

        if not keyword and not date:
            return [{'error': '請提供至少一個查詢條件（股票代號或日期）'}]

        results = [
            {
                'id': q.id,
                'stock_id': q.stock.id,
                'symbol': q.stock.symbol,
                'name': q.stock.name,
                'price_date': q.price_date,
                'open_price': q.open_price,
                'close_price': q.close_price,
                'high_price': q.high_price,
                'low_price': q.low_price,
                'volume': q.volume,
                'change_percent': q.change_percent,
            }
            for q in queryset
        ]

        return results

    except Exception as e:
        logger.error(f'[StockPrice] 資料查詢失敗 {e}')
        return [{'error': '查詢過程中發生錯誤'}]
