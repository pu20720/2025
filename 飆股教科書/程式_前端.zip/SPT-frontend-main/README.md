# 飆股教科書

套件安裝

```
npm install
```

啟動開發伺服器

```
npm run dev
```

專案打包（生成生產環境檔案）

```
npm run build
```

若要手動檢查並檢查程式碼

```
npm run lint
```