// 檔案路徑: Assets/Scripts/UI/InventoryPanelUI.cs
using UnityEngine;
using System.Collections.Generic;

public class InventoryPanelUI : MonoBehaviour
{
    [Header("Panel 結構引用")]
    [Tooltip("供 InventoryManager 獲取生成位置")]
    [SerializeField] private Transform itemSlotsParent;

    // 此腳本僅作為容器，所有核心控制邏輯皆在 InventoryManager 中實作。

    public Transform GetItemSlotsParent()
    {
        return itemSlotsParent;
    }

    public void OnSlotClicked(ItemData item)
    {
        Debug.Log("PanelUI: 訊號已轉交給 InventoryManager 處理。");
    }
}