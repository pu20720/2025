<template>
  <div>
    <button @click="toggleChat" class="text-4xl fixed bottom-5 right-5 w-20 h-20 bg-blue-600 text-white rounded-full shadow-lg flex items-center justify-center z-50">
      💬
    </button>

    <transition name="fade">
      <div v-if="open" class="fixed bottom-20 right-5 w-[500px] h-[800px] bg-white rounded-xl shadow-lg flex flex-col z-50">
        
        <div class="flex justify-between items-center bg-blue-600 text-white p-2 rounded-t-xl">
          <span>股票助理</span>
          <button @click="toggleChat">✕</button>
        </div>

        <div ref="messagesContainer" class="flex-1 p-2 overflow-y-auto space-y-2">
          <div v-for="(msg, index) in messages" :key="index" :class="msg.from === 'user' ? 'text-right' : 'text-left'">
            <div :class="msg.from === 'user' ? 'bg-blue-500 text-white inline-block px-3 py-2 rounded-lg' : 'bg-gray-200 inline-block px-3 py-2 rounded-lg'">
              <span v-if="!msg.markdown">{{ msg.text }}</span>
              <span v-else v-html="renderMarkdown(msg.text)"></span>
            </div>
          </div>

          <div v-if="loading" class="text-left">
            <div class="bg-gray-200 inline-block px-3 py-2 rounded-lg animate-pulse">...</div>
          </div>
        </div>

        <div class="p-2 border-t flex gap-2">
          <input v-model="query" @keyup.enter="sendMessage" class="flex-1 border rounded px-2 py-1" placeholder="輸入股票問題或代碼-新聞"/>
          <button @click="sendMessage" class="bg-blue-600 text-white px-3 py-1 rounded">送出</button>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, nextTick } from "vue"
import axios from "axios"
import { marked } from "marked" // 導入 marked 函式庫

const open = ref(false)
const messages = ref([])
const query = ref("")
const loading = ref(false)
const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:5000"
const messagesContainer = ref(null)

// 新增一個方法來轉換 Markdown 為 HTML
const renderMarkdown = (text) => {
    // 使用 marked.parse() 將 Markdown 轉換為 HTML
    return marked.parse(text)
}

const sendMessage = async () => {
    if (!query.value.trim()) return
    messages.value.push({ from: "user", text: query.value })
    const q = query.value
    query.value = ""
    loading.value = true
    scrollToBottom()

    try {
        const res = await axios.post(`${API_BASE}/chat`, { query: q })
        // 將 API 回應的文字加上 flag，標示為 markdown 內容
        messages.value.push({ from: "bot", text: res.data.answer, markdown: true })
        scrollToBottom()
    } catch (err) {
        messages.value.push({ from: "bot", text: "伺服器錯誤：" + (err.response?.data?.error || err.message) })
        scrollToBottom()
    } finally {
        loading.value = false
    }
}

const toggleChat = () => {
  open.value = !open.value
}

const scrollToBottom = async () => {
  await nextTick()
  if (messagesContainer.value) {
    messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
  }
}

</script>

<style scoped>
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s, transform 0.3s;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
  transform: translateY(20px);
}
</style>