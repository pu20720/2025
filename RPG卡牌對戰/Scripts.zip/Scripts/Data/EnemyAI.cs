using UnityEngine;
using System.Linq;

// ▼▼▼ 因為 RPEnums.cs 裡沒有，所以必須在這裡定義，否則會報錯 ▼▼▼
public enum EnemyAILogic
{
    SimpleAttack,
    HeavyHitter,
    TutorialTarget,
    TutorialAssassinHard,
    Debuffer,
    Passive,

    // B/C 級與特殊 Boss 邏輯
    MaddeningLogic,   // Morwen
    HowlerLogic,      // Fenris
    SpiderKingLogic,  // Yantarlion
    DioLogic,         // Dio Brando
    CalamityLogic,    // Amber
    BloodyLogic,      // Mary
    CaesarLogic,      // Julius
    FrederickLogic,   // Frederick
    GargantuanLogic,  // Grog
    BloomLogic,       // Carnivorous Rex
    DespairLogic,     // Despair Knight
    ShadowLogic,      // Kai
    WhisperLogic,     // Phantom

    // A/S 級
    GarrothLogic,
    VerminusLogic
}
// ▲▲▲ 定義結束 ▲▲▲

public class EnemyAI : MonoBehaviour
{
    // ▼▼▼ 【重點 1】 公開變數 enemyData ▼▼▼
    public EnemyData enemyData;
    // ▲▲▲

    private CharacterStats _myStats;

    // 狀態變數
    private bool dio50Triggered = false;
    private bool dio30Triggered = false;
    private bool shadowTriggered = false;
    private bool verminusFirstTurn = true;

    // 初始化：由 BattleManager 呼叫 (修正為接收 Character)
    public void Initialize(EnemyData data, Character character)
    {
        this.enemyData = data;
        this._myStats = character.stats;

        // 重置狀態
        dio50Triggered = false;
        dio30Triggered = false;
        shadowTriggered = false;
        verminusFirstTurn = true;
    }

    // 補上 BattleManager 呼叫的缺失方法
    public void SetTutorialHardMode(int index)
    {
        Debug.Log($"EnemyAI: Tutorial Hard Mode Set for enemy index {index}.");
    }

    // ▼▼▼ 【重點 2】 補上 SetLastEnemyMode 方法 ▼▼▼
    public void SetLastEnemyMode()
    {
        Debug.Log("EnemyAI: Last Enemy Mode Set.");
    }
    // ▲▲▲

    // 執行回合 (修正為接收 Character)
    public void ExecuteTurn(Character playerCharacter)
    {
        if (_myStats == null || _myStats.isDead) return;
        if (playerCharacter == null) return;

        CharacterStats playerStats = playerCharacter.stats;
        CharacterStats enemyStats = _myStats;

        if (enemyData == null)
        {
            PerformAttack(enemyStats, playerStats, 1.0f);
            return;
        }

        switch (enemyData.aiLogic)
        {
            // --- 基礎邏輯 ---
            case EnemyAILogic.SimpleAttack:
                PerformAttack(enemyStats, playerStats, 1.0f);
                break;
            case EnemyAILogic.HeavyHitter:
                PerformAttack(enemyStats, playerStats, 1.2f);
                break;
            case EnemyAILogic.Debuffer:
                PerformAttack(enemyStats, playerStats, 0.8f);
                playerStats.AddStatus(StatusType.Corruption, 1);
                break;
            case EnemyAILogic.TutorialTarget:
            case EnemyAILogic.Passive:
                break;
            case EnemyAILogic.TutorialAssassinHard:
                PerformAttack(enemyStats, playerStats, 1.0f, DamageType.Pierce);
                break;

            // --- B/C 級與特殊 Boss 邏輯 ---

            case EnemyAILogic.MaddeningLogic: // Morwen
                PerformAttack(enemyStats, playerStats, 1.0f);
                playerStats.AddStatus(StatusType.Poison, 2);
                break;

            case EnemyAILogic.HowlerLogic: // Fenris
                int bonusAtk = Mathf.CeilToInt(enemyStats.attackValue * 0.2f);
                enemyStats.Repair(ArmorPart.Armor, Mathf.CeilToInt(enemyStats.armor.maxArmor * 0.2f));
                PerformAttack(enemyStats, playerStats, 1.0f, DamageType.Normal, bonusAtk);
                break;

            case EnemyAILogic.SpiderKingLogic: // Yantarlion
                if (Random.value <= 0.2f) playerStats.AddStatus(StatusType.Freeze, 1);
                else PerformAttack(enemyStats, playerStats, 1.0f);
                break;

            case EnemyAILogic.DioLogic: // Dio
                float hpPct = (float)enemyStats.hp / enemyStats.maxHp;
                if (hpPct <= 0.3f && !dio30Triggered)
                {
                    playerStats.AddStatus(StatusType.Freeze, 5);
                    dio30Triggered = true; dio50Triggered = true;
                }
                else if (hpPct <= 0.5f && !dio50Triggered)
                {
                    playerStats.AddStatus(StatusType.Freeze, 3);
                    dio50Triggered = true;
                }
                else
                {
                    PerformAttack(enemyStats, playerStats, 1.0f);
                }
                break;

            case EnemyAILogic.CalamityLogic: // Amber
                PerformAttack(enemyStats, playerStats, 1.0f);
                if (playerStats.mp > 0) playerStats.mp = Mathf.Max(0, playerStats.mp - 50);
                break;

            case EnemyAILogic.BloodyLogic: // Mary
                float lostPct = 1.0f - ((float)enemyStats.hp / enemyStats.maxHp);
                int stacks = Mathf.FloorToInt(lostPct / 0.25f);
                float mult = 1.0f + (stacks * 0.15f);
                PerformAttack(enemyStats, playerStats, mult);
                break;

            case EnemyAILogic.CaesarLogic: // Julius
                PerformAttack(enemyStats, playerStats, 1.0f);
                break;

            case EnemyAILogic.FrederickLogic: // Frederick
                if (playerStats.mp >= 1500) playerStats.TakeDamage(99999, DamageType.True, ArmorPart.Armor);
                else PerformAttack(enemyStats, playerStats, 1.0f);
                break;

            case EnemyAILogic.GargantuanLogic: // Grog
                PerformAttack(enemyStats, playerStats, 1.0f);
                break;

            case EnemyAILogic.BloomLogic: // Rex
                float pHP = (float)playerStats.hp / playerStats.maxHp;
                if (pHP < 0.23f) playerStats.TakeDamage(99999, DamageType.True, ArmorPart.Armor);
                else PerformAttack(enemyStats, playerStats, 1.0f);
                break;

            case EnemyAILogic.DespairLogic: // Despair Knight
                PerformAttack(enemyStats, playerStats, 1.0f);
                playerStats.AddStatus(StatusType.Corruption, 5);
                break;

            case EnemyAILogic.ShadowLogic: // Kai
                if (!shadowTriggered)
                {
                    playerStats.AddStatus(StatusType.Freeze, 3);
                    shadowTriggered = true;
                }
                else
                {
                    PerformAttack(enemyStats, playerStats, 1.0f);
                }
                break;

            case EnemyAILogic.WhisperLogic: // Phantom
                PerformAttack(enemyStats, playerStats, 1.0f);
                break;

            // --- A/S 級 ---
            case EnemyAILogic.GarrothLogic:
                PerformAttack(enemyStats, playerStats, 1.0f);
                playerStats.AddStatus(StatusType.Bleed, 3);
                break;

            case EnemyAILogic.VerminusLogic:
                if (verminusFirstTurn)
                {
                    Character plagueDoc = FindObjectsByType<Character>(FindObjectsSortMode.None)
                        .FirstOrDefault(c => c.characterName == "Plague Doctor" && !c.stats.isDead);

                    const int FIXED_DAMAGE = 30;
                    string logMessage;

                    if (plagueDoc != null)
                    {
                        // 1. 執行固定傷害 (使用 True Damage 繞過護甲，直接減 HP)
                        // 由於 Plague Doctor 只有 50 HP，扣 30 HP 後會剩 20 HP
                        plagueDoc.stats.TakeDamage(FIXED_DAMAGE, DamageType.True, ArmorPart.Armor);

                        // 2. 記錄指定的 Action Log
                        logMessage = $"Verminus attack Plague Doctor, Causing {FIXED_DAMAGE} Damage!";
                    }
                    else
                    {
                        // 如果 Plague Doctor 已死亡或不存在，執行標準攻擊
                        PerformAttack(enemyStats, playerStats, 1.0f);
                        logMessage = $"Verminus attacks Player (Plague Doctor not found).";
                    }

                    // 3. 呼叫 BattleManager 記錄動作 (假設 BattleManager.Instance 存在)
                    if (BattleManager.Instance != null)
                    {
                        BattleManager.Instance.LogAction(logMessage);
                    }

                    // 標記第一回合結束
                    verminusFirstTurn = false;
                }
                else
                {
                    // 之後的回合：正常攻擊玩家 + 10% 流血
                    PerformAttack(enemyStats, playerStats, 1.0f);
                    if (Random.value <= 0.1f) playerStats.AddStatus(StatusType.Bleed, 1);
                }
                break;

            default:
                PerformAttack(enemyStats, playerStats, 1.0f);
                break;
        }
    }

    private void PerformAttack(CharacterStats attacker, CharacterStats target, float multiplier, DamageType type = DamageType.Normal, int flatBonus = 0)
    {
        int dmg = Mathf.CeilToInt(attacker.attackValue * multiplier) + flatBonus;
        target.TakeDamage(dmg, type, ArmorPart.Armor);
    }
}