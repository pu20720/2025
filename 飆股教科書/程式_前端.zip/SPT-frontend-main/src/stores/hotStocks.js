import { useToast } from 'primevue/usetoast'
import api from '@/api/axios'

export function useHotStocks() {
    const toast = useToast()
    const API_URL = 'hotstocks/'

    const getHotStocks = async () => {
        try {
            const response = await api.get(API_URL)
            if (!response.data || response.data.length === 0) {
                toast.add({
                    severity: 'info',
                    summary: '提示',
                    detail: '目前沒有熱門股票資料',
                    life: 3000,
                })
                return []
            }
            return response.data
        } catch (e) {
            toast.add({
                severity: 'error',
                summary: '讀取熱門股票失敗',
                detail: e.message || '發生未知錯誤',
                life: 3000,
            })
            return []
        }
    }
    return {
        getHotStocks,
    }
}
