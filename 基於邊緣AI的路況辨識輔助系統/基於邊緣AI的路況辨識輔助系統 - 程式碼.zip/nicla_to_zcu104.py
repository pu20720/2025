# Notebook cell
from flask import Flask, request
import os
import threading

app = Flask(__name__)

# 影像儲存資料夾
SAVE_DIR = "/home/root/nicla_images"
os.makedirs(SAVE_DIR, exist_ok=True)

# 編號 (每次啟動重置從 1 開始)
img_count = 0

@app.route('/upload', methods=['POST'])
def upload_image():
    global img_count

    try:
        img_bytes = request.data
        if not img_bytes:
            print("收到空資料")
            return "No Data", 400

        img_count += 1
        filename = os.path.join(SAVE_DIR, f"img_{img_count:04d}.jpg")

        with open(filename, "wb") as f:
            f.write(img_bytes)

        print(f"收到影像並存檔: {filename}")
        return "OK", 200

    except Exception as e:
        print("影像接收失敗:", e)
        return "Error", 500

def run_flask():
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)

# 在背景執行 Flask
thread = threading.Thread(target=run_flask)
thread.daemon = True
thread.start()

print("Flask server 已啟動，等待 Nicla Vision 上傳影像...")
