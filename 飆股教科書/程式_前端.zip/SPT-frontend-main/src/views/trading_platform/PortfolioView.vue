<script setup>
    import { onMounted } from 'vue'
    import { useTrade } from '@/stores/trade.js'

    const { portfolio, loading, fetchPortfolio } = useTrade()

    onMounted(() => {
        fetchPortfolio()
    })
</script>

<template>
    <div>
        <div class="card">
            <h1 class="text-4xl font-bold text-center text-gray-900 mb-6 tracking-wider">
                💰我的投資組合
            </h1>

            <div v-if="loading" class="text-center p-10">正在載入持股資料...</div>

            <div v-else-if="!portfolio.length" class="text-center p-10">
                您的投資組合目前沒有任何持股。
            </div>

            <div v-else class="max-w-9xl mx-auto p-6 text-gray-800 hide-scrollbar">
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white rounded-xl shadow">
                        <thead>
                            <tr class="text-2xl text-white bg-custom-purple font-semibold">
                                <th class="px-5 py-5 text-center rounded-tl-xl">股票代碼</th>
                                <th class="px-5 py-5 text-center">公司名稱</th>
                                <th class="px-5 py-5 text-center">持股數量</th>
                                <th class="px-5 py-5 text-center">平均成本</th>
                                <th class="px-5 py-5 text-center">現價</th>
                                <th class="px-5 py-5 text-center">市值</th>
                                <th class="px-5 py-5 text-center">損益</th>
                                <th class="px-5 py-5 text-center rounded-tr-xl">報酬率</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr
                                v-for="(holding, index) in portfolio"
                                :key="holding.id || holding.stock_symbol"
                                :class="[
                                    index % 2 === 0 ? 'bg-white' : 'bg-gray-50',
                                    'text-lg',
                                    'transition',
                                    'hover:bg-blue-50',
                                ]"
                            >
                                <td class="px-5 py-5 text-center">{{ holding.stock_symbol }}</td>
                                <td class="px-5 py-5 text-center">{{ holding.stock_name }}</td>
                                <td class="px-5 py-5 text-center">{{ holding.shares }}</td>
                                <td class="px-5 py-5 text-center">
                                    ${{ holding.average_price.toFixed(2) }}
                                </td>
                                <td class="px-5 py-5 text-center">
                                    ${{ holding.current_price.toFixed(2) }}
                                </td>
                                <td class="px-5 py-5 text-center">
                                    ${{ (holding.shares * holding.current_price).toLocaleString() }}
                                </td>
                                <td
                                    class="px-5 py-5 text-center"
                                    :class="
                                        holding.profit_loss >= 0 ? 'text-green-600' : 'text-red-600'
                                    "
                                >
                                    {{ holding.profit_loss.toFixed(0) }}
                                </td>
                                <td
                                    class="px-5 py-5 text-center"
                                    :class="
                                        holding.return_rate >= 0 ? 'text-green-600' : 'text-red-600'
                                    "
                                >
                                    {{ holding.return_rate.toFixed(2) }}%
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>
