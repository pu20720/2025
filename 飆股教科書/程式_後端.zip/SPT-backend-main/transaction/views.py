from decimal import InvalidOperation
from stocks.models import Stock
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from rest_framework.exceptions import ValidationError
from transaction.services.transaction import execute_trade
from .services.get_portfolio_data import get_portfolio_data


# 取得使用者投資組合的 API
class UsersPortfolioView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        try:
            result = get_portfolio_data(user=request.user)
            return Response(result, status=status.HTTP_200_OK)
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


# 買賣股票的 API
class TradeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        trade_type = request.data.get('type')
        symbol = request.data.get('symbol')
        shares = request.data.get('shares')

        if not all([trade_type, symbol, shares]):
            raise ValidationError('請提供 type、symbol、shares')

        try:
            shares = int(shares)

            if shares <= 0:
                raise ValidationError('shares 必須為正數')

            stock = Stock.objects.get(symbol=symbol)
            result = execute_trade(request.user, stock, trade_type, shares)
            return Response(result, status=status.HTTP_200_OK)
        except Stock.DoesNotExist:
            return Response({'error': '找不到該股票'}, status=status.HTTP_404_NOT_FOUND)
        except (ValueError, TypeError, InvalidOperation):
            return Response(
                {'error': 'shares 格式不正確'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except ValidationError as e:
            # 做錯誤訊息處理
            message = e.detail[0] if isinstance(e.detail, list) else str(e.detail)
            return Response({'error': message}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response(
                {'error': f'交易失敗：{str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class TransactionHistoryView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        transaction_type = request.query_params.get('type')  # 可選的篩選條件
        transactions = request.user.transaction_set.all().order_by('-date')

        # 根據交易類型篩選
        if transaction_type:
            transactions = transactions.filter(transaction_type=transaction_type)

        data = [
            {
                'id': tx.id,
                'stock_symbol': tx.stock.symbol,
                'transaction_type': tx.transaction_type,
                'shares': tx.shares,
                'price': str(tx.price),
                'amount': str(tx.amount),
                'date': tx.date,
            }
            for tx in transactions
        ]
        return Response(data, status=status.HTTP_200_OK)


class SearchBarView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        from transaction.services.get_search_bar import get_search_bar

        keyword = request.query_params.get('keyword', None)

        results = get_search_bar(keyword=keyword)
        return Response(results, status=status.HTTP_200_OK)
