import os
os.environ["GLOG_minloglevel"] = "2"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
try:
    from absl import logging
    logging.set_verbosity(logging.ERROR)
except Exception:
    pass

import re
import cv2, pandas as pd, mediapipe as mp

# ========== 路徑 ==========
VIDEO_FOLDER = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\overhand"
CONTROL_FILE = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\overhand_csv\overhand.csv"
OUTPUT_CSV   = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\overhand_csv\overhand_poses_labeled.csv"

# ========== 基本設定 ==========
CONTROL_REF_FPS = 30  # ⭐ 強制 30fps
DEFAULT_FRAME_STRIDE = 1
VALID_EXT = (".mov", ".mp4")

OK_WORDS  = {"correct","right","good","ok","pass","正確","對","合格","true","1"}
BAD_WORDS = {"wrong","incorrect","bad","fail","不正確","錯","錯誤","不合格","false","0"}

# ========== 小工具 ==========
def keyify(name: str) -> str:
    base = os.path.basename(str(name))
    return os.path.splitext(base)[0].lower()

def to_int(x):
    try:
        if x is None: return None
        s = str(x).strip()
        if s == "": return None
        return int(float(s))
    except Exception:
        return None

def parse_is_correct_from_quality(q, fallback_name=""):
    if q is not None and str(q).strip() != "":
        s = str(q).lower()
        if any(w in s for w in OK_WORDS):  return 1
        if any(w in s for w in BAD_WORDS): return 0
        try:
            v = float(s)
            if v in (1, 1.0): return 1
            if v in (0, 0.0): return 0
        except Exception:
            pass
    base = os.path.splitext(os.path.basename(str(fallback_name)))[0].lower()
    if any(w in base for w in OK_WORDS):  return 1
    if any(w in base for w in BAD_WORDS): return 0
    return None

def parse_angle_from_any(value, fallback_name=""):
    try:
        if value is not None and str(value).strip() != "":
            return int(round(float(str(value).strip())))
    except Exception:
        pass

    name = os.path.splitext(os.path.basename(str(fallback_name)))[0]
    nums = re.findall(r"\d{1,3}", name)
    for s in nums:
        try:
            v = int(s)
            if 0 <= v <= 180:
                return v
        except Exception:
            continue
    return None

def flatten_landmarks(lmlist):
    d = {}
    for i, lm in enumerate(lmlist):
        d[f"x{i}"] = lm.x
        d[f"y{i}"] = lm.y
        d[f"z{i}"] = lm.z
        d[f"v{i}"] = lm.visibility
    return d

# ========== 讀控制表 ==========
ext = os.path.splitext(CONTROL_FILE)[1].lower()
if ext in (".xlsx", ".xls"):
    ctrl = pd.read_excel(CONTROL_FILE)
else:
    ctrl = pd.read_csv(CONTROL_FILE, encoding="utf-8", engine="python")

ctrl.columns = [c.strip().lower() for c in ctrl.columns]

required = {"filename", "start_frame", "end_frame"}
missing = [c for c in required if c not in ctrl.columns]
if missing:
    raise ValueError(f"控制表缺少欄位：{missing}（至少要 filename, start_frame, end_frame）")

if "angle" not in ctrl.columns:
    ctrl["angle"] = None

ctrl["__key__"] = ctrl["filename"].apply(keyify)
ctrl["start_frame"] = ctrl["start_frame"].apply(to_int)
ctrl["end_frame"]   = ctrl["end_frame"].apply(to_int)
for col in ("action","quality","total_frames","frame_count","fps","notes"):
    if col not in ctrl.columns:
        ctrl[col] = None

control_map = { r["__key__"]: r for _, r in ctrl.iterrows() }

# ========== 掃描影片 ==========
files = [f for f in os.listdir(VIDEO_FOLDER)
         if os.path.splitext(f)[1].lower() in VALID_EXT]
files.sort()

if not files:
    raise SystemExit("⚠️ 資料夾內沒有 .mov/.mp4 影片，請確認 VIDEO_FOLDER。")

rows = []

with mp.solutions.pose.Pose(
    static_image_mode=False, model_complexity=2,
    enable_segmentation=False,
    min_detection_confidence=0.5, min_tracking_confidence=0.5
) as pose:

    for file in files:
        path = os.path.join(VIDEO_FOLDER, file)
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            print(f"⚠️ 無法開啟影片：{file}")
            continue

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
        name_noext = keyify(file)

        cfg = control_map.get(name_noext)
        if cfg is None:
            print(f"⚠️ 控制表找不到：{file}，跳過（請在 {os.path.basename(CONTROL_FILE)} 補一列）")
            cap.release(); continue

        quality_ctrl = cfg.get("quality")
        is_correct = parse_is_correct_from_quality(quality_ctrl, fallback_name=name_noext)
        angle_ctrl = parse_angle_from_any(cfg.get("angle"), fallback_name=name_noext)

        sf30 = to_int(cfg.get("start_frame"))
        ef30 = to_int(cfg.get("end_frame"))
        if sf30 is None and ef30 is None:
            print(f"⚠️ {file} 缺 start_frame/end_frame，跳過")
            cap.release(); continue

        # ⭐ 強制以 30fps，直接使用控制表 frame index
        start_f = 0 if sf30 is None else sf30
        end_f   = total_frames if ef30 is None else ef30  # 不含終點

        start_f = max(0, min(start_f, max(0, total_frames - 1)))
        end_f   = max(0, min(end_f,   total_frames))

        expected = (ef30 - sf30) if (sf30 is not None and ef30 is not None) else (end_f - start_f)
        actual   = end_f - start_f
        if actual < expected:
            end_f = min(total_frames, start_f + expected)

        stride = DEFAULT_FRAME_STRIDE
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_f)
        abs_idx, rel_idx = start_f, 0

        while True:
            if abs_idx >= end_f: break
            ok, bgr = cap.read()
            if not ok: break

            if (rel_idx % stride) != 0:
                abs_idx += 1; rel_idx += 1; continue

            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            res = pose.process(rgb)

            if res.pose_landmarks:
                row = {
                    "video": name_noext,
                    "frame_index_abs": abs_idx,
                    "frame_index_rel": rel_idx,
                    "timestamp_ms": int(abs_idx * (1000.0 / CONTROL_REF_FPS)),
                    "fps": CONTROL_REF_FPS,
                    "action": cfg.get("action"),
                    "quality": quality_ctrl,
                    "is_correct": is_correct,
                    "angle": angle_ctrl,
                }
                row.update(flatten_landmarks(res.pose_landmarks.landmark))
                rows.append(row)

            abs_idx += 1; rel_idx += 1

        # ⭐ 如果幀數不足，補最後一幀
        actual_frames = sum(1 for r in rows if r["video"] == name_noext and start_f <= r["frame_index_abs"] < end_f)
        if actual_frames < expected and actual_frames > 0:
            last_row = rows[-1].copy()
            last_row["frame_index_abs"] += 1
            last_row["frame_index_rel"] += 1
            last_row["timestamp_ms"] = int(last_row["frame_index_abs"] * (1000.0 / CONTROL_REF_FPS))
            rows.append(last_row)

        cap.release()

# ========== 輸出與檢查 ==========
out = pd.DataFrame(rows)
try:
    if "is_correct" in out.columns:
        out["is_correct"] = out["is_correct"].astype("Int64")
    if "angle" in out.columns:
        out["angle"] = out["angle"].astype("Int64")
except Exception:
    pass

if not out.empty:
    try:
        counts = out.groupby("video")["frame_index_rel"].count()
        print("每支影片輸出列數（行數）摘要：")
        print(counts.sort_index().to_string())
        print("\n統計：")
        print(counts.describe().to_string())
    except Exception:
        pass
else:
    print("⚠️ 沒有任何輸出列，請檢查控制表區間與影片。")

dest = OUTPUT_CSV
if os.path.isdir(dest) or dest.endswith(("\\", "/")):
    dest = os.path.join(dest, "underhandpass_poses_labeled.csv")
os.makedirs(os.path.dirname(dest), exist_ok=True)

try:
    out.to_csv(dest, index=False, encoding="utf-8-sig")
    print(f"✅ 已輸出：{dest}，共 {len(out)} 列")
except PermissionError:
    print("⚠️ 寫檔被拒：很可能 CSV 正在被 Excel/其他程式開啟，或 OUTPUT_CSV 只是一個資料夾。")
    print("→ 請關閉檔案或把 OUTPUT_CSV 設成完整檔名（.csv 結尾）後再試。")
