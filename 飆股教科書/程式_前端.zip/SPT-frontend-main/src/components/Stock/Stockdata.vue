<script setup>
    import { ref, onMounted, onUnmounted, watch, nextTick } from 'vue'
    import api from '@/api/axios'
    import * as echarts from 'echarts'
    import { CanvasRenderer } from 'echarts/renderers'
    import { CandlestickChart, LineChart, BarChart } from 'echarts/charts'
    import {
        GridComponent,
        TooltipComponent,
        LegendComponent,
        DataZoomComponent,
    } from 'echarts/components'

    echarts.use([
        CanvasRenderer,
        CandlestickChart,
        LineChart,
        BarChart,
        GridComponent,
        TooltipComponent,
        LegendComponent,
        DataZoomComponent,
    ])

    const props = defineProps({ stockCode: { type: String, required: true } })
    const chartContainer = ref(null)
    let myChart
    const loading = ref(false)
    const error = ref(null)
    const hasKData = ref(true)
    const indicatorOptions = [
        { label: 'RSI (5,10)', value: 'rsi' },
        { label: 'MACD', value: 'macd' },
        { label: 'KD', value: 'kd' },
    ]
    const indicator = ref('kd')

    function mapValue(src, key, dates) {
        return dates.map((date) => {
            const found = src.find((x) => x.date === date)
            return found ? +found[key] : '-'
        })
    }

    async function fetchAndDraw() {
        loading.value = true
        error.value = null
        hasKData.value = true
        try {
            const { data: priceData } = await api.get('prices/import/all/', {
                params: { keyword: props.stockCode },
            })

            if (!priceData || priceData.length === 0) {
                hasKData.value = false
                return
            }

            const fullData = priceData
                .map((i) => [i.price_date, i.open_price, i.close_price, i.low_price, i.high_price])
                .reverse()
            const dates = fullData.map((i) => i[0])
            const kData = fullData.map((i) => [i[1], i[2], i[3], i[4]])

            const [ma5, ma20, ma60] = await Promise.all([
                api.get('technical-indicators/ma5', {
                    params: { symbol: props.stockCode },
                }),
                api.get('technical-indicators/ma20', {
                    params: { symbol: props.stockCode },
                }),
                api.get('technical-indicators/ma60', {
                    params: { symbol: props.stockCode },
                }),
            ])

            const baseSeries = [
                {
                    name: 'K線',
                    type: 'candlestick',
                    xAxisIndex: 0,
                    yAxisIndex: 0,
                    data: kData,
                    barWidth: '50%',
                    itemStyle: {
                        color: '#ec0000',
                        color0: '#00da3c',
                        borderColor: '#8A0000',
                        borderColor0: '#008F28',
                    },
                },
                {
                    name: 'MA5',
                    type: 'line',
                    xAxisIndex: 0,
                    yAxisIndex: 0,
                    showSymbol: false,
                    lineStyle: { width: 1, color: '#5470C6' },
                    data: mapValue(ma5.data, 'value', dates),
                },
                {
                    name: 'MA20',
                    type: 'line',
                    xAxisIndex: 0,
                    yAxisIndex: 0,
                    showSymbol: false,
                    lineStyle: { width: 1, color: '#EE6666' },
                    data: mapValue(ma20.data, 'value', dates),
                },
                {
                    name: 'MA60',
                    type: 'line',
                    xAxisIndex: 0,
                    yAxisIndex: 0,
                    showSymbol: false,
                    lineStyle: { width: 1, color: '#91cc75' },
                    data: mapValue(ma60.data, 'value', dates),
                },
            ]
            let subSeries = []

            if (indicator.value === 'rsi') {
                const [rsi5, rsi10] = await Promise.all([
                    api.get('technical-indicators/rsi5', {
                        params: { symbol: props.stockCode },
                    }),
                    api.get('technical-indicators/rsi10', {
                        params: { symbol: props.stockCode },
                    }),
                ])
                subSeries = [
                    {
                        name: 'RSI5',
                        type: 'line',
                        showSymbol: false,
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        lineStyle: { width: 1, color: '#5470C6' },
                        data: mapValue(rsi5.data, 'value', dates),
                    },
                    {
                        name: 'RSI10',
                        type: 'line',
                        showSymbol: false,
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        lineStyle: { width: 1, color: '#EE6666' },
                        data: mapValue(rsi10.data, 'value', dates),
                    },
                ]
            } else if (indicator.value === 'macd') {
                const macd = await api.get('technical-indicators/macd', {
                    params: { symbol: props.stockCode },
                })
                subSeries = [
                    {
                        name: 'DIF',
                        type: 'line',
                        showSymbol: false,
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        lineStyle: { width: 1, color: '#5470C6' },
                        data: mapValue(macd.data, 'dif', dates),
                    },
                    {
                        name: 'MACD',
                        type: 'line',
                        showSymbol: false,
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        lineStyle: { width: 1, color: '#EE6666' },
                        data: mapValue(macd.data, 'macd', dates),
                    },
                    {
                        name: 'OSC',
                        type: 'bar',
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        itemStyle: { color: '#91cc75' },
                        data: mapValue(macd.data, 'osc', dates),
                    },
                ]
            } else {
                const kd = await api.get('technical-indicators/kd', {
                    params: { symbol: props.stockCode },
                })
                subSeries = [
                    {
                        name: 'KD_K',
                        type: 'line',
                        showSymbol: false,
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        lineStyle: { width: 1, color: '#5470C6' },
                        data: mapValue(kd.data, 'kd_k', dates),
                    },
                    {
                        name: 'KD_D',
                        type: 'line',
                        showSymbol: false,
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        lineStyle: { width: 1, color: '#EE6666' },
                        data: mapValue(kd.data, 'kd_d', dates),
                    },
                ]
            }

            loading.value = false
            await nextTick()
            if (!chartContainer.value) return
            myChart?.dispose()
            myChart = echarts.init(chartContainer.value)
            myChart.setOption({
                tooltip: { trigger: 'axis', axisPointer: { type: 'cross' } },
                legend: [
                    {
                        top: 25,
                        data: ['K線', 'MA5', 'MA20', 'MA60'],
                    },
                    {
                        top: '58%',
                        data: subSeries.map((s) => s.name),
                    },
                ],
                grid: [
                    { left: '5%', right: '5%', height: '38%' },
                    { left: '5%', right: '5%', top: '65%', height: '25%' },
                ],
                xAxis: [
                    { type: 'category', data: dates, boundaryGap: true, gridIndex: 0 },
                    { type: 'category', data: dates, boundaryGap: true, gridIndex: 1 },
                ],
                yAxis: [{ scale: true, gridIndex: 0, splitArea: { show: true } }, { gridIndex: 1 }],
                dataZoom: [
                    {
                        type: 'slider',
                        xAxisIndex: [0, 1],
                        start: 100 - (30 / dates.length) * 100,
                        end: 100,
                    },
                    {
                        type: 'inside',
                        xAxisIndex: [0, 1],
                        zoomOnMouseWheel: false,
                        moveOnMouseMove: true,
                        moveCursor: 'grabbing',
                    },
                ],
                series: [...baseSeries, ...subSeries],
            })
        } catch (e) {
            error.value = e
            console.error(e)
        } finally {
            loading.value = false
        }
    }

    onMounted(() => {
        fetchAndDraw()
        window.addEventListener('resize', () => myChart?.resize())
    })

    onUnmounted(() => {
        window.removeEventListener('resize', () => myChart?.resize())
        myChart?.dispose()
    })

    watch(indicator, fetchAndDraw)
    watch(() => props.stockCode, fetchAndDraw)
</script>

<template>
    <div class="bg-gray-50 border rounded-xl relative">
        <div v-if="!loading && hasKData" class="absolute top-[53%] transform -translate-x-1/2 z-20">
            <label class="text-sm text-gray-600 mr-2">技術指標：</label>
            <select v-model="indicator" class="border rounded px-2 py-1 text-sm">
                <option v-for="item in indicatorOptions" :key="item.value" :value="item.value">
                    {{ item.label }}
                </option>
            </select>
        </div>
        <div class="bg-white border rounded-xl h-[600px] w-full relative">
            <div
                v-if="loading"
                class="absolute inset-0 flex items-center justify-center bg-white bg-opacity-80 z-10"
            >
                <p class="text-gray-500 p-4">資料載入中...</p>
            </div>
            <div
                v-else-if="error"
                class="absolute inset-0 flex items-center justify-center bg-white bg-opacity-80 z-10 text-center text-red-500 p-4"
            >
                <p>載入失敗，請檢查網路或 API。</p>
                <p>錯誤訊息: {{ error.message }}</p>
            </div>
            <div
                v-else-if="!hasKData"
                class="absolute inset-0 flex items-center justify-center bg-white z-10 text-center text-gray-700 p-4"
            >
                <p class="text-xl">目前無相關 K 線交易資料 😔</p>
            </div>
            <div v-else ref="chartContainer" class="w-full h-full"></div>
        </div>
    </div>
</template>
