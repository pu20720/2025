// 檔案路徑: Assets/Scripts/SceneManagers/BattleManager.cs
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BattleManager : MonoBehaviour
{
    public static BattleManager Instance { get; private set; }

    [Header("Inventory Integration")]
    public Inventory playerInventory;
    public InventoryManager inventoryManager;
    private ItemData selectedItem;

    [Header("Prefabs & Spawn Points")]
    [SerializeField] private Character playerCharacter;
    [SerializeField] private GameObject enemyCharacterPrefab;
    [SerializeField] private List<string> enemyNamesToSpawn;
    [SerializeField] private List<Transform> enemySpawnPoints = new List<Transform>();

    [Header("Databases")]
    [SerializeField] private EnemyArtLibrary enemyArtLibrary;
    [SerializeField] private RPGStatsData defaultRPGStatsData;

    [Header("Player Sprites")]
    [SerializeField] private Sprite knightSprite;
    [SerializeField] private Sprite adventurerSprite;
    [SerializeField] private Sprite assassinSprite;

    [Header("Card Draw Settings")]
    [SerializeField] private int initialHandSize = 5;
    [SerializeField] private int cardsToDrawPerTurn = 1;

    [Header("UI Reference (Pre-Placed)")]
    [SerializeField] private List<EnemyUI> enemyUIPanels = new List<EnemyUI>();

    [Header("Conditional Cards")]
    [SerializeField] private GameObject activeCardPrefab;
    [SerializeField] private Sprite conditionalCardBack;

    [Header("Targeting")]
    [SerializeField] private GameObject targetIconPrefab;

    [Header("Battle UI")]
    [SerializeField] private Button endTurnButton;
    [SerializeField] private TextMeshProUGUI mpText;
    [SerializeField] private Image mpFillImage;
    [SerializeField] private float mpBarMaxValue = 400f;
    [SerializeField] private Color mpColorBlue = Color.blue;
    [SerializeField] private Color mpColorYellow = Color.yellow;
    [SerializeField] private Color mpColorOrange = new Color(1.0f, 0.5f, 0.0f);
    [SerializeField] private Color mpColorRed = Color.red;
    [SerializeField] private TextMeshProUGUI actionLogText;
    [SerializeField] private Transform coveredCardArea;
    [SerializeField] private TextMeshProUGUI cardPileText;
    [SerializeField] private DeckManager deckManager;

    [Header("Speaker UI (For Tutorial)")]
    public GameObject dialoguePanel;
    [SerializeField] private TMP_Text dialogueText;
    [SerializeField] private TMP_Text speakerNameText;
    [SerializeField] private Image speakerIconImage;
    [SerializeField] private Image dialoguePanelBackground;
    [SerializeField] private List<SpeakerIconEntry> speakerIcons;

    private HorizontalLayoutGroup coveredAreaLayoutGroup;
    private RectTransform coveredAreaRectTransform;
    private float conditionalCardWidth = 360f;
    private float originalCoveredAreaSpacing = 20f;

    private Dictionary<string, Sprite> speakerIconDictionary = new Dictionary<string, Sprite>();
    private bool isInstructionalDialogue = false;
    private BranchStrategy currentStrategy = null;
    private bool isTutorialActive = false;
    private bool isDialogueActive = false;

    private List<Character> activeEnemies = new List<Character>();
    private PlayerUI playerPanel;
    private List<EnemyUI> enemyUIInstances = new List<EnemyUI>();
    private bool isPlayerTurn = false;
    private CardDisplay selectedCardDisplay = null;
    private int globalTurnCount = 1;
    private readonly List<TargetIndicator> allTargetIndicators = new List<TargetIndicator>();
    private List<GameObject> activeTargetIcons = new List<GameObject>();
    private List<ActiveConditionalCard> activeConditionalCards = new List<ActiveConditionalCard>();
    private string chosenBranch = "default";

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        if (endTurnButton != null) endTurnButton.onClick.AddListener(OnEndTurnButtonPressed);

        if (coveredCardArea != null)
        {
            coveredAreaLayoutGroup = coveredCardArea.GetComponent<HorizontalLayoutGroup>();
            coveredAreaRectTransform = coveredCardArea.GetComponent<RectTransform>();
            if (coveredAreaLayoutGroup != null) originalCoveredAreaSpacing = coveredAreaLayoutGroup.spacing;
            if (activeCardPrefab != null)
            {
                RectTransform prefabRect = activeCardPrefab.GetComponent<RectTransform>();
                if (prefabRect != null) conditionalCardWidth = prefabRect.sizeDelta.x;
            }
        }

        SaveData dataToLoad = null;
        if (TempLoadData.Instance != null) dataToLoad = TempLoadData.Instance.GetData();

        chosenBranch = string.IsNullOrEmpty(ConversationManager.chosenBranch) ? "default" : ConversationManager.chosenBranch;

        InitializeSpeakerUI();

        if (speakerIconDictionary.ContainsKey("Player"))
        {
            if (chosenBranch == "Adventurer" && adventurerSprite != null)
                speakerIconDictionary["Player"] = adventurerSprite;
            else if ((chosenBranch == "Assassin_Simple" || chosenBranch == "Assassin_Hard") && assassinSprite != null)
                speakerIconDictionary["Player"] = assassinSprite;
        }

        EnemyDatabase.Initialize(enemyArtLibrary, defaultRPGStatsData);

        enemyUIInstances.Clear();
        foreach (EnemyUI panel in enemyUIPanels) { if (panel != null) panel.gameObject.SetActive(false); }

        // === 分支邏輯 ===
        if (chosenBranch == "Quest")
        {
            // 1. Quest 模式：生成敵人
            // ★★★ 這裡會自動讀取 QuestManager 的 TargetEnemyName ★★★
            SpawnCharacters();

            // 2. 載入玩家裝備與牌組
            InitializeFromLoadout();

            // 3. 設定自由戰鬥
            currentStrategy = null;
            isTutorialActive = false;

            // 4. 開始 (抽牌數量依據 InitialHandSize)
            if (deckManager != null) deckManager.DrawCards(initialHandSize);
            StartPlayerTurnInternal();
        }
        else if (dataToLoad != null && dataToLoad.isInBattle)
        {
            LoadBattleFromSave(dataToLoad);
        }
        else
        {
            // 一般/教學模式
            SpawnCharacters();

            // 非 Loadout 模式，使用預設牌組
            if (deckManager != null)
            {
                deckManager.InitializeDeck(chosenBranch);
                deckManager.DrawCards(initialHandSize);
            }

            if (chosenBranch == "Knight") { currentStrategy = new KnightTutorialStrategy(); isTutorialActive = true; }
            else if (chosenBranch == "Adventurer") { currentStrategy = new AdventurerTutorialStrategy(); isTutorialActive = true; }
            else if (chosenBranch == "Assassin_Simple") { currentStrategy = new AssassinTutorialStrategy(); isTutorialActive = true; }
            else if (chosenBranch == "Assassin_Hard") { currentStrategy = new AssassinHardTutorialStrategy(); isTutorialActive = true; }
            else
            {
                currentStrategy = null;
                isTutorialActive = false;
                StartPlayerTurnInternal();
            }

            if (isTutorialActive && currentStrategy != null)
            {
                currentStrategy.Initialize(this, playerCharacter, activeEnemies);
                currentStrategy.OnBattleStart();
            }
        }
    }

    private void InitializeFromLoadout()
    {
        if (InventoryManager.Instance == null)
        {
            Debug.LogWarning("[BattleManager] No InventoryManager found.");
            if (deckManager != null) deckManager.InitializeDeck("default");
            return;
        }

        // ★★★ 新增：強制初始化 CardDatabase ★★★
        // 這是為了解決 "Database not initialized" 的錯誤
        // 假設您有 CardArtLibrary 的引用 (battleManager 應該有這個欄位)
        // 如果沒有引用，這裡可能會報錯，請確認 BattleManager Inspector 中有綁定 CardArtLibrary
        // 或者，我們可以透過 DeckManager 間接初始化 (如果 DeckManager 有 ArtLibrary 的話)

        if (deckManager != null)
        {
            // 借用 DeckManager 來初始化資料庫 (因為 DeckManager 身上有 ArtLibrary)
            // 我們傳入一個假的 branch name，只是為了觸發裡面的 CardDatabase.Initialize
            deckManager.InitializeDeck("Quest_Preload");
        }

        Debug.Log("[BattleManager] Initializing Loadout...");

        // 1. 裝備數值 (保持不變)
        // ... (略，保持原樣) ...

        // 2. 卡牌繼承
        if (deckManager != null)
        {
            List<CardData> loadoutCards = new List<CardData>();

            foreach (var slot in InventoryManager.Instance.backpackSlots)
            {
                // 這裡加一個 Log 來確認背包裡到底有什麼
                // Debug.Log($"[BattleManager] Checking Slot: {slot.itemData.itemName}, Type: {slot.itemData.itemType}, Equipped: {slot.equippedCount}");

                if (slot.itemData.itemType == ItemType.Card && slot.equippedCount > 0)
                {
                    // 現在 Database 應該已經初始化了，嘗試獲取
                    CardData card = CardDatabase.GetCardByName(slot.itemData.itemName);

                    if (card != null)
                    {
                        for (int i = 0; i < slot.equippedCount; i++)
                        {
                            loadoutCards.Add(card);
                        }
                        Debug.Log($"[BattleManager] Added to Deck: {card.cardName}");
                    }
                    else
                    {
                        Debug.LogError($"[BattleManager] Card '{slot.itemData.itemName}' not found in Database! (Check name spelling)");
                    }
                }
            }

            if (loadoutCards.Count > 0)
            {
                deckManager.SetCustomDeck(loadoutCards);
                Debug.Log($"[BattleManager] Custom Deck Set with {loadoutCards.Count} cards.");
            }
            else
            {
                Debug.LogWarning("[BattleManager] Loadout has 0 cards! Using Default Deck.");
                // 注意：這裡我們不再呼叫 InitializeDeck("default")，因為上面已經透過 Quest_Preload 初始化過了
                // 如果真的沒牌，可能需要手動塞一些預設牌，或者就讓它空著 (視遊戲設計)
            }
        }
    }
    private void Update()
    {
        if (isTutorialActive && currentStrategy != null)
        {
            if (isDialogueActive)
            {
                bool shouldIntercept = !isInstructionalDialogue;

                if (dialogueText != null) dialogueText.raycastTarget = shouldIntercept;
                if (speakerIconImage != null) speakerIconImage.raycastTarget = shouldIntercept;
                if (speakerNameText != null) speakerNameText.raycastTarget = shouldIntercept;
                if (dialoguePanelBackground != null) dialoguePanelBackground.raycastTarget = shouldIntercept;

                if (shouldIntercept)
                {
                    if (Mouse.current.leftButton.wasPressedThisFrame)
                    {
                        if (EventSystem.current.IsPointerOverGameObject())
                        {
                            GameObject clickedObject = EventSystem.current.currentSelectedGameObject;
                            if (clickedObject != null && clickedObject.GetComponent<Button>() != null) return;
                        }
                        currentStrategy.OnDialoguePanelClicked();
                    }
                    return;
                }
            }
            currentStrategy.OnUpdate();
        }
    }

    private void SpawnCharacters()
    {
        // 1. 清除舊資料
        allTargetIndicators.Clear();
        activeEnemies.Clear();

        // 2. 初始化玩家
        string playerName = string.IsNullOrEmpty(ConversationManager.playerName) ? "Player" : ConversationManager.playerName;

        if (playerCharacter != null)
        {
            playerCharacter.InitializeAsPlayer(playerName);
            playerPanel = playerCharacter.GetComponentInChildren<PlayerUI>(true);
            if (playerPanel != null) { playerPanel.Initialize(playerCharacter); }

            switch (chosenBranch)
            {
                case "Adventurer": playerCharacter.SetCharacterSprite(adventurerSprite); break;
                case "Assassin_Simple":
                case "Assassin_Hard": playerCharacter.SetCharacterSprite(assassinSprite); break;
                case "Knight": playerCharacter.SetCharacterSprite(knightSprite); break;
                case "default": break;
            }
        }

        // 3. 決定要生成的敵人清單
        List<string> enemyNamesToSpawnThisBattle = new List<string>();
        switch (chosenBranch)
        {
            case "Quest":
                if (QuestManager.Instance != null && QuestManager.Instance.currentAcceptedQuest != null)
                {
                    string target = QuestManager.Instance.currentAcceptedQuest.targetEnemyName;
                    if (string.IsNullOrEmpty(target)) target = "Assassin";
                    enemyNamesToSpawnThisBattle.Add(target);
                    Debug.Log($"[BattleManager] Spawning Quest Target: {target}");
                }
                else
                {
                    enemyNamesToSpawnThisBattle.Add("Target");
                    Debug.LogWarning("[BattleManager] No accepted quest found! Spawning Target dummy.");
                }
                break;

            // ▼▼▼ 【修改重點】 常駐模式：生成 3 隻 Goblin (模擬 Slime) ▼▼▼
            case "Verminus_Mode":
            case "default":
                enemyNamesToSpawnThisBattle.Add("Evil Dragon");
                Debug.Log("[BattleManager] Spawning 3 Slimes (Goblin) for permanent mode.");
                break;
            // ▲▲▲ 修改結束 ▲▲▲

            case "Knight":
            case "Adventurer":
                enemyNamesToSpawnThisBattle.Add("Target");
                break;

            case "Assassin_Simple":
                enemyNamesToSpawnThisBattle.Add("Assassin");
                break;

            case "Assassin_Hard":
                enemyNamesToSpawnThisBattle.Add("Assassin");
                enemyNamesToSpawnThisBattle.Add("Assassin");
                enemyNamesToSpawnThisBattle.Add("Assassin");
                break;

            default:
                enemyNamesToSpawnThisBattle = new List<string>(enemyNamesToSpawn);
                break;
        }

        // 4. 生成敵人實體
        for (int i = 0; i < enemySpawnPoints.Count; i++)
        {
            if (i >= enemyNamesToSpawnThisBattle.Count) break;
            if (i >= enemyUIPanels.Count) break;

            Transform spawnPoint = enemySpawnPoints[i];
            string enemyName = enemyNamesToSpawnThisBattle[i];
            EnemyUI enemyUI = enemyUIPanels[i];

            if (string.IsNullOrEmpty(enemyName)) continue;

            EnemyData data = EnemyDatabase.GetEnemyDataByName(enemyName);
            if (data == null)
            {
                Debug.LogError($"[BattleManager] Enemy '{enemyName}' not found in database!");
                continue;
            }

            var enemyObj = Instantiate(enemyCharacterPrefab, spawnPoint.position, spawnPoint.rotation);
            Character enemyCharacter = enemyObj.GetComponentInChildren<Character>(true);
            EnemyAI enemyAI = enemyObj.GetComponentInChildren<EnemyAI>(true);

            if (enemyCharacter == null || enemyAI == null)
            {
                Destroy(enemyObj);
                continue;
            }

            enemyCharacter.InitializeFromData(data);
            // 修正過的 EnemyAI.Initialize 只需要 data 和 Character
            enemyAI.Initialize(data, enemyCharacter);

            if (chosenBranch == "Assassin_Hard")
            {
                enemyAI.SetTutorialHardMode(i);
            }

            activeEnemies.Add(enemyCharacter);

            if (enemyUI != null)
            {
                enemyUI.gameObject.SetActive(true);
                enemyUI.Initialize(enemyCharacter);
                enemyUIInstances.Add(enemyUI);
            }
        }

        // 5. 初始化所有目標指示器 (Target Indicators) 與 UI 更新
        InitializeAllTargetIndicators();
        UpdateBattleUI();
    }

    public void StartPlayerTurnInternal()
    {
        if (playerCharacter == null || playerCharacter.stats == null || playerCharacter.stats.data == null) return;

        if (playerCharacter.stats.stunTurns > 0 || playerCharacter.stats.frozenTurns > 0)
        {
            string statusLog = "";
            if (playerCharacter.stats.stunTurns > 0)
            {
                playerCharacter.stats.stunTurns--;
                statusLog += "Stunned";
            }
            if (playerCharacter.stats.frozenTurns > 0)
            {
                playerCharacter.stats.frozenTurns--;
                statusLog += (statusLog.Length > 0 ? " & Paused" : "Paused");
            }

            LogAction($"Player is {statusLog}, turn skipped!");
            UpdateBattleUI();
            EndPlayerTurn("Control effect skip.");
            return;
        }

        isPlayerTurn = true;
        playerCharacter.OnTurnStart();
        InitializeAllTargetIndicators();

        if (globalTurnCount > 1)
        {
            RPGStatsData statsData = playerCharacter.stats.data;
            int recover = 0;
            if (playerCharacter.stats.turnCount >= statsData.mpRecoverTurnsUntilSuper)
            {
                recover = statsData.mpRecoverSuperAmount;
            }
            else
            {
                recover = Mathf.Min(
                    statsData.mpRecoverBase * playerCharacter.stats.turnCount,
                    statsData.mpRecoverCap
                );
            }
            playerCharacter.stats.mp += recover;
            LogAction($"Player turn {globalTurnCount}. Recovered {recover} MP.");
        }
        else
        {
            LogAction($"Player turn 1. Battle start!");
        }

        playerCharacter.stats.turnCount++;
        UpdateBattleUI();

        if (deckManager != null) UpdateCardPileText(deckManager.GetRemainingDeckCount());

        if (isTutorialActive && currentStrategy != null)
        {
            currentStrategy.OnPlayerTurnStart();
        }
    }

    public void OnEndTurnButtonPressed()
    {
        if (isTutorialActive && isDialogueActive && !isInstructionalDialogue) return;
        if (!isPlayerTurn) return;

        bool validated = true;
        if (isTutorialActive && currentStrategy != null) validated = currentStrategy.ValidateEndTurn();

        if (validated) EndPlayerTurn("Player ends the turn.");
    }

    private void EndPlayerTurn(string endReasonLog = "Player turn ends.")
    {
        isPlayerTurn = false;
        DeselectCard();
        ClearAllTargetIcons();
        LogAction(endReasonLog);
        UpdateBattleUI();
        if (CheckForBattleEnd()) return;

        globalTurnCount++;
        StartCoroutine(EnemyTurnCoroutine());
    }

    private IEnumerator EnemyTurnCoroutine()
    {
        yield return new WaitForSeconds(1.0f);
        LogAction($"Enemy turn {globalTurnCount}.");

        bool anyStatusTriggered = false;
        foreach (var enemy in activeEnemies)
        {
            if (enemy != null && !enemy.stats.isDead)
            {
                enemy.OnTurnStart();
                anyStatusTriggered = true;
            }
        }
        if (anyStatusTriggered) UpdateBattleUI();

        yield return new WaitForSeconds(3.0f);

        var livingEnemies = activeEnemies.Where(e => e != null && !e.stats.isDead).ToList();

        foreach (var enemy in livingEnemies)
        {
            if (playerCharacter != null && playerCharacter.stats != null && !playerCharacter.stats.isDead)
            {
                if (enemy.stats.stunTurns > 0 || enemy.stats.frozenTurns > 0)
                {
                    string statusLog = "";
                    if (enemy.stats.stunTurns > 0)
                    {
                        enemy.stats.stunTurns--;
                        statusLog += "Stunned";
                    }
                    if (enemy.stats.frozenTurns > 0)
                    {
                        enemy.stats.frozenTurns--;
                        statusLog += (statusLog.Length > 0 ? " & Paused" : "Paused");
                    }

                    LogAction($"{enemy.characterName} is {statusLog}, turn skipped.");
                    UpdateBattleUI();
                    yield return new WaitForSeconds(2.0f);
                    continue;
                }

                EnemyAI ai = enemy.GetComponent<EnemyAI>();
                if (ai != null)
                {
                    ai.ExecuteTurn(playerCharacter);
                    if (isTutorialActive && currentStrategy != null)
                    {
                        currentStrategy.OnEnemyAction(ai, playerCharacter);
                    }
                }

                UpdateBattleUI();
                yield return new WaitForSeconds(3.0f);
            }
            else
            {
                break;
            }
        }

        LogAction("Enemy turn ends.");

        if (CheckForBattleEnd()) { yield break; }

        globalTurnCount++;

        if (!isTutorialActive)
        {
            deckManager.DrawCards(cardsToDrawPerTurn);
        }
        else if (isTutorialActive && currentStrategy != null && currentStrategy.CanDrawCards())
        {
            deckManager.DrawCards(cardsToDrawPerTurn);
        }

        StartPlayerTurnInternal();
    }

    public void HandleCardClick(CardData card, CardDisplay display)
    {
        if (!isPlayerTurn) return;
        if (playerCharacter == null || playerCharacter.stats == null) return;

        if (isTutorialActive && currentStrategy != null)
        {
            if (!currentStrategy.ValidateCardClick(card)) return;
        }

        if (card.mpCost > playerCharacter.stats.mp)
        {
            LogAction("Not enough MP!");
            return;
        }

        if (isTutorialActive && isDialogueActive) ClearTutorialDialogue();

        DeselectCard();
        selectedCardDisplay = display;
        selectedCardDisplay.Select();
        ShowValidTargetIndicators(card);
    }

    public void HandleTargetClick(TargetIndicator target)
    {
        if (!isPlayerTurn) return;

        if (selectedCardDisplay != null)
        {
            CardData card = selectedCardDisplay.GetCardData();
            if (card == null) return;

            if (isTutorialActive && currentStrategy != null)
            {
                if (currentStrategy.HandleTargetClick(card, target)) return;
            }

            if (ValidateTarget(card, target))
            {
                GameObject cardObjectToDiscard = selectedCardDisplay.gameObject;
                PlayCard(card, target);

                if (deckManager != null) deckManager.PlayCardToDiscard(card, cardObjectToDiscard);

                DeselectCard();
                CheckForBattleEnd();
            }
            else
            {
                LogAction($"Invalid target for {card.cardName}.");
                DeselectCard();
            }
            return;
        }

        if (selectedItem != null)
        {
            if (ValidateItemTarget(selectedItem, target)) UseItem(selectedItem, target.GetCharacter());
            else { LogAction("Invalid target for this item."); DeselectItem(); }
            return;
        }
    }

    public void PlayCard(CardData card, TargetIndicator target)
    {
        if (playerCharacter.stats.mp < card.mpCost)
        {
            LogAction("Not enough MP!");
            return;
        }

        Character targetCharacter = target.GetCharacter();
        playerCharacter.stats.mp -= card.mpCost;

        List<string> logEffects = new List<string>();

        switch (card.type)
        {
            case CardType.Attack:
            case CardType.Weapon:
                if (card.cardName.Trim() == "Cleave")
                {
                    string mainLog = PerformDefaultAttack(card, target, targetCharacter);
                    logEffects.Add(mainLog);
                    if (card.cleaveDamage > 0)
                    {
                        var otherEnemies = activeEnemies.Where(e => e != targetCharacter && e != null && !e.stats.isDead);
                        foreach (var otherEnemy in otherEnemies)
                        {
                            string splashLog = PerformCleaveAttack(card, otherEnemy, card.cleaveDamage, true);
                            logEffects.Add(splashLog);
                        }
                    }
                }
                else
                {
                    string attackLog = PerformDefaultAttack(card, target, targetCharacter);
                    logEffects.Add(attackLog);
                }

                if (card.statusStacks > 0 && targetCharacter != null && !targetCharacter.stats.isDead)
                {
                    targetCharacter.stats.AddStatus(card.statusToApply, card.statusStacks, target.GetArmorPart());
                    logEffects.Add($"Applied {card.statusStacks} {card.statusToApply} to {targetCharacter.characterName}!");
                }
                break;

            case CardType.Magic:
                if (card.cleanseDebuffs)
                {
                    playerCharacter.stats.CleanseDebuffs();
                    logEffects.Add("Player is cleansed of all debuffs.");
                }
                if (card.effectValue > 0 && target.GetCategory() == TargetCategory.Player)
                {
                    playerCharacter.stats.Heal(card.effectValue);
                    logEffects.Add($"Restored {card.effectValue} HP.");
                }
                break;

            case CardType.Debuff:
                if (targetCharacter != null)
                {
                    targetCharacter.stats.AddStatus(card.statusToApply, card.effectValue, card.targetArmorPart);
                    logEffects.Add($"{targetCharacter.characterName} is afflicted with {card.statusToApply}!");
                }
                break;

            case CardType.Armor:
                ArmorPart partToRepair = target.GetArmorPart();
                playerCharacter.stats.Repair(partToRepair, card.effectValue);
                logEffects.Add($"Repaired {partToRepair} by {card.effectValue}.");
                break;

            case CardType.Buff:
                if (target.GetCategory() == TargetCategory.CardInHand)
                {
                    CardDisplay targetCardDisplay = target.GetCardDisplay();
                    if (targetCardDisplay != null)
                    {
                        CardData targetCardData = targetCardDisplay.GetCardData();
                        if (card.effectValue > 0)
                        {
                            targetCardData.effectValue += card.effectValue;
                            logEffects.Add($"Infused {targetCardData.cardName} with +{card.effectValue} attack!");
                        }
                        if (card.statusStacks > 0)
                        {
                            targetCardData.statusToApply = card.statusToApply;
                            targetCardData.statusStacks += card.statusStacks;
                            logEffects.Add($"Coated {targetCardData.cardName} with {card.statusToApply}!");
                        }
                    }
                }
                if (card.drawCards > 0)
                {
                    logEffects.Add($"Drew {card.drawCards} card(s).");
                    deckManager.DrawCards(card.drawCards);
                }
                break;

            case CardType.Conditional:
                if (activeCardPrefab != null)
                {
                    GameObject cardGO = Instantiate(activeCardPrefab, coveredCardArea);
                    ActiveConditionalCard activeCard = cardGO.GetComponent<ActiveConditionalCard>();
                    if (activeCard != null)
                    {
                        activeCard.Initialize(card);
                        activeConditionalCards.Add(activeCard);
                        logEffects.Add($"Set {card.cardName}.");
                        UpdateCoveredAreaSpacing();
                    }
                }
                break;
        }

        string combinedLog = $"Player used {card.cardName}. " + string.Join(" ", logEffects);
        LogAction(combinedLog);
        UpdateBattleUI();
    }

    public void DeselectCard()
    {
        if (selectedCardDisplay != null)
        {
            selectedCardDisplay.Deselect();
            selectedCardDisplay = null;
        }
        ClearAllTargetIcons();
    }

    public void SelectItem(ItemData item)
    {
        DeselectCard();
        selectedItem = item;
        LogAction($"Selected item: {item.itemName}. Choose a target.");
        ShowValidTargetIndicatorsForItem(item);
    }

    public void DeselectItem()
    {
        selectedItem = null;
        ClearAllTargetIcons();
    }

    private void UseItem(ItemData item, Character target)
    {
        if (item.healAmount > 0)
        {
            target.stats.Heal(item.healAmount);
            LogAction($"Used {item.itemName}. Healed {item.healAmount} HP.");
        }

        if (inventoryManager != null)
        {
            inventoryManager.RemoveItemData(item);
        }
        else
        {
            if (playerInventory != null) playerInventory.RemoveItem(item.itemID, 1);
        }

        DeselectItem();
        UpdateBattleUI();
    }

    public void UpdateBattleUI()
    {
        if (playerCharacter == null || playerCharacter.stats == null) return;
        if (mpText != null) mpText.text = playerCharacter.stats.mp.ToString();
        if (mpFillImage != null)
        {
            float fill = Mathf.Clamp01(playerCharacter.stats.mp / mpBarMaxValue);
            mpFillImage.fillAmount = fill;
            if (playerCharacter.stats.mp >= 400) mpFillImage.color = mpColorRed;
            else if (playerCharacter.stats.mp >= 300) mpFillImage.color = mpColorOrange;
            else if (playerCharacter.stats.mp >= 200) mpFillImage.color = mpColorYellow;
            else mpFillImage.color = mpColorBlue;
        }
        if (playerPanel != null) playerPanel.UpdateStats();
        foreach (var enemyUI in enemyUIInstances) { if (enemyUI != null) enemyUI.UpdateStats(); }
    }

    public void LogAction(string message)
    {
        if (actionLogText != null) actionLogText.text = message;
        else Debug.Log($"[ActionLog] {message}");
    }

    public void LogCharacterStatus(string message)
    {
        LogAction(message);
    }

    private bool ValidateTarget(CardData card, TargetIndicator targetIndicator)
    {
        if (card == null || targetIndicator == null) return false;

        Character targetChar = targetIndicator.GetCharacter();

        // =========================================================
        // ▼▼▼ 【新增規則】 禁止玩家選擇 Plague Doctor ▼▼▼
        // =========================================================
        if (targetChar != null && targetChar.characterName == "Plague Doctor")
        {
            // 直接回傳 false，讓玩家無法對他使用任何卡片
            return false;
        }
        // ▲▲▲ 規則結束 ▲▲▲

        TargetCategory category = targetIndicator.GetCategory();

        if (targetChar == null)
        {
            if (card.type == CardType.Buff && category == TargetCategory.CardInHand)
            {
                CardDisplay targetCard = targetIndicator.GetCardDisplay();
                return (targetCard != null && targetCard.GetCardData().type == CardType.Weapon);
            }
            if (card.type == CardType.Conditional && category == TargetCategory.Special) return true;
            return false;
        }

        if (category == TargetCategory.PlayerArmorSlot || category == TargetCategory.EnemyArmorSlot)
        {
            ArmorSlot slot = targetChar.stats.GetArmorSlot(targetIndicator.GetArmorPart());
            if (slot == null) return false;
            if (card.type == CardType.Armor) return (category == TargetCategory.PlayerArmorSlot && slot.currentArmor > 0);
            if (slot.currentArmor <= 0) return false;
        }

        switch (card.type)
        {
            case CardType.Attack:
            case CardType.Weapon:
            case CardType.Debuff:
                if (category == TargetCategory.Enemy)
                {
                    bool allArmorUp = targetChar.stats.helmet.currentArmor > 0 &&
                                      targetChar.stats.armor.currentArmor > 0 &&
                                      targetChar.stats.gauntlets.currentArmor > 0 &&
                                      targetChar.stats.legArmor.currentArmor > 0;
                    return !allArmorUp;
                }
                return (category == TargetCategory.EnemyArmorSlot);
            case CardType.Armor: return false;
            case CardType.Buff: return false;
            case CardType.Magic: return (category == TargetCategory.Player);
            case CardType.Conditional: return false;
        }
        return false;
    }

    private bool ValidateItemTarget(ItemData item, TargetIndicator target)
    {
        if (item.itemType == ItemType.Consumable)
        {
            if (item.healAmount > 0 && target.GetCategory() == TargetCategory.Player) return true;
        }
        return false;
    }
    // 1. 修改顯示目標圖示的函數
    private void ShowValidTargetIndicators(CardData card)
    {
        if (card == null) return;
        ClearAllTargetIcons();

        foreach (var ind in allTargetIndicators)
        {
            if (ind == null) continue;

            if (ValidateTarget(card, ind))
            {
                if (targetIconPrefab != null)
                {
                    GameObject icon = Instantiate(targetIconPrefab, ind.transform);
                    icon.SetActive(true);

                    Image iconImage = icon.GetComponent<Image>();
                    SpriteRenderer iconSprite = icon.GetComponent<SpriteRenderer>();

                    bool targetIsUI = ind.GetComponent<RectTransform>() != null;

                    if (targetIsUI)
                    {
                        // === UI 模式 ===
                        if (iconImage != null) { iconImage.enabled = true; iconImage.raycastTarget = false; }
                        if (iconSprite != null) iconSprite.enabled = false;

                        // ★★★ 關鍵修正：強制重置縮放為 1x1x1 ★★★
                        icon.transform.localScale = Vector3.one;

                        RectTransform rect = icon.GetComponent<RectTransform>();
                        if (rect != null)
                        {
                            rect.anchorMin = new Vector2(0.5f, 0.5f);
                            rect.anchorMax = new Vector2(0.5f, 0.5f);
                            rect.pivot = new Vector2(0.5f, 0.5f);
                            rect.anchoredPosition = Vector2.zero;

                            // ★★★ 關鍵修正：長寬設為 100x100 ★★★
                            rect.sizeDelta = new Vector2(100f, 100f);
                        }
                        icon.transform.SetAsLastSibling();
                    }
                    else
                    {
                        // === 角色模式 ===
                        if (iconImage != null) iconImage.enabled = false;
                        if (iconSprite != null)
                        {
                            iconSprite.enabled = true;
                            iconSprite.sortingLayerName = "UI";
                            iconSprite.sortingOrder = 999;
                        }

                        icon.transform.localPosition = Vector3.zero;
                        icon.transform.localRotation = Quaternion.identity;
                        icon.transform.localScale = Vector3.one;
                    }

                    icon.layer = LayerMask.NameToLayer("UI");
                    activeTargetIcons.Add(icon);
                }
            }
        }
    }

    // 2. 修改顯示物品目標圖示的函數 (同步修正)
    private void ShowValidTargetIndicatorsForItem(ItemData item)
    {
        ClearAllTargetIcons();
        if (targetIconPrefab == null || playerCharacter == null) return;

        TargetIndicator playerIndicator = allTargetIndicators.FirstOrDefault(
            ind => ind.GetCharacter() == playerCharacter && ind.GetCategory() == TargetCategory.Player);

        if (playerIndicator != null)
        {
            GameObject icon = Instantiate(targetIconPrefab, playerIndicator.transform);
            icon.SetActive(true);

            Image iconImage = icon.GetComponent<Image>();
            SpriteRenderer iconSprite = icon.GetComponent<SpriteRenderer>();

            bool targetIsUI = playerIndicator.GetComponent<RectTransform>() != null;

            if (targetIsUI)
            {
                if (iconImage != null) { iconImage.enabled = true; iconImage.raycastTarget = false; }
                if (iconSprite != null) iconSprite.enabled = false;

                // ★★★ 強制重置縮放 ★★★
                icon.transform.localScale = Vector3.one;

                RectTransform rect = icon.GetComponent<RectTransform>();
                if (rect != null)
                {
                    rect.anchorMin = new Vector2(0.5f, 0.5f);
                    rect.anchorMax = new Vector2(0.5f, 0.5f);
                    rect.pivot = new Vector2(0.5f, 0.5f);
                    rect.anchoredPosition = Vector2.zero;

                    // ★★★ 長寬設為 100x100 ★★★
                    rect.sizeDelta = new Vector2(100f, 100f);
                }
                icon.transform.SetAsLastSibling();
            }
            else
            {
                if (iconImage != null) iconImage.enabled = false;
                if (iconSprite != null)
                {
                    iconSprite.enabled = true;
                    iconSprite.sortingLayerName = "UI";
                    iconSprite.sortingOrder = 999;
                }

                icon.transform.localPosition = Vector3.zero;
                icon.transform.localRotation = Quaternion.identity;
                icon.transform.localScale = Vector3.one;
            }

            icon.layer = LayerMask.NameToLayer("UI");
            activeTargetIcons.Add(icon);
        }
    }
    private void ClearAllTargetIcons()
    {
        foreach (GameObject icon in activeTargetIcons) Destroy(icon);
        activeTargetIcons.Clear();
    }

    private string PerformDefaultAttack(CardData card, TargetIndicator target, Character targetCharacter)
    {
        if (target.GetCategory() == TargetCategory.EnemyArmorSlot)
        {
            ArmorPart partToHit = target.GetArmorPart();
            int damageDealt = targetCharacter.stats.TakeDamage(card.effectValue, card.damageType, partToHit, card.piercePercent);
            return $"Deals {damageDealt} damage to {targetCharacter.characterName}'s {partToHit}.";
        }
        else
        {
            int damageDealt = targetCharacter.stats.TakeDamage(card.effectValue, DamageType.True, card.targetArmorPart, 0);
            return $"Deals {damageDealt} HP damage to {targetCharacter.characterName}.";
        }
    }

    private string PerformCleaveAttack(CardData card, Character target, int damage, bool isSplash)
    {
        if (target == null || target.stats == null || target.stats.isDead) return "";
        string logHeader = isSplash ? $"{card.cardName} splash" : "";
        int damageDealt;
        string logSuffix;

        if (target.stats.IsAnyArmorBroken())
        {
            damageDealt = target.stats.TakeDamage(damage, DamageType.True, ArmorPart.Armor);
            logSuffix = $"Deals {damageDealt} HP damage to {target.characterName}.";
        }
        else
        {
            ArmorPart partToHit = target.stats.GetLowestArmorPart();
            damageDealt = target.stats.TakeDamage(damage, DamageType.Normal, partToHit);
            logSuffix = $"Deals {damageDealt} damage to {target.characterName}'s {partToHit}.";
        }
        return !string.IsNullOrEmpty(logHeader) ? $"{logHeader}: {logSuffix}" : logSuffix;
    }

    public void OnEnemyDied(Character deadEnemy)
    {
        int index = activeEnemies.IndexOf(deadEnemy);
        if (index != -1 && index < enemyUIInstances.Count)
        {
            EnemyUI uiPanel = enemyUIInstances[index];
            if (uiPanel != null)
            {
                Destroy(uiPanel.gameObject);
                enemyUIInstances[index] = null;
            }
        }
    }

    public bool CheckForAttackNegation(Character target)
    {
        if (target.gameObject.CompareTag("Player"))
        {
            ActiveConditionalCard wardCard = activeConditionalCards.FirstOrDefault(c => c.GetTriggerType() == ConditionalTriggerType.OnPlayerAttacked);
            if (wardCard != null) return wardCard.TriggerEffect();
        }
        return false;
    }

    private bool CheckForBattleEnd()
    {
        if (isTutorialActive && currentStrategy != null)
        {
            if (currentStrategy.CheckForSpecialBattleEnd(out bool playerWon)) return true;
        }
        if (!isTutorialActive)
        {
            if (playerCharacter != null && playerCharacter.stats.isDead)
            {
                LogAction("Player was defeated. Game Over.");
                isPlayerTurn = false;
                return true;
            }
            if (activeEnemies.All(e => e == null || e.stats.isDead))
            {
                LogAction("All enemies defeated. Victory!");
                isPlayerTurn = false;
                return true;
            }
        }
        return false;
    }

    public int GetGlobalTurnCount() { return globalTurnCount; }
    public bool IsPlayerTurn() => isPlayerTurn;
    public Character GetPlayerCharacter() => playerCharacter;
    public CardDisplay GetSelectedCardDisplay() { return selectedCardDisplay; }
    public Sprite GetConditionalCardBack() { return conditionalCardBack; }
    public DeckManager GetDeckManager() => deckManager;
    public void RemoveActiveConditional(ActiveConditionalCard card) { activeConditionalCards.Remove(card); UpdateCoveredAreaSpacing(); }
    public void UpdateCardPileText(int remaining) { if (cardPileText != null) cardPileText.text = $"Card:{remaining}"; }

    public void ShowTutorialDialogue(string speaker, string text, bool isInstruction = false)
    {
        if (dialoguePanel == null) return;
        isDialogueActive = true;
        isInstructionalDialogue = isInstruction;
        dialogueText.text = text;

        if (speaker == "Narrator" || string.IsNullOrEmpty(speaker))
        {
            speakerNameText.text = "";
            speakerIconImage.enabled = false;
        }
        else if (speakerIconDictionary.TryGetValue(speaker, out Sprite icon))
        {
            speakerNameText.text = speaker;
            speakerIconImage.sprite = icon;
            speakerIconImage.enabled = true;
        }
        else
        {
            speakerNameText.text = speaker;
            speakerIconImage.enabled = false;
        }
    }

    public bool IsDialogueActiveAndIntercepting() => isDialogueActive && !isInstructionalDialogue;
    public bool IsDialogueInstructional() => isDialogueActive && isInstructionalDialogue;
    public void ClearTutorialDialogue() { isDialogueActive = false; if (dialoguePanel != null) { dialogueText.text = ""; speakerNameText.text = ""; speakerIconImage.enabled = false; } }
    public void OnDialoguePanelClicked() { if (isTutorialActive && currentStrategy != null) currentStrategy.OnDialoguePanelClicked(); }

    public IEnumerator EndTutorialGame(bool playerWon)
    {
        isPlayerTurn = false;
        yield return new WaitForSeconds(3.0f);
        ClearTutorialDialogue();
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }

    private void InitializeSpeakerUI()
    {
        if (dialoguePanel != null) dialoguePanel.SetActive(true);
        speakerIconDictionary.Clear();
        foreach (var entry in speakerIcons)
        {
            if (entry != null && !string.IsNullOrEmpty(entry.speakerKey)) speakerIconDictionary[entry.speakerKey] = entry.speakerIcon;
        }
    }

    private void UpdateCoveredAreaSpacing()
    {
        if (coveredAreaLayoutGroup == null || coveredAreaRectTransform == null || conditionalCardWidth <= 0) return;
        int cardCount = activeConditionalCards.Count;

        // ▼▼▼ 【修正】這裡要用 originalCoveredAreaSpacing ▼▼▼
        if (cardCount <= 1) { coveredAreaLayoutGroup.spacing = originalCoveredAreaSpacing; return; }
        // ▲▲▲

        float coveredAreaWidth = coveredAreaRectTransform.rect.width;
        float totalCardWidth = conditionalCardWidth * cardCount;

        // ▼▼▼ 【修正】這裡也要用 originalCoveredAreaSpacing ▼▼▼
        float totalRequiredWidth = totalCardWidth + (originalCoveredAreaSpacing * (cardCount - 1));
        // ▲▲▲

        if (totalRequiredWidth > coveredAreaWidth)
        {
            float newSpacing = (coveredAreaWidth - totalCardWidth) / (float)(cardCount - 1);
            coveredAreaLayoutGroup.spacing = newSpacing;
        }
        else
        {
            // ▼▼▼ 【修正】這裡也要用 originalCoveredAreaSpacing ▼▼▼
            coveredAreaLayoutGroup.spacing = originalCoveredAreaSpacing;
            // ▲▲▲
        }
    }

    public void RegisterTargetIndicator(TargetIndicator indicator) { if (!allTargetIndicators.Contains(indicator)) allTargetIndicators.Add(indicator); }
    public void UnregisterTargetIndicator(TargetIndicator indicator) { allTargetIndicators.Remove(indicator); }

    public void GatherSaveData(SaveData data)
    {
        if (data == null) return;
        data.isInBattle = true;
        data.globalTurnCount = this.globalTurnCount;
        data.chosenBranch = this.chosenBranch;

        if (playerCharacter != null && playerCharacter.stats != null)
            data.playerSaveData = playerCharacter.stats.GatherSaveData();

        data.enemiesSaveData = new List<CharacterSaveData>();
        foreach (var enemy in activeEnemies)
        {
            if (enemy != null && enemy.stats != null)
                data.enemiesSaveData.Add(enemy.stats.GatherSaveData());
        }

        if (deckManager != null) data.deckSaveData = deckManager.GatherSaveData();

        data.conditionalCardsSaveData = new List<ConditionalCardSaveData>();
        foreach (var condCard in activeConditionalCards)
        {
            if (condCard != null) data.conditionalCardsSaveData.Add(condCard.GatherSaveData());
        }

        if (isTutorialActive && currentStrategy != null) data.tutorialStepName = currentStrategy.GetCurrentTutorialStepName();
        else data.tutorialStepName = "FreePlay";

        if (isDialogueActive)
        {
            data.savedDialogueSpeaker = speakerNameText.text;
            data.savedDialogueText = dialogueText.text;
            data.savedIsInstructional = this.isInstructionalDialogue;
        }
    }

    private void LoadBattleFromSave(SaveData data)
    {
        this.chosenBranch = data.chosenBranch;
        this.globalTurnCount = data.globalTurnCount;

        if (speakerIconDictionary.ContainsKey("Player"))
        {
            if (chosenBranch == "Adventurer" && adventurerSprite != null) speakerIconDictionary["Player"] = adventurerSprite;
            else if ((chosenBranch == "Assassin_Simple" || chosenBranch == "Assassin_Hard") && assassinSprite != null) speakerIconDictionary["Player"] = assassinSprite;
        }

        if (playerCharacter != null)
        {
            playerCharacter.InitializeAsPlayer(data.PlayerName);
            playerCharacter.stats.LoadFromSave(data.playerSaveData);
            playerPanel = playerCharacter.GetComponentInChildren<PlayerUI>(true);
            if (playerPanel != null) playerPanel.Initialize(playerCharacter);

            switch (chosenBranch)
            {
                case "Knight": playerCharacter.SetCharacterSprite(knightSprite); break;
                case "Adventurer": playerCharacter.SetCharacterSprite(adventurerSprite); break;
                case "Assassin_Simple": case "Assassin_Hard": playerCharacter.SetCharacterSprite(assassinSprite); break;
                case "default": break;
            }
        }

        activeEnemies.Clear();
        for (int i = 0; i < data.enemiesSaveData.Count; i++)
        {
            if (i >= enemySpawnPoints.Count || i >= enemyUIPanels.Count) break;
            CharacterSaveData enemyData = data.enemiesSaveData[i];
            Transform spawnPoint = enemySpawnPoints[i];
            EnemyUI enemyUI = enemyUIPanels[i];
            EnemyData dataSheet = EnemyDatabase.GetEnemyDataByName(enemyData.characterNameForLoad);
            if (dataSheet == null) continue;

            var enemyObj = Instantiate(enemyCharacterPrefab, spawnPoint.position, spawnPoint.rotation);
            Character enemyCharacter = enemyObj.GetComponentInChildren<Character>(true);
            EnemyAI enemyAI = enemyObj.GetComponentInChildren<EnemyAI>(true);

            if (enemyCharacter == null || enemyAI == null)
            {
                Destroy(enemyObj);
                continue;
            }

            enemyCharacter.InitializeFromData(dataSheet);
            enemyCharacter.stats.LoadFromSave(enemyData);
            enemyAI.Initialize(dataSheet, enemyCharacter);
            activeEnemies.Add(enemyCharacter);

            if (enemyUI != null)
            {
                enemyUI.gameObject.SetActive(true);
                enemyUI.Initialize(enemyCharacter);
                enemyUIInstances.Add(enemyUI);
            }
        }

        if (deckManager != null)
        {
            deckManager.InitializeDeck(chosenBranch);
            deckManager.LoadHandFromSave(data.deckSaveData);
        }

        activeConditionalCards.Clear();
        foreach (var condCardData in data.conditionalCardsSaveData)
        {
            CardData cardData = CardDatabase.GetCardByName(condCardData.cardName);
            if (cardData != null && activeCardPrefab != null)
            {
                GameObject cardGO = Instantiate(activeCardPrefab, coveredCardArea);
                ActiveConditionalCard activeCard = cardGO.GetComponent<ActiveConditionalCard>();
                if (activeCard != null)
                {
                    activeCard.Initialize(cardData);
                    activeCard.LoadFromSave(condCardData);
                    activeConditionalCards.Add(activeCard);
                }
            }
        }
        UpdateCoveredAreaSpacing();
        InitializeAllTargetIndicators();
        UpdateBattleUI();
        isPlayerTurn = true;
        LogAction("Game loaded. Player turn.");
    }

    private void InitializeAllTargetIndicators()
    {
        var allIndicators = FindObjectsByType<TargetIndicator>(FindObjectsInactive.Include, FindObjectsSortMode.None);

        foreach (var indicator in allIndicators)
        {
            if (indicator != null)
            {
                indicator.Initialize();
            }
        }
    }
}