# rag_backend.py


import os
import re
import math
from collections import Counter
from typing import Optional, List, Tuple, Any

# ====  huggingface_hub 相容補丁 ====
import importlib

try:
    hf_errors = importlib.import_module("huggingface_hub.errors")
except Exception as e:
    hf_errors = None
    print(f"[Compat] 無法載入 huggingface_hub.errors：{e}")

if hf_errors is not None:
    
    if not hasattr(hf_errors, "EntryNotFoundError"):
        class EntryNotFoundError(Exception):
            """Compat shim for huggingface_hub.errors.EntryNotFoundError"""
            pass

        hf_errors.EntryNotFoundError = EntryNotFoundError
        print("[Compat] 已注入 huggingface_hub.errors.EntryNotFoundError")

    
    if not hasattr(hf_errors, "LocalEntryNotFoundError"):
        class LocalEntryNotFoundError(hf_errors.EntryNotFoundError):
            """Compat shim for huggingface_hub.errors.LocalEntryNotFoundError"""
            pass

        hf_errors.LocalEntryNotFoundError = LocalEntryNotFoundError
        print("[Compat] 已注入 huggingface_hub.errors.LocalEntryNotFoundError")

# ==== LangChain / Chroma / Embeddings ====
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

# ==== Pandas（直接讀 courses_1132.csv）====
try:
    import pandas as pd
except Exception as e:
    pd = None
    print(f"[RAG-backend] 警告：無法載入 pandas：{e}，老師姓名查詢將無法使用表格精準查詢。")

# === 路徑與設定） ===
CHROMA_DIR = r"F:\test\rag\test\chroma_db"     # 向量資料庫資料夾
RAG_COLLECTION_NAME = "courses_rag"            # 建庫時用的 collection_name
RAG_EMB_MODEL = "BAAI/bge-small-zh-v1.5"       # 建庫時用的 embedding 模型

# === 課程表 CSV 路徑 ===
COURSE_CSV_PATH = r"F:\test\rag\test\data\courses_1132.csv"

# ======= 進階檢索 / re-rank 設定 =======
# 是否啟用「超保守模式」：若所有候選文件跟 query 的字面重疊都很低，直接視為查無資料
ENABLE_SUPER_CONSERVATIVE = True
SUPER_MIN_BEST_LEX = 0.03    # 最高字面重疊 門檻 

# 是否啟用 BM25 / 關鍵字 + 向量混合排序
ENABLE_BM25_HYBRID = True
BM25_K1 = 1.5
BM25_B = 0.75
# hybrid_score = α * 向量相似 + (1-α) * BM25_norm
HYBRID_ALPHA = 0.6

# 
ENABLE_LLM_RERANK = True    
RERANK_MODEL_NAME = "BAAI/bge-reranker-base"
RERANK_DEVICE = "cuda"
MAX_RERANK_DOCS = 12          # 最多交給 re-ranker 的候選數

# hybrid 排序後，還要一起輸出的「高相關」門檻 & 最多輸出幾筆
REL_TOP_HYBRID = 0.7      # 相關
MAX_FINAL_DOCS = 10       # 最多輸出幾筆，避免 context 過長

# ====================================================
# 全域暫存向量庫 & 課程表
_vectorstore: Optional[Chroma] = None
_course_df: Any = None          
_teacher_names_norm: List[str] = []

# re-ranker 模型（小模型）
_rerank_model = None
_rerank_tokenizer = None


# ===============================
# 基本工具
# ===============================
def _normalize_spaces(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def _lexical_overlap_score(query: str, text: str) -> float:
    """
    用很簡單的方式計算「query 跟 text 的字面重疊程度」：
    - 只看字元層級（適合中文人名、課名）
    - 去掉空白和換行
    - 回傳 0~1 之間的大約比例（只是拿來相對比較用）
    """
    q = _normalize_spaces(query)
    t = _normalize_spaces(text)

    if not q or not t:
        return 0.0

    q_set = set(q)
    hits = sum(1 for ch in t if ch in q_set)
    return hits / max(1, len(q))


def _tokenize_for_bm25(s: str) -> List[str]:
    """
    BM25 用的簡單 tokenizer：
    - 先移除空白
    - 中文就當成「每個字一個 token」
    """
    s = _normalize_spaces(s)
    return list(s)


def _compute_bm25_scores(query: str, docs: List[str]) -> List[float]:
    """
    在「候選文件集合 docs」上，對 query 計算一組簡化 BM25 分數。
    （這裡不是對整個 corpus，而是對 similarity_search 抓回來的候選做二階段排序）
    """
    if not docs:
        return []

    q_tokens = _tokenize_for_bm25(query)
    if not q_tokens:
        return [0.0] * len(docs)

    doc_tokens_list = [_tokenize_for_bm25(d) for d in docs]
    N = len(doc_tokens_list)
    avgdl = sum(len(toks) for toks in doc_tokens_list) / max(1, N)

    # 統計 df
    df = {}
    for toks in doc_tokens_list:
        for term in set(toks):
            df[term] = df.get(term, 0) + 1

    # idf
    idf = {}
    for term, freq in df.items():
        idf[term] = math.log((N - freq + 0.5) / (freq + 0.5) + 1.0)

    bm25_scores = []
    q_terms = list(set(q_tokens))  # 去重，避免重複加權
    for toks in doc_tokens_list:
        tf = Counter(toks)
        dl = len(toks)
        score = 0.0
        for term in q_terms:
            if term not in tf or term not in idf:
                continue
            f = tf[term]
            denom = f + BM25_K1 * (1 - BM25_B + BM25_B * dl / avgdl)
            score += idf[term] * f * (BM25_K1 + 1) / denom
        bm25_scores.append(score)

    return bm25_scores


def _min_max_norm(values: List[float]) -> List[float]:
    """
    把一組分數縮放到 [0, 1]，全部一樣時回傳 0.5。
    """
    if not values:
        return []
    v_min = min(values)
    v_max = max(values)
    if v_max - v_min < 1e-8:
        return [0.5] * len(values)
    return [(v - v_min) / (v_max - v_min) for v in values]


# ===============================
# 向量庫載入
# ===============================
def _ensure_vectorstore() -> Optional[Chroma]:
    
    global _vectorstore

    if _vectorstore is not None:
        return _vectorstore

    if not os.path.isdir(CHROMA_DIR):
        print(f"[RAG-backend] 找不到向量資料庫資料夾：{CHROMA_DIR}")
        return None

    try:
        print("[RAG-backend] 載入 BGE Embedding 模型…")
        embedding = HuggingFaceEmbeddings(
            model_name=RAG_EMB_MODEL,
            model_kwargs={'device': 'cpu'},
            encode_kwargs={'normalize_embeddings': True},
        )

        print(f"[RAG-backend] 從 {CHROMA_DIR} 載入 Chroma 向量資料庫…")
        vs = Chroma(
            collection_name=RAG_COLLECTION_NAME,
            persist_directory=CHROMA_DIR,
            embedding_function=embedding,
        )

        # 額外印出目前有幾筆向量
        try:
            n = vs._collection.count()
            print(f"[RAG-backend] collection '{RAG_COLLECTION_NAME}' 目前共有 {n} 筆向量。")
        except Exception as e:
            print(f"[RAG-backend] 無法取得 collection 筆數：{e}")

        _vectorstore = vs
        print("[RAG-backend] 向量庫載入完成，可用。")
        return _vectorstore

    except Exception as e:
        print(f"[RAG-backend] 初始化向量庫失敗：{e}")
        _vectorstore = None
        return None


# ===============================
# 課程表（CSV）載入 + 老師姓名偵測
# ===============================
def _ensure_courses_table():
    
    global _course_df, _teacher_names_norm

    if _course_df is not None:
        return

    if pd is None:
        print("[RAG-backend] 無 pandas，無法使用課程 CSV 精準查詢。")
        return

    if not os.path.isfile(COURSE_CSV_PATH):
        print(f"[RAG-backend] 找不到課程 CSV 檔：{COURSE_CSV_PATH}")
        return

    try:
        df = pd.read_csv(COURSE_CSV_PATH)
    except Exception as e:
        print(f"[RAG-backend] 讀取課程 CSV 失敗：{e}")
        return

    if "instructor" not in df.columns:
        print("[RAG-backend] 課程 CSV 缺少 instructor 欄位，無法做老師查詢。")
        return

    df["instructor"] = df["instructor"].fillna("")
    df["instructor_norm"] = df["instructor"].astype(str).str.replace(r"\s+", "", regex=True)

    teacher_names = sorted(set(df["instructor_norm"]) - {""})

    _course_df = df
    _teacher_names_norm = teacher_names

    print(f"[RAG-backend] 課程 CSV 已載入，共有 {len(df)} 筆課程，老師數量：約 {len(teacher_names)} 位。")


def _detect_teacher_in_query(query_norm: str) -> Optional[str]:
    """
    嘗試從 query（去掉空白後）裡找出「出現在 instructor 欄位裡的老師姓名」。
    回傳的是「老師姓名（去空白後）」；找不到則回傳 None。
    """
    _ensure_courses_table()
    if not _teacher_names_norm:
        return None

    best_name = None
    best_len = 0
    for name in _teacher_names_norm:
        if not name:
            continue
        if name in query_norm and len(name) > best_len:
            best_name = name
            best_len = len(name)

    return best_name


def _lookup_courses_by_teacher(teacher_norm: str) -> List[dict]:
    
    _ensure_courses_table()
    if _course_df is None:
        return []

    df = _course_df
    mask = df["instructor_norm"].str.contains(teacher_norm, na=False)
    rows = df[mask].copy()
    if rows.empty:
        return []

    # 去掉完全重複的課，用 (名稱, 老師, 時間) 當 key
    seen = set()
    uniq_rows = []
    for _, r in rows.iterrows():
        key = (str(r.get("name", "")).strip(),
               str(r.get("instructor", "")).strip(),
               str(r.get("time", "")).strip())
        if key in seen:
            continue
        seen.add(key)
        uniq_rows.append(r.to_dict())

    # 排序一下，讓輸出穩定一點
    uniq_rows.sort(key=lambda d: (str(d.get("name", "")), str(d.get("time", ""))))

    return uniq_rows


def _build_context_from_course_rows(rows: List[dict], max_docs: Optional[int] = None) -> str:
   
    if not rows:
        return ""

    if max_docs is not None and len(rows) > max_docs:
        rows = rows[:max_docs]

    parts = []
    for i, r in enumerate(rows, start=1):
        name = str(r.get("name", "") or "").strip()
        instructor = str(r.get("instructor", "") or "").strip()
        time_place = str(r.get("time", "") or "").strip()
        desc = str(r.get("description", "") or "").strip()
        grading = str(r.get("grading", "") or "").strip()
        url = str(r.get("url", "") or "").strip()

        lines = [
            f"[{i}] 來源：courses_1132.csv",
            f"課程名稱(回答時如果有使用請原封不動複製名稱)：{name}",
            f"授課教師：{instructor}",
        ]

        if time_place:
            # ★ 在 context 裡明寫：這是「時間地點」原始文字，回答時請原封不動複製
            lines.append("【以下為時間地點原始文字，回答時如果有使用請原封不動複製這一行】")
            lines.append(f"時間地點：{time_place}")

        if desc:
            lines.append(f"課程簡介：{desc}")
        if grading:
            lines.append(f"評分方式：{grading}")
        if url:
            lines.append(f"課程連結：{url}")

        block = "\n".join(lines)
        parts.append(block)

    return "\n\n".join(parts)


# ===============================
# 小模型 re-rank（cross-encoder）
# ===============================
def _ensure_rerank_model():
    """
    懶載入 re-ranker 模型（例如 BAAI/bge-reranker-base）。
    只在 ENABLE_LLM_RERANK = True 時使用。
    """
    global _rerank_model, _rerank_tokenizer
    if _rerank_model is not None:
        return

    try:
        from transformers import AutoTokenizer, AutoModelForSequenceClassification
    except Exception as e:
        print(f"[RAG-backend][Rerank] 無法載入 transformers 進行 re-rank：{e}")
        return

    try:
        print(f"[RAG-backend][Rerank] 載入小模型：{RERANK_MODEL_NAME}")
        _rerank_tokenizer = AutoTokenizer.from_pretrained(RERANK_MODEL_NAME)
        _rerank_model = AutoModelForSequenceClassification.from_pretrained(RERANK_MODEL_NAME)
        _rerank_model.to(RERANK_DEVICE)
        _rerank_model.eval()
    except Exception as e:
        print(f"[RAG-backend][Rerank] 載入模型失敗：{e}")
        _rerank_model = None
        _rerank_tokenizer = None


def _llm_rerank(query: str, docs: List[str]) -> List[int]:
  
    if not ENABLE_LLM_RERANK or not docs:
        return list(range(len(docs)))

    _ensure_rerank_model()
    if _rerank_model is None or _rerank_tokenizer is None:
        # 模型載入失敗就原順序回傳
        return list(range(len(docs)))

    from torch import no_grad

    # 最多只 re-rank 前 MAX_RERANK_DOCS 篇（避免太慢）
    n = min(len(docs), MAX_RERANK_DOCS)
    sub_docs = docs[:n]

    # 對每篇 doc 做 [query, doc] 的 pair scoring
    inputs = _rerank_tokenizer(
        [query] * n,
        sub_docs,
        padding=True,
        truncation=True,
        return_tensors="pt"
    ).to(RERANK_DEVICE)

    with no_grad():
        outputs = _rerank_model(**inputs)
        # 假設是 regression / 單一 logit
        if hasattr(outputs, "logits"):
            logits = outputs.logits.squeeze(-1).cpu().tolist()
        else:
            # fallback
            logits = [0.0] * n

    # 將 logits 轉成排序 index（由大到小）
    sub_indices = list(range(n))
    sub_indices.sort(key=lambda i: logits[i], reverse=True)

    # 如果 docs 比 n 多，後面那幾個照原順序接在後面
    if len(docs) > n:
        tail_indices = list(range(n, len(docs)))
        return sub_indices + tail_indices
    else:
        return sub_indices


# ===============================
# 給 GUI 用的統一輸出：RAG Context
# ===============================
def _log_rag_ctx(ctx: str, reason: str = ""):
    """
    統一輸出給 launcher_gui 用的 RAG context 區塊。

    ctx    = 準備丟給 LLM 的 context（可以是空字串）
    reason = 若沒有實際資料，可以放說明文字，讓 GUI 那格至少有「查無資料」之類的訊息
    """
    print("[RAG-CTX-BEGIN]", flush=True)

    text = (ctx or "").strip()
    if text:
        print(text, flush=True)
    else:
        msg = reason.strip() or "（RAG 無相關資料）"
        print(msg, flush=True)

    print("[RAG-CTX-END]", flush=True)


# ===============================
# 主函式：search_context
# ===============================
def search_context(query: str, k: int = 4) -> str:
    """
    對外提供的查詢函式：
    傳入使用者問題 query（建議是 LLM 幫你整理過的關鍵字）
    回傳整理好的 context 文字（給 LLM 當參考）
    """

    query_norm = _normalize_spaces(query)

    # =====  老師姓名查詢 → 直接走 CSV =====
    teacher_norm = _detect_teacher_in_query(query_norm)
    if teacher_norm:
        print(f"[RAG-backend] 偵測老師姓名查詢，改用課程表精準搜尋：{teacher_norm}")
        rows = _lookup_courses_by_teacher(teacher_norm)
        if rows:
            context = _build_context_from_course_rows(rows, max_docs=MAX_FINAL_DOCS)
            print(f"[RAG-backend] 老師查詢：共找到 {len(rows)} 門課。")
            #  一定輸出給 GUI
            _log_rag_ctx(context)
            return context
        else:
            print("[RAG-backend] 課程表中找不到這位老師。")
            # 也讓 GUI 看到「沒找到」
            _log_rag_ctx("", reason="（課程表中找不到這位老師，RAG 無結果）")
            return ""

    # =====  一般向量檢索流程 =====
    vs = _ensure_vectorstore()
    if vs is None:
        _log_rag_ctx("", reason="（RAG 向量資料庫尚未載入或初始化失敗）")
        return ""

    raw_k = max(k * 5, 20)

    try:
        print(f"[RAG-backend] 查詢：{query}")
        docs_with_scores: List[Tuple] = vs.similarity_search_with_score(query, k=raw_k)
        print(f"[RAG-backend] 初始命中筆數：{len(docs_with_scores)}")
    except Exception as e:
        print(f"[RAG-backend] 查詢失敗：{e}")
        _log_rag_ctx("", reason=f"（RAG 查詢失敗：{e}）")
        return ""

    if not docs_with_scores:
        _log_rag_ctx("", reason="（RAG 查無任何命中項目）")
        return ""

    docs = [d for (d, dist) in docs_with_scores]
    vec_dists = [dist for (d, dist) in docs_with_scores]

    # ===== 字面重疊評估 =====
    lex_scores = [_lexical_overlap_score(query, d.page_content) for d in docs]
    best_lex = max(lex_scores) if lex_scores else 0.0
    print(f"[RAG-backend] 最高字面重疊分數：{best_lex:.4f}")

    if ENABLE_SUPER_CONSERVATIVE and best_lex < SUPER_MIN_BEST_LEX:
        print("[RAG-backend] 超保守模式：字面重疊太低，視為無可靠資料。")
        _log_rag_ctx("", reason="（超保守模式：查詢與資料重合度過低，視為查無資料）")
        return ""

    # ===== BM25 / hybrid 排序 =====
    if ENABLE_BM25_HYBRID:
        bm25_scores = _compute_bm25_scores(query, [d.page_content for d in docs])
    else:
        bm25_scores = [0.0] * len(docs)

    vec_sims_raw = [1.0 / (1.0 + max(0.0, dist)) for dist in vec_dists]
    vec_sims = _min_max_norm(vec_sims_raw)
    bm25_norm = _min_max_norm(bm25_scores)

    hybrid_scores = []
    for vsim, b25 in zip(vec_sims, bm25_norm):
        hybrid_scores.append(HYBRID_ALPHA * vsim + (1.0 - HYBRID_ALPHA) * b25)

    indices = list(range(len(docs)))
    indices.sort(key=lambda i: hybrid_scores[i], reverse=True)

    sorted_docs = [docs[i] for i in indices]
    sorted_scores = [hybrid_scores[i] for i in indices]
    sorted_lex = [lex_scores[i] for i in indices]

    # 可選：LLM re-rank（如果有開 ENABLE_LLM_RERANK）
    rerank_order = _llm_rerank(query, [d.page_content for d in sorted_docs])
    reranked_docs = [sorted_docs[i] for i in rerank_order]
    reranked_scores = [sorted_scores[i] for i in rerank_order]
    reranked_lex = [sorted_lex[i] for i in rerank_order]

    if not reranked_docs:
        _log_rag_ctx("", reason="（RAG 排序後沒有候選文件）")
        return ""

    best_score = reranked_scores[0]
    selected: List[Tuple] = []

    # 撈分數接近第一名的
    for doc, sc, lx in zip(reranked_docs, reranked_scores, reranked_lex):
        if sc < best_score * REL_TOP_HYBRID:
            break
        selected.append((doc, sc, lx))

    # 不足 k 筆就補
    if len(selected) < k:
        needed = k - len(selected)
        for doc, sc, lx in zip(
            reranked_docs[len(selected):],
            reranked_scores[len(selected):],
            reranked_lex[len(selected):]
        ):
            selected.append((doc, sc, lx))
            needed -= 1
            if needed <= 0:
                break

    # 安全上限
    if MAX_FINAL_DOCS is not None and len(selected) > MAX_FINAL_DOCS:
        selected = selected[:MAX_FINAL_DOCS]

    final_docs   = [d  for (d, sc, lx) in selected]
    final_scores = [sc for (d, sc, lx) in selected]
    final_lex    = [lx for (d, sc, lx) in selected]

    print("[RAG-backend] 最終選用 {} 筆：".format(len(final_docs)))
    for i, (sc, lx) in enumerate(zip(final_scores, final_lex), start=1):
        print(f"  - #{i}: hybrid={sc:.4f}, lex={lx:.4f}")

    if not final_docs:
        _log_rag_ctx("", reason="（RAG 經篩選後沒有合適文件）")
        return ""

    parts = []
    for i, d in enumerate(final_docs, start=1):
        src = d.metadata.get("source", "")
        parts.append(f"[{i}] 來源：{src}\n{d.page_content.strip()}")

    context = "\n\n".join(parts)

    # 最終一定輸出給 GUI
    _log_rag_ctx(context)
    return context


# === 可選：單獨測試用 ===
if __name__ == "__main__":
    print("RAG Backend 測試模式，輸入問題（exit 離開）")
    while True:
        q = input("問題：").strip()
        if not q:
            continue
        if q.lower() == "exit":
            break
        ctx = search_context(q, k=3)
        print("\n==== RAG Context ====")
        print(ctx or "(沒有查到資料)")
        print("=====================\n")
