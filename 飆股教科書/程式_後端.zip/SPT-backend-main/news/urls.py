from .views import NewsView
from django.urls import path

urlpatterns = [
    path('', NewsView.as_view(), name='news'),
]
