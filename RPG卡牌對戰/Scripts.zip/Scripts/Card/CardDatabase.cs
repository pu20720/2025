using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public static class CardDatabase
{
    private static List<CardData> allCards = new List<CardData>();
    private static bool isInitialized = false;
    private static CardArtLibrary cachedArtLibrary;

    public static void Initialize(CardArtLibrary artLibrary)
    {
        if (isInitialized) return;
        cachedArtLibrary = artLibrary;
        BuildCardList();
        isInitialized = true;
    }

    public static void ResetCardStats() => BuildCardList();

    private static void BuildCardList()
    {
        allCards.Clear();
        Dictionary<string, Sprite> art = new Dictionary<string, Sprite>();
        if (cachedArtLibrary != null)
        {
            foreach (var entry in cachedArtLibrary.cardArtEntries)
                if (!art.ContainsKey(entry.cardName)) art.Add(entry.cardName, entry.cardArt);
        }

        // ========================================================================
        // 1. 基礎與修正卡片
        // ========================================================================
        allCards.Add(new CardData { cardName = "Fortify Armor", description = "Reinforce: Target armor gains +10 Durability. (Grade C)", mpCost = 10, type = CardType.Armor, effectValue = 10, targetArmorPart = ArmorPart.Armor, cardGrade = "C", itemPrice = 600, isStarterCard = true, cardArt = GetArt(art, "Fortify Armor") });
        allCards.Add(new CardData { cardName = "Heal", description = "Magic: Restores 25 HP. (Grade B)", mpCost = 30, type = CardType.Magic, effectValue = 25, cardGrade = "B", itemPrice = 600, isStarterCard = true, cardArt = GetArt(art, "Heal") });
        allCards.Add(new CardData { cardName = "Divine_Radiance", description = "Cleanse: Removes all negative status effects. (Grade C)", mpCost = 150, type = CardType.Magic, cleanseDebuffs = true, cardGrade = "C", itemPrice = 30000, isStarterCard = true, cardArt = GetArt(art, "Divine_Radiance") });
        allCards.Add(new CardData { cardName = "Cleave", description = "Attack: Deal +5% bonus dmg to target. Deal 2% of weapon dmg to adjacent enemies. (Grade B)", mpCost = 80, type = CardType.Attack, effectValue = 5, cleaveDamage = 2, cardGrade = "B", itemPrice = 2500, isStarterCard = true, cardArt = GetArt(art, "Cleave") });
        allCards.Add(new CardData { cardName = "Threefold_Ward", description = "Conditional: Negate ALL attacks for 3 turns. (Grade A)", mpCost = 400, type = CardType.Conditional, durationTurns = 3, damageReductionPercent = 100, triggerType = ConditionalTriggerType.OnPlayerAttacked, cardGrade = "A", itemPrice = 65000, isStarterCard = true, cardArt = GetArt(art, "Threefold_Ward") });
        allCards.Add(new CardData
        {
            cardName = "Sharp Blade",
            description = "5 Dmg + Bleeding.",
            mpCost = 10,
            type = CardType.Weapon,
            effectValue = 5,
            statusToApply = StatusType.Bleed,
            statusStacks = 1,
            cardGrade = "C",
            itemPrice = 500,
            isStarterCard = true,
            cardArt = GetArt(art, "Sharp Blade") // <--- 確保這裡的字串與 Library 中的名稱一致
        });
        // Envenom & Bloodlust Axe (非初始)
        allCards.Add(new CardData { cardName = "Envenom", description = "Buff: Coats weapon with deadly venom (Apply 2 Poison). (Grade C)", mpCost = 40, type = CardType.Buff, statusToApply = StatusType.Poison, statusStacks = 2, cardGrade = "C", itemPrice = 300, isStarterCard = false, cardArt = GetArt(art, "Envenom") });
        allCards.Add(new CardData { cardName = "Bloodlust Axe", description = "Buff: Enchant weapon with 3 stacks of Bleed. (Grade B)", mpCost = 120, type = CardType.Buff, statusToApply = StatusType.Bleed, statusStacks = 3, cardGrade = "B", itemPrice = 15000, isStarterCard = false, cardArt = GetArt(art, "Bloodlust Axe") });

        // ========================================================================
        // 2. 護甲類
        // ========================================================================
        allCards.Add(new CardData { cardName = "CHAINMAIL ARMOR", description = "GAIN +50 ARMOR.", mpCost = 150, type = CardType.Armor, effectValue = 50, cardGrade = "C", itemPrice = 180000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "CRUCIFIX ARMOR", description = "GAIN +100 ARMOR.", mpCost = 250, type = CardType.Armor, effectValue = 100, cardGrade = "C", itemPrice = 20000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "REINFORCED STEEL", description = "Multiply all current armor by 1.5x.", mpCost = 150, type = CardType.Armor, effectValue = 0, cardGrade = "A", itemPrice = 13000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "GERMAN TECHNOLOGY", description = "Double all current armor values.", mpCost = 200, type = CardType.Armor, effectValue = 0, cardGrade = "A", itemPrice = 13000, isStarterCard = true });

        // ========================================================================
        // 3. 特殊機制與擴充卡片
        // ========================================================================
        allCards.Add(new CardData { cardName = "Mana Spring", description = "Magic: GAIN +80 MANA.", mpCost = 20, type = CardType.Magic, effectValue = 80, cardGrade = "B", itemPrice = 80000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Star Platinum", description = "Conditional: Gain +100 All Stats (3 turns) & Block all incoming attacks (1 turn).", mpCost = 400, type = CardType.Conditional, effectValue = 100, durationTurns = 3, cardGrade = "A", itemPrice = 180000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Money Bag", description = "Active: Chance to gain MP (90%: 0-50, 5%: 51-80...).", mpCost = 20, type = CardType.Magic, cardGrade = "C", itemPrice = 5, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Bunker Brute", description = "Conditional: Chance to gain Armor or lose Health each turn.", mpCost = 0, type = CardType.Conditional, cardGrade = "B", itemPrice = 130000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "You're already here", description = "Conditional: Randomly apply 2 buffs and 2 debuffs to self (3 turns).", mpCost = 150, type = CardType.Conditional, durationTurns = 3, cardGrade = "B", itemPrice = 50000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Big Loaf", description = "Conditional: Block 75% damage, deal 1 counter dmg.", mpCost = 80, type = CardType.Conditional, damageReductionPercent = 75, effectValue = 1, cardGrade = "C", itemPrice = 500, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Lightning Five-Chain Whip", description = "Conditional: Attack 5 times with 35% damage ratio.", mpCost = 500, type = CardType.Conditional, hitCount = 5, attackRatio = 0.35f, cardGrade = "A", itemPrice = 200000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Dirty Sneak Attack", description = "Conditional: +1 Attack opportunity, lose 1 HP (3 turns).", mpCost = 150, type = CardType.Conditional, extraAttacks = 1, statusToApply = StatusType.Bleed, statusStacks = 1, durationTurns = 3, cardGrade = "S", itemPrice = 650000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Vehicle Destroyer", description = "Buff: Convert buff stacks into 5 Attack Power.", mpCost = 800, type = CardType.Buff, effectValue = 5, cardGrade = "S", itemPrice = 600000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Trampoline", description = "Conditional: 50% chance +20% ATK / 50% chance -20 HP.", mpCost = 0, type = CardType.Conditional, durationTurns = 3, cardGrade = "A", itemPrice = 65000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Silent Six", description = "Attack: Execute enemies with <=10% HP (30% fail chance).", mpCost = 0, type = CardType.Attack, cardGrade = "A", itemPrice = 3000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Giant Mushroom", description = "Passive: Deduct 30% Enemy HP (if >50%), lose 1% Self HP/turn.", mpCost = 300, type = CardType.Conditional, cardGrade = "A", itemPrice = 500000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Resentful Toiler", description = "Conditional: After 50 turns, enemy attacks reflect 1% HP dmg.", mpCost = 500, type = CardType.Conditional, turnThreshold = 50, cardGrade = "A", itemPrice = 28500, isStarterCard = true });
        allCards.Add(new CardData { cardName = "STRONGER WITH ADVERSITY", description = "Conditional: GAIN +50 ATTACK WHEN HP < 25%.", mpCost = 300, type = CardType.Conditional, effectValue = 50, charges = 1, cardGrade = "B", isStarterCard = true });
        allCards.Add(new CardData { cardName = "OVERDRAW FUTURE", description = "Conditional: DIE in 20 turns. GAIN +20 ATTACK/TURN.", mpCost = 450, type = CardType.Conditional, effectValue = 20, cardGrade = "A", isStarterCard = true });
        allCards.Add(new CardData { cardName = "LAST STAND HEALING", description = "Conditional: DIE in 20 turns. GAIN +100 HP/TURN.", mpCost = 800, type = CardType.Conditional, effectValue = 100, cardGrade = "S", isStarterCard = true });
        allCards.Add(new CardData { cardName = "TEMPORAL MANA PACT", description = "Conditional: DIE in 20 turns. GAIN +20 ATTACK/TURN.", mpCost = 300, type = CardType.Conditional, effectValue = 20, cardGrade = "A", isStarterCard = true });
        allCards.Add(new CardData { cardName = "CLASSIC PORRIDGE", description = "Debuff: Poison and Stun enemy for 3 turns.", mpCost = 350, type = CardType.Debuff, statusToApply = StatusType.Poison, statusStacks = 1, durationTurns = 3, cardGrade = "B", itemPrice = 40000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "HEALING FOUNTAIN", description = "Magic: Restore 80 HP.", mpCost = 20, type = CardType.Magic, effectValue = 80, cardGrade = "B", itemPrice = 80000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Sacrifice", description = "Consume 10-30% HP to deal 20-30% dmg.", mpCost = 20, type = CardType.Attack, cardGrade = "B", itemPrice = 10000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Forced Vigor", description = "Restore 100 HP now. Lose 100 HP after 3 turns.", mpCost = 150, type = CardType.Magic, effectValue = 100, durationTurns = 3, cardGrade = "B", itemPrice = 35000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Elixir of Clarity", description = "Cleanse debuffs. Restore 1 HP/turn (3 turns).", mpCost = 100, type = CardType.Magic, cleanseDebuffs = true, effectValue = 1, durationTurns = 3, cardGrade = "A", itemPrice = 6400, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Roar of the Hut", description = "30% kill chance / 99% HP loss chance.", mpCost = 50, type = CardType.Magic, cardGrade = "C", itemPrice = 1000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Tavern Oratory", description = "Chance +10% ATK / Chance -20% Armor.", mpCost = 0, type = CardType.Buff, cardGrade = "C", itemPrice = 500000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Last Stand", description = "If HP<=0: HP=1, +30% Stats, MaxHP=1.", mpCost = 350, type = CardType.Conditional, cardGrade = "A", itemPrice = 45000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Lion's Roar", description = "Deal 200 Pierce Dmg to all enemies.", mpCost = 400, type = CardType.Attack, damageType = DamageType.Pierce, effectValue = 200, cardGrade = "B", itemPrice = 84000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Sciatica Tonic", description = "Next turn: Cleanse & Restore 20 HP.", mpCost = 250, type = CardType.Magic, cardGrade = "C", itemPrice = 50000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Quacker's Grand Lunchbox", description = "Wait 5 turns. Gain Hypertension (Lose 10 HP/turn).", mpCost = 30, type = CardType.Conditional, durationTurns = 5, statusToApply = StatusType.Bleed, statusStacks = 10, cardGrade = "B", itemPrice = 10000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Labor's Return", description = "Deduct 20 MP (3 turns). Then gain 81 MP.", mpCost = 0, type = CardType.Magic, effectValue = 81, durationTurns = 3, cardGrade = "C", itemPrice = 6500, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Poisoned Dagger", description = "5 Dmg + Poison.", mpCost = 10, type = CardType.Weapon, effectValue = 5, statusToApply = StatusType.Poison, statusStacks = 1, cardGrade = "C", itemPrice = 500, isStarterCard = true });
        allCards.Add(new CardData { cardName = "Rusted Dagger", description = "5 Dmg + Tetanus.", mpCost = 20, type = CardType.Weapon, effectValue = 5, statusToApply = StatusType.Corruption, statusStacks = 1, cardGrade = "C", itemPrice = 100, isStarterCard = true });

        // ▼▼▼ 【修正】將 Sharp Dagger 改名為 Sharp Blade ▼▼▼
        allCards.Add(new CardData { cardName = "Sharp Blade", description = "5 Dmg + Bleeding.", mpCost = 10, type = CardType.Weapon, effectValue = 5, statusToApply = StatusType.Bleed, statusStacks = 1, cardGrade = "C", itemPrice = 500, isStarterCard = true });
        // ▲▲▲ 修正結束 ▲▲▲

        // ========================================================================
        // 4. 高階效果卡片
        // ========================================================================
        allCards.Add(new CardData { cardName = "HEARTY FEAST", description = "Passive: Healing x2.", mpCost = 250, type = CardType.Buff, effectValue = 2, cardGrade = "A", itemPrice = 18000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "RESILIENT BLOCK", description = "Conditional: Block 50% damage.", mpCost = 80, type = CardType.Conditional, damageReductionPercent = 50, cardGrade = "B", itemPrice = 80, isStarterCard = true });
        allCards.Add(new CardData { cardName = "BERSERKER'S ECHO", description = "Conditional: Counterattack after 3 hits.", mpCost = 300, type = CardType.Conditional, charges = 3, cardGrade = "A", itemPrice = 200000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "DANCE OF DEATH", description = "Conditional: Delay 50% damage.", mpCost = 400, type = CardType.Conditional, durationTurns = 5, effectValue = 50, cardGrade = "S", itemPrice = 500000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "GAUNTLET OF BLOOD", description = "ATK from Armor.", mpCost = 400, type = CardType.Buff, cardGrade = "S", itemPrice = 600000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "ALL-OUT STRIKE", description = "Weapon dmg x2.", mpCost = 200, type = CardType.Buff, effectValue = 2, durationTurns = 1, cardGrade = "B", itemPrice = 50000, isStarterCard = true });
        allCards.Add(new CardData { cardName = "DUAL WIELD", description = "Weapons hit x2.", mpCost = 400, type = CardType.Buff, extraAttacks = 1, durationTurns = 1, cardGrade = "A", itemPrice = 100000, isStarterCard = true });
    }

    private static Sprite GetArt(Dictionary<string, Sprite> d, string n) => d.ContainsKey(n) ? d[n] : null;
    public static List<CardData> GetAllCards() => new List<CardData>(allCards);
    public static CardData GetCardByName(string n) => allCards.FirstOrDefault(c => c.cardName == n);
}