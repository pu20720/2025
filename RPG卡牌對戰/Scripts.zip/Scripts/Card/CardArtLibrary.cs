// 檔案路徑: Assets/Scripts/Card/CardArtLibrary.cs
using System.Collections.Generic;
using UnityEngine;

// ▼▼▼ 這是一個 [System.Serializable] 類別，不需要是獨立檔案 ▼▼▼
[System.Serializable]
public class CardArtEntry
{
    public string cardName; // (您需要手動輸入 "Cleave", "Sharpen" 等)
    public Sprite cardArt;  // (您需要手動拖曳 Cleave.jpg, Sharpen.jpg 等)
}
// ▲▲▲ 結束 ▲▲▲


// ▼▼▼ 這是您要在 Project 視窗中建立的 .asset 檔案 ▼▼▼
[CreateAssetMenu(fileName = "CardArtLibrary", menuName = "RPG/Card Art Library")]
public class CardArtLibrary : ScriptableObject
{
    [Header("在此處連結所有卡片圖片")]
    [Tooltip("您只需要在這裡手動設置卡片名稱和圖片")]
    public List<CardArtEntry> cardArtEntries = new List<CardArtEntry>();
}
// ▲▲▲ 結束 ▲▲▲