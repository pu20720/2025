using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Linq;
using System.Collections; // 為了 IEnumerator

public class AdventurerManager : MonoBehaviour
{
    public static AdventurerManager Instance;

    [Header("UI Reference")]
    public AdventurerUI ui;

    [Header("Simulation Config")]
    public Sprite defaultEnemyIcon;
    public string defaultEnemyName = "Assassin";

    private List<QuestData> poolD = new List<QuestData>();
    private List<QuestData> poolC = new List<QuestData>();
    private List<QuestData> poolB = new List<QuestData>();
    private List<QuestData> poolA = new List<QuestData>();
    private List<QuestData> poolS = new List<QuestData>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // ★★★ 補上這一行 ★★★
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // 改用 IEnumerator 確保 UI 準備好
    private IEnumerator Start()
    {
        yield return null;

        if (ui == null)
        {
            ui = FindFirstObjectByType<AdventurerUI>();
        }

        GenerateSimulatedPool();
        RefreshBoard();
    }

    void GenerateSimulatedPool()
    {
        for (int i = 0; i < 4; i++) poolD.Add(CreateQuest(QuestRank.D, i));
        for (int i = 0; i < 2; i++) poolC.Add(CreateQuest(QuestRank.C, i));
        for (int i = 0; i < 2; i++) poolB.Add(CreateQuest(QuestRank.B, i));
        for (int i = 0; i < 2; i++) poolA.Add(CreateQuest(QuestRank.A, i));
        for (int i = 0; i < 2; i++) poolS.Add(CreateQuest(QuestRank.S, i));
    }

    QuestData CreateQuest(QuestRank rank, int index)
    {
        QuestData q = ScriptableObject.CreateInstance<QuestData>();
        q.rank = rank;

        // ▼▼▼ 【修正】 標題格式 S1, A2... ▼▼▼
        q.title = $"{rank}{index + 1}";

        q.questID = $"{rank}_{index}";

        // ▼▼▼ 【修正】 預設敵人 Assassin ▼▼▼
        q.description = $"Target: {defaultEnemyName}\nRank: {rank}";
        q.targetEnemyName = defaultEnemyName;

        q.enemyImage = defaultEnemyIcon;

        return q;
    }

    public void RefreshBoard()
    {
        List<QuestData> boardQuests = new List<QuestData>();

        boardQuests.AddRange(GetRandomQuests(poolD, 2));
        boardQuests.AddRange(GetRandomQuests(poolC, 1));
        boardQuests.AddRange(GetRandomQuests(poolB, 1));
        boardQuests.AddRange(GetRandomQuests(poolA, 1));
        boardQuests.AddRange(GetRandomQuests(poolS, 1));

        Shuffle(boardQuests);

        if (ui != null) ui.GenerateGrid(boardQuests);
    }

    List<QuestData> GetRandomQuests(List<QuestData> sourcePool, int count)
    {
        List<QuestData> result = new List<QuestData>();

        var available = sourcePool.Where(q =>
            QuestManager.Instance == null || !QuestManager.Instance.IsQuestCompleted(q.questID)
        ).ToList();

        if (available.Count <= count)
        {
            result.AddRange(available);
        }
        else
        {
            while (result.Count < count && available.Count > 0)
            {
                int idx = Random.Range(0, available.Count);
                result.Add(available[idx]);
                available.RemoveAt(idx);
            }
        }
        return result;
    }

    void Shuffle<T>(List<T> list)
    {
        int n = list.Count;
        while (n > 1)
        {
            n--;
            int k = Random.Range(0, n + 1);
            T value = list[k];
            list[k] = list[n];
            list[n] = value;
        }
    }

    public void AcceptAndTransition(QuestData quest)
    {
        if (QuestManager.Instance == null)
        {
            GameObject go = new GameObject("QuestManager");
            go.AddComponent<QuestManager>();
        }

        QuestManager.Instance.AcceptQuest(quest);
        SceneManager.LoadScene("Shop");
    }
}