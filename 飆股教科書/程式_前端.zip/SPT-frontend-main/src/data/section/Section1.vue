<template>
    <!-- 1. 套用 'Target Style' 的背景、全域間距 -->
    <div class="w-full px-4 md:px-16 py-12 bg-gray-50 min-h-screen">
        <!-- 2. 套用 'Target Style' 的自定義進度條 -->
        <div class="mb-10 max-w-5xl mx-auto">
            <div class="flex justify-between items-end mb-2">
                <h3 class="text-xl font-semibold text-blue-700 transition duration-300">
                    {{
                        slides[currentSlide].title.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]\s?/, '')
                    }}
                </h3>
                <span class="text-sm font-medium text-gray-500">
                    主題 {{ currentSlide + 1 }} / {{ slides.length }}
                </span>
            </div>
            <div class="w-full bg-gray-300 rounded-full h-2.5 overflow-hidden">
                <div
                    class="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
                    :style="{ width: ((currentSlide + 1) / slides.length) * 100 + '%' }"
                ></div>
            </div>
        </div>

        <!-- 3. 套用 'Target Style' 的 'slide-fade' 動畫 -->
        <transition name="slide-fade" mode="out-in">
            <!-- 4. 套用 'Target Style' 的卡片樣式 (p-10, rounded-2xl, shadow-xl) -->
            <div
                :key="currentSlide"
                class="bg-white rounded-2xl shadow-xl p-10 md:flex gap-12 items-start border border-gray-100 max-w-5xl mx-auto"
            >
                <!-- 5. 套用 'Target Style' 的佈局 (自動判斷有無圖片) -->
                <div
                    :class="{
                        'md:w-2/3': slides[currentSlide].img,
                        'md:w-full': !slides[currentSlide].img,
                    }"
                    class="w-full"
                >
                    <!-- 6. 套用 'Target Style' 的標題樣式 -->
                    <h2 class="text-3xl font-extrabold mb-6 text-gray-800">
                        {{ slides[currentSlide].title }}
                    </h2>
                    <!-- 7. 套用 'Target Style' 的內容樣式 (使用 div 替換 p) -->
                    <div
                        class="text-lg text-gray-700 leading-relaxed space-y-4"
                        v-html="slides[currentSlide].content"
                    ></div>
                </div>

                <!-- 8. 補上 'Target Style' 的圖片顯示區塊 -->
                <div
                    v-if="slides[currentSlide].img"
                    class="md:w-1/3 w-full mt-10 md:mt-0 flex justify-center items-center"
                >
                    <img
                        :src="slides[currentSlide].img"
                        :class="`${slides[currentSlide].imgClass} object-contain rounded-xl shadow-lg border border-gray-200`"
                    />
                </div>
            </div>
        </transition>

        <!-- 9. 套用 'Target Style' 的按鈕樣式 (rounded-full, 間距) -->
        <div class="flex justify-between mt-16 max-w-5xl mx-auto">
            <button
                @click="prevSlide"
                :disabled="currentSlide === 0"
                class="px-7 py-2.5 rounded-full border border-blue-600 text-blue-600 font-medium hover:bg-blue-50 transition duration-300 disabled:opacity-40 disabled:border-gray-300 disabled:text-gray-400"
            >
                &larr; 上一主題
            </button>

            <button
                v-if="!isLastSlide"
                @click="nextSlide"
                class="px-9 py-2.5 rounded-full bg-blue-600 text-white font-semibold shadow-md shadow-blue-300 hover:bg-blue-700 hover:shadow-lg transition duration-300"
            >
                下一主題 &rarr;
            </button>

            <button
                v-else
                @click="goHome"
                class="px-9 py-2.5 rounded-full bg-green-600 text-white font-semibold shadow-md shadow-green-300 hover:bg-green-700 hover:shadow-lg transition duration-300"
            >
                回到課程首頁
            </button>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed } from 'vue'
    import { useRouter } from 'vue-router'
    import { useToast } from 'primevue/usetoast' // 補上 import

    const toast = useToast() // 補上 const
    const router = useRouter()
    const currentSlide = ref(0)

    // 這是您第二個組件的 slides 資料
    const slides = [
        {
            title: '📘 股票是什麼？（總覽）',
            content: `<p class="mb-3 text-gray-700 leading-relaxed">股票代表你對一間公司的所有權份額；持有股票即為股東，可分享公司盈餘與資本增值</p> 
                      <ul class="list-disc list-inside space-y-2 text-gray-800 leading-relaxed">
                        <li><span class="font-semibold text-blue-700">本質：</span>公司對股東的出資證明與權益憑證</li>
                        <li><span class="font-semibold text-blue-700">權利：</span>盈餘分配、剩餘財產分配、表決等（依股別而定）</li>
                        <li><span class="font-semibold text-blue-700">風險與報酬：</span>價格波動、公司經營與市場情緒影響</li>
                      </ul>
                    `,
        },
        {
            title: '🧩 定義與種類',
            content: `<p class="mb-3 text-gray-700">股票是股東擁有公司的證明，也是公司提供給股東的出資證明</p> 
                      <ul class="space-y-3 text-gray-800 leading-relaxed">
                        <li>📄 <span class="font-semibold text-blue-700">普通股：</span>有 <span class="font-semibold">表決權</span> 與 <span class="font-semibold">盈餘分配權</span>（股利）</li>
                        <li>🏅 <span class="font-semibold text-blue-700">特別股：</span>通常享有 <span class="font-semibold">優先分配盈餘</span> 與 <span class="font-semibold">優先清償</span>，但多數 <span class="font-semibold">無表決權</span></li>
                      </ul>
                    `,
        },
        {
            title: '💎 股票的三種價值',
            content: `<ol class="list-decimal list-inside space-y-3 text-gray-800 leading-relaxed">
                        <li><span class="font-semibold text-blue-700">面額：</span>股票票面金額（修法前多為每股 10 元），<span class="text-gray-600">供發行與帳務使用，與市價無必然關係</span></li>
                        <li><span class="font-semibold text-blue-700">每股帳面價值：</span>公司權益總額 ÷ 流通在外股數，<span class="text-gray-600">反映帳上淨值</span></li>
                        <li><span class="font-semibold text-blue-700">每股市價：</span>市場即時交易價格，<span class="text-gray-600">受供需與投資人情緒影響</span></li>
                      </ol>
                    `,
        },
        {
            title: '🌏 上市來源分類',
            content: `<ul class="list-disc list-inside space-y-3 text-gray-800 leading-relaxed">
                        <li><span class="font-semibold text-blue-700">上市櫃股票：</span>本國公司在台發行之流通在外股票</li>
                        <li><span class="font-semibold text-blue-700">KY 上市櫃股票：</span>外國公司首次來台掛牌（名稱帶 KY）</li>
                        <li><span class="font-semibold text-blue-700">臺灣存託憑證（TDR）：</span>海外已上市公司於台灣發行的存託憑證</li>
                      </ul>
                    `,
        },
    ]

    const isLastSlide = computed(() => currentSlide.value === slides.length - 1)

    function nextSlide() {
        if (currentSlide.value < slides.length - 1) currentSlide.value++
    }
    function prevSlide() {
        if (currentSlide.value > 0) currentSlide.value--
    }
    function goHome() {
        router.push('/learning')
        setTimeout(() => {
            toast.add({
                severity: 'success',
                summary: '🎉 恭喜你完成本單元！',
                life: 2500,
            })
        }, 300)
    }
</script>

<style scoped>
    table {
        border-collapse: collapse;
    }
</style>
