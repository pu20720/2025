from ultralytics import YOLO
import cv2

# 載入你的 YOLO 模型
model = YOLO("best.pt")   # ← 換成你的模型路徑

# 類別對應
class_names = ["left", "right", "all"]

# 啟動攝影機
cap = cv2.VideoCapture(0)  # 0 = webcam，或換成影片路徑

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 進行預測
    results = model(frame, conf=0.2)  # conf 可自行調整

    for result in results:
        boxes = result.boxes

        if boxes is None:
            continue

        for box in boxes:
            cls_id = int(box.cls[0])     # 類別編號
            label = class_names[cls_id]

            # 只顯示 left & right （排除 all）
            if label not in ["left", "right"]:
                continue

            x1, y1, x2, y2 = map(int, box.xyxy[0])

            # 左右不同顏色
            color = (255, 0, 0) if label == "left" else (0, 255, 0)

            # 畫框
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

            # 顯示文字
            cv2.putText(frame, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

    cv2.imshow("Hand Detection", frame)

    # 按 q 離開
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
