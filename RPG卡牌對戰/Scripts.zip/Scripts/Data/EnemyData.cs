using UnityEngine;

[System.Serializable]
public class EnemyData
{
    public string characterName;
    public RPGStatsData statsData;
    public int initialMaxHp;
    public int initialAttack;
    public DamageType attackDamageType;

    public int initialHelmetArmor;
    public int initialArmor;
    public int initialGauntletsArmor;
    public int initialLegArmor;

    public EnemyAILogic aiLogic;
    public Sprite characterSprite;

    // --- [整合修復] 補上所有缺失的特殊標籤 ---
    public bool isMaddening;    // Morwen
    public bool isHowler;       // Fenris
    public bool isSpiderKing;   // Yantarlion
    public bool isDio;          // Dio Brando
    public bool isCalamity;     // Amber
    public bool isBloody;       // Mary
    public bool isCaesar;       // Julius
    public bool isFrederick;    // Frederick
    public bool isGargantuan;   // Grog
    public bool isBloom;        // Carnivorous Rex
    public bool isDespair;      // Despair Knight
    public bool isShadow;       // Kai
    public bool isWhisper;      // Phantom
    public bool isAbysmal;      // The Darkborn
    public bool isPlagueDoctor; // Plague Doctor
    public bool isMechanical;   // 機械族
}