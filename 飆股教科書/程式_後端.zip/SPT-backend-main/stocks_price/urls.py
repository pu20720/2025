from django.urls import path
from .views import ImportAllStocksHistoryView, PriceView

urlpatterns = [
    path(
        'import/all/',
        ImportAllStocksHistoryView.as_view(),
        name='all-stock-prices-import',
    ),
    path(
        'import/yesterday/',
        PriceView.as_view(),
        name='yesterday-stock-price-import',
    ),
]
