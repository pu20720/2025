# main.py
import os
import csv
from mods.test import person, syllabus, search


def safe_dict(d):
    """如果不是 dict（例如 None），就回傳空 dict，避免 .get() 爆炸。"""
    return d if isinstance(d, dict) else {}


def main():
    # 學期
    year_sem = "1132"
    # 先抓前 N 筆課程測試，全部就設 None
    max_courses = None

    project_dir = os.path.dirname(os.path.abspath(__file__))

    # 指定存放資料夾
    folder = os.path.join(project_dir, "data")
    if not os.path.exists(folder):
        os.makedirs(folder)

    print(f"抓取學期 {year_sem} 課程...")

    #  先抓取全部課程
    courses, url = search(year_sem, "課程", "")
    print(f"搜尋網址：{url}")
    print(f"總共抓到 {len(courses)} 門課程")

    if max_courses:
        courses = courses[:max_courses]  # 只抓前 N 筆

    all_courses = []

    # 逐門課抓取課程餘額與綱要
    total = len(courses)
    for idx, c in enumerate(courses[:1000000], 1):
        selectno = c.get("選課代號")
        if not selectno:
            print(f"[{idx}/{total}] 找不到選課代號，略過一筆課程：{c}")
            continue

        print(f"[{idx}/{total}] 抓取課程代碼 {selectno} ...")

        # 課程餘額
        seat_info_raw = person(int(selectno))
        seat_info = safe_dict(seat_info_raw)

        # 課程綱要
        syllabus_info_raw = syllabus(year_sem, selectno)
        syllabus_info = safe_dict(syllabus_info_raw)

        # 如果 syllabus 完全抓不到，可以選擇：略過 / 或者寫一筆空資料
        if not syllabus_info:
            print(f"   無法取得課程綱要，課程 {selectno} 只會寫入部分資訊。")

        # 整理資料
        course_data = {
            "selectno": selectno,
            "name": syllabus_info.get("name", ""),
            "instructor": syllabus_info.get("instructor", ""),
            "time": syllabus_info.get("time", ""),
            "description": syllabus_info.get("description", ""),
            "grading": syllabus_info.get("grading", ""),
            "remaining": seat_info.get("remaining", ""),  # 可能是 int 或空白
            "url": syllabus_info.get("url", ""),
        }

        all_courses.append(course_data)

    #  寫入 CSV
    fields = ["selectno", "name", "instructor", "time", "description", "grading", "remaining", "url"]
    file_path = os.path.join(folder, f"courses_{year_sem}.csv")

    with open(file_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(all_courses)

    print(f"完成 資料已儲存至 {file_path}")


if __name__ == "__main__":
    main()
