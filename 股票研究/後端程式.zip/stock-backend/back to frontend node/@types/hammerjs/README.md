# Installation
> `npm install --save @types/hammerjs`

# Summary
This package contains type definitions for hammerjs (http://hammerjs.github.io/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hammerjs.

### Additional Details
 * Last updated: Mon, 07 Oct 2024 22:07:58 GMT
 * Dependencies: none

# Credits
These definitions were written by [Han Lin Yap](https://github.com/codler).
