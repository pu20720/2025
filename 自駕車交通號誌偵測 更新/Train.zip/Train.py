from ultralytics import YOLO
from multiprocessing import freeze_support
import torch
from torchvision.ops import nms
import matplotlib.pyplot as plt
import matplotlib
import cv2
import os
import glob

# 設定 Matplotlib 中文顯示
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Noto Sans CJK SC']
matplotlib.rcParams['axes.unicode_minus'] = False


if __name__ == '__main__':
    freeze_support()

    # 檢查 CUDA 是否可用
    print("CUDA 是否可用:", torch.cuda.is_available())
    print("CUDA 版本:", torch.version.cuda)
    print("目前 GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")

    # 測試 NMS 函數
    boxes = torch.tensor([[10, 10, 20, 20], [15, 15, 25, 25]], dtype=torch.float32)
    scores = torch.tensor([0.9, 0.8])
    keep = nms(boxes, scores, 0.5)
    print("NMS 結果:", keep)

    # === 訓練設定 ===
    data_yaml = r"C:\Users\hnm\Desktop\Taiwan Traffic Sign.v7i.yolov8 (1)v1\data.yaml"

    if not os.path.exists(data_yaml):
        raise FileNotFoundError(f"data.yaml 不存在: {data_yaml}")

    project_dir = r"C:\Users\hnm\Desktop\python\runs\detect"
    model_name = "traffic_sign"
    weight_path = os.path.join(project_dir, model_name, "weights", "best.pt")

    # 清除舊 cache
    for cache_file in glob.glob(os.path.join(os.path.dirname(data_yaml), '**', '*.cache'), recursive=True):
        os.remove(cache_file)
        print(f"刪除快取檔: {cache_file}")

    # === 若有舊模型則載入，否則建立新模型 ===
    if os.path.exists(weight_path):
        print(f"載入舊模型：{weight_path}")
        model = YOLO(weight_path)
    else:
        print("未找到舊模型，建立新的 YOLOv8 模型")
        model = YOLO("yolov8n.pt")

    # === 開始訓練 ===
    train_results = model.train(
        data=data_yaml,
        epochs=1,        # 可調整，如：130
        imgsz=640,
        device="0",
        batch=9,
        project=project_dir,
        name=model_name,
        exist_ok=True
    )

    # === 驗證模型性能 ===
    print("\n--- 驗證模型 ---")
    metrics = model.val(
        plots=True,
        save_json=True   # 生成 Precision/Recall/MAP 報告
    )

    # === 匯出模型 ===
    print("\n--- 匯出 TorchScript 模型 ---")
    export_path = model.export(format="torchscript")
    print(f"匯出完成：{export_path}")