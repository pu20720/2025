import os
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 假視窗設定
options = Options()
options.add_argument('--headless=new')
options.add_argument('--disable-blink-features=AutomationControlled')
options.add_argument('--window-size=1920,1080')
options.add_argument('--disable-dev-shm-usage')

driver = webdriver.Chrome(options=options)

# 指定 .env 路徑
BASE_DIR = Path(__file__).resolve().parents[1]  # 指到 SPT-backend
ENV_PATH = BASE_DIR / '.env'
load_dotenv(ENV_PATH)

# ====== 從 .env 讀帳號密碼 ======
accounts = []
for i in range(1, 5):  # 假設 4 組
    email = os.getenv(f'FM_EMAIL{i}')
    password = os.getenv(f'FM_PASS{i}')
    if email and password:
        accounts.append({'email': email, 'password': password})

print('總共讀取帳號數:', len(accounts))

api_keys = {}

# ====== 自動登入&抓 API Key ======
for idx, acc in enumerate(accounts, start=1):
    print(f'正在登入帳號: {acc["email"]}')

    driver = webdriver.Chrome(options=options)
    driver.get('https://finmindtrade.com/analysis/#/account/user')

    # Email
    email_input = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='email']"))
    )
    email_input.clear()
    email_input.send_keys(acc['email'])

    # Password
    password_input = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='password']"))
    )
    password_input.clear()
    password_input.send_keys(acc['password'])
    password_input.send_keys(Keys.RETURN)

    time.sleep(5)

    # 點擊 "建立 Token"按鈕
    try:
        create_btn = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//button[contains(text(),'建立 7 天後過期的 token')]")
            )
        )
        create_btn.click()
        print('已點擊 建立token 按鈕')
        time.sleep(3)
    except Exception as e:
        print(f'找不到 建立token 按鈕: {e}')

    # 抓 API Key
    try:
        api_key_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, "//td[@aria-colindex='3']/div[@class='velmld-parent']")
            )
        )
        full_text = api_key_element.text.strip()
        api_key = full_text.split('\n')[0].strip()

        env_key = f'finmindkey{idx}'
        api_keys[env_key] = api_key
        print(f' {acc["email"]} 的 {env_key}: {api_key}')
    except Exception as e:
        print(f' {acc["email"]} 取不到 API Key: {e}')

    driver.quit()


# ====== 更新 .env 檔 ======
def update_env(api_keys: dict, env_file='.env'):
    if not os.path.exists(env_file):
        with open(env_file, 'w', encoding='utf-8') as f:
            f.write('')

    with open(env_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    new_lines = []
    updated_keys = set()

    for line in lines:
        updated = False
        for env_key, token in api_keys.items():
            if line.startswith(f'{env_key}='):
                new_lines.append(f'{env_key}={token}\n')
                updated = True
                updated_keys.add(env_key)
                break
        if not updated:
            new_lines.append(line)

    for env_key, token in api_keys.items():
        if env_key not in updated_keys:
            new_lines.append(f'{env_key}={token}\n')

    with open(env_file, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)

    print(f' {env_file} 已更新')


# ====== 主程式執行 ======
update_env(api_keys, env_file=ENV_PATH)
