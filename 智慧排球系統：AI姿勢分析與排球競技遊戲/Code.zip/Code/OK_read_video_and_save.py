# Description: 透過 Mediapipe 進行姿勢估測，並將結果儲存為影片與 CSV 檔案
# 使用python 3.12  (目前只有3.12支援mediapipe) 

import cv2
import os
import time
from datetime import datetime
import mediapipe as mp
import pandas as pd
import numpy as np

# 初始化 Mediapipe Pose
mp_drawing = mp.solutions.drawing_utils         # mediapipe 繪圖方法
mp_drawing_styles = mp.solutions.drawing_styles # mediapipe 繪圖樣式
#mp_holistic = mp.solutions.holistic             # mediapipe 全身偵測方法
mp_pose = mp.solutions.pose # mediapipe 姿勢偵測方法

pose = mp_pose.Pose(min_detection_confidence=0.5,min_tracking_confidence=0.5)



# 讀影片
cap = cv2.VideoCapture("underhand_180.MOV")  # 讀取影片檔案


# 創建儲存影像與 log 的資料夾
output_dir = "mediapipe_output"
video_dir = os.path.join(output_dir, "videos")
os.makedirs(video_dir, exist_ok=True)
log_dir = os.path.join(output_dir, "logs")
os.makedirs(log_dir, exist_ok=True)


# 取得當前時間作為影片與 log 檔案名稱
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
video_filename = f"{timestamp}.mp4"
video_path = os.path.join(video_dir, video_filename)
log_filename = f"{timestamp}_pose_landmarks.csv"
log_path = os.path.join(log_dir, log_filename)

# 影片儲存設定
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))  # 取得攝影機的寬度
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))  # 取得攝影機的高度
fps=int(cap.get(cv2.CAP_PROP_FPS))  # 取得攝影機的 FPS
# 如果無法取得 FPS，則使用預設值
if fps <= 0:
    fps = 20  # 設定影片的每秒幀數 (FPS)

print(f"FPS: {fps}")  # 印出 FPS    





# 初始化 VideoWriter (儲存影片)
fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # 儲存為 MP4 格式
out = cv2.VideoWriter(video_path, fourcc, fps, (frame_width, frame_height))

# 初始化 CSV 存儲
landmark_data = []


# 設定錄影開始時間
start_time = time.time()

# 設定錄影時間 (秒)
record_time = 5  # 錄影時間 (秒)

frame_count = 0  # 初始化幀數計數器

while cap.isOpened():
    ret, frame = cap.read()
    frame_count += 1
    # 如果無法讀取影像，則退出循環

    if not ret:
        break


    # 轉換顏色為 RGB (mediapipe 需要)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = pose.process(rgb_frame)

    # 取得時間戳記
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 檢測到姿勢
    if results.pose_landmarks:
        # 繪製關鍵點與骨架
        mp_drawing.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                 landmark_drawing_spec=mp_drawing_styles.get_default_pose_landmarks_style())

        # 取得 33 個關鍵點 (x, y, z, visibility)
        landmarks = results.pose_landmarks.landmark
        frame_landmarks = [frame_count]  # 加入幀數資訊
        
        # 將每個關鍵點的 x, y, z, visibility 加入列表
        for lm in landmarks:
            frame_landmarks.extend([lm.x, lm.y, lm.z, lm.visibility])

        landmark_data.append([timestamp] + frame_landmarks)
        


    '''# 顯示畫面
    cv2.imshow("BlazePose Pose Detection", frame)'''
    out.write(frame)  # 儲存影像到 MP4

    # 按 'q' 退出
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


    if frame_count >= fps * record_time:  # 如果錄影時間達到設定的時間
        print(f"錄影時間達到設定的時間{record_time}(秒)，正在停止錄影...")
        break 
# 停止錄影  



# 儲存 33 個關鍵點的資料
columns =["timestamp"]+ ["Frame"] + [f"{name}_{coord}" for name in range(33) for coord in ["x", "y", "z", "visibility"]]
df = pd.DataFrame(landmark_data, columns=columns)
df.to_csv(log_path, index=False)

# 釋放資源
cap.release()
out.release()
cv2.destroyAllWindows()

print(f"✅ 影片已儲存至：{video_path}")
print(f"✅ 姿態數據已儲存至：{log_path}")

