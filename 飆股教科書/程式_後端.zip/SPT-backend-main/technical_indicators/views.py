import logging
from rest_framework import status
from django.db.models import F
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from technical_indicators.models import TechnicalIndicator


logger = logging.getLogger(__name__)


class BaseIndicatorView(APIView):
    indicator_field = None

    def get(self, request, *args, **kwargs):
        if not self.indicator_field:
            raise ValidationError('未設定 indicator_field')
        symbol = request.query_params.get('symbol')
        if not symbol:
            raise ValidationError('請提供股票代碼')
        try:
            qs = (
                TechnicalIndicator.objects.filter(stock__symbol=symbol)
                .order_by('date')  # 預設升冪
                .annotate(value=F(self.indicator_field))  # 統一輸出欄位名
                .annotate(  # 這裡把關聯欄位攤平成 'symbol'
                    symbol=F('stock__symbol'),
                    value=F(self.indicator_field),
                )
                .values('symbol', 'date', 'value')
            )
            return Response(list(qs))
        except RuntimeError as e:
            logger.error(f'[TechnicalIndicator] 查詢失敗{e}')
            return Response(
                {'error': '查詢過程中發生錯誤'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class MA5View(BaseIndicatorView):
    indicator_field = 'ma_5'


class MA20View(BaseIndicatorView):
    indicator_field = 'ma_20'


class MA60View(BaseIndicatorView):
    indicator_field = 'ma_60'


class RSI5View(BaseIndicatorView):
    indicator_field = 'rsi_5'


class RSI10View(BaseIndicatorView):
    indicator_field = 'rsi_10'


class MACDView(APIView):
    def get(self, request, *args, **kwargs):
        symbol = request.query_params.get('symbol')
        if not symbol:
            raise ValidationError('請提供股票代碼')
        try:
            qs = (
                TechnicalIndicator.objects.filter(stock__symbol=symbol)
                .order_by('date')
                .annotate(symbol=F('stock__symbol'))
                .values('symbol', 'date', 'dif', 'macd', 'osc')
            )
            return Response(list(qs))
        except RuntimeError as e:
            logger.error(f'[TechnicalIndicator] 查詢失敗 {e}')
            return Response(
                {'error': '查詢過程中發生錯誤'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class KDView(APIView):
    def get(self, request, *args, **kwargs):
        symbol = request.query_params.get('symbol')
        if not symbol:
            raise ValidationError('請提供股票代碼')
        try:
            qs = (
                TechnicalIndicator.objects.filter(stock__symbol=symbol)
                .order_by('date')
                .annotate(symbol=F('stock__symbol'))
                .values('symbol', 'date', 'kd_k', 'kd_d')
            )
            return Response(list(qs))
        except RuntimeError as e:
            logger.error(f'[TechnicalIndicator] 查詢失敗 {e}')
            return Response(
                {'error': '查詢過程中發生錯誤'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
