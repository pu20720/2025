<template>
    <div class="falling-container">
        <span
            v-for="(stock, index) in fallingWords"
            :key="stock.id"
            class="falling-keyword"
            :style="stock.style"
            @click="fallingKeywordsRouter(stock.text)"
        >
            {{ stock.text }}
        </span>
    </div>
</template>
<script setup>
    import { ref, onMounted } from 'vue'
    import { useRouter } from 'vue-router'
    import { useStockSearch } from '@/stores/stockSearch'
    import { useToast } from 'primevue/usetoast'

    const { getAllStocks, fallingKeywordsRouter } = useStockSearch()
    const router = useRouter()

    const stockData = ref([])
    const keywords = ref([])
    const fallingWords = ref([])

    const TIMEOUT_MS = 5000 // 修正：增加到 5 秒
    const toast = useToast()

    async function fetchData() {
        try {
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => {
                    reject(new Error('Response timeout: API response took too long.'))
                }, TIMEOUT_MS)
            })

            const result = await Promise.race([getAllStocks(), timeoutPromise])

            if (Array.isArray(result) && result.length > 0) {
                stockData.value = result

                keywords.value = result.slice(0, 10).map((item, index) => ({
                    text: item.symbol,
                    rank: index + 1,
                }))
            } else {
                toast.add({
                    severity: 'warn',
                    summary: '查詢結果',
                    detail: '沒有資料',
                    life: 4000,
                })
            }
        } catch (error) {
            const isTimeout = error.message.includes('Response timeout')
            toast.add({
                severity: isTimeout ? 'warn' : 'error',
                summary: isTimeout ? '連線逾時' : '查詢失敗',
                detail: isTimeout
                    ? `伺服器回應過久 (超過 ${TIMEOUT_MS / 1000} 秒)，請稍後再試。`
                    : error.message || '未知錯誤',
                life: 4000,
            })
        }
    }

    function getWeightedPool() {
        return keywords.value.flatMap((item) => Array((11 - item.rank) * 2).fill(item))
    }

    function generateWord() {
        const weightedPool = getWeightedPool()
        if (!weightedPool.length) return null // 安全防護
        const item = weightedPool[Math.floor(Math.random() * weightedPool.length)]
        const { text, rank } = item
        const id = Date.now() + Math.random()
        const left = Math.random() * 90
        const duration = 7 + Math.random() * 5
        const minSize = 14
        const maxSize = 30
        const fontSize = maxSize - (rank - 1) * ((maxSize - minSize) / 9)

        return {
            id,
            text,
            style: {
                left: `${left}%`,
                animationDuration: `${duration}s`,
                fontSize: `${fontSize}px`,
            },
        }
    }

    function spawnWordLoop() {
        setInterval(() => {
            if (fallingWords.value.length > 30) {
                fallingWords.value.shift()
            }
            if (keywords.value.length) {
                const newWord = generateWord()
                if (newWord) {
                    fallingWords.value.push(newWord)
                }
            }
        }, 400)
    }

    onMounted(() => {
        spawnWordLoop()
        fetchData()
    })
</script>

<style scoped>
    .falling-container {
        position: absolute;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        pointer-events: none;
        overflow: hidden;
        z-index: 0;
    }

    .falling-keyword {
        position: absolute;
        top: -10%;
        color: #1e90ff;
        pointer-events: auto;
        cursor: pointer;
        animation-name: fall;
        animation-timing-function: linear;
        animation-fill-mode: forwards;
        user-select: none;
        transition: transform 0.2s ease;
    }

    .falling-keyword:hover {
        transform: scale(1.5);
        z-index: 5;
    }

    @keyframes fall {
        to {
            transform: translateY(150vh);
            opacity: 0.5;
        }
    }
</style>
