using System.Collections.Generic;
using UnityEngine;

public class QuestManager : MonoBehaviour
{
    public static QuestManager Instance { get; private set; }

    // 記錄已完成的委託 ID
    public List<string> completedQuestIDs = new List<string>();

    // 當前已接受 (Accept) 的委託，準備去戰鬥
    public QuestData currentAcceptedQuest;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject); // 讓它在切換場景時不會消失
    }

    public bool IsQuestCompleted(string id)
    {
        return completedQuestIDs.Contains(id);
    }

    public void CompleteCurrentQuest()
    {
        if (currentAcceptedQuest != null)
        {
            if (!completedQuestIDs.Contains(currentAcceptedQuest.questID))
            {
                completedQuestIDs.Add(currentAcceptedQuest.questID);
            }
            currentAcceptedQuest = null; // 清空當前任務
        }
    }

    public void AcceptQuest(QuestData quest)
    {
        currentAcceptedQuest = quest;
        Debug.Log($"已接受委託: {quest.title} (Rank {quest.rank})");
    }
}