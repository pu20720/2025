// 檔案路徑: Assets/Scripts/Data/EnemyArtLibrary.cs
using System.Collections.Generic;
using UnityEngine;

// ▼▼▼ 這是一個 [System.Serializable] 類別，不需要是獨立檔案 ▼▼▼
[System.Serializable]
public class EnemyArtEntry
{
    public string enemyName; // (您需要手動輸入 "Goblin", "Orc" 等)
    public Sprite enemySprite;  // (您需要手動拖曳 Goblin.jpg, Orc.jpg 等)
}
// ▲▲▲ 結束 ▲▲▲


// ▼▼▼ 這是您要在 Project 視窗中建立的 .asset 檔案 ▼▼▼
[CreateAssetMenu(fileName = "EnemyArtLibrary", menuName = "RPG/Enemy Art Library")]
public class EnemyArtLibrary : ScriptableObject
{
    [Header("在此處連結所有敵人圖片")]
    [Tooltip("您只需要在這裡手動設置敵人名稱和圖片")]
    public List<EnemyArtEntry> enemyArtEntries = new List<EnemyArtEntry>();
}
// ▲▲▲ 結束 ▲▲▲