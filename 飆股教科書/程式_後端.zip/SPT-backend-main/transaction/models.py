from django.db import models


class Transaction(models.Model):
    TYPE_CHOICES = [
        ('BUY', '買入'),
        ('SELL', '賣出'),
    ]
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey('users.User', on_delete=models.CASCADE)
    stock = models.ForeignKey('stocks.Stock', on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=4, choices=TYPE_CHOICES)  # 交易類型
    shares = models.PositiveIntegerField()  # 股數
    price = models.DecimalField(max_digits=12, decimal_places=2)  # 單價
    amount = models.DecimalField(max_digits=15, decimal_places=2)  # 金額
    date = models.DateTimeField(auto_now_add=True)  # 交易日期

    class Meta:
        ordering = ['-date']  # 根據日期降序排列

    def __str__(self):
        return f'{self.user.username} {self.transaction_type} {self.stock.symbol} {self.shares}股'


class Portfolio(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey('users.User', on_delete=models.CASCADE)
    stock = models.ForeignKey('stocks.Stock', on_delete=models.CASCADE)
    shares = models.PositiveIntegerField(default=0)  # 持有股數
    average_price = models.DecimalField(
        max_digits=12, decimal_places=2, default=0
    )  # 平均成本價
    current_price = models.DecimalField(
        max_digits=12, decimal_places=2, default=0
    )  # 最新價格
    profit_loss = models.DecimalField(
        max_digits=12, decimal_places=2, default=0
    )  # 損益
    return_rate = models.DecimalField(
        max_digits=6, decimal_places=2, default=0
    )  # 報酬率 (%)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'stock')  # 每個使用者對每支股票只能有一筆紀錄

    def __str__(self):
        return f'{self.user.username} 持有 {self.stock.symbol} {self.shares}股'

    def get_latest_price(self):
        """從 StockPrice 取得最新收盤價"""
        latest_price = self.stock.prices.order_by('-price_date').first()
        return latest_price.close_price if latest_price else 0

    def update_metrics(self):
        """根據最新股價自動更新損益與報酬率"""
        current_price = self.get_latest_price()
        total_value = current_price * self.shares
        cost = self.average_price * self.shares
        self.current_price = current_price
        self.profit_loss = total_value - cost
        self.return_rate = (self.profit_loss / cost * 100) if cost > 0 else 0
        self.save()
