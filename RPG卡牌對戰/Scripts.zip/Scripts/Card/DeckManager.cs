using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class DeckManager : MonoBehaviour
{
    [Header("牌組設定")]
    [SerializeField] private GameObject cardPrefab;
    [SerializeField] private Transform handArea;

    [Header("Database")]
    [SerializeField] private CardArtLibrary cardArtLibrary;

    private List<CardData> fixedSequenceDeck = new List<CardData>();
    private int currentDeckIndex = 0;

    private List<GameObject> cardsInHand = new List<GameObject>();

    private HorizontalLayoutGroup handLayoutGroup;
    private RectTransform handRectTransform;
    private float originalCardSpacing;
    private float cardWidth;

    private string branchName;

    private void Awake()
    {
        if (handArea != null)
        {
            handLayoutGroup = handArea.GetComponent<HorizontalLayoutGroup>();
            handRectTransform = handArea.GetComponent<RectTransform>();
        }

        if (handLayoutGroup != null)
        {
            originalCardSpacing = handLayoutGroup.spacing;
        }

        cardWidth = 360f;
    }

    public void InitializeDeck(string branchName)
    {
        this.branchName = branchName;

        if (cardArtLibrary == null) return;

        CardDatabase.Initialize(cardArtLibrary);

        // ========================================================================
        // ▼▼▼ 【修改重點】 設定常駐戰鬥的固定抽牌順序 ▼▼▼
        // ========================================================================
        if (this.branchName == "default" || this.branchName == "Verminus_Mode")
        {
            fixedSequenceDeck.Clear();

            // 1. 第一張: Sharp Blade
            CardData sharpCard = CardDatabase.GetCardByName("Sharp Blade");
            if (sharpCard != null) fixedSequenceDeck.Add(sharpCard);
            else Debug.LogError("找不到 Sharp Blade!");

            // 2. 第二張: Divine_Radiance
            CardData divineCard = CardDatabase.GetCardByName("Divine_Radiance");
            if (divineCard != null) fixedSequenceDeck.Add(divineCard);
            else Debug.LogError("找不到 Divine_Radiance!");

            // 3. 後續 62 張: Sharp Blade
            if (sharpCard != null)
            {
                for (int i = 0; i < 62; i++)
                {
                    fixedSequenceDeck.Add(sharpCard);
                }
            }

            currentDeckIndex = 0;
            Debug.Log($"[DeckManager] 已設定常駐牌組: 總共 {fixedSequenceDeck.Count} 張 (Sharp Blade -> Divine -> 62x Sharp)");

            if (BattleManager.Instance != null)
            {
                BattleManager.Instance.UpdateCardPileText(GetRemainingDeckCount());
            }
            return;
        }
        // ▲▲▲ 修改結束 ▲▲▲

        // 若不是常駐模式，先載入所有卡片
        fixedSequenceDeck = CardDatabase.GetAllCards();

        if (this.branchName == "Quest")
        {
            Debug.Log("[DeckManager] Quest Mode: Waiting for Custom Deck via Loadout...");
            fixedSequenceDeck.Clear();
            return;
        }

        List<string> tutorialBranches = new List<string> { "Knight", "Adventurer", "Assassin_Simple", "Assassin_Hard" };

        if (tutorialBranches.Contains(this.branchName))
        {
            // 教學牌組
        }
        else
        {
            ShuffleDeck();
            currentDeckIndex = 0;
        }

        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.UpdateCardPileText(GetRemainingDeckCount());
        }
    }

    public void ShuffleDeck()
    {
        for (int i = 0; i < fixedSequenceDeck.Count; i++)
        {
            CardData temp = fixedSequenceDeck[i];
            int randomIndex = Random.Range(i, fixedSequenceDeck.Count);
            fixedSequenceDeck[i] = fixedSequenceDeck[randomIndex];
            fixedSequenceDeck[randomIndex] = temp;
        }
    }

    public void DrawCards(int amount)
    {
        if (fixedSequenceDeck.Count == 0) return;

        for (int i = 0; i < amount; i++)
        {
            if (currentDeckIndex >= fixedSequenceDeck.Count)
            {
                Debug.Log("[DeckManager] 牌組已抽光，從頭開始補牌。");
                currentDeckIndex = 0;
                if (fixedSequenceDeck.Count == 0) break;
            }

            CardData cardToDraw = fixedSequenceDeck[currentDeckIndex];
            currentDeckIndex++;

            if (cardToDraw == null) continue;
            InstantiateCardInHand(cardToDraw);
        }

        UpdateHandSpacing();
        if (handRectTransform != null) LayoutRebuilder.MarkLayoutForRebuild(handRectTransform);
        if (BattleManager.Instance != null) BattleManager.Instance.UpdateCardPileText(GetRemainingDeckCount());
    }

    public void PlayCardToDiscard(CardData cardData, GameObject cardGameObject)
    {
        cardsInHand.Remove(cardGameObject);
        Destroy(cardGameObject);
        UpdateHandSpacing();
    }

    public void MoveCardFromHand(GameObject cardGameObject)
    {
        cardsInHand.Remove(cardGameObject);
        UpdateHandSpacing();
    }

    private void InstantiateCardInHand(CardData cardToDraw)
    {
        if (cardToDraw == null || cardPrefab == null || handArea == null) return;

        GameObject cardGO = Instantiate(cardPrefab, handArea);
        CardDisplay display = cardGO.GetComponent<CardDisplay>();

        if (display != null)
        {
            display.Initialize(cardToDraw, handArea);
        }

        TargetIndicator indicator = cardGO.GetComponent<TargetIndicator>();
        if (indicator != null)
        {
            indicator.Initialize();
        }

        cardsInHand.Add(cardGO);
    }

    private void UpdateHandSpacing()
    {
        if (handLayoutGroup == null || handRectTransform == null || cardWidth <= 0) return;

        int cardCount = cardsInHand.Count;
        if (cardCount <= 1)
        {
            handLayoutGroup.spacing = originalCardSpacing;
            return;
        }

        float handAreaWidth = handRectTransform.rect.width;
        float totalCardWidth = cardWidth * cardCount;
        float totalRequiredWidth = totalCardWidth + (originalCardSpacing * (cardCount - 1));

        if (totalRequiredWidth > handAreaWidth)
        {
            float newSpacing = (handAreaWidth - totalCardWidth) / (float)(cardCount - 1);
            handLayoutGroup.spacing = newSpacing;
        }
        else
        {
            handLayoutGroup.spacing = originalCardSpacing;
        }
    }

    public DeckSaveData GatherSaveData()
    {
        var data = new DeckSaveData();
        data.currentDeckIndex = this.currentDeckIndex;
        data.handCardNames = new List<string>();
        foreach (var cardGO in cardsInHand)
        {
            CardDisplay display = cardGO.GetComponent<CardDisplay>();
            if (display != null && display.GetCardData() != null)
            {
                data.handCardNames.Add(display.GetCardData().cardName);
            }
        }
        return data;
    }

    public void LoadHandFromSave(DeckSaveData data)
    {
        if (data == null) return;
        this.currentDeckIndex = data.currentDeckIndex;

        foreach (var cardGO in cardsInHand) Destroy(cardGO);
        cardsInHand.Clear();

        if (data.handCardNames != null)
        {
            foreach (string cardName in data.handCardNames)
            {
                CardData cardData = CardDatabase.GetCardByName(cardName);
                if (cardData != null) InstantiateCardInHand(cardData);
            }
        }

        UpdateHandSpacing();
        if (handRectTransform != null) LayoutRebuilder.MarkLayoutForRebuild(handRectTransform);
        if (BattleManager.Instance != null) BattleManager.Instance.UpdateCardPileText(GetRemainingDeckCount());
    }

    public void SetCustomDeck(List<CardData> customCards)
    {
        if (customCards == null || customCards.Count == 0) return;

        fixedSequenceDeck = new List<CardData>(customCards);
        ShuffleDeck();
        currentDeckIndex = 0;

        foreach (var card in cardsInHand) Destroy(card);
        cardsInHand.Clear();

        Debug.Log($"[DeckManager] Custom Deck Set. Total Cards: {fixedSequenceDeck.Count}");

        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.UpdateCardPileText(GetRemainingDeckCount());
        }
    }

    public int GetRemainingDeckCount()
    {
        return fixedSequenceDeck.Count - currentDeckIndex;
    }
}