import cv2
import os
import time
from datetime import datetime

# ========= 參數設定 =========
OUTPUT_DIR = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\input_videos"
VIDEO_DIR = OUTPUT_DIR
os.makedirs(VIDEO_DIR, exist_ok=True)

FPS = 30              # 每秒幀數
DURATION = 2          # 錄製秒數
FRAME_COUNT = FPS * DURATION
COUNTDOWN = 3         # 倒數秒數（3 → 2 → 1）

# ========= 檔名設定 =========
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
video_filename = f"{timestamp}.mov"
video_path = os.path.join(VIDEO_DIR, video_filename)

# ========= 開啟攝影機 =========
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("⚠️ 無法開啟攝影機，請檢查設備是否可用")

# 取得畫面尺寸
width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# ========= 建立寫檔器（.mov）=========
try_codes = ["avc1", "H264", "MJPG", "mp4v"]  # 依序嘗試 H.264 → MJPG → mp4v
out = None
for code in try_codes:
    fourcc = cv2.VideoWriter_fourcc(*code)
    out = cv2.VideoWriter(video_path, fourcc, FPS, (width, height))
    if out.isOpened():
        print(f"✅ 使用編碼器：{code}")
        break
if not out or not out.isOpened():
    raise RuntimeError("⚠️ 無法建立 MOV 寫檔器，請嘗試改回 MP4 格式或更換 fourcc")

# ========= 倒數 3,2,1（可按 q 取消）=========
print(f"⏳ 錄影即將開始，倒數 {COUNTDOWN} 秒（按 q 可取消）")
start_time = time.time()
while True:
    ret, frame = cap.read()
    if not ret:
        print("⚠️ 無法讀取影像（倒數）")
        break

    elapsed = time.time() - start_time
    remain = COUNTDOWN - int(elapsed)  # 整數顯示 3/2/1

    # 顯示倒數文字
    if remain > 0:
        text = str(remain)
        cv2.putText(frame, text, (width // 2 - 30, height // 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 255, 255), 6, cv2.LINE_AA)
        cv2.putText(frame, "Get Ready...", (20, height - 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2, cv2.LINE_AA)
        cv2.imshow("Recording", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("🛑 已取消錄影")
            cap.release()
            out.release()
            cv2.destroyAllWindows()
            raise SystemExit
    else:
        # 顯示「Start!」一瞬間（~0.3秒）
        cv2.putText(frame, "Start!", (width // 2 - 70, height // 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 6, cv2.LINE_AA)
        cv2.imshow("Recording", frame)
        cv2.waitKey(300)  # 0.3秒
        break

print(f"🎥 開始錄影：{video_path}（共 {FRAME_COUNT} 幀）")

# ========= 正式錄影 =========
frame_idx = 0
while frame_idx < FRAME_COUNT:
    ret, frame = cap.read()
    if not ret:
        print("⚠️ 無法讀取影像")
        break

    # 左上角 REC 指示
    cv2.circle(frame, (20, 20), 8, (0, 0, 255), -1)
    cv2.putText(frame, "REC", (40, 27),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2, cv2.LINE_AA)

    out.write(frame)
    cv2.imshow("Recording", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        print("🛑 提前結束錄影")
        break

    frame_idx += 1

# ========= 結束錄影 =========
print(f"✅ 錄影完成，影片已儲存：{video_path}")
cap.release()
out.release()
cv2.destroyAllWindows()
