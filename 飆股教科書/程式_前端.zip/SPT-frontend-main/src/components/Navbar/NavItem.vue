<!-- src/components/NavItem.vue -->
<template>
    <router-link
        :to="to"
        class="text-2xl font-medium text-white p-2 rounded-lg hover:bg-white hover:text-slate-600"
    >
        {{ label }}
    </router-link>
</template>

<script setup>
    defineProps({
        label: String,
        to: String,
    })
</script>
