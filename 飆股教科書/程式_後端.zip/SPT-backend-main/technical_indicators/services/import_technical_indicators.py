import logging
import pandas as pd
from stocks.models import Stock
from django.db import DatabaseError
from decimal import Decimal, ROUND_HALF_UP
from technical_indicators.models import TechnicalIndicator
from technical_indicators.services.technical_analysis import (
    calculate_technical_indicators,
)

logger = logging.getLogger(__name__)

INDICATOR_FIELDS = [
    'ma_5',
    'ma_20',
    'ma_60',
    'rsi_5',
    'rsi_10',
    'dif',
    'macd',
    'osc',
    'kd_k',
    'kd_d',
]
ERROR_KEYS = {'detail', 'error', 'message', 'code'}


def q4(x):
    """轉成 Decimal 並四捨五入到小數 4 位"""
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return None
    try:
        return Decimal(str(x)).quantize(Decimal('0.0001'), rounding=ROUND_HALF_UP)
    except Exception:
        return None


def import_technical_indicators(stock_id: str, date):
    stock = Stock.objects.filter(symbol=stock_id).first()
    if not stock:
        return {
            'status': 'not_found',
            'stock': stock_id,
            'detail': f'找不到股票代碼: {stock_id}',
        }

    try:
        existing = TechnicalIndicator.objects.filter(stock=stock, date=date).first()
        if existing:
            # 檢查欄位完整度
            all_filled = all(
                getattr(existing, f, None) is not None for f in INDICATOR_FIELDS
            )
            if all_filled:
                return {
                    'status': 'skipped',
                    'stock': stock_id,
                    'date': date.isoformat(),
                    'detail': '該股票此日期之技術指標已存在，略過計算',
                }
        df = calculate_technical_indicators(stock_id, date=date)

        if isinstance(df, dict):
            if any(k in df for k in ERROR_KEYS) and str(
                df.get('status', '')
            ).lower() not in ('ok', 'success', ''):
                return {
                    'status': 'calculation_error',
                    'stock': stock_id,
                    'detail': df.get('detail') or df.get('error') or str(df),
                }
            data = df
        elif isinstance(df, pd.DataFrame) and not df.empty:
            data = df.iloc[0].to_dict()
        else:
            return {
                'status': 'no_indicator_data',
                'stock': stock_id,
                'detail': '沒有可匯入的資料',
            }

        # 只塞有值的欄位，轉成 Decimal
        tec = {}
        for k in INDICATOR_FIELDS:
            v = data.get(k)
            d = q4(v)
            if d is not None:
                tec[k] = d

        if not tec:
            return {
                'status': 'no_indicator_data',
                'stock': stock_id,
                'detail': '指標數值皆為空',
            }

        _, created = TechnicalIndicator.objects.update_or_create(
            stock=stock,
            date=date,
            defaults=tec,
        )

        return {
            'status': 'success',
            'stock': stock.symbol,
            'date': date.isoformat(),
            'created': created,
        }

    except DatabaseError as de:
        logger.error(f'資料庫錯誤 {stock_id}: {de}')
        return {'status': 'database_error', 'stock': stock_id, 'detail': str(de)}

    except Exception as e:
        logger.exception(f'[TechnicalIndicator] 匯入資料庫失敗 {stock_id}: {e}')
        return {'status': 'error', 'stock': stock_id, 'detail': str(e)}
