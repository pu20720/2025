using UnityEngine;

public static class GameSession
{
    public static RPGItemData SelectedStartingItem;

    public static void ClearSession()
    {
        SelectedStartingItem = null;
    }
}