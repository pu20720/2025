<template>
    <div class="search-wrapper">
        <div class="search-container">
            <input
                v-model="stockCode"
                type="text"
                placeholder="請輸入股票代碼 (e.g. 2330)"
                class="search-input"
                @keyup.enter="goToStockResult(stockCode)"
            />
            <button class="search-button" @click="goToStockResult(stockCode)">🔍</button>
        </div>
    </div>
</template>

<script setup>
    import { ref } from 'vue'
    import { useStockSearch } from '@/stores/stockSearch'
    // 建立一個響應式變數來儲存使用者輸入的查詢
    const stockCode = ref('')
    const { goToStockResult } = useStockSearch()
</script>

<style scoped>
    .search-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
    }
    .search-container {
        display: flex;
        border: 1px solid #1e90ff;
        border-radius: 8px;
        overflow: hidden;
        width: 70%;
        max-width: 600px; /* ✅ 建議加這行限制最大寬度 */
        margin: 20px auto;
        flex-direction: row;
        justify-content: center; /* ✅ 加這行讓內容水平置中 */
    }
    .search-input {
        flex: 1 1 70%;
        padding: 12px 20px;
        font-size: 18px;
        border: none;
        outline: none;
    }
    .search-button {
        flex: 0 0 30%;
        background-color: #1e90ff;
        color: white;
        font-size: 18px;
        padding: 12px 0;
        border: none;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    /* 響應式：手機版時垂直堆疊 */
    @media (max-width: 600px) {
        .search-container {
            flex-direction: column;
        }
        .search-input,
        .search-button {
            width: 100%;
            box-sizing: border-box;
        }
        .search-button {
            padding: 14px 0;
            font-size: 20px;
        }
    }
</style>
