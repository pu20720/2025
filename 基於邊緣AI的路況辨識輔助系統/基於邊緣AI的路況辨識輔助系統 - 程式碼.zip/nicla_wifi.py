
import sensor, network, urequests, time, sys

# ====== WiFi 設定 ======
SSID = 'Lab504_wireless_2.4G'
PASSWORD = 'lab504_wireless'
SERVER_URL = 'http://120.110.113.61:5000/upload'

# ====== 上傳設定 ======
CAPTURE_INTERVAL_MS = 200  # 每1秒拍一張
MAX_RETRY = 3               # 上傳失敗最多重試3次

# ====== 初始化相機 ======
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time=2000)
sensor.snapshot()

# ====== 初始化 WiFi 函數 ======
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print("正在連接WiFi...")
        wlan.connect(SSID, PASSWORD)
        timeout = 10000  # 最多等10秒
        start = time.ticks_ms()
        while not wlan.isconnected():
            if time.ticks_diff(time.ticks_ms(), start) > timeout:
                print("WiFi連接超時，重新啟動...")
                return None
            time.sleep_ms(500)
    print("WiFi已連接:", wlan.ifconfig())
    return wlan

# ====== 拍照並上傳 ======
def capture_and_upload():
    try:
        img = sensor.snapshot()
    except Exception as e:
        print("拍照失敗:", e)
        return
    buf = img.compress(quality=70)  # 壓縮一下比較快
    success = False
    for attempt in range(MAX_RETRY):
        try:
            print(f"上傳第 {attempt+1} 次...")
            response = urequests.post(SERVER_URL, data=buf)
            if response.status_code == 200:
                print("上傳成功，伺服器回應:", response.content)
                #response.close()
                success = True
                break
            else:
                print(f"伺服器回應錯誤，狀態碼: {response.status_code}")
                response.close()
        except Exception as e:
            print("上傳失敗:", e)
        finally:
            if 'response' in locals() and hasattr(response, 'close'):
                try:
                    response.close()
                except:
                    pass
        time.sleep_ms(1000)  # 等1秒再試

    if not success:
        print("連續上傳失敗，暫停操作...")
        # 可以選擇不重啟，而是讓程式持續運行並顯示錯誤訊息
        time.sleep_ms(5000)  # 等5秒再試一次
    return

# ====== 主程式 ======
def main():
    wlan = connect_wifi()
    if wlan is None:
        print("WiFi連接失敗，請檢查網路設定。")
        sys.exit()  # 如果WiFi連接失敗，退出程式

    last_capture_time = time.ticks_ms()

    while True:
        now = time.ticks_ms()
        if time.ticks_diff(now, last_capture_time) >= CAPTURE_INTERVAL_MS:
            last_capture_time = now
            if not wlan.isconnected():
                print("WiFi掉線，重連中...")
                wlan = connect_wifi()
                if wlan is None:
                    print("WiFi 重新連接失敗，程式將停止。")
                    sys.exit()  # 連接失敗則退出程式
            capture_and_upload()

main()
