using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;

public class InventoryUI : MonoBehaviour
{
    [Header("Manager Reference")]
    [SerializeField] private ConversationManager conversationManager;

    [Header("UI References (General)")]
    [SerializeField] private GameObject inventoryPanel;   // 背包的底圖面板
    [SerializeField] private Button openInventoryButton;  // 開啟背包的按鈕
    [SerializeField] private Button closeInventoryButton; // 關閉背包的按鈕

    [Header("Backpack (Bottom Area)")]
    [Tooltip("背包 ScrollView 的 Content 物件")]
    [SerializeField] private Transform itemsContainer;
    [Tooltip("背包格子 Prefab (掛載 InventorySlotUI)")]
    [SerializeField] private GameObject itemSlotPrefab;

    [Header("Loadout (Top Area)")]
    [Tooltip("上方 Loadout 的 Content 物件 (Horizontal Layout)")]
    [SerializeField] private Transform loadoutContainer;
    [Tooltip("Loadout 格子 Prefab (掛載 LoadoutSlotUI)")]
    [SerializeField] private GameObject loadoutSlotPrefab;

    [Header("Item Action UI")]
    [SerializeField] private GameObject itemDetailPanel;
    [SerializeField] private Image detailIconImage;
    [SerializeField] private Text detailNameText;
    [SerializeField] private Text detailDescriptionText;
    [SerializeField] private Button useItemButton;

    // 暫存選擇
    private int currentSelectedSlotIndex = -1;

    private void Start()
    {
        if (inventoryPanel != null) inventoryPanel.SetActive(false);
        if (itemDetailPanel != null) itemDetailPanel.SetActive(false);

        if (conversationManager == null) conversationManager = FindFirstObjectByType<ConversationManager>();

        if (openInventoryButton != null) openInventoryButton.onClick.AddListener(OpenInventory);
        if (closeInventoryButton != null) closeInventoryButton.onClick.AddListener(CloseInventory);

        // 使用按鈕：嘗試將選中的物品放入 Loadout
        if (useItemButton != null)
        {
            useItemButton.onClick.AddListener(() => {
                if (currentSelectedSlotIndex != -1)
                {
                    InventoryManager.Instance.TryIncreaseLoadout(currentSelectedSlotIndex);
                    RefreshUI();
                }
            });
        }
    }

    public void OpenInventory()
    {
        if (inventoryPanel != null)
        {
            inventoryPanel.SetActive(true);
            RefreshUI();
            if (itemDetailPanel != null) itemDetailPanel.SetActive(false);
        }
    }

    public void CloseInventory()
    {
        if (inventoryPanel != null) inventoryPanel.SetActive(false);
    }

    // ▼▼▼ 【修復】 實作 RefreshUI 方法，解決 CS1061 錯誤 ▼▼▼
    public void RefreshUI()
    {
        if (InventoryManager.Instance == null) return;

        // A. 刷新下方背包 (Backpack)
        if (itemsContainer != null && itemSlotPrefab != null)
        {
            foreach (Transform child in itemsContainer) Destroy(child.gameObject);

            List<InventorySlot> slots = InventoryManager.Instance.backpackSlots;
            for (int i = 0; i < slots.Count; i++)
            {
                GameObject obj = Instantiate(itemSlotPrefab, itemsContainer);
                InventorySlotUI slotUI = obj.GetComponent<InventorySlotUI>();
                if (slotUI != null)
                {
                    bool isSelected = (i == currentSelectedSlotIndex);
                    slotUI.Setup(slots[i], i, this, isSelected);
                }
            }
        }

        // B. 刷新上方攜帶欄 (Loadout)
        if (loadoutContainer != null && loadoutSlotPrefab != null)
        {
            foreach (Transform child in loadoutContainer) Destroy(child.gameObject);

            var equippedSlots = InventoryManager.Instance.backpackSlots.Where(s => s.equippedCount > 0);
            foreach (var slot in equippedSlots)
            {
                GameObject obj = Instantiate(loadoutSlotPrefab, loadoutContainer);
                LoadoutSlotUI ui = obj.GetComponent<LoadoutSlotUI>();
                if (ui != null)
                {
                    ui.Setup(slot.itemData, slot.equippedCount, this);
                }
            }
        }
    }
    // ▲▲▲

    // ▼▼▼ 【修復】 實作 OnSlotClicked (被 InventorySlotUI 呼叫) ▼▼▼
    public void OnSlotClicked(int index)
    {
        currentSelectedSlotIndex = index;
        RefreshUI(); // 更新高亮顯示

        // 更新詳細資訊面板
        if (index >= 0 && index < InventoryManager.Instance.backpackSlots.Count)
        {
            InventorySlot slot = InventoryManager.Instance.backpackSlots[index];
            if (itemDetailPanel != null) itemDetailPanel.SetActive(true);
            if (detailIconImage != null)
            {
                if (slot.itemData.icon != null) detailIconImage.sprite = slot.itemData.icon;
                else detailIconImage.color = slot.itemData.displayColor;
            }
            if (detailNameText != null) detailNameText.text = slot.itemData.itemName;
            if (detailDescriptionText != null) detailDescriptionText.text = slot.itemData.description;
        }
    }
    // ▲▲▲

    // ▼▼▼ 【修復】 實作 OnLoadoutItemClicked (被 LoadoutSlotUI 呼叫) ▼▼▼
    public void OnLoadoutItemClicked(ItemData item)
    {
        // 當玩家點擊上方的攜帶物品 -> 移除它 (減少攜帶量)
        if (InventoryManager.Instance != null)
        {
            InventoryManager.Instance.TryDecreaseLoadout(item);
            RefreshUI();
        }
    }
    // ▲▲▲
}