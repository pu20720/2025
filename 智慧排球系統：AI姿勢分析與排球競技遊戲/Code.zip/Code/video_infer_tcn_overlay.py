#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
video_infer_tcn_overlay.py
--------------------------
把影片丟到 (TCNClassifier) 模型，逐幀顯示「正確 / 錯誤」，並輸出一支新影片。

特點
- 以 MediaPipe Pose 抓 33 個關鍵點 (x,y,z,visibility) → 每幀 132 維
- 使用滑動視窗長度 T（seq_len）組成輸入序列
- 與你的 evaluate_pose.py 一致的模型定義 (TCNClassifier)
- 可選：用資料集 npz 做校正常態化；若未提供，改以「當前視窗」自行標準化
- 支援 CUDA：加上 --cuda
- 平滑輸出：對最近 k 個預測做投票/平均，減少抖動

用法範例
python video_infer_tcn_overlay.py \
  --video "input.mp4" \
  --model "best_model_fold1.pt" \
  --out   "input_pred.mp4" \
  --seq_len 30 \
  --calib_npz "dataset_underhandpass5.npz" \
  --cuda
"""
import os
import time
import argparse
import numpy as np
import cv2

import torch
import torch.nn as nn

# ===== MediaPipe =====
try:
    import mediapipe as mp
except ImportError:
    raise SystemExit("請先安裝 mediapipe： pip install mediapipe==0.10.11")

# ========================
# Model 定義（與 evaluate_pose.py 相同）
# ========================
class TCNBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, d=1, p=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_ch, out_ch, kernel_size=k, padding=d*(k-1)//2, dilation=d),
            nn.ReLU(),
            nn.Dropout(p),
            nn.Conv1d(out_ch, out_ch, kernel_size=k, padding=d*(k-1)//2, dilation=d),
        )
        self.res = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(self.net(x) + self.res(x))

class TCNClassifier(nn.Module):
    def __init__(self, in_feats=132, num_classes=2):
        super().__init__()
        chs = [in_feats, 256, 256]
        dilations = [1, 2]
        blocks = []
        for i in range(len(chs)-1):
            blocks.append(TCNBlock(chs[i], chs[i+1], k=3, d=dilations[i], p=0.3))
        self.backbone = nn.Sequential(*blocks)
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(chs[-1], num_classes)
        )

    def forward(self, x):  # x: (B, F, T)
        h = self.backbone(x)
        return self.head(h)

# ========================
# MediaPipe Pose
# ========================
mp_pose = mp.solutions.pose
POSE = mp_pose.Pose(
    static_image_mode=False,
    model_complexity=1,
    enable_segmentation=False,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

def extract_pose_33(frame_bgr):
    """回傳 (33,4) np.float32；若偵測不到人回 None"""
    img_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    res = POSE.process(img_rgb)
    if not res.pose_landmarks:
        return None
    lm = res.pose_landmarks.landmark
    arr = np.array([[p.x, p.y, p.z, p.visibility] for p in lm], dtype=np.float32)
    return arr

# ========================
# Preprocess / Normalization
# ========================
def compute_mu_std_from_npz(npz_path):
    d = np.load(npz_path, allow_pickle=True)
    X = d["X"].astype(np.float32)  # (N, T, 132)
    mu = X.mean(axis=(0,1), keepdims=True)  # (1,1,132)
    std = X.std(axis=(0,1), keepdims=True) + 1e-6
    return mu, std

def normalize_window(window_feat, mu=None, std=None):
    """
    window_feat: (T, 132) float32
    若提供 mu/std（建議用資料集算），用它；否則用當前視窗自算。
    回傳 (T, 132)
    """
    if mu is None or std is None:
        mu_local = window_feat.mean(axis=0, keepdims=True)
        std_local = window_feat.std(axis=0, keepdims=True) + 1e-6
        return (window_feat - mu_local) / std_local
    else:
        # mu/std shape: (1,1,132) or (1,132)
        if mu.ndim == 3: mu = mu.reshape(1, -1)  # (1,132)
        if std.ndim == 3: std = std.reshape(1, -1)
        return (window_feat - mu) / std

def softmax_np(x):
    x = x - x.max()
    ex = np.exp(x)
    return ex / (ex.sum() + 1e-9)

# ========================
# 主流程：影片 → 推論 → 疊字輸出
# ========================
def run(video_path, model_path, out_path=None, seq_len=30, device="cpu",
        label_wrong="錯誤", label_correct="正確", smooth_k=5, calib_npz=None,
        draw_prob=True):
    if not os.path.exists(video_path):
        raise FileNotFoundError(video_path)
    if out_path is None:
        base, ext = os.path.splitext(video_path)
        out_path = base + "_pred" + ext

    # 視訊 I/O
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError("無法開啟影片")

    fps    = cap.get(cv2.CAP_PROP_FPS) or 30.0
    width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(out_path, fourcc, fps, (width, height))

    # 模型
    model = TCNClassifier(in_feats=132, num_classes=2).to(device)
    state = torch.load(model_path, map_location=device)
    # 兼容 {"state_dict": ...} 或直接 state_dict
    if isinstance(state, dict) and "state_dict" in state and isinstance(state["state_dict"], dict):
        state = state["state_dict"]
    model.load_state_dict(state, strict=False)
    model.eval()

    # 正規化參考（可選）
    mu = std = None
    if calib_npz is not None and os.path.exists(calib_npz):
        mu, std = compute_mu_std_from_npz(calib_npz)  # (1,1,132)

    # 推論狀態
    buf_poses = []   # list of (33,4)
    pred_hist = []   # [(label_text, prob)] for smoothing
    total_frames = 0
    t0 = time.time()

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        total_frames += 1

        pose334 = extract_pose_33(frame)
        if pose334 is None:
            cv2.putText(frame, "未偵測到人", (40, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.4, (0,0,255), 3, cv2.LINE_AA)
            writer.write(frame)
            continue

        buf_poses.append(pose334)
        if len(buf_poses) > seq_len:
            buf_poses.pop(0)

        if len(buf_poses) == seq_len:
            window = np.stack(buf_poses, axis=0)          # (T,33,4)
            feat   = window.reshape(seq_len, -1)          # (T,132)
            feat   = normalize_window(feat, mu, std)      # (T,132)

            x = torch.from_numpy(feat.transpose(1,0)[None, ...]).to(device)  # (1,132,T)
            with torch.no_grad():
                logits = model(x).detach().cpu().numpy()[0]  # (2,)
                probs  = softmax_np(logits)
                pred_id = int(np.argmax(probs))

            label_text = label_correct if pred_id == 1 else label_wrong
            prob_val = float(probs[pred_id])

            # 平滑
            pred_hist.append((label_text, prob_val))
            if len(pred_hist) > smooth_k:
                pred_hist.pop(0)
            labels = [p[0] for p in pred_hist]
            probs_list = [p[1] for p in pred_hist]
            final_label = max(set(labels), key=labels.count)
            final_prob  = sum(probs_list)/len(probs_list)

            color = (0,200,0) if final_label == label_correct else (0,0,255)
            text = f"{final_label}"
            if draw_prob:
                text += f" ({final_prob*100:.1f}%)"
            cv2.putText(frame, text, (40, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.6, color, 4, cv2.LINE_AA)

        writer.write(frame)

    cap.release()
    writer.release()
    dt = time.time() - t0
    print(f"完成！輸出：{out_path}；總幀數：{total_frames}；耗時 {dt:.2f}s；平均 {total_frames/max(dt,1e-6):.1f} FPS")

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True, help=r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\underhand_pass\underhandpass_90_correct_(50）.MOV")
    ap.add_argument("--model", required=True, help="best_model_fold1.pt (state_dict)")
    ap.add_argument("--out", default=None, help="輸出影片路徑（未填則為 _pred.mp4）")
    ap.add_argument("--seq_len", type=int, default=30, help="視窗長度 T（預設30）")
    ap.add_argument("--cuda", action="store_true", help="若可用則以 CUDA 推論")
    ap.add_argument("--label_wrong", default="錯誤", help="ID=0 的標籤文字")
    ap.add_argument("--label_correct", default="正確", help="ID=1 的標籤文字")
    ap.add_argument("--smooth_k", type=int, default=5, help="平滑視窗大小（票選）")
    ap.add_argument("--calib_npz", default=None, help="(可選) 訓練資料 npz 以取得 mu/std 正規化")
    args = ap.parse_args()

    device = "cuda" if (args.cuda and torch.cuda.is_available()) else "cpu"
    return args, device

if __name__ == "__main__":
    args, device = parse_args()
    run(
        video_path=args.video,
        model_path=args.model,
        out_path=args.out,
        seq_len=args.seq_len,
        device=device,
        label_wrong=args.label_wrong,
        label_correct=args.label_correct,
        smooth_k=args.smooth_k,
        calib_npz=args.calib_npz
    )
