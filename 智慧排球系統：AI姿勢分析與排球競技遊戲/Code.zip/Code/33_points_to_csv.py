import mediapipe as mp
from mediapipe import solutions
from mediapipe.framework.formats import landmark_pb2
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
import numpy as np
import pandas as pd
import cv2
import os
from draw_keypoints import draw_landmarks_on_image


# ---------- 安全輸出 ----------
def safe_print(text):
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode('cp950', errors='ignore').decode('cp950'))

# ---------- 設定路徑 ----------
image_folder = r"D:\\workspace\\Python\\Mediapipe Pose Landmark Detection\\spike"  # 圖片位置
model_path = r"D:\\workspace\\Python\\Mediapipe Pose Landmark Detection\\pose_landmarker_heavy.task"  # 模型位置
output_csv_folder = r"D:\\workspace\\Python\\Mediapipe Pose Landmark Detection\\spike_pose_output"
output_image_folder = r"D:\\workspace\\Python\\Mediapipe Pose Landmark Detection\\spike_annotated_image"

# ---------- 初始化模型 ----------
base_options = python.BaseOptions(model_asset_path=model_path)
options = vision.PoseLandmarkerOptions(
    base_options=base_options,
    output_segmentation_masks=False)
detector = vision.PoseLandmarker.create_from_options(options)

# ---------- 載入圖片 ----------
valid_extensions = (".jpg", ".jpeg", ".png")

for filename in os.listdir(image_folder):
    if not filename.lower().endswith(valid_extensions):
        continue  # 跳過非圖片

    image_path = os.path.join(image_folder, filename)
    try:
        image = mp.Image.create_from_file(image_path)
        # ---------- 偵測姿勢 ----------
        detection_result = detector.detect(image)
        image.append(image)

        # ------- 繪製關鍵點並顯示 -------

        annotated_image = draw_landmarks_on_image(image.numpy_view(), detection_result)
        annotated_path = os.path.join(output_image_folder, f"annotated_{filename}")
        cv2.imwrite(annotated_path, cv2.cvtColor(annotated_image, cv2.COLOR_RGB2BGR))
        safe_print(f"標記圖儲存於：{annotated_path}")

        # ---------- 儲存到 DataFrame ----------
        if detection_result.pose_landmarks:
            landmark_data = []
            for landmark in detection_result.pose_landmarks[0]:
                landmark_data.append([landmark.x, landmark.y, landmark.z, landmark.visibility])

            df = pd.DataFrame(landmark_data, columns=["x", "y", "z", "visibility"])
            df.index.name = "landmark_id"
            df.to_csv(output_csv_folder)
            safe_print(f"姿勢資料已儲存到 DataFrame 並輸出到：{output_csv_folder}")
        else:
            safe_print("沒有偵測到姿勢")

    except Exception as e:
        safe_print(f"處理 {filename} 時出錯：{e}")


# ---------- 關閉模型 ----------
detector.close()