using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class LoadoutSlotUI : MonoBehaviour
{
    [Header("UI References")]
    public Image iconImage;       // 請綁定 Prefab 自己的 Image
    public TextMeshProUGUI quantityText; // 請綁定子物件 Text

    private ItemData myItem;
    private InventoryUI uiManager;
    private Button selfButton; // 這是物件自己的按鈕

    public void Setup(ItemData data, int quantity, InventoryUI ui)
    {
        myItem = data;
        uiManager = ui;

        if (data == null) return;

        // --- 1. 純色設定 (不顯示圖片) ---
        if (iconImage != null)
        {
            iconImage.sprite = null; // 確保沒有圖片
            iconImage.color = data.displayColor; // 使用資料的顏色
        }

        // --- 2. 堆疊數量顯示 (位置強制設定) ---
        if (quantityText != null)
        {
            // 裝備不顯示數量，其他都顯示 (x1, x2...)
            bool showNumber = (data.itemType != ItemType.Equipment);
            quantityText.gameObject.SetActive(showNumber);

            if (showNumber)
            {
                quantityText.text = $"x{quantity}";

                // 強制設定文字位置 (跟背包一樣，卡片下方)
                RectTransform rt = quantityText.rectTransform;
                if (rt != null)
                {
                    rt.anchorMin = new Vector2(0.5f, 0);
                    rt.anchorMax = new Vector2(0.5f, 0);
                    rt.pivot = new Vector2(0.5f, 1); // 上緣對齊
                    rt.sizeDelta = new Vector2(120, 40); // 寬度與卡片一致
                    rt.anchoredPosition = new Vector2(0, -10); // 稍微往下移

                    quantityText.alignment = TextAlignmentOptions.Center;
                    quantityText.enableAutoSizing = false;
                    quantityText.fontSize = 36;
                    quantityText.color = Color.white;
                }
            }
        }

        // --- 3. 綁定自身點擊事件 (減少攜帶) ---
        // 自動抓取或新增 Button 組件
        selfButton = GetComponent<Button>();
        if (selfButton == null) selfButton = gameObject.AddComponent<Button>();

        selfButton.onClick.RemoveAllListeners();
        selfButton.onClick.AddListener(OnClicked);
    }

    private void OnClicked()
    {
        // 點擊自己 -> 通知 UI Manager 減少這個物品的攜帶量
        if (uiManager != null)
        {
            uiManager.OnLoadoutItemClicked(myItem);
        }
    }
}