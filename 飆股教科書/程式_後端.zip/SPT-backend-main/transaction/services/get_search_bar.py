import logging
from stocks_price.models import StockPrices
from django.db.models import OuterRef, Subquery, F, Q


def get_search_bar(keyword):
    logger = logging.getLogger(__name__)
    try:
        if not keyword:
            return [{'error': '請提供股票代號'}]
        # 子查詢：找出每檔股票的最新日期
        latest_price_subquery = (
            StockPrices.objects.filter(stock=OuterRef('stock'))
            .order_by('-price_date')
            .values('price_date')[:1]
        )

        # 主查詢：每支股票只留最新一筆價格
        queryset = (
            StockPrices.objects.select_related('stock')
            .annotate(latest_date=Subquery(latest_price_subquery))
            .filter(price_date=F('latest_date'))
        )

        if keyword:
            queryset = queryset.filter(
                Q(stock__symbol__icontains=keyword) | Q(stock__name__icontains=keyword)
            )

        queryset = queryset.order_by('stock__symbol')[:10]

        # 回傳結果
        results = [
            {
                'id': q.id,
                'symbol': q.stock.symbol,
                'name': q.stock.name,
                'price': q.close_price,
            }
            for q in queryset
        ]

        return results

    except Exception as e:
        logger.error(f'[StockPrice] 資料查詢失敗 {e}')
        return [{'error': '查詢過程中發生錯誤'}]
