// Assets/Scripts/BodyPartDefense.cs
using UnityEngine;

[System.Serializable]
public class BodyPartDefense
{
    public string partName;

    // 關鍵：改為 public，讓 CharacterStats 可存取
    public int currentArmor;
    public int maxArmor;
    public bool isBroken = false;
    public int corruptStacks = 0;
    public int corruptTurns = 0;  // 改為 public

    public BodyPartDefense(string name)
    {
        this.partName = name;
        this.currentArmor = 0;
        this.maxArmor = 0;
        this.isBroken = false;
        this.corruptStacks = 0;
        this.corruptTurns = 0;
    }

    public void EquipArmor(int defenseValue)
    {
        this.maxArmor = defenseValue;
        this.currentArmor = defenseValue;
        this.isBroken = false;
    }

    public void Repair(int amount)
    {
        if (amount <= 0) return;
        // ▼▼▼ 修正：移除 Mathf.Min 以符合「護甲無上限」規則 ▼▼▼
        // this.currentArmor = Mathf.Min(this.currentArmor + amount, this.maxArmor); // <-- 舊的錯誤邏輯
        this.currentArmor += amount; // <-- 新的正確邏輯
        // ▲▲▲ 修正結束 ▲▲▲
        this.isBroken = false;
    }

    public void ApplyDamage(int damage)
    {
        if (this.isBroken || damage <= 0) return;
        this.currentArmor -= damage;
        if (this.currentArmor <= 0)
        {
            this.currentArmor = 0;
            this.isBroken = true;
        }
    }

    public void AddCorruption(int stacks)
    {
        if (stacks <= 0) return;
        this.corruptStacks += stacks;
        this.corruptTurns = Mathf.Max(this.corruptTurns, 1); // 至少一回合
    }

    // 關鍵：讓外部可呼叫，修正 CS0122
    public void UpdateCorruption(RPGStatsData data)
    {
        if (data == null || this.corruptStacks <= 0) return;

        // 每回合扣 1.3x 護甲
        int decay = Mathf.CeilToInt(this.corruptStacks * 1.3f);
        this.currentArmor = Mathf.Max(0, this.currentArmor - decay);

        // 回合遞減
        this.corruptTurns--;
        if (this.corruptTurns <= 0)
        {
            this.corruptStacks = 0;
            this.corruptTurns = 0;
        }

        if (this.currentArmor <= 0)
        {
            this.currentArmor = 0;
            this.isBroken = true;
        }
    }
}