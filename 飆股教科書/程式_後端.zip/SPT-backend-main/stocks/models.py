from django.db import models
from django.db.models import Max

# Create your models here.


class Stock(models.Model):
    id = models.AutoField(primary_key=True)
    symbol = models.CharField(max_length=10, unique=True)  # 股票代碼
    name = models.CharField(max_length=100)  # 股票名稱
    industry = models.CharField(max_length=100)  # 所屬產業
    founded_date = models.DateField(blank=True, null=True)  # 成立日期
    listed_date = models.DateField(blank=True, null=True)  # 上市日期
    capital = models.DecimalField(
        max_digits=15, decimal_places=2, blank=True, null=True
    )  # 實收資本額
    website = models.URLField(max_length=200, blank=True, null=True)  # 公司網站

    def __str__(self):
        return f'{self.symbol} - {self.name}'


class Watchlist(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(
        'users.User', on_delete=models.CASCADE, related_name='watchlists'
    )  # 關聯到使用者
    stock = models.ForeignKey(
        'stocks.Stock', on_delete=models.CASCADE, related_name='watchlisted_by'
    )  # 關聯到股票
    position = models.PositiveIntegerField(
        db_index=True, null=True, blank=True
    )  # 位置，用於排序
    created_at = models.DateTimeField(auto_now_add=True)  # 建立時間

    class Meta:
        unique_together = (
            ('user', 'stock'),
            ('user', 'position'),
        )  # 同一使用者不能重複加入同一支股票，且 position 也不能重複
        ordering = ['position', 'id']  # 預設依 position 排

    def save(self, *args, **kwargs):
        if self.position is None:
            max_pos = (
                (
                    Watchlist.objects.filter(user=self.user).aggregate(Max('position'))[
                        'position__max'
                    ]
                )
                or 0
            )
            self.position = max_pos + 1
        return super().save(*args, **kwargs)


class HotStocks(models.Model):
    id = models.AutoField(primary_key=True)
    stock = models.ForeignKey(
        'stocks.Stock', on_delete=models.CASCADE, related_name='hot_entries'
    )  # 關聯到股票
    rank = models.PositiveIntegerField()  # 熱門排名
    date = models.DateField()  # 日期
    reason = models.TextField(blank=True, null=True)  # 熱門原因描述

    class Meta:
        ordering = ['date', 'rank']  # 預設依日期和排名排序
        constraints = [
            models.CheckConstraint(
                check=models.Q(rank__gte=1) & models.Q(rank__lte=20),
                name='排名必須介於 1 到 20 之間',
            ),
            models.UniqueConstraint(
                fields=['date', 'stock'],
                name='同一天的股票不能重複出現',
            ),
            models.UniqueConstraint(
                fields=['date', 'rank'],
                name='同一天的排名不能重複',
            ),
        ]

    def __str__(self):
        return f'{self.date} - {self.rank} - {self.stock.symbol}'
