import logging
from financial.models import Financial

logger = logging.getLogger(__name__)


def get_financial(keyword) -> list:
    try:
        queryset = Financial.objects.filter(stock_id__symbol=keyword)

        if not queryset.exists():
            logger.warning(f'[Financial] 查詢結果為空 symbol={keyword}')
            return [{'error': '查無資料'}]

        return list(queryset.values())

    except Exception as e:
        logger.error(f'[Financial] 資料查詢失敗 {e}')
        return [{'error': '查詢過程中發生錯誤'}]
