import logging
from stocks.models import Stock
from datetime import datetime, timedelta, date
from django.core.management.base import BaseCommand
from technical_indicators.services.import_technical_indicators import (
    import_technical_indicators,
)

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = '批次匯入技術指標：預設從上市日至昨天；也可指定 --start/--end 覆蓋日期範圍；--stock 可限定單一股票。'

    def add_arguments(self, parser):
        parser.add_argument(
            '--start', type=str, help='起始日期 (YYYY-MM-DD)(若不指定則用 2020-01-01)'
        )
        parser.add_argument(
            '--end', type=str, help='結束日期 (YYYY-MM-DD)(若不指定則用 前天)'
        )
        parser.add_argument('--stock', type=str, help='指定股票代號（若不指定則全部）')

    def handle(self, *args, **options):
        stock_filter = options.get('stock')
        start_str = options.get('start')
        end_str = options.get('end')

        # 取今天、昨天、前天
        today = date.today()
        yesterday = today - timedelta(days=1)

        # 解析 --end 參數，有錯則退出
        try:
            end_date = (
                datetime.strptime(end_str, '%Y-%m-%d').date() if end_str else yesterday
            )
        except ValueError:
            self.stderr.write(self.style.ERROR('結束日期格式錯誤，請用 YYYY-MM-DD'))
            return

        # 抓股票清單
        stock_list = Stock.objects.all()
        if stock_filter:
            stock_list = stock_list.filter(symbol=stock_filter)

        for stock in stock_list:
            # 決定起始日期：優先 --start，否則用2020-01-01
            if start_str:
                try:
                    start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
                except ValueError:
                    self.stderr.write(
                        self.style.ERROR('起始日期格式錯誤，請用 YYYY-MM-DD')
                    )
                    return
            else:
                start_date = date(2020, 1, 1)

            # 如果起始晚於結束，跳過
            if start_date > end_date:
                self.stdout.write(
                    self.style.WARNING(
                        f'[跳過] {stock.symbol} 起始日 {start_date} 晚於結束日 {end_date}'
                    )
                )
                continue

            # 取得該股票在期間內的實際交易日
            qs = stock.prices.filter(price_date__range=(start_date, end_date))

            # 確認至少有一筆交易資料
            if not qs.exists():
                self.stdout.write(
                    self.style.WARNING(
                        f'[跳過] {stock.symbol} 在 {start_date}~{end_date} 無交易資料'
                    )
                )
                continue

            for run_date in qs.order_by('price_date').values_list(
                'price_date', flat=True
            ):
                result = import_technical_indicators(stock.symbol, run_date)
                if result is None:
                    self.stdout.write(
                        self.style.WARNING(f'[跳過] {stock.symbol} {run_date}')
                    )
                else:
                    self.stdout.write(
                        self.style.SUCCESS(f'[完成] {stock.symbol} {run_date}')
                    )
