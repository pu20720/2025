<template>
    <div class="w-full px-4 md:px-16 py-12 bg-gray-50 min-h-screen">
        <div class="mb-10 max-w-5xl mx-auto">
            <div class="flex justify-between items-end mb-2">
                <h3 class="text-xl font-semibold text-blue-700 transition duration-300">
                    {{
                        slides[currentSlide].title.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]\s?/, '')
                    }}
                </h3>
                <span class="text-sm font-medium text-gray-500">
                    主題 {{ currentSlide + 1 }} / {{ slides.length }}
                </span>
            </div>
            <div class="w-full bg-gray-300 rounded-full h-2.5 overflow-hidden">
                <div
                    class="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
                    :style="{ width: ((currentSlide + 1) / slides.length) * 100 + '%' }"
                ></div>
            </div>
        </div>

        <transition name="slide-fade" mode="out-in">
            <div
                :key="currentSlide"
                class="bg-white rounded-2xl shadow-xl p-10 md:flex gap-12 items-start border border-gray-100 max-w-5xl mx-auto"
            >
                <div
                    :class="{
                        'md:w-1/2': slides[currentSlide].img,
                        'md:w-full': !slides[currentSlide].img,
                    }"
                    class="w-full"
                >
                    <h2 class="text-3xl font-extrabold mb-6 text-gray-800">
                        {{ slides[currentSlide].title }}
                    </h2>
                    <div
                        class="text-lg text-gray-700 leading-relaxed space-y-4"
                        v-html="slides[currentSlide].content"
                    ></div>
                </div>

                <div
                    v-if="Array.isArray(slides[currentSlide].img)"
                    class="md:w-1/2 w-full mt-8 md:mt-0 space-y-4"
                >
                    <div
                        v-for="(image, index) in slides[currentSlide].img"
                        :key="index"
                        class="bg-gray-100 p-3 rounded-lg shadow-sm border border-gray-200 cursor-pointer hover:shadow-lg transition duration-200"
                        @click="openModal(image.src, image.caption)"
                    >
                        <img
                            :src="image.src"
                            :alt="image.caption || 'K線圖型態'"
                            class="w-full h-auto max-h-48 object-contain rounded-md mx-auto"
                            :style="{ maxHeight: '12rem' }"
                        />
                        <p class="mt-2 text-center text-sm text-gray-600 font-medium">
                            {{ image.caption }}
                        </p>
                    </div>
                </div>

                <img
                    v-else-if="slides[currentSlide].img"
                    :src="slides[currentSlide].img"
                    :class="`${slides[currentSlide].imgClass} object-contain rounded-xl shadow-lg border border-gray-200 cursor-pointer hover:opacity-90 transition duration-200`"
                    class="md:w-1/2 w-full mt-8 md:mt-0"
                    @click="openModal(slides[currentSlide].img, slides[currentSlide].title)"
                />
            </div>
        </transition>

        <transition name="modal-fade">
            <div
                v-if="showModal"
                class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 p-4"
                @click.self="showModal = false"
            >
                <div
                    class="max-w-4xl max-h-full overflow-y-auto bg-white rounded-lg shadow-2xl relative"
                >
                    <button
                        @click="showModal = false"
                        class="absolute top-3 right-3 text-white bg-red-600 rounded-full p-2 hover:bg-red-700 transition duration-200 z-10"
                    >
                        <svg
                            class="w-6 h-6"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"
                            ></path>
                        </svg>
                    </button>

                    <img
                        :src="modalImgSrc"
                        class="w-full h-auto object-contain max-h-screen-75"
                        style="max-height: 80vh"
                    />

                    <div
                        v-if="modalImgCaption"
                        class="p-4 bg-gray-100 text-center text-lg font-medium text-gray-700"
                    >
                        {{ modalImgCaption }}
                    </div>
                </div>
            </div>
        </transition>

        <div class="flex justify-between mt-16 max-w-5xl mx-auto">
            <button
                @click="prevSlide"
                :disabled="currentSlide === 0"
                class="px-7 py-2.5 rounded-full border border-blue-600 text-blue-600 font-medium hover:bg-blue-50 transition duration-300 disabled:opacity-40 disabled:border-gray-300 disabled:text-gray-400"
            >
                &larr; 上一主題
            </button>

            <button
                v-if="!isLastSlide"
                @click="nextSlide"
                class="px-9 py-2.5 rounded-full bg-blue-600 text-white font-semibold shadow-md shadow-blue-300 hover:bg-blue-700 hover:shadow-lg transition duration-300"
            >
                下一主題 &rarr;
            </button>

            <button
                v-else
                @click="goHome"
                class="px-9 py-2.5 rounded-full bg-green-600 text-white font-semibold shadow-md shadow-green-300 hover:bg-green-700 hover:shadow-lg transition duration-300"
            >
                回到課程首頁
            </button>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed } from 'vue'
    import { useRouter } from 'vue-router'
    import { useToast } from 'primevue/usetoast'

    const toast = useToast()
    const router = useRouter()
    const currentSlide = ref(0)

    // 💡 新增 Modal 相關狀態
    const showModal = ref(false)
    const modalImgSrc = ref('')
    const modalImgCaption = ref('')

    // 圖片引入
    import K from '@/assets/K線圖介紹.png'
    import K1 from '@/assets/常見K線型態1.png'
    import K2 from '@/assets/常見K線型態2.png'
    import RedThreeSoldiers from '@/assets/紅三兵.png'
    import BlackThreeSoldiers from '@/assets/黑三兵.png'
    import TwoStarLookMore from '@/assets/二星看多.png'
    import TwoStarLookLess from '@/assets/二星看空.png'
    import LineChartIntroImg from '@/assets/line_chart_intro.png'

    // 💡 新增開啟 Modal 的函數
    function openModal(src, caption = '') {
        modalImgSrc.value = src
        modalImgCaption.value = caption
        showModal.value = true
    }

    const slides = [
        // --- Slide 0: 股票線圖介紹 & 成交量 ---
        {
            title: '📈 股票線圖介紹 & 成交量',
            content: `
      <p class="mb-5 text-gray-700 leading-relaxed">股票線圖（Price Chart）是投資人分析股價走勢最重要的工具，用於判斷趨勢與價格轉折常見類型包括：</p>
      <ul class="list-disc pl-5 space-y-3 text-gray-800 leading-relaxed">
        <li><strong>折線圖（Line Chart）：</strong> 以每日收盤價連線，觀察價格整體趨勢</li>
        <li><strong>K 線圖（Candlestick Chart）：</strong> 顯示開、高、低、收四個價位，資訊最完整</li>
        <li><strong>成交量（Volume）：</strong> 反映市場交易活絡程度，通常在線圖下方顯示</li>
      </ul>
      <div class="mt-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-md text-gray-700 text-base">
        <strong class="text-blue-700">📌 成交量與趨勢：</strong><br>
        價漲量增代表趨勢健康；價漲量縮代表潛在力道不足或觀望量價關係是判斷趨勢健康度的重要依據
      </div>
    `,
            img: LineChartIntroImg,
            imgClass: 'h-64 h-auto',
        },

        // --- Slide 1 (New): K 線基礎與單根型態 ---
        {
            title: '🕯️ K 線圖基礎與單根型態',
            content: `
              <p class="mb-5 text-gray-700 leading-relaxed">K 線（Candlestick）由特定週期內的「開、高、低、收」四個價位構成，是技術分析中最直接展現多空力量對比的工具</p>
              
              <div class="overflow-x-auto border rounded-lg mb-6">
                  <table class="min-w-full text-sm text-gray-700">
                      <thead class="bg-blue-800 text-white">
                          <tr>
                              <th class="p-3 w-1/4">組成要素</th>
                              <th class="p-3">定義</th>
                              <th class="p-3 w-1/4">意涵</th>
                          </tr>
                      </thead>
                      <tbody class="divide-y divide-gray-200">
                          <tr class="hover:bg-blue-50">
                              <td class="p-3 font-semibold text-green-700 whitespace-nowrap">紅 K（陽線）</td>
                              <td class="p-3">收盤價 > 開盤價</td>
                              <td class="p-3">多方優勢，買盤強勁</td>
                          </tr>
                          <tr class="hover:bg-blue-50">
                              <td class="p-3 font-semibold text-red-700 whitespace-nowrap">黑 K（陰線）</td>
                              <td class="p-3">收盤價 < 開盤價</td>
                              <td class="p-3">空方優勢，賣壓沉重</td>
                          </tr>
                          <tr class="hover:bg-blue-50">
                              <td class="p-3 font-semibold whitespace-nowrap">影線 (Shadow)</td>
                              <td class="p-3">實體以外的線（最高/最低價）</td>
                              <td class="p-3">長上影線代表 壓力；長下影線代表 支撐</td>
                          </tr>
                      </tbody>
                  </table>
              </div>

              <h4 class="mb-3 font-extrabold text-xl text-gray-800">單根 K 線型態判斷：</h4>
              <ul class="list-disc pl-5 space-y-2 text-gray-700 leading-relaxed text-base">
                  <li><strong class="text-green-700">長實體 K：</strong> 力量強勢，長紅代表多方全勝，長黑代表空方全勝</li>
                  <li><strong class="text-blue-700">十字線：</strong> 開收盤價接近，多空勢均力敵，常出現在行情轉折點</li>
                  <li><strong class="text-fuchsia-700">錘子/倒錘線：</strong> 影線長度遠大於實體，表示價格雖然曾被拉往某一側，但被強勢推回，常作為趨勢反轉的訊號</li>
              </ul>
              <div class="mt-6 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-md text-gray-700 text-base">
                  <strong class="text-yellow-700">🎯 閱讀重點：</strong>
                  關注實體大小與影線長度，實體越大趨勢越強，影線越長代表該方向的阻力或支撐越強
              </div>
            `,
            img: [{ src: K }, { src: K1 }, { src: K2 }],
            imgClass: '',
        },

        // --- Slide 2 (New): K 線組合型態 (趨勢延續/反轉) ---
        {
            title: '🔄 K 線組合型態解析',
            content: `
              <p class="mb-5 text-gray-700 leading-relaxed">單根 K 線可視為一天的戰況，而多根 K 線組合則反映了連續數日的多空趨勢，常能預示趨勢的延續或反轉</p>
              
              <h4 class="mb-3 font-extrabold text-xl text-gray-800">趨勢延續型態：</h4>
              <ul class="list-disc pl-5 space-y-2 text-gray-700 leading-relaxed text-base">
                  <li><strong class="text-green-700">紅三兵 (Three White Soldiers)：</strong> 連續三根陽線，收盤價逐步走高，強烈的 **多方反攻** 或趨勢 **延續** 訊號</li>
                  <li><strong class="text-red-700">黑三兵 (Three Black Crows)：</strong> 連續三根陰線，收盤價逐步走低，強烈的 **空方趨勢延續** 訊號</li>
              </ul>
            `,
            img: [{ src: RedThreeSoldiers }, { src: BlackThreeSoldiers }],
            imgClass: '',
        },

        // --- Slide 3 (New): K 線轉折型態 (二星看多/看空) ---
        {
            title: '⭐ K 線轉折型態：吞噬線/孕線',
            content: `
              <p class="mb-5 text-gray-700 leading-relaxed">這些轉折型態的特徵是，第二根 K 線與第一根 K 線的對比，顯示市場力量發生了急劇的逆轉或平衡</p>
              
              <h4 class="mb-3 font-extrabold text-xl text-gray-800 mt-6">轉折訊號型態：</h4>
              <ul class="list-disc pl-5 space-y-2 text-gray-700 leading-relaxed text-base">
                  <li><strong class="text-yellow-700">吞噬線 (Engulfing)：</strong> 後一根 K 線的實體完全包覆前一根 K 線，顯示市場力量突然逆轉，是強烈的 <strong>反轉訊號</strong></li>
                  <li><strong class="text-fuchsia-700">孕線 (Harami)：</strong> 後一根 K 線的實體被前一根 K 線的實體包覆，常預示市場力量均衡，趨勢可能 <strong>暫停或轉折</strong></li>
              </ul>
              
              <div class="mt-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-md text-gray-700 text-base">
                  <strong class="text-blue-700">💡 應用：</strong>
                   這些組合型態只有出現在相對高點或低點時，反轉意義才顯著
              </div>
            `,
            img: [{ src: TwoStarLookMore }, { src: TwoStarLookLess }],
            imgClass: '',
        },

        // --- Slide 4 (原 Slide 2): MA（Moving Average，移動平均線） ---
        {
            title: '📊 MA（Moving Average，移動平均線）',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">移動平均線（MA）是將特定期間的收盤價進行平均後連成的線，能有效過濾股價波動雜訊，判斷趨勢方向</p>
      
      <div class="overflow-x-auto border rounded-lg mb-4">
          <table class="min-w-full text-sm text-gray-700">
              <thead class="bg-blue-800 text-white">
                  <tr>
                      <th class="p-3">MA 種類</th>
                      <th class="p-3">期間（日）</th>
                      <th class="p-3">用途</th>
                  </tr>
              </thead>
              <tbody class="divide-y divide-gray-200">
                  <tr class="hover:bg-blue-50">
                      <td class="p-3 font-semibold whitespace-nowrap">MA5</td>
                      <td class="p-3">5 日</td>
                      <td class="p-3">反映短線趨勢</td>
                  </tr>
                  <tr class="hover:bg-blue-50">
                      <td class="p-3 font-semibold whitespace-nowrap">MA20 (月線)</td>
                      <td class="p-3">20 日</td>
                      <td class="p-3">反映中期趨勢</td>
                  </tr>
                  <tr class="hover:bg-blue-50">
                      <td class="p-3 font-semibold whitespace-nowrap">MA60 (季線)</td>
                      <td class="p-3">60 日</td>
                      <td class="p-3">反映長期趨勢</td>
                  </tr>
              </tbody>
          </table>
      </div>

      <p class="mb-3 font-semibold text-gray-800">MA 判讀重點：</p>
      <ul class="list-disc pl-5 space-y-3 text-gray-700 leading-relaxed text-base">
          <li><strong class="text-green-700">黃金交叉：</strong> 短期線向上突破長期線，視為 轉強買進 訊號</li>
          <li><strong class="text-red-700">死亡交叉：</strong> 短期線向下跌破長期線，視為 轉弱賣出 訊號</li>
          <li>線向上（多頭）或線向下（空頭）是判斷趨勢方向的最直接依據</li>
      </ul>

      <div class="mt-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-md text-gray-700 text-base">
          <strong class="text-blue-700">🎯 趨勢輔助：</strong> 當股價位於 MA 線之上，代表短期上漲力道強勁；跌破 MA 線則可能轉弱
      </div>
    `,
            img: null,
            imgClass: '',
        },

        // --- Slide 5 (原 Slide 3): 技術指標：MACD / KD / RSI ---
        {
            title: '📈 技術指標：MACD / KD / RSI',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">技術指標是根據股價與成交量計算出的輔助工具，幫助投資人判斷市場趨勢強弱、超買超賣，以及可能的反轉點</p>

      <ul class="space-y-6 text-gray-800 leading-relaxed">
          <li>
              <h4 class="text-xl font-bold text-red-600">📉 MACD（指數平滑異同移動平均線）</h4>
              <p class="mt-1 text-base">定義：以兩條不同期數的 EMA 計算快線（DIF）與慢線（MACD），觀察趨勢強弱適合辨識中期趨勢</p>
              <ul class="list-disc pl-6 mt-1 text-base">
                  <li><strong class="text-green-700">多頭訊號：</strong> 快線（DIF）向上突破慢線（MACD）</li>
                  <li><strong>柱狀體（OSC）：</strong> 由負轉正代表趨勢轉強；由正轉負代表趨勢轉弱</li>
              </ul>
          </li>

          <li>
              <h4 class="text-xl font-bold text-yellow-600">⚙️ KD 指標（隨機指標）</h4>
              <p class="mt-1 text-base">定義：衡量股價在特定期間內相對高低價的位置適合觀察短線超買／超賣現象</p>
              <ul class="list-disc pl-6 mt-1 text-base">
                  <li><strong class="text-red-700">超買區：</strong> K 值 > 80，股價可能回檔</li>
                  <li><strong class="text-green-700">超賣區：</strong> K 值 < 20，股價可能反彈</li>
                  <li><strong>轉折訊號：</strong> K 線上穿 D 線視為短線轉強</li>
              </ul>
          </li>
          
          <li>
              <h4 class="text-xl font-bold text-blue-600">💪 RSI（相對強弱指標）</h4>
              <p class="mt-1 text-base">定義：計算一定期間內股價漲跌的比率，判斷買盤或賣壓是否過熱，預測短期反轉</p>
              <ul class="list-disc pl-6 mt-1 text-base">
                  <li><strong class="text-red-700">超買：</strong> RSI > 70，短線可能過熱</li>
                  <li><strong class="text-green-700">超賣：</strong> RSI < 30，短線可能反彈</li>
                  <li><strong class="text-fuchsia-700">背離訊號：</strong> 股價創新高但 RSI 未創新高，暗示上漲力道減弱</li>
              </ul>
          </li>
      </ul>
    `,
            img: null,
            imgClass: '',
        },

        // --- Slide 6 (原 Slide 4): 多頭與空頭市場 ---
        {
            title: '🐂🐻 多頭與空頭市場',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">股市可依投資人預期與市場走勢分為「多頭（牛市）」與「空頭（熊市）」：</p>

      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
              <thead class="bg-blue-800 text-white">
                  <tr>
                      <th class="p-3 w-1/4 whitespace-nowrap">類別</th>
                      <th class="p-3">定義</th>
                      <th class="p-3">市場特性</th>
                  </tr>
              </thead>
              <tbody class="divide-y divide-gray-200">
                  <tr class="hover:bg-blue-50">
                      <td class="p-3 font-semibold text-green-700 whitespace-nowrap">多頭市場（Bull Market）</td>
                      <td class="p-3">預期股市上漲，投資人普遍樂觀</td>
                      <td class="p-3">成交量活絡、指數持續上揚、投資氣氛高漲</td>
                  </tr>
                  <tr class="hover:bg-blue-50">
                      <td class="p-3 font-semibold text-red-700 whitespace-nowrap">空頭市場（Bear Market）</td>
                      <td class="p-3">預期股市下跌，投資人普遍悲觀</td>
                      <td class="p-3">成交量萎縮、指數持續下跌、資金退場觀望</td>
                  </tr>
              </tbody>
          </table>
      </div>

      <div class="mt-6 bg-green-50 border-l-4 border-green-600 p-4 rounded-md text-gray-700 text-base">
          <strong class="text-green-700">📘 判斷關鍵：</strong>
          多空市場的轉換常與經濟景氣、政策變化及市場信心有關<br>
          技術分析可輔助判斷轉折點，但仍需搭配基本面與風險控管
      </div>
    `,
            img: null,
            imgClass: '',
        },
    ]

    const isLastSlide = computed(() => currentSlide.value === slides.length - 1)

    function nextSlide() {
        if (currentSlide.value < slides.length - 1) currentSlide.value++
    }
    function prevSlide() {
        if (currentSlide.value > 0) currentSlide.value--
    }
    function goHome() {
        router.push('/learning')
        setTimeout(() => {
            toast.add({
                severity: 'success',
                summary: '🎉 恭喜你完成本單元！',
                life: 2500,
            })
        }, 300)
    }
</script>

<style scoped>
    /* 確保表格邊框美觀 */
    table {
        border-collapse: collapse;
    }
    /* 新增 Modal 專屬動畫 */
    .modal-fade-enter-active,
    .modal-fade-leave-active {
        transition: opacity 0.3s ease;
    }
    .modal-fade-enter-from,
    .modal-fade-leave-to {
        opacity: 0;
    }
</style>
