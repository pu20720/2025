```bash
# 安裝 pipx
pip install pipx

# 安裝 poetry (安裝套件時為每個套件建出一個分離的環境，並可以在不啟動虛擬環境的情況下直接使用)
pipx install poetry
----
# 安裝 poetry (將套件安裝至全域且用自身環境)
pip install poetry
```

```bash
# 啟用虛擬環境
poetry env activate

# 初始化環境
poetry init
```
```bash
# 設定環境
poetry install

# 啟動環境
poetry run python manage.py runserver
```
```bash
# 產生金鑰 DJANGO_SECRET_KEY
poetry run python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```


```bash
# 新增 APP
poetry run python manage.py startapp users

# 新增 Model -> 資料庫
poetry run python manage.py makemigrations
poetry run python manage.py migrate
```


```bash
# Linux
## 開啟mariadb
sudo systemctl start mariadb
```

```bash
# ruff 程式碼工具

## 程式碼格式化
poetry run ruff format .

## 程式碼檢查並修改
poetry run ruff check --fix .
```
