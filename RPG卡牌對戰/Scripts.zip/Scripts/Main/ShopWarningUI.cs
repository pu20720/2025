using UnityEngine;
using UnityEngine.UI; // 必須引用，因為我們要用 Button
using TMPro;          // 引用 TextMeshPro
using System.Collections;

public class SimpleWarningUI : MonoBehaviour
{
    [Header("UI References")]
    [Tooltip("用來顯示警告訊息的文字物件")]
    [SerializeField] private TextMeshProUGUI warningText;

    [Header("Click Target")]
    [Tooltip("請拖曳您想按下的按鈕 (Button)")]
    // ▼▼▼ 【修正】直接指定為 Button 型別，確保能觸發 ▼▼▼
    [SerializeField] private Button targetButton;
    // ▲▲▲ 修正結束 ▲▲▲

    [Header("Settings")]
    [Tooltip("訊息顯示的持續時間 (秒)")]
    [SerializeField] private float displayDuration = 2.0f;
    [Tooltip("要顯示的警告訊息")]
    [SerializeField] private string message = "You don't have the money to buy this!";

    private Coroutine hideCoroutine;

    private void Start()
    {
        // 1. 確保文字一開始是隱藏的
        if (warningText != null)
        {
            warningText.gameObject.SetActive(false);
        }

        // 2. 綁定按鈕點擊事件
        if (targetButton != null)
        {
            // 清除舊的事件 (避免重複綁定)
            targetButton.onClick.RemoveListener(ShowWarning);
            // 加入新的事件
            targetButton.onClick.AddListener(ShowWarning);
        }
        else
        {
            Debug.LogError("[SimpleWarningUI] 請在 Inspector 中拖曳 Target Button！");
        }
    }

    // 這是點擊後觸發的方法
    public void ShowWarning()
    {
        if (warningText != null)
        {
            warningText.text = message;
            warningText.gameObject.SetActive(true);

            // 重置倒數計時
            if (hideCoroutine != null) StopCoroutine(hideCoroutine);
            hideCoroutine = StartCoroutine(HideAfterDelay());
        }
    }

    private IEnumerator HideAfterDelay()
    {
        yield return new WaitForSeconds(displayDuration);

        if (warningText != null)
        {
            warningText.gameObject.SetActive(false);
        }
    }
}