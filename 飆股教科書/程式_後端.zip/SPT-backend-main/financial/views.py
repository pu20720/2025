import logging
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from .services.get_financial import get_financial

logger = logging.getLogger(__name__)


class FinancialImportDB(APIView):
    def get(self, request):
        try:
            symbol = request.query_params.get('symbol')

            if not symbol:
                return Response(
                    {'error': '缺少必要的參數：symbol'},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            result = get_financial(symbol)
            return Response(result, status=status.HTTP_200_OK)
        except RuntimeError as e:
            logger.error(f'[查詢失敗] {e}')
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
