# video_infer_tcn_overlay.py
# -*- coding: utf-8 -*-
"""
影片動作判斷：輸入影片 + 模型（best_model_fold1.pt）
輸出新影片，畫面左上角顯示「正確 / 錯誤」
"""

import os, time, argparse
import numpy as np
import cv2
import torch
import torch.nn as nn

# ===== MediaPipe =====
import mediapipe as mp
mp_pose = mp.solutions.pose
POSE = mp_pose.Pose(static_image_mode=False, model_complexity=1,
                    enable_segmentation=False, min_detection_confidence=0.5,
                    min_tracking_confidence=0.5)

# ===== 模型結構（與 evaluate_pose.py 相同） =====
class TCNBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, d=1, p=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_ch, out_ch, kernel_size=k, padding=d*(k-1)//2, dilation=d),
            nn.ReLU(),
            nn.Dropout(p),
            nn.Conv1d(out_ch, out_ch, kernel_size=k, padding=d*(k-1)//2, dilation=d),
        )
        self.res = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(self.net(x) + self.res(x))

class TCNClassifier(nn.Module):
    def __init__(self, in_feats=132, num_classes=2):
        super().__init__()
        chs = [in_feats, 256, 256]
        dilations = [1, 2]
        blocks = []
        for i in range(len(chs)-1):
            blocks.append(TCNBlock(chs[i], chs[i+1], k=3, d=dilations[i], p=0.3))
        self.backbone = nn.Sequential(*blocks)
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(chs[-1], num_classes)
        )

    def forward(self, x):  # x: (B, F, T)
        h = self.backbone(x)
        return self.head(h)

# ===== 函式 =====
def extract_pose_33(frame_bgr):
    img_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    res = POSE.process(img_rgb)
    if not res.pose_landmarks:
        return None
    lm = res.pose_landmarks.landmark
    return np.array([[p.x, p.y, p.z, p.visibility] for p in lm], dtype=np.float32)

def normalize_window(feat):
    mu = feat.mean(axis=0, keepdims=True)
    std = feat.std(axis=0, keepdims=True) + 1e-6
    return (feat - mu) / std

def softmax_np(x):
    x = x - np.max(x)
    e = np.exp(x)
    return e / (np.sum(e) + 1e-9)

# ===== 主程式 =====
def run(video_path, model_path, out_path=None, seq_len=30, device="cpu"):
    if not os.path.exists(video_path):
        raise FileNotFoundError(video_path)
    if out_path is None:
        base, ext = os.path.splitext(video_path)
        out_path = base + "_pred" + ext

    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    writer = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))

    # 載入模型
    model = TCNClassifier(in_feats=132, num_classes=2).to(device)
    state = torch.load(model_path, map_location=device)
    if "state_dict" in state:
        state = state["state_dict"]
    model.load_state_dict(state, strict=False)
    model.eval()

    seq, history = [], []
    frame_idx = 0
    t0 = time.time()

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame_idx += 1
        pose = extract_pose_33(frame)
        if pose is None:
            cv2.putText(frame, "未偵測到人", (40, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.4, (0,0,255), 3)
            writer.write(frame)
            continue

        seq.append(pose)
        if len(seq) > seq_len:
            seq.pop(0)
        if len(seq) < seq_len:
            writer.write(frame)
            continue

        feat = np.stack(seq).reshape(seq_len, -1)  # (T,132)
        feat = normalize_window(feat)
        x = torch.from_numpy(feat.T[None,...]).float().to(device)  # (1,132,T)
        with torch.no_grad():
            logits = model(x).cpu().numpy()[0]
            probs = softmax_np(logits)
            pred = int(np.argmax(probs))

        label = "正確" if pred == 1 else "錯誤"
        color = (0,255,0) if label=="正確" else (0,0,255)
        cv2.putText(frame, f"{label} ({probs[pred]*100:.1f}%)", (40,80),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.6, color, 4)
        writer.write(frame)

    cap.release()
    writer.release()
    print(f"✅ 完成！輸出檔案：{out_path}")

# ===== 執行區 =====
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True, help=r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\underhand_pass\underhandpass_90_correct_(57）.MOV")
    parser.add_argument("--model", required=True, help=r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\best_model_fold1.pt")
    parser.add_argument("--out", default=None, help="輸出影片檔案（預設為 _pred.mp4）")
    parser.add_argument("--seq_len", type=int, default=30, help="視窗長度（預設30）")
    parser.add_argument("--cuda", action="store_true", help="若支援則使用GPU")
    args = parser.parse_args()

    device = "cuda" if (args.cuda and torch.cuda.is_available()) else "cpu"
    run(args.video, args.model, args.out, args.seq_len, device)
