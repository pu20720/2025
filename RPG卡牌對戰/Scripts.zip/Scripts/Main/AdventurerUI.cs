using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AdventurerUI : MonoBehaviour
{
    [Header("References")]
    public Transform gridContent; // 綁定那個有 Grid Layout Group 的 Panel
    public GameObject questSlotPrefab;
    public Button acceptButton;

    private QuestSlotUI currentSelectedSlot;
    private QuestData currentSelectedData;

    private void Start()
    {
        if (acceptButton != null)
        {
            acceptButton.onClick.AddListener(OnAcceptClicked);
            acceptButton.gameObject.SetActive(false); // 一開始隱藏，選中才顯示
        }
    }

    // 由 Manager 呼叫，生成 6 個格子
    public void GenerateGrid(List<QuestData> quests)
    {
        // 清空舊的
        foreach (Transform child in gridContent) Destroy(child.gameObject);

        // 生成新的 (照順序，因為 Manager 已經排好順序了)
        foreach (var quest in quests)
        {
            GameObject slotObj = Instantiate(questSlotPrefab, gridContent);
            QuestSlotUI ui = slotObj.GetComponent<QuestSlotUI>();
            if (ui != null)
            {
                ui.Setup(quest, this);
            }
        }
    }

    public void OnQuestSelected(QuestSlotUI slotUI, QuestData data)
    {
        // 取消上一個選中
        if (currentSelectedSlot != null) currentSelectedSlot.SetSelected(false);

        // 選中新的
        currentSelectedSlot = slotUI;
        currentSelectedData = data;
        currentSelectedSlot.SetSelected(true);

        // 顯示接受按鈕
        if (acceptButton != null) acceptButton.gameObject.SetActive(true);
    }

    private void OnAcceptClicked()
    {
        if (currentSelectedData != null)
        {
            // 通知 Manager 處理轉場
            AdventurerManager.Instance.AcceptAndTransition(currentSelectedData);
        }
    }
}