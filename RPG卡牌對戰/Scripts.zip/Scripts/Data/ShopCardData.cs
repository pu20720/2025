using UnityEngine;

[System.Serializable]
public class ShopCardData
{
    public string id;
    public int price;
    public CardRarity rarity;
    public Color cardColor;

    // ▼▼▼ 【新增】這裡用來存放真實的物品資料 ▼▼▼
    public ItemData itemRef;

    public ShopCardData(int price, CardRarity rarity, ItemData item)
    {
        this.price = price;
        this.rarity = rarity;
        this.itemRef = item; // 記住這個物品
        this.id = System.Guid.NewGuid().ToString();

        switch (rarity)
        {
            case CardRarity.White: cardColor = Color.white; break;
            case CardRarity.Green: cardColor = Color.green; break;
            case CardRarity.Blue: cardColor = Color.cyan; break;
            case CardRarity.Gold: cardColor = Color.yellow; break;
        }
    }
}