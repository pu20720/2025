using UnityEngine;

// 注意：ItemType 和 EquipmentSlot 已經在 RPEnums.cs 定義過了，這裡不要重複定義

[CreateAssetMenu(fileName = "NewItem", menuName = "RPG/Item Data")]
public class ItemData : ScriptableObject
{
    [Header("Basic Info")]
    // ▼▼▼ 【關鍵修正】這裡必須有 itemID (int)，才能跟 Inventory.cs 對接 ▼▼▼
    public int itemID;
    // ▲▲▲

    public string itemName;
    public Sprite icon;
    public ItemType itemType;

    // ▼▼▼ 【關鍵新增】讓物品自己記住顏色 ▼▼▼
    public Color displayColor = Color.white;

    [TextArea] public string description;

    [Header("Equipment Specific")]
    public EquipmentSlot equipSlot;
    public int defense;
    public string setBonusId;

    [Header("Card Specific")]
    public int cardCost;

    [Header("Consumable Specific")]
    public int healAmount;
    // ▼▼▼ 【新增】用於 Mana Potion ▼▼▼
    public int manaRestoreAmount;
}