using UnityEngine;

[CreateAssetMenu(fileName = "NewQuest", menuName = "RPG/Quest Data")]
public class QuestData : ScriptableObject
{
    public string questID;       // 唯一 ID (用於判斷是否做過)
    public string title;         // 標題
    public QuestRank rank;       // 等級 (S, A, B, C, D)
    public Sprite enemyImage;    // 敵人圖像
    [TextArea] public string description; // 簡介

    // 這裡可以擴充：例如這個委託對應哪個敵人 prefab 名稱，或戰鬥場景設定
    public string targetEnemyName;
}