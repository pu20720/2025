from .models import User
from rest_framework import status
from django.db import IntegrityError
from rest_framework import permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import update_last_login


class UsersView(APIView):
    permission_classes = [permissions.IsAuthenticated]  # 需要登入才能存取

    def get(self, request):
        user = request.user  # JWT 驗證後的使用者
        return Response(
            {
                'id': user.id,
                'username': user.username,
                'email': user.email,
            },
            status=status.HTTP_200_OK,
        )

    def patch(self, request):
        data = request.data
        user = request.user
        # 預設改自己；管理員可用 ?id=xxx 指定別人
        target_id = request.query_params.get('id')
        if target_id and request.user.is_staff:
            user = get_object_or_404(User, id=target_id)
        user.username = data.get('username', user.username)
        user.email = data.get('email', user.email)

        new_pwd = data.get('password')
        if new_pwd:  # 只有提供新密碼才雜湊
            user.set_password(new_pwd)

        try:
            user.save()
        except IntegrityError as e:
            # 根據例外訊息判斷是哪個欄位違反唯一性
            if 'username' in str(e):
                message = '該使用者名稱已被使用'
            elif 'email' in str(e):
                message = '該電子郵件已被註冊'
            else:
                message = '資料重複，無法儲存'

            return Response({'error': message}, status=status.HTTP_400_BAD_REQUEST)

        return Response({'message': '已成功更新使用者資料'}, status=status.HTTP_200_OK)

    def delete(self, request):
        user = request.user

        # 預設改自己；管理員可用 ?id=xxx 指定別人
        target_id = request.query_params.get('id')
        if target_id and request.user.is_staff:
            user = get_object_or_404(User, id=target_id)

        user.delete()
        return Response({'message': '已成功刪除使用者'}, status=status.HTTP_200_OK)


class RegisterView(APIView):
    permission_classes = []  # 註冊通常開放
    authentication_classes = []

    def post(self, request):
        data = request.data
        try:
            if User.objects.filter(username=data.get('username')).exists():
                return Response(
                    {'error': 'Username 已被使用'}, status=status.HTTP_400_BAD_REQUEST
                )
            if User.objects.filter(email=data.get('email')).exists():
                return Response(
                    {'error': 'Email 已被使用'}, status=status.HTTP_400_BAD_REQUEST
                )
            User.objects.create_user(
                username=data.get('username'),
                email=data.get('email'),
                password=data.get('password'),
            )
            return Response(
                {'message': '使用者創建成功'}, status=status.HTTP_201_CREATED
            )
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    authentication_classes = []  # 登入本身不驗證
    permission_classes = []  # 開放存取

    def post(self, request):
        data = request.data
        email = data.get('email')
        password = data.get('password')

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            # 不洩漏是哪個錯
            return Response(
                {'error': '帳號或密碼有誤'}, status=status.HTTP_401_UNAUTHORIZED
            )

        if not user.check_password(password):
            return Response(
                {'error': '帳號或密碼有誤'}, status=status.HTTP_401_UNAUTHORIZED
            )

        update_last_login(None, user)

        # 發 JWT
        refresh = RefreshToken.for_user(user)
        return Response(
            {
                'access': str(refresh.access_token),
                'refresh': str(refresh),
                'user': {'id': user.id, 'username': user.username, 'email': user.email},
            },
            status=status.HTTP_200_OK,
        )


class LogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]  # 需要登入才能登出

    def post(self, request):
        try:
            # 將 refresh token 加入黑名單
            refresh_token = request.data.get('refresh')
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({'message': '已成功登出'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class UserInvestmentView(APIView):
    permission_classes = [permissions.IsAuthenticated]  # 需要登入才能存取

    def get(self, request):
        user = request.user  # JWT 驗證後的使用者
        return Response(
            {
                'id': user.id,
                'username': user.username,
                'available_funds': user.available_funds,
                'portfolio_value': user.portfolio_value,
                'total_return_rate': user.total_return_rate,
            },
            status=status.HTTP_200_OK,
        )
