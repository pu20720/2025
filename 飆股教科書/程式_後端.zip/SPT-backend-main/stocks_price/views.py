import logging
from stocks.models import Stock
from rest_framework import status
from datetime import datetime, timedelta
from rest_framework.views import APIView
from rest_framework.response import Response
from stocks_price.services.get_stocks_price import get_stocks_prices
from stocks_price.services.import_yesterday_price import import_yesterday_price
from stocks_price.services.import_all_history_prices import import_all_history_prices

logger = logging.getLogger(__name__)


class ImportAllStocksHistoryView(APIView):
    def post(self, request):
        all_stocks = Stock.objects.all()
        results = []

        for stock in all_stocks:
            symbol = stock.symbol
            try:
                result = import_all_history_prices(symbol)
                results.append(result)
            except Exception as e:
                logger.error(f'[StockPrice] {symbol} 匯入失敗: {e}')
                results.append({'symbol': symbol, 'status': 'error', 'message': str(e)})

        return Response(results, status=status.HTTP_200_OK)

    def get(self, request):
        keyword = request.query_params.get('keyword', None)
        date = request.query_params.get('date', None)

        try:
            result = get_stocks_prices(keyword=keyword, date=date)
            return Response(result, status=status.HTTP_200_OK)

        except Exception as e:
            logger.error(f'[StockPrice]  查詢失敗{e}')
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class PriceView(APIView):
    def post(self, request):
        all_stocks = Stock.objects.all()
        date = request.data.get('date', None)
        results = []
        if date:
            try:
                start_from = datetime.strptime(date, '%Y-%m-%d').date()
            except ValueError:
                return Response(
                    {'error': '日期格式錯誤，請使用 YYYY-MM-DD'},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            start_from = datetime.today().date() - timedelta(days=1)

        for stock in all_stocks:
            symbol = stock.symbol
            try:
                result = import_yesterday_price(symbol, start_from)
                results.append(result)
            except Exception as e:
                logger.error(f'[StockPrice] {symbol} 匯入失敗: {e}')
                results.append({'symbol': symbol, 'status': 'error', 'message': str(e)})

        return Response(results, status=status.HTTP_200_OK)
