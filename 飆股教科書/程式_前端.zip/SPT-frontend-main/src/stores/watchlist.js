import { useToast } from 'primevue/usetoast'
import api from '@/api/axios'

export function useWatchlist() {
    const toast = useToast()
    const API_URL = 'watchlist/'

    const getUserWatchlist = async () => {
        try {
            const response = await api.get(API_URL)
            if (!response.data || response.data.length === 0) {
                toast.add({
                    severity: 'info',
                    summary: '提示',
                    detail: '您的自選股清單目前是空的',
                    life: 3000,
                })
                return []
            }
            return response.data
        } catch (e) {
            toast.add({
                severity: 'error',
                summary: '讀取自選股失敗',
                detail: e.message || '發生未知錯誤',
                life: 3000,
            })
            return []
        }
    }

    const addStockToWatchlist = async (symbol) => {
        try {
            await api.post(API_URL, { symbol: symbol })
            return true
        } catch (e) {
            const errorMessage =
                e.response?.data?.detail || e.response?.data?.error || '找不到該股票代碼或已存在'
            toast.add({
                severity: 'error',
                summary: `新增 ${symbol} 失敗`,
                detail: errorMessage,
                life: 3000,
            })
            return false
        }
    }

    const deleteStockFromWatchlist = async (symbol) => {
        try {
            await api.delete(API_URL, {
                data: {
                    symbol: symbol,
                },
            })
            return true
        } catch (e) {
            const errorMessage = e.response?.data?.detail || e.response?.data?.error || '刪除失敗'
            toast.add({
                severity: 'error',
                summary: `刪除 ${symbol} 失敗`,
                detail: errorMessage,
                life: 3000,
            })
            return false
        }
    }

    const updateStockOrder = async (stockIds) => {
        try {
            await api.patch(API_URL, { ids: stockIds })
            toast.add({ severity: 'success', summary: '成功', detail: '順序已更新', life: 2000 })
            return true
        } catch (e) {
            console.log(stockIds)

            toast.add({
                severity: 'error',
                summary: '順序更新失敗',
                detail: e.response?.data?.detail || '發生未知錯誤',
                life: 3000,
            })
            return false
        }
    }

    return {
        getUserWatchlist,
        addStockToWatchlist,
        deleteStockFromWatchlist,
        updateStockOrder,
    }
}
