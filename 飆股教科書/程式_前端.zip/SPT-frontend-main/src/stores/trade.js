import { ref } from 'vue'
import api from '@/api/axios'
import { useToast } from 'primevue/usetoast'
import { useRouter } from 'vue-router'

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export function useTrade() {
    const portfolio = ref([])
    const tradeHistory = ref([])
    const loading = ref(false)
    const toast = useToast()
    const router = useRouter()

    const ENDPOINTS = {
        transaction: 'transaction/',
        history: 'transaction/history/',
        trade: 'transaction/trade/',
    }

    // 取得投資組合
    const fetchPortfolio = async () => {
        const maxRetries = 3
        const retryDelay = 2000
        loading.value = true

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const res = await api.get(ENDPOINTS.transaction)
                portfolio.value = res.data
                loading.value = false
                return res.data
            } catch (err) {
                if (attempt === maxRetries) {
                    toast.add({
                        severity: 'error',
                        summary: '取得投資組合失敗',
                        detail: err.message,
                        life: 2500,
                    })
                    loading.value = false
                    return []
                }
                await sleep(retryDelay)
            }
        }
    }

    // 取得交易紀錄
    const fetchHistory = async (options = {}) => {
        const { transactionType } = options
        const params = {}
        if (transactionType) params.type = transactionType

        const maxRetries = 3
        const retryDelay = 2000
        loading.value = true

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const res = await api.get(ENDPOINTS.history, { params })
                tradeHistory.value = res.data
                loading.value = false
                return res.data
            } catch (err) {
                if (attempt === maxRetries) {
                    toast.add({
                        severity: 'error',
                        summary: '無法載入交易歷史',
                        detail: err.message,
                        life: 2500,
                    })
                    loading.value = false
                    return []
                }
                await sleep(retryDelay)
            }
        }
    }

    // 提交交易
    const postTrade = async (tradeData) => {
        try {
            const res = await api.post(ENDPOINTS.trade, tradeData)

            router.push({ name: 'TradingTrade' })
            return { success: true, data: res.data }
        } catch (err) {
            toast.add({
                severity: 'error',
                summary: '交易失敗',
                detail: err.message,
                life: 2500,
            })
            return { success: false, error: err.response?.data?.error || err.message }
        }
    }

    const loadTradeData = async () => {
        loading.value = true
        await fetchPortfolio()
        await fetchHistory()
        loading.value = false
    }

    return {
        portfolio,
        tradeHistory,
        loading,
        fetchPortfolio,
        fetchHistory,
        postTrade,
        loadTradeData,
    }
}
