// 檔案路徑: Assets/Scripts/MainMenu.cs
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
// using TMPro; // (此檔案目前不需要 TMPro)

public class MainMenu : MonoBehaviour
{
    public Button startButton;
    public Button loadButton;
    public Button quitButton;

    void Start()
    {
        if (startButton == null || loadButton == null || quitButton == null)
        {
            Debug.LogError("[MainMenu.Start] FAILED: Start, Load, 或 Quit 按鈕未在 Inspector 中綁定！");
            return;
        }

        startButton.onClick.AddListener(StartGame);
        loadButton.onClick.AddListener(LoadGame);
        quitButton.onClick.AddListener(QuitGame);
        Debug.Log("[MainMenu.Start] 成功綁定 Start, Load, 和 Quit 按鈕的 OnClick 事件。");

        // 檢查 SaveManager 是否存在以及是否有存檔
        var data = SaveManager.Instance.Load();
        if (data == null || string.IsNullOrEmpty(data.SaveTime))
        {
            loadButton.interactable = false;
        }
        else
        {
            loadButton.interactable = true;
        }
    }

    void StartGame()
    {
        Debug.Log("[MainMenu.StartGame] 'Start' 按鈕已按下。");

        // 清除可能殘留的讀取資料
        if (TempLoadData.Instance != null)
            TempLoadData.Instance.GetData();

        SceneManager.LoadScene("OpeningDialogue");
    }

    void LoadGame()
    {
        Debug.Log("[MainMenu.LoadGame] 'Load' 按鈕已按下。");

        // 清除舊資料
        if (TempLoadData.Instance == null)
        {
            Debug.LogError("TempLoadData.Instance is null!");
            return;
        }
        TempLoadData.Instance.GetData();

        var data = SaveManager.Instance.Load();

        if (data == null)
        {
            Debug.LogWarning("[MainMenu.LoadGame] 檢查失敗：SaveManager.Instance.Load() 返回 'null'。");
            return;
        }

        // 設置靜態玩家名稱 (OpenSceneManager 會用到)
        ConversationManager.playerName = data.PlayerName;

        // 將讀取到的資料存入 TempLoadData
        TempLoadData.Instance.SetData(data);

        string sceneToLoad = data.savedSceneName;
        Debug.Log($"[MainMenu.LoadGame] 檢查存檔中的場景：data.savedSceneName = '{sceneToLoad}'");

        if (string.IsNullOrEmpty(sceneToLoad))
        {
            Debug.LogWarning($"[MainMenu.LoadGame] 準備轉移... 但場景名稱為空。將載入預設場景 'OpeningDialogue'。");
            SceneManager.LoadScene("OpeningDialogue");
        }
        else
        {
            Debug.Log($"[MainMenu.LoadGame] 準備轉移... 正在呼叫 SceneManager.LoadScene('{sceneToLoad}')。");
            SceneManager.LoadScene(sceneToLoad);
        }
    }

    void QuitGame()
    {
        Debug.Log("[MainMenu.QuitGame] 'Quit' 按鈕已按下。");
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
    }
}