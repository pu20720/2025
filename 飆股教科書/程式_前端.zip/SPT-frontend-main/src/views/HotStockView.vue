<template>
    <div class="w-full p-6 bg-gray-100 text-gray-800">
        <div class="max-w-6xl mx-auto mb-6">
            <h1 class="text-4xl font-bold text-center text-red-600 tracking-wider mb-2">
                🔥熱門股
            </h1>

            <div v-if="topStocks.length" class="flex justify-end">
                <div class="text-gray-700 text-lg font-semibold">
                    更新日期：{{ topStocks[0].date }}
                </div>
            </div>
        </div>
        <div class="max-w-6xl mx-auto p-6 text-gray-800 hide-scrollbar">
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-xl shadow">
                    <thead>
                        <tr class="text-2xl text-white bg-custom-purple font-semibold">
                            <th class="px-5 py-5 text-center rounded-tl-xl">名次</th>
                            <th class="px-5 py-5 text-center">股票代碼</th>
                            <th class="px-5 py-5 text-center">股票名稱</th>
                            <th class="px-5 py-5 text-center">最新價</th>
                            <th class="px-5 py-5 text-center">漲跌</th>
                            <th class="px-5 py-5 text-center">漲跌%</th>
                            <th class="px-5 py-5 text-center rounded-tr-xl">成交(股)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr
                            v-for="(stock, index) in topStocks"
                            :key="stock.code"
                            v-tooltip.bottom="{
                                value: stock.reason,
                                showDelay: 200,
                                hideDelay: 100,
                                mouseTrack: true,
                            }"
                            :class="[
                                index === 0
                                    ? 'bg-amber-100'
                                    : index === 1
                                      ? 'bg-red-100'
                                      : index === 2
                                        ? 'bg-violet-100'
                                        : index % 2 === 0
                                          ? 'bg-white'
                                          : 'bg-gray-50',
                                'text-lg transition hover:bg-blue-50 cursor-pointer',
                            ]"
                            @click="goStock(stock.symbol)"
                        >
                            <td
                                class="px-5 py-5 text-center cursor-pointer"
                                @click="goStock(stock.symbol)"
                            >
                                <span
                                    class="border-2 border-gray-400 rounded-full text-black font-bold cursor-pointer inline-block"
                                >
                                    {{ stock.rank }}
                                </span>
                            </td>

                            <td
                                class="px-5 py-5 text-center cursor-pointer"
                                @click="goStock(stock.symbol)"
                            >
                                <span
                                    class="border-2 border-gray-400 rounded-full text-black font-bold cursor-pointer inline-block"
                                >
                                    {{ stock.symbol }}
                                </span>
                            </td>

                            <td
                                class="px-5 py-5 text-center cursor-pointer"
                                @click="goStock(stock.symbol)"
                            >
                                <span
                                    class="border-2 border-gray-400 rounded-full text-black font-bold cursor-pointer inline-block"
                                >
                                    {{ stock.stock_name }}
                                </span>
                            </td>

                            <td
                                class="px-5 py-5 text-center cursor-pointer"
                                @click="goStock(stock.symbol)"
                            >
                                <div
                                    class="border-2 border-gray-400 rounded-full text-black font-bold cursor-pointer inline-block"
                                >
                                    {{ formatNumber(stock.close_price) }}
                                </div>
                            </td>

                            <td
                                class="px-5 py-5 text-center cursor-pointer"
                                @click="goStock(stock.symbol)"
                            >
                                <div
                                    class="border-2 rounded-full inline-block"
                                    :class="
                                        stock.change_value >= 0
                                            ? 'border-red-500 text-red-600 font-bold'
                                            : 'border-green-500 text-green-600 font-bold'
                                    "
                                >
                                    {{ stock.change_value > 0 ? '+' : ''
                                    }}{{ formatNumber(stock.change_value) }}
                                </div>
                            </td>

                            <td
                                class="px-5 py-5 text-center cursor-pointer"
                                @click="goStock(stock.symbol)"
                            >
                                <div
                                    class="border-2 rounded-full px-4 py-1 inline-block"
                                    :class="
                                        stock.change_percent >= 0
                                            ? 'border-red-500 text-red-600 font-bold'
                                            : 'border-green-500 text-green-600 font-bold'
                                    "
                                >
                                    {{ stock.change_percent > 0 ? '+' : ''
                                    }}{{ formatNumber(stock.change_percent) }}%
                                </div>
                            </td>

                            <td class="px-5 py-5 text-center cursor-pointer relative">
                                <div
                                    class="border-2 border-gray-400 rounded-full px-4 py-1 inline-block font-bold"
                                    @click="goStock(stock.symbol)"
                                >
                                    {{ formatNumber(stock.volume) }}
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>
<script setup>
    import { ref, onMounted } from 'vue'
    import { useRouter } from 'vue-router'
    import { useHotStocks } from '@/stores/hotStocks'
    import { useToast } from 'primevue/usetoast'

    const router = useRouter()
    const toast = useToast()
    const { getHotStocks } = useHotStocks()

    const formatNumber = (value) => {
        const num = parseFloat(value)
        if (!isNaN(num)) {
            // toLocaleString() 會自動加上千分位
            return num.toLocaleString()
        }
        return value
    }

    const topStocks = ref([])

    onMounted(async () => {
        topStocks.value = await getHotStocks()

        const shouldShowToast = sessionStorage.getItem('showHotStocksToast')
        if (shouldShowToast) {
            toast.add({ severity: 'success', summary: '成功', detail: '熱門股已更新', life: 3000 })
            sessionStorage.removeItem('showHotStocksToast')
        }
    })

    function goStock(symbol) {
        if (symbol) {
            router.push(`/stock/${symbol}`)
        }
    }
</script>
