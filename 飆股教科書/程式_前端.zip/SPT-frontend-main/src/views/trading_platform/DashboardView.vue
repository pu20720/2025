<script setup>
    import { ref, onMounted } from 'vue'
    import { useUserStore } from '@/stores/user.js'

    const userStore = useUserStore()

    const user = ref({ balance: 0 })
    const portfolioValue = ref(0)
    const totalReturn = ref(0)
    const isLoading = ref(true)

    onMounted(async () => {
        isLoading.value = true
        const data = await userStore.getUserInvestments()
        if (data) {
            user.value.balance = data.available_funds
            portfolioValue.value = data.portfolio_value
            totalReturn.value = data.total_return_rate
        }
        isLoading.value = false
    })

    const popularStocks = ref([
        { code: '2330', name: '台積電', price: 785, change: 10 },
        { code: '2317', name: '鴻海', price: 130, change: -1 },
        { code: '2454', name: '聯發科', price: 1090, change: 12 },
    ])
</script>

<template>
    <div>
        <div v-if="isLoading" class="text-center p-10">載入資金資訊中...</div>

        <div v-else>
            <div class="grid grid-2">
                <div class="card">
                    <h2 class="card-title">熱門股票</h2>
                    <div v-for="stock in popularStocks" :key="stock.code" class="stock-item">
                        <div class="stock-info">
                            <h3>{{ stock.name }}</h3>
                            <div class="stock-code">{{ stock.code }}</div>
                        </div>
                        <div class="stock-price">
                            <div :class="['price', stock.change >= 0 ? 'up' : 'down']">
                                NT${{ stock.price.toFixed(2) }}
                            </div>
                            <div :class="['change', stock.change >= 0 ? 'up' : 'down']">
                                {{ stock.change >= 0 ? '+' : '' }}{{ stock.change.toFixed(2) }}%
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <h2 class="card-title">投資組合分布</h2>
                    <canvas id="portfolioChart" class="chart-container"></canvas>
                </div>
            </div>
        </div>
    </div>
</template>
