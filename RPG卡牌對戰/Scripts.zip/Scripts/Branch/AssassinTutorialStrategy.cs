// 檔案路徑: Assets/Scripts/SceneManagers/Branch/AssassinTutorialStrategy.cs
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

// ▼▼▼ 【修改 1/4】 新增教學指示步驟 ▼▼▼
public enum AssassinTutorialStep
{
    None,
    Start_0_Intro,
    Start_1_PlayerCheck,
    Start_2_PlayerCheck,
    Start_3_Rules,
    Start_4_Rules,
    Start_5_Rules,
    Start_6_WinCon,
    Start_7_Ready,
    Start_8_CleaveIntro,
    Start_9_CleaveIntro,
    WaitForCleave,
    Cleave_1_After,
    Cleave_2_ThreefoldIntro,
    Cleave_3_ThreefoldIntro,
    Threefold_4_Instruction, // (新增)
    WaitForThreefold,
    Threefold_1_After,
    Threefold_2_Observe,
    Threefold_3_Observe,
    WaitForEndTurn1,
    Enemy_1_Nothing,
    Turn2_0_SharpenIntro,
    Turn2_1_SharpenIntro,
    Sharpen_2_Instruction, // (新增)
    WaitForSharpen,
    Sharpen_1_After,
    Sharpen_2_BladeIntro,
    Sharpen_3_BladeIntro,
    WaitForSharpBlade,
    Blade_1_After,
    Blade_2_EndTurn,
    WaitForEndTurn2,
    Enemy_2_Scratch,
    Turn3_0_PostScratch,
    Turn3_1_CleanseIntro,
    Cleanse_2_Instruction, // (新增)
    WaitForDivineRadiance,
    Divine_1_After,
    FreePlay,
    ArmorBreak_0_Advantage,
    ArmorBreak_1_Mechanic,
    Dying_0_Player,
    Dying_1_Killer,
    Dying_2_Killer,
    Dying_3_KillerAttack
}
// ▲▲▲ 【修改結束】 ▲▲▲

public class AssassinTutorialStrategy : BranchStrategy
{
    private Character targetEnemy;
    private AssassinTutorialStep currentTutorialStep = AssassinTutorialStep.None;
    private bool hasShownLowMPWarning = false;
    private bool hasShownOverloadWarning = false;
    private bool hasShownTargetNothingWarning = false;
    private bool isEnemyDowned = false;
    private bool hasTriggeredArmorBreakDialogue = false;

    // 1. 初始化
    public override void Initialize(BattleManager battleManager, Character player, List<Character> enemies)
    {
        base.Initialize(battleManager, player, enemies);
        this.targetEnemy = enemies.FirstOrDefault(e => e.characterName == "Assassin");

        if (this.targetEnemy != null)
        {
            this.targetEnemy.stats.OnDowned += OnEnemyDowned;
        }
    }

    // 2. 事件：戰鬥開始
    public override void OnBattleStart()
    {
        currentTutorialStep = AssassinTutorialStep.Start_0_Intro;
        battleManager.ShowTutorialDialogue("Killer", "You two new recruits fight each other. Whoever wins, stays.");
    }

    // 2. 事件：玩家回合開始
    public override void OnPlayerTurnStart()
    {
        if (currentTutorialStep == AssassinTutorialStep.Enemy_1_Nothing)
        {
            AdvanceTutorial(currentTutorialStep);
        }
        else if (currentTutorialStep == AssassinTutorialStep.Enemy_2_Scratch)
        {
            AdvanceTutorial(currentTutorialStep);
        }
    }

    // 2. 事件：敵人行動
    public override void OnEnemyAction(EnemyAI ai, Character playerTarget)
    {
        if (ai.enemyData.aiLogic == EnemyAILogic.TutorialTarget)
        {
            if (currentTutorialStep == AssassinTutorialStep.Enemy_1_Nothing)
            {
                battleManager.LogAction("The Target uses Nothing. It's a target, what did you expect?");
            }
            if (currentTutorialStep == AssassinTutorialStep.FreePlay && !hasShownTargetNothingWarning)
            {
                if (player.stats.turnCount == 4 || (player.stats.turnCount > 4 && (player.stats.turnCount - 4) % 3 == 0))
                {
                    hasShownTargetNothingWarning = true;
                    battleManager.ShowTutorialDialogue("Player", "Nice... it's playing dumb.");
                }
            }
        }
    }

    // 2. 事件：Update
    public override void OnUpdate()
    {
        if (player == null || player.stats == null) return;

        CardDisplay selectedCard = battleManager.GetSelectedCardDisplay();

        if (!hasShownLowMPWarning && selectedCard != null)
        {
            CardData card = selectedCard.GetCardData();
            if (card != null && player.stats.mp < card.mpCost)
            {
                hasShownLowMPWarning = true;
                battleManager.ShowTutorialDialogue("Player", "My magic teacher always told me not to use mana recklessly, but I still forget...");
                battleManager.LogAction("Not enough MP!");
            }
        }

        if (!hasShownOverloadWarning && player.stats.mp >= 200)
        {
            hasShownOverloadWarning = true;
            battleManager.ShowTutorialDialogue("Player", "Overloaded already? You've got to be kidding me. Better play some cards quickly...");
        }

        // (碎甲對話 - 啟動對話鏈)
        if (!hasTriggeredArmorBreakDialogue && currentTutorialStep == AssassinTutorialStep.FreePlay && targetEnemy != null && (
            targetEnemy.stats.helmet.isBroken ||
            targetEnemy.stats.armor.isBroken ||
            targetEnemy.stats.gauntlets.isBroken ||
            targetEnemy.stats.legArmor.isBroken))
        {
            hasTriggeredArmorBreakDialogue = true;
            currentTutorialStep = AssassinTutorialStep.ArmorBreak_0_Advantage;
            AdvanceTutorial(currentTutorialStep);
        }
    }


    // 3. 驗證：點擊卡牌
    public override bool ValidateCardClick(CardData card)
    {
        switch (currentTutorialStep)
        {
            case AssassinTutorialStep.WaitForCleave:
                if (card.type == CardType.Attack) return true;
                break;
            case AssassinTutorialStep.WaitForThreefold:
                if (card.type == CardType.Conditional) return true;
                break;
            case AssassinTutorialStep.WaitForSharpen:
                if (card.type == CardType.Buff) return true;
                if (card.type == CardType.Weapon && battleManager.GetSelectedCardDisplay() != null && battleManager.GetSelectedCardDisplay().GetCardData().type == CardType.Buff)
                {
                    return true;
                }
                break;
            case AssassinTutorialStep.WaitForSharpBlade:
                if (card.type == CardType.Weapon) return true;
                break;
            case AssassinTutorialStep.WaitForDivineRadiance:
                if (card.type == CardType.Magic) return true;
                break;

            // (Fortify 已移除)

            case AssassinTutorialStep.FreePlay:
                return true;
        }

        battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
        return false;
    }

    // 3. 驗證：結束回合
    public override bool ValidateEndTurn()
    {
        if (currentTutorialStep == AssassinTutorialStep.WaitForEndTurn1)
        {
            currentTutorialStep = AssassinTutorialStep.Enemy_1_Nothing;
            return true;
        }
        if (currentTutorialStep == AssassinTutorialStep.WaitForEndTurn2)
        {
            currentTutorialStep = AssassinTutorialStep.Enemy_2_Scratch;
            return true;
        }
        if (currentTutorialStep == AssassinTutorialStep.FreePlay)
        {
            return true;
        }

        if (isEnemyDowned)
        {
            return false;
        }

        battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
        return false;
    }


    // 4. 覆蓋：點擊目標
    public override bool HandleTargetClick(CardData card, TargetIndicator target)
    {
        if (card == null || target == null) return false;

        bool isAttackCard = (card.type == CardType.Attack || card.type == CardType.Weapon);

        bool isInstructional =
            (currentTutorialStep >= AssassinTutorialStep.WaitForCleave && currentTutorialStep <= AssassinTutorialStep.WaitForEndTurn2);

        if (isAttackCard && isInstructional && target.GetCategory() == TargetCategory.Enemy)
        {
            battleManager.ShowTutorialDialogue("Player", "I don't have the habit to wasting time on this......", true);
            battleManager.DeselectCard();
            return true;
        }

        if (currentTutorialStep == AssassinTutorialStep.WaitForCleave && card.type == CardType.Attack)
        {
            if (target.GetCategory() == TargetCategory.EnemyArmorSlot)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinTutorialStep.Cleave_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
            battleManager.ShowTutorialDialogue("Player", "I don't have the habit to wasting time on this......", true);
            battleManager.DeselectCard();
            return true;
        }

        if (currentTutorialStep == AssassinTutorialStep.WaitForThreefold && card.type == CardType.Conditional)
        {
            if (target.GetCategory() == TargetCategory.Special)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().MoveCardFromHand(battleManager.GetSelectedCardDisplay().gameObject);
                UnityEngine.Object.Destroy(battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinTutorialStep.Threefold_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        if (currentTutorialStep == AssassinTutorialStep.WaitForSharpen && card.type == CardType.Buff)
        {
            if (target.GetCategory() == TargetCategory.CardInHand && target.GetCardDisplay().GetCardData().type == CardType.Weapon)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinTutorialStep.Sharpen_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        if (currentTutorialStep == AssassinTutorialStep.WaitForSharpBlade && card.type == CardType.Weapon)
        {
            if (target.GetCategory() == TargetCategory.EnemyArmorSlot && target.GetArmorPart() == ArmorPart.Armor)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinTutorialStep.Blade_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
            else
            {
                battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
                battleManager.DeselectCard();
                return true;
            }
        }

        if (currentTutorialStep == AssassinTutorialStep.WaitForDivineRadiance && card.type == CardType.Magic)
        {
            if (target.GetCategory() == TargetCategory.Player)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = AssassinTutorialStep.Divine_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        // (Fortify 已移除)

        return false;
    }

    // 5. 勝利/失敗
    public override bool CheckForSpecialBattleEnd(out bool playerWon)
    {
        if (player != null && player.stats.isDead)
        {
            battleManager.LogAction("Player was defeated. Game Over.");
            battleManager.StartCoroutine(battleManager.EndTutorialGame(false));
            playerWon = false;
            return true;
        }

        if (targetEnemy != null && targetEnemy.stats.isDead && isEnemyDowned)
        {
            battleManager.LogAction("Assassin was executed. Victory!");
            battleManager.StartCoroutine(battleManager.EndTutorialGame(true));
            playerWon = true;
            return true;
        }

        playerWon = false;
        return false;
    }

    // 6. 抽牌
    public override bool CanDrawCards()
    {
        return (currentTutorialStep == AssassinTutorialStep.FreePlay ||
                currentTutorialStep == AssassinTutorialStep.Enemy_1_Nothing ||
                currentTutorialStep == AssassinTutorialStep.Enemy_2_Scratch);
    }

    // 7. 狀態機 (Helper Methods)

    private void OnEnemyDowned()
    {
        if (isEnemyDowned) return;
        isEnemyDowned = true;

        currentTutorialStep = AssassinTutorialStep.Dying_0_Player;
        AdvanceTutorial(currentTutorialStep);
    }

    // ▼▼▼ 【修改 2/4】 將新狀態加入 Switch ▼▼▼
    public override void OnDialoguePanelClicked()
    {
        bool isInstruction = battleManager.IsDialogueInstructional();

        switch (currentTutorialStep)
        {
            case AssassinTutorialStep.WaitForCleave:
            case AssassinTutorialStep.WaitForThreefold:
            case AssassinTutorialStep.WaitForSharpen:
            case AssassinTutorialStep.WaitForSharpBlade:
            case AssassinTutorialStep.WaitForDivineRadiance:
            // (WaitForFortifyArmor 已移除)
            case AssassinTutorialStep.WaitForEndTurn1:
            case AssassinTutorialStep.WaitForEndTurn2:
                if (isInstruction)
                {
                    Debug.LogWarning($"[AssassinStrategy] OnDialoguePanelClicked: Click ignored. Waiting for game action (Current: {currentTutorialStep}).");
                    return;
                }
                break;

            case AssassinTutorialStep.FreePlay:
                Debug.Log($"[AssassinStrategy] OnDialoguePanelClicked: Click valid (FreePlay). Clearing dialogue.");
                battleManager.ClearTutorialDialogue();
                return;

            // (新增) 確保新舊對話狀態可以安全推進
            case AssassinTutorialStep.ArmorBreak_0_Advantage:
            case AssassinTutorialStep.ArmorBreak_1_Mechanic:
            case AssassinTutorialStep.Dying_0_Player:
            case AssassinTutorialStep.Dying_1_Killer:
            case AssassinTutorialStep.Dying_2_Killer:
            case AssassinTutorialStep.Dying_3_KillerAttack:
            case AssassinTutorialStep.Threefold_4_Instruction: // (新增)
            case AssassinTutorialStep.Sharpen_2_Instruction:  // (新增)
            case AssassinTutorialStep.Cleanse_2_Instruction:  // (新增)
                break; // Fall-through 執行 AdvanceTutorial
        }

        Debug.Log($"[AssassinStrategy] OnDialoguePanelClicked: Click valid. Advancing dialogue (Current: {currentTutorialStep}).");
        AdvanceTutorial(currentTutorialStep);
    }
    // ▲▲▲ 【修改結束】 ▲▲▲

    // ▼▼▼ 【修改 3/4】 更新教學流程 ▼▼▼
    private void AdvanceTutorial(AssassinTutorialStep requiredStep)
    {
        if (currentTutorialStep != requiredStep) return;

        switch (currentTutorialStep)
        {
            case AssassinTutorialStep.Start_0_Intro:
                currentTutorialStep = AssassinTutorialStep.Start_1_PlayerCheck;
                battleManager.ShowTutorialDialogue("Player", "Let's check if I'm prepared first.");
                break;
            case AssassinTutorialStep.Start_1_PlayerCheck:
                currentTutorialStep = AssassinTutorialStep.Start_2_PlayerCheck;
                battleManager.ShowTutorialDialogue("Player", "I don't want to be like those story protagonists who are missing everything at the start...");
                break;
            case AssassinTutorialStep.Start_2_PlayerCheck:
                currentTutorialStep = AssassinTutorialStep.Start_3_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "Here is all the basic information.");
                break;
            case AssassinTutorialStep.Start_3_Rules:
                currentTutorialStep = AssassinTutorialStep.Start_4_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "When any piece of armor on a character (including yourself) is broken, the opponent can deal damage to that character's HP.");
                break;
            case AssassinTutorialStep.Start_4_Rules:
                currentTutorialStep = AssassinTutorialStep.Start_5_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "The victory goal in a normal game is to reduce the opponent's HP to below 0.");
                break;
            case AssassinTutorialStep.Start_5_Rules:
                currentTutorialStep = AssassinTutorialStep.Start_6_WinCon;
                battleManager.ShowTutorialDialogue("Narrator", "But there are other ways to win awaiting players to explore.\nThis time, the goal is to defeat the opponent!");
                break;
            case AssassinTutorialStep.Start_6_WinCon:
                currentTutorialStep = AssassinTutorialStep.Start_7_Ready;
                battleManager.ShowTutorialDialogue("Player", "Great, looks like I can start.");
                break;
            case AssassinTutorialStep.Start_7_Ready:
                currentTutorialStep = AssassinTutorialStep.Start_8_CleaveIntro;
                battleManager.ShowTutorialDialogue("Player", "If I had to say what I learned best from the military academy, it's attacking.");
                break;
            case AssassinTutorialStep.Start_8_CleaveIntro:
                currentTutorialStep = AssassinTutorialStep.Start_9_CleaveIntro;
                battleManager.ShowTutorialDialogue("Player", "I'm not bragging, but when everyone else was learning 'Straight Attack', I learned 'Cleave' first.");
                break;
            case AssassinTutorialStep.Start_9_CleaveIntro:
                currentTutorialStep = AssassinTutorialStep.WaitForCleave;
                battleManager.ShowTutorialDialogue("Narrator", "(Click Cleave, then click the Target's Armor to deal damage)", true);
                battleManager.StartPlayerTurnInternal();
                break;
            case AssassinTutorialStep.WaitForCleave:
                break;

            case AssassinTutorialStep.Cleave_1_After:
                currentTutorialStep = AssassinTutorialStep.Cleave_2_ThreefoldIntro;
                battleManager.ShowTutorialDialogue("Player", "That being said, it doesn't seem very necessary this time...");
                break;
            case AssassinTutorialStep.Cleave_2_ThreefoldIntro:
                currentTutorialStep = AssassinTutorialStep.Cleave_3_ThreefoldIntro;
                battleManager.ShowTutorialDialogue("Player", "The defense instructor always said, 'Defense is the best offense.'");
                break;

            // (分離教學文字)
            case AssassinTutorialStep.Cleave_3_ThreefoldIntro:
                currentTutorialStep = AssassinTutorialStep.Threefold_4_Instruction;
                battleManager.ShowTutorialDialogue("Player", "Now is not the time to be idle, defend well.");
                break;
            case AssassinTutorialStep.Threefold_4_Instruction:
                currentTutorialStep = AssassinTutorialStep.WaitForThreefold;
                battleManager.ShowTutorialDialogue("Player", "(Click Threefold Ward, then click the Play Area to pre-block the enemy's attack)", true);
                break;
            case AssassinTutorialStep.WaitForThreefold:
                break;

            case AssassinTutorialStep.Threefold_1_After:
                currentTutorialStep = AssassinTutorialStep.Threefold_2_Observe;
                battleManager.ShowTutorialDialogue("Player", "That instructor also taught: 'Observe the enemy, then act.'");
                break;
            case AssassinTutorialStep.Threefold_2_Observe:
                currentTutorialStep = AssassinTutorialStep.Threefold_3_Observe;
                battleManager.ShowTutorialDialogue("Player", "I've seen him 'Ora Ora' without any hesitation...");
                break;
            case AssassinTutorialStep.Threefold_3_Observe:
                currentTutorialStep = AssassinTutorialStep.WaitForEndTurn1;
                battleManager.ShowTutorialDialogue("Player", "(Press End Turn to end the turn)", true);
                break;
            case AssassinTutorialStep.WaitForEndTurn1:
                break;

            case AssassinTutorialStep.Enemy_1_Nothing:
                currentTutorialStep = AssassinTutorialStep.Turn2_0_SharpenIntro;
                AdvanceTutorial(currentTutorialStep);
                break;

            case AssassinTutorialStep.Turn2_0_SharpenIntro:
                currentTutorialStep = AssassinTutorialStep.Turn2_1_SharpenIntro;
                battleManager.ShowTutorialDialogue("Player", "The equipment instructor always said, 'To do a good job, one must first sharpen one's tools.'");
                break;

            // (分離教學文字)
            case AssassinTutorialStep.Turn2_1_SharpenIntro:
                currentTutorialStep = AssassinTutorialStep.Sharpen_2_Instruction;
                battleManager.ShowTutorialDialogue("Player", "I'm tired of hearing it, but thanks to that, I still remember to enhance my weapon.");
                break;
            case AssassinTutorialStep.Sharpen_2_Instruction:
                currentTutorialStep = AssassinTutorialStep.WaitForSharpen;
                battleManager.ShowTutorialDialogue("Player", "(Click Sharpen, then click Sharp Blade to enhance it)", true);
                break;
            case AssassinTutorialStep.WaitForSharpen:
                break;

            case AssassinTutorialStep.Sharpen_1_After:
                currentTutorialStep = AssassinTutorialStep.Sharpen_2_BladeIntro;
                battleManager.ShowTutorialDialogue("Player", "How many throwing knives did I use back then...");
                break;
            case AssassinTutorialStep.Sharpen_2_BladeIntro:
                currentTutorialStep = AssassinTutorialStep.Sharpen_3_BladeIntro;
                battleManager.ShowTutorialDialogue("Player", "Forget it. Can you count how many loaves of bread you've eaten in your life?");
                break;
            case AssassinTutorialStep.Sharpen_3_BladeIntro:
                currentTutorialStep = AssassinTutorialStep.WaitForSharpBlade;
                battleManager.ShowTutorialDialogue("Player", "(Click Sharp Blade, then click the opponent to attack)", true);
                break;
            case AssassinTutorialStep.WaitForSharpBlade:
                break;

            case AssassinTutorialStep.Blade_1_After:
                currentTutorialStep = AssassinTutorialStep.Blade_2_EndTurn;
                battleManager.ShowTutorialDialogue("Player", "Let's just keep going like this.");
                break;
            case AssassinTutorialStep.Blade_2_EndTurn:
                currentTutorialStep = AssassinTutorialStep.WaitForEndTurn2;
                battleManager.ShowTutorialDialogue("Player", "(Press End Turn to end the turn)", true);
                break;
            case AssassinTutorialStep.WaitForEndTurn2:
                currentTutorialStep = AssassinTutorialStep.Enemy_2_Scratch;
                break;

            case AssassinTutorialStep.Enemy_2_Scratch:
                currentTutorialStep = AssassinTutorialStep.Turn3_0_PostScratch;
                AdvanceTutorial(currentTutorialStep);
                break;

            case AssassinTutorialStep.Turn3_0_PostScratch:
                currentTutorialStep = AssassinTutorialStep.Turn3_1_CleanseIntro;
                battleManager.ShowTutorialDialogue("Player", "Seriously? That dull knife actually got sharpened?");
                break;

            // (分離教學文字)
            case AssassinTutorialStep.Turn3_1_CleanseIntro:
                currentTutorialStep = AssassinTutorialStep.Cleanse_2_Instruction;
                battleManager.ShowTutorialDialogue("Player", "Quick, do as the survival instructor said, cleanse myself.");
                break;
            case AssassinTutorialStep.Cleanse_2_Instruction:
                currentTutorialStep = AssassinTutorialStep.WaitForDivineRadiance;
                battleManager.ShowTutorialDialogue("Player", "(Use Divine Radiance to remove the status effect)", true);
                break;
            case AssassinTutorialStep.WaitForDivineRadiance:
                break;

            // (Fortify 已移除, Divine_1_After 直接跳到 FreePlay)
            case AssassinTutorialStep.Divine_1_After:
                currentTutorialStep = AssassinTutorialStep.FreePlay;
                battleManager.ShowTutorialDialogue("Narrator", "Use what you have learned to defeat the enemy!");
                break;

            case AssassinTutorialStep.FreePlay:
                battleManager.ClearTutorialDialogue();
                break;

            // (碎甲說明)
            case AssassinTutorialStep.ArmorBreak_0_Advantage:
                currentTutorialStep = AssassinTutorialStep.ArmorBreak_1_Mechanic;
                battleManager.ShowTutorialDialogue("Player", "Good, keep suppressing them like this!");
                break;

            case AssassinTutorialStep.ArmorBreak_1_Mechanic:
                currentTutorialStep = AssassinTutorialStep.FreePlay;
                battleManager.ShowTutorialDialogue("Narrator", "Armor is broken. The attack that breaks it is immune to HP damage (unless Pierce) and ignores control effects, but subsequent attacks can target the opponent's HP.");
                break;

            // (特殊結局)
            case AssassinTutorialStep.Dying_0_Player:
                currentTutorialStep = AssassinTutorialStep.Dying_1_Killer;
                battleManager.ShowTutorialDialogue("Player", "The opponent can't move. Does this mean I win?");
                break;
            case AssassinTutorialStep.Dying_1_Killer:
                currentTutorialStep = AssassinTutorialStep.Dying_2_Killer;
                battleManager.ShowTutorialDialogue("Killer", "How could that be? He's not dead yet.");
                break;
            case AssassinTutorialStep.Dying_2_Killer:
                currentTutorialStep = AssassinTutorialStep.Dying_3_KillerAttack;
                battleManager.ShowTutorialDialogue("Killer", "Forget it, I'll finish him for you...");
                break;

            case AssassinTutorialStep.Dying_3_KillerAttack:
                battleManager.ClearTutorialDialogue();
                battleManager.StartCoroutine(ExecuteFatalBlow());
                break;

            default:
                battleManager.ClearTutorialDialogue();
                break;
        }
    }
    // ▲▲▲ 【修改結束】 ▲▲▲

    // ▼▼▼ 【修改 4/4】 更新日誌文字 ▼▼▼
    private IEnumerator ExecuteFatalBlow()
    {
        // 1. 顯示日誌
        battleManager.LogAction("Killer lands a fatal blow on Assassin, deals 9999 damage!");

        // 2. 等待 1 秒
        yield return new WaitForSeconds(1.0f);

        // 3. 造成傷害
        if (targetEnemy != null)
        {
            targetEnemy.stats.TakeDamage(9999, DamageType.True, ArmorPart.Armor);
        }
    }
    // ▲▲▲ 【修改結束】 ▲▲▲

    // 8. 存檔/讀檔
    public override string GetCurrentTutorialStepName()
    {
        return currentTutorialStep.ToString();
    }

    public override void SetCurrentTutorialStep(string stepName)
    {
        if (Enum.TryParse(stepName, out AssassinTutorialStep newStep))
        {
            currentTutorialStep = newStep;
            Debug.Log($"[AssassinStrategy] SetCurrentTutorialStep:  successfully set to {currentTutorialStep}");
        }
        else
        {
            Debug.LogError($"[AssassinStrategy] SetCurrentTutorialStep: Failed to parse step '{stepName}'!");
            currentTutorialStep = AssassinTutorialStep.FreePlay;
        }
    }
}