package com.example.uimo.ui.screens

import android.net.Uri
import android.os.Environment
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.uimo.R
import com.example.uimo.ui.theme.UIMOTheme
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecondScreen(navController: NavHostController) {
    val context = LocalContext.current

    val selectVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            Log.d("NavCheck", "動画が選択されました。URI: $uri")
            val encodedUri = Uri.encode(uri.toString())
            Log.d("NavCheck", "ThirdScreenへナビゲートします。宛先: third/$encodedUri")
            navController.navigate("courtSetup/$encodedUri")
        }
    }

    var videoUri: Uri? by remember { mutableStateOf(null) }

    val captureVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success: Boolean ->
        if (success) {
            videoUri?.let { uri ->
                Log.d("NavCheck", "動画撮影成功。URI: $uri")
                val encodedUri = Uri.encode(uri.toString())
                Log.d("NavCheck", "ThirdScreenへナビゲートします。宛先: third/$encodedUri")
                navController.navigate("courtSetup/$encodedUri")
            }
        } else {
            Log.d("NavCheck", "動画撮影キャンセルまたは失敗")
        }
    }

    val createVideoUri: () -> Uri = {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val videoFileName = "MP4_${timeStamp}_"
        val storageDir: File? = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
        val videoFile = File.createTempFile(videoFileName, ".mp4", storageDir)
        FileProvider.getUriForFile(context, "${context.packageName}.provider", videoFile)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Second Screen") })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = {
                    // --- ↓↓↓ このログを追加 ↓↓↓ ---
                    Log.d("NavCheck", "「動画を選択」ボタンがクリックされました。ランチャーを起動します。")
                    selectVideoLauncher.launch("video/*")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.upload_24dp_000000_fill0_wght400_grad0_opsz24),
                    contentDescription = "動画をアップロードするアイコン",
                    tint = Color.White
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val newVideoUri = createVideoUri()
                    videoUri = newVideoUri
                    captureVideoLauncher.launch(newVideoUri)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_camera_alt_24),
                    contentDescription = "カメラを起動するアイコン",
                    tint = Color.White
                )
            }
        }
    }
}

