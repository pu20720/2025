from .models import Stock, Watchlist
from rest_framework import serializers


class StockSerializer(serializers.ModelSerializer):
    class Meta:
        model = Stock
        fields = '__all__'


class WatchlistSerializer(serializers.ModelSerializer):
    symbol = serializers.CharField(source='stock.symbol', read_only=True)
    name = serializers.CharField(source='stock.name', read_only=True)

    class Meta:
        model = Watchlist
        fields = ['id', 'symbol', 'name', 'created_at']
        read_only_fields = ['id', 'created_at']
