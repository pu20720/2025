# inout_judge.py  (IN/OUT可視化重視版)
import os, csv, math, argparse
import numpy as np
import cv2 as cv

# ---- Court geometry (meters) ----
COURT_LENGTH = 13.40
COURT_WIDTH  = 6.10
SINGLES_WIDTH = 5.18
NET_Y = COURT_LENGTH / 2.0
SHORT_SERVICE_FROM_NET = 1.98
DOUBLES_LONG_SERVICE_FROM_BACK = 0.76

def build_court_lines(mode="singles"):
    lines=[]
    lines.append(np.array([[0,0],[COURT_WIDTH,0],[COURT_WIDTH,COURT_LENGTH],[0,COURT_LENGTH],[0,0]],np.float32))
    if mode=="singles":
        off=(COURT_WIDTH-SINGLES_WIDTH)/2
        xL, xR = off, COURT_WIDTH-off
        lines.append(np.array([[xL,0],[xL,COURT_LENGTH]],np.float32))
        lines.append(np.array([[xR,0],[xR,COURT_LENGTH]],np.float32))
    y1 = NET_Y - SHORT_SERVICE_FROM_NET
    y2 = NET_Y + SHORT_SERVICE_FROM_NET
    lines.append(np.array([[0,y1],[COURT_WIDTH,y1]],np.float32))
    lines.append(np.array([[0,y2],[COURT_WIDTH,y2]],np.float32))
    yT = DOUBLES_LONG_SERVICE_FROM_BACK
    yB = COURT_LENGTH - DOUBLES_LONG_SERVICE_FROM_BACK
    lines.append(np.array([[0,yT],[COURT_WIDTH,yT]],np.float32))
    lines.append(np.array([[0,yB],[COURT_WIDTH,yB]],np.float32))
    xC = COURT_WIDTH/2.0
    lines.append(np.array([[xC,0],[xC,y1]],np.float32))
    lines.append(np.array([[xC,y2],[xC,COURT_LENGTH]],np.float32))
    lines.append(np.array([[0,NET_Y],[COURT_WIDTH,NET_Y]],np.float32))
    return lines

def to_img_pts(H, pts_m):
    pts = pts_m.reshape(-1,1,2).astype(np.float32)
    return cv.perspectiveTransform(pts, H).reshape(-1,2)

def draw_court(frame, H, mode="singles", thickness=3):
    for seg in build_court_lines(mode):
        ip = np.round(to_img_pts(H, seg)).astype(int)
        for i in range(len(ip)-1):
            cv.line(frame, tuple(ip[i]), tuple(ip[i+1]), (0,255,0), thickness, cv.LINE_AA)

def load_H(npz_path):
    d=np.load(npz_path, allow_pickle=True)
    if 'H' in d: return d['H']
    for k in d.files:
        if d[k].shape==(3,3): return d[k]
    raise RuntimeError("npzに3x3のHが見つかりません: "+npz_path)

def read_ball_csv(csv_path):
    rows=[]
    with open(csv_path, newline='', encoding='utf-8') as f:
        r=csv.DictReader(f)
        for row in r:
            fr=int(row.get('frame', row.get('Frame')))
            x =float(row['x']); y=float(row['y'])
            sc=float(row.get('score',1.0))
            rows.append((fr,x,y,sc))
    rows.sort(key=lambda t:t[0])
    return rows

def moving_avg_1d(arr, win=3):
    if win<=1: return arr.copy()
    out=arr.copy(); n=len(arr)
    for i in range(n):
        s=0.0; c=0
        for j in range(i-(win//2), i+(win//2)+1):
            if 0<=j<n and not math.isnan(arr[j]):
                s += arr[j]; c += 1
        out[i] = (s/c) if c>0 else arr[i]
    return out

def px_to_m(H_inv, x_px, y_px):
    pt=np.array([[[x_px, y_px]]], np.float32)
    out=cv.perspectiveTransform(pt, H_inv)[0,0]
    return float(out[0]), float(out[1])

def inside_rect_singles(xm, ym, margin_m=0.0):
    off=(COURT_WIDTH-SINGLES_WIDTH)/2.0
    xL=off - margin_m; xR=COURT_WIDTH-off + margin_m
    yT=0.0 - margin_m; yB=COURT_LENGTH + margin_m
    return (xL <= xm <= xR) and (yT <= ym <= yB)

def inside_rect_doubles(xm, ym, margin_m=0.0):
    xL=0.0 - margin_m; xR=COURT_WIDTH + margin_m
    yT=0.0 - margin_m; yB=COURT_LENGTH + margin_m
    return (xL <= xm <= xR) and (yT <= ym <= yB)

def pick_fourcc(pref):
    tried=set()
    for code in [pref,'avc1','XVID','MJPG','mp4v']:
        if code in tried: continue
        tried.add(code); yield code
    yield 'mp4v'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--H", required=True)
    ap.add_argument("--csv", required=True)  # frame,x,y,score
    ap.add_argument("--output", required=True)
    ap.add_argument("--events_csv", default=None)
    ap.add_argument("--mode", choices=["singles","doubles"], default="singles")
    ap.add_argument("--margin_cm", type=float, default=0.0)
    ap.add_argument("--min_score", type=float, default=0.20)
    ap.add_argument("--smooth", type=int, default=3)
    ap.add_argument("--vel_thresh_px", type=float, default=2.0)
    ap.add_argument("--min_gap", type=int, default=6)
    ap.add_argument("--trail", type=int, default=10)
    ap.add_argument("--thickness", type=int, default=3)
    ap.add_argument("--fourcc", default="avc1")

    # ★ 追加：バナーの保持制御
    ap.add_argument("--banner_sec", type=float, default=2.5, help="IN/OUTバナーの最短表示秒")
    ap.add_argument("--hold_until_motion", action="store_true", help="動き再開までバナー保持")
    ap.add_argument("--resume_speed_px", type=float, default=3.0, help="ラリー再開判定の速度")
    ap.add_argument("--resume_consec", type=int, default=5, help="再開速度を満たす連続フレーム数")
    args=ap.parse_args()

    # load
    H=load_H(args.H).astype(np.float32)
    H_inv=np.linalg.inv(H)
    det=read_ball_csv(args.csv)
    if not det: raise SystemExit("球CSVが空: "+args.csv)

    cap=cv.VideoCapture(args.input)
    if not cap.isOpened(): raise SystemExit("動画が開けません: "+args.input)
    fps=cap.get(cv.CAP_PROP_FPS)
    Wimg=int(cap.get(cv.CAP_PROP_FRAME_WIDTH))
    Himg=int(cap.get(cv.CAP_PROP_FRAME_HEIGHT))
    nfrm=int(cap.get(cv.CAP_PROP_FRAME_COUNT))

    # series
    x=np.full(nfrm, np.nan); y=np.full(nfrm, np.nan); s=np.zeros(nfrm, np.float32)
    for fr,xp,yp,sc in det:
        if 0<=fr<nfrm and sc>=args.min_score:
            x[fr]=xp; y[fr]=yp; s[fr]=sc

    # smoothing
    x_s=moving_avg_1d(x, args.smooth)
    y_s=moving_avg_1d(y, args.smooth)

    # speed                                                                                                       ##
    vx=np.gradient(np.nan_to_num(x_s, nan=np.nanmedian(x_s)))
    vy=np.gradient(np.nan_to_num(y_s, nan=np.nanmedian(y_s)))
    speed=np.sqrt(vx*vx+vy*vy)

    # landings (speed dip)
    landings=[]; last=-9999
    for i in range(2, nfrm-2):
        if not np.isfinite(speed[i]): continue
        if speed[i]<args.vel_thresh_px and (i-last)>=args.min_gap:
            prev_ok=np.isfinite(speed[i-1]) and speed[i-1]>args.vel_thresh_px
            next_ok=(not np.isfinite(speed[i+1])) or speed[i+1]>args.vel_thresh_px
            if prev_ok and next_ok and np.isfinite(x_s[i]) and np.isfinite(y_s[i]):
                landings.append(i); last=i                                                                        ##
    landing_set=set(landings)

    # writer
    out=None; tried=[]
    for code in pick_fourcc(args.fourcc):
        fourcc=cv.VideoWriter_fourcc(*code)
        out=cv.VideoWriter(args.output, fourcc, fps, (Wimg,Himg))
        ok=out.isOpened(); tried.append((code,ok))
        if ok: break
    if not out or not out.isOpened():
        raise SystemExit(f"VideoWriterを開けません: tried={tried}")

    # events csv
    ev_path = args.events_csv or os.path.splitext(args.output)[0] + "_events.csv"
    evf=open(ev_path,"w",newline="",encoding="utf-8"); evw=csv.writer(evf)
    evw.writerow(["frame","x_px","y_px","x_m","y_m","label","speed_px"])

    # banner state
    banner_text=None
    banner_color=(0,200,0)
    banner_expire_frame=-1
    resume_count=0
    min_hold_frames=int(round(args.banner_sec*fps))

    def is_in(xm, ym):
        margin_m=args.margin_cm/100.0
        return inside_rect_singles(xm,ym,margin_m) if args.mode=="singles" \
               else inside_rect_doubles(xm,ym,margin_m)

    # loop
    i=0; trail=[]
    while True:
        ok, frame = cap.read()
        if not ok: break

        draw_court(frame, H, args.mode, args.thickness)

        # dot & trail
        if np.isfinite(x_s[i]) and np.isfinite(y_s[i]):
            trail.append((int(x_s[i]), int(y_s[i])))
            if len(trail)>args.trail: trail=trail[-args.trail:]
            for j in range(1,len(trail)):
                cv.line(frame, trail[j-1], trail[j], (0,0,255), 2, cv.LINE_AA)
            cv.circle(frame,(int(x_s[i]),int(y_s[i])),5,(0,0,255),-1)

        # landing → set banner
        if i in landing_set and np.isfinite(x_s[i]) and np.isfinite(y_s[i]):                                                   ######
            xm, ym = px_to_m(H_inv, x_s[i], y_s[i])
            label = "IN" if is_in(xm, ym) else "OUT"
            banner_text = label
            banner_color = (0,200,0) if label=="IN" else (0,0,255)                                                             ###### 
            banner_expire_frame = i + min_hold_frames  # 最低保持                                                               
            resume_count = 0  # 再開カウンタをリセット
            evw.writerow([i, float(x_s[i]), float(y_s[i]), xm, ym, label, float(speed[i])])

        # banner: hold / clear
        if banner_text:
            # 動き再開の判定（任意）
            if args.hold_until_motion and np.isfinite(speed[i]):
                if speed[i] >= args.resume_speed_px:
                    resume_count += 1
                else:
                    resume_count = 0
            # 消去条件：最短表示が過ぎ、かつ（hold指定なら再開達成）
            if i >= banner_expire_frame and (not args.hold_until_motion or resume_count >= args.resume_consec):
                banner_text=None
                resume_count=0
            else:
                # 画面上部に帯＋大文字表示
                overlay=frame.copy()
                cv.rectangle(overlay, (0,0), (Wimg,120), banner_color, -1)
                frame=cv.addWeighted(overlay, 0.35, frame, 0.65, 0)
                cv.putText(frame, banner_text, (20,85), cv.FONT_HERSHEY_SIMPLEX, 2.2, banner_color, 5, cv.LINE_AA)

        cv.putText(frame, f"frame {i}", (20, Himg-20), cv.FONT_HERSHEY_SIMPLEX, 0.7, (200,200,200), 2, cv.LINE_AA)
        out.write(frame)
        i+=1

    cap.release(); out.release(); evf.close()
    print("[done] video :", args.output)
    print("[done] events:", ev_path)

if __name__=="__main__":
    main()
