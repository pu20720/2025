# SPT-backend/app.py
import os
import uuid
import re
import json
import requests
import chromadb
from google import genai
from typing import List
from flask_cors import CORS
from dotenv import load_dotenv
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from sentence_transformers import SentenceTransformer, CrossEncoder

# === 初始化 ===
load_dotenv()
google_client = genai.Client()


# === 股票代碼對照表 ===
def load_stock_data(file_path: str) -> dict:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f'⚠️ 找不到股票資料檔案: {file_path}')
        return {}


STOCK_DATA = load_stock_data('stock_data.json')
# 初始化嵌入模型
embedding_model = SentenceTransformer('shibing624/text2vec-base-chinese')

# 初始化 Chroma 資料庫
chromadb_client = chromadb.PersistentClient(path='./chromadb.db')
chromadb_collection = chromadb_client.get_or_create_collection(name='default')

# CrossEncoder
cross_encoder = CrossEncoder('cross-encoder/mmarco-mMiniLMv2-L12-H384-v1')

FINMIND_TOKEN = os.getenv('FINMIND_TOKEN')

# === Flask App ===

app = Flask(__name__)
CORS(app)


# === 函數區 ===
def embed_chunk(chunk: str) -> List[float]:
    return embedding_model.encode(chunk).tolist()


def retrieve(query: str, top_k: int = 5) -> List[str]:
    query_embedding = embed_chunk(query)
    results = chromadb_collection.query(
        query_embeddings=[query_embedding], n_results=top_k
    )
    return results['documents'][0]


def rerank(query: str, retrieved_chunks: List[str], top_k: int = 3) -> List[str]:
    pairs = [(query, chunk) for chunk in retrieved_chunks]
    scores = cross_encoder.predict(pairs)
    chunk_with_score_list = sorted(
        zip(retrieved_chunks, scores), key=lambda pair: pair[1], reverse=True
    )
    return [chunk for chunk, _ in chunk_with_score_list[:top_k]]


def generate(query: str, chunks: List[str]) -> str:
    if not chunks:
        return '抱歉，我沒有找到相關資料。'

    prompt = f"""你是一位股票學習知識助手，請根據用戶問題和下列片段生成準確地回答。

用戶問題: {query}

相關片段:
{'\n\n'.join(chunks)}

請基於上述內容作答，不能編造信息。"""

    response = google_client.models.generate_content(
        model='gemini-2.5-flash', contents=prompt
    )
    return response.text


# === 新聞摘要專用 ===
def generate_news_summary(chunks: List[str]) -> str:
    if not chunks:
        return '抱歉，沒有找到相關新聞內容。'

    prompt = f"""你是一位金融新聞分析助手，請閱讀以下新聞並統整出重點。
強調該股票可能的市場影響與投資人應注意的事項，不要逐字抄寫。
請將回答整理成 3 個重點，並使用條列式清單（如 1. 2. 3.）。
請在每個重點的開頭加上相關的**新聞標題**，接著再分析其**市場影響**和**投資人應注意**事項，並在每個重點的結尾附上 Markdown 超連結格式的**完整新聞連結**。
請將回答控制在250字內，簡潔明瞭。最後一段使用****並且30字內將全部投資建議說清楚：
{'\n\n'.join(chunks)}
"""

    response = google_client.models.generate_content(
        model='gemini-2.5-flash', contents=prompt
    )
    return response.text


def get_stock_news(stock_id: str, days: int = 3) -> str:
    try:
        if not FINMIND_TOKEN:
            return '未設定 FinMind API Token，無法查詢新聞。'
        start_date = (datetime.today() - timedelta(days=days)).strftime('%Y-%m-%d')
        url = 'https://api.finmindtrade.com/api/v4/data'
        params = {
            'dataset': 'TaiwanStockNews',
            'data_id': stock_id,
            'start_date': start_date,
            'token': FINMIND_TOKEN,
        }
        resp = requests.get(url, params=params).json()
        if not resp.get('data'):
            return '最近沒有相關新聞'

        # 整理新聞標題、內文與連結
        news_items = resp['data'][:5]  # 最多 5 則
        chunks = [
            f'標題: {item["title"]} ({item["date"]})\n連結: {item["link"]}\n內文: {item.get("content", "")}'
            for item in news_items
        ]

        # 呼叫專用的新聞摘要生成器
        return generate_news_summary(chunks)

    except Exception as e:
        return f'取得新聞失敗: {str(e)}'


# === 文件切片與寫入 ChromaDB ===
def split_into_chunks(
    file_path: str, chunk_size: int = 300, overlap: int = 50
) -> List[str]:
    """讀取 .md 文件並切片"""
    with open(file_path, 'r', encoding='utf-8') as f:
        text = f.read()

    tokens = re.split(r'(?<=[。！？\n])', text)
    chunks, current_chunk = [], []

    for sentence in tokens:
        if sum(len(s) for s in current_chunk) + len(sentence) > chunk_size:
            chunks.append(''.join(current_chunk))
            current_chunk = current_chunk[-overlap:]
        current_chunk.append(sentence)
    if current_chunk:
        chunks.append(''.join(current_chunk))
    return chunks


def save_embeddings(chunks: List[str], embeddings: List[List[float]]):
    ids = [str(uuid.uuid4()) for _ in chunks]
    chromadb_collection.add(ids=ids, documents=chunks, embeddings=embeddings)


def embed_chunks(chunks: List[str]) -> List[List[float]]:
    return [embed_chunk(chunk) for chunk in chunks]


# === 路由 ===
@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    query = data.get('query', '').strip()
    stock_id = None
    # 股票新聞
    if '新聞' in query:
        # 1. 檢查是否包含股票名稱
        for name, id in STOCK_DATA.items():
            if name in query:
                stock_id = id
                break

        # 2. 如果沒有匹配到名稱，則檢查是否包含四位數代碼
        if not stock_id:
            match = re.search(r'(\d{4})', query)
            if match:
                stock_id = match.group(1)

        # 3. 如果找到了股票代碼，則查詢新聞
        if stock_id:
            news = get_stock_news(stock_id)
            return jsonify({'answer': news})
        else:
            return jsonify({'answer': '抱歉，我無法辨識您想查詢的新聞股票名稱或代碼。'})

    # RAG
    retrieved_chunks = retrieve(query, 5)
    reranked_chunks = rerank(query, retrieved_chunks, 3)
    answer = generate(query, reranked_chunks)

    return jsonify({'answer': answer})


if __name__ == '__main__':
    # 1. 載入文件並分割
    file_path = '文件.md'
    if os.path.exists(file_path):
        chunks = split_into_chunks(file_path)
        # 2. 轉為向量並儲存
        embeddings = embed_chunks(chunks)
        save_embeddings(chunks, embeddings)

        # 3. 測試查詢
        query = '平均線是甚麼??'
        retrieved_chunks = retrieve(query, top_k=5)
        reranked_chunks = rerank(query, retrieved_chunks, top_k=3)

        # 4. 生成回答
        answer = generate(query, reranked_chunks)
        print('\n📘 測試查詢回答：\n', answer)
    else:
        print(f'⚠️ 找不到文件 {file_path}，略過 RAG 初始化')

    # 啟動 Flask
    app.run(host='0.0.0.0', port=5000, debug=True)
