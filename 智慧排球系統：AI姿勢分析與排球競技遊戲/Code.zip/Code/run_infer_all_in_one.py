# run_infer_all_in_one.py — 進度條 / 中文標籤 / 相容 mediapipe / 自動產生 npz / 門檻判定
import os, sys, glob, csv
import numpy as np
import cv2
import torch
import torch.nn as nn
import mediapipe as mp
from PIL import Image, ImageDraw, ImageFont

# ========== 進度條 ==========
try:
    from tqdm import tqdm
except Exception:
    class tqdm:
        def __init__(self, iterable=None, total=None, desc=None, unit=None, leave=True):
            self.iterable, self.total, self.count = iterable, total, 0
        def update(self, n=1): self.count += n
        def __iter__(self):
            if self.iterable is None: return iter(range(self.total or 0))
            for x in self.iterable: yield x
        def close(self): pass

# ========== 音效 ==========
def ding():
    try:
        import winsound
        winsound.Beep(880, 200); winsound.Beep(988, 200)
    except Exception:
        print("\a", end="")

# ========= 字型設定 =========
FONT_PATH = r"C:\Windows\Fonts\msjh.ttc"
FONT_SIZE = 40

# ========= 路徑配置 =========
BASE_DIR   = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1"
MODEL_DIR  = os.path.join(BASE_DIR, "model_files")
INPUT_DIR  = os.path.join(BASE_DIR, "input_videos")
OUTPUT_DIR = os.path.join(BASE_DIR, "output_results")

# ========= 推論參數 =========
WIN               = 30
SMOOTH_N          = 5
DRAW_SKELETON     = True
FILL_MISSING      = "last"
VALID_EXTS        = (".mp4", ".mov", ".avi", ".mkv")
LABEL_MAP         = {0: "錯誤", 1: "正確"}
SKIP_IF_EXISTS    = True
WRITE_PERFRAME_CSV= True
THRESH_CORRECT    = 0.70   # ★ p_correct >= 0.70 視為「正確」

# ========= Mediapipe 相容處理 =========
try:
    from mediapipe.solutions import drawing_styles as mp_styles
except Exception:
    mp_styles = None

# ========= 模型結構 =========
class TCNBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, d=1, p=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_ch, out_ch, kernel_size=k, padding=d*(k-1)//2, dilation=d),
            nn.ReLU(), nn.Dropout(p),
            nn.Conv1d(out_ch, out_ch, kernel_size=k, padding=d*(k-1)//2, dilation=d),
        )
        self.res = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.act = nn.ReLU()
    def forward(self, x): return self.act(self.net(x) + self.res(x))

class TCNClassifier(nn.Module):
    def __init__(self, in_feats=132, num_classes=2):
        super().__init__()
        chs = [in_feats, 256, 256]; dilations = [1, 2]
        blocks = [TCNBlock(chs[i], chs[i+1], k=3, d=dilations[i], p=0.3) for i in range(len(chs)-1)]
        self.backbone = nn.Sequential(*blocks)
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Dropout(0.3), nn.Linear(chs[-1], num_classes)
        )
    def forward(self, x): return self.head(self.backbone(x))

# ========= 小工具 =========
def ensure_dir(p): os.makedirs(p, exist_ok=True)

def list_videos(input_dir):
    vids = []
    for ext in VALID_EXTS:
        vids.extend(glob.glob(os.path.join(input_dir, f"*{ext}")))
    return sorted(vids)

def flatten_landmarks(lms):
    xs, ys, zs, vs = [], [], [], []
    for lm in lms:
        xs.append(lm.x); ys.append(lm.y); zs.append(lm.z); vs.append(lm.visibility)
    return np.array(xs + ys + zs + vs, dtype=np.float32)

def newest(paths):
    if not paths: return None
    paths = [(p, os.path.getmtime(p)) for p in paths]
    paths.sort(key=lambda x: x[1], reverse=True)
    return paths[0][0]

def extract_fold_num(path):
    import re
    name = os.path.basename(path).lower()
    m = re.search(r"fold(\d+)", name)
    return int(m.group(1)) if m else None

def put_text_zh(bgr, text, xy=(20, 40), font_path=FONT_PATH, font_size=FONT_SIZE, color=(0,255,0)):
    if not os.path.exists(font_path):
        cv2.putText(bgr, text.encode('ascii','ignore').decode('ascii'),
                    xy, cv2.FONT_HERSHEY_SIMPLEX, 1.1, color, 2, cv2.LINE_AA)
        return bgr
    img_pil = Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    font = ImageFont.truetype(font_path, font_size)
    r, g, b = int(color[2]), int(color[1]), int(color[0])
    draw.text(xy, text, font=font, fill=(r, g, b))
    return cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)

# ========= 自動生成標準化檔 =========
def make_norm_from_videos(video_dir, save_path):
    print("⚙️ 未找到 npz，開始自動生成標準化參數...")
    mp_pose = mp.solutions.pose
    all_feats = []
    with mp_pose.Pose(static_image_mode=False, model_complexity=2,
                      min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        # ✅ 修正錯誤：改成 tuple 傳入 endswith
        files = [f for f in os.listdir(video_dir) if f.lower().endswith(tuple(ext.lower() for ext in VALID_EXTS))]
        for fn in tqdm(files, desc="掃描影片抽關鍵點", unit="檔"):
            path = os.path.join(video_dir, fn)
            cap = cv2.VideoCapture(path)
            if not cap.isOpened(): continue
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or None
            bar = tqdm(total=total, desc=f"  讀取 {fn}", unit="f", leave=False)
            while True:
                ok, frame = cap.read()
                if not ok: break
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                res = pose.process(rgb)
                if res.pose_landmarks:
                    feat = flatten_landmarks(res.pose_landmarks.landmark)
                    all_feats.append(feat)
                bar.update(1)
            bar.close(); cap.release()

    if not all_feats:
        raise RuntimeError("❌ 無法生成 npz，沒有擷取到任何關鍵點。")

    X = np.stack(all_feats, axis=0)
    mu  = X.mean(axis=0, keepdims=True).reshape(1,1,132)
    std = X.std(axis=0,  keepdims=True).reshape(1,1,132)
    np.savez(save_path, mu=mu, std=std)
    print(f"✅ 已自動生成標準化檔：{save_path}")
    return save_path

# ========= 模型載入 =========
def pick_model_and_norm(model_dir):
    models = glob.glob(os.path.join(model_dir, "*.pt"))
    norms  = glob.glob(os.path.join(model_dir, "*.npz"))
    if not models: raise FileNotFoundError(f"❌ 找不到模型檔（.pt）：{model_dir}")
    if not norms:  return newest(models), None
    for m in sorted(models):
        mf = extract_fold_num(m)
        for n in norms:
            nf = extract_fold_num(n)
            if mf and nf and mf == nf:
                return m, n
    return newest(models), newest(norms)

def load_model_and_norm(model_pt, norm_npz, device):
    model = TCNClassifier(in_feats=132, num_classes=2).to(device)
    state = torch.load(model_pt, map_location=device)
    model.load_state_dict(state); model.eval()
    norm = np.load(norm_npz)
    mu  = norm["mu"].astype(np.float32).squeeze()
    std = norm["std"].astype(np.float32).squeeze()
    return model, mu, std

# ========= 影片推論 =========
def process_video(in_path, out_dir, model, mu, std, device):
    mp_pose = mp.solutions.pose
    mp_draw = mp.solutions.drawing_utils

    base = os.path.splitext(os.path.basename(in_path))[0]
    out_mp4 = os.path.join(out_dir, f"{base}_annotated.mp4")
    out_csv = os.path.join(out_dir, f"{base}_probs.csv")

    if SKIP_IF_EXISTS and os.path.exists(out_mp4):
        print(f"⏩ 跳過（已存在）：{out_mp4}")
        return True

    cap = cv2.VideoCapture(in_path)
    if not cap.isOpened():
        print(f"⚠️ 無法開啟影片：{in_path}")
        return False

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or None

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(out_mp4, fourcc, float(fps), (w, h))

    buf, prob_hist, per_frame_rows = [], [], []
    last_feat = np.zeros(132, dtype=np.float32)
    bar = tqdm(total=total, desc=f"處理 {os.path.basename(in_path)}", unit="f")

    with mp_pose.Pose(static_image_mode=False, model_complexity=2,
                      min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        fidx = 0
        while True:
            ok, frame = cap.read()
            if not ok: break
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            res = pose.process(rgb)

            # 畫骨架
            if res.pose_landmarks and DRAW_SKELETON:
                lspec = cspec = None
                if mp_styles is not None:
                    if hasattr(mp_styles, "get_default_pose_landmarks_style"):
                        try: lspec = mp_styles.get_default_pose_landmarks_style()
                        except: pass
                    if hasattr(mp_styles, "get_default_pose_connections_style"):
                        try: cspec = mp_styles.get_default_pose_connections_style()
                        except: pass
                if lspec is None: lspec = mp_draw.DrawingSpec(thickness=2, circle_radius=2)
                if cspec is None: cspec = mp_draw.DrawingSpec(thickness=2)
                mp_draw.draw_landmarks(frame, res.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                       landmark_drawing_spec=lspec, connection_drawing_spec=cspec)

            if res.pose_landmarks:
                feat = flatten_landmarks(res.pose_landmarks.landmark)
                last_feat = feat
            else:
                feat = last_feat if FILL_MISSING == "last" else np.zeros(132, dtype=np.float32)

            buf.append(feat)
            if len(buf) > WIN: buf.pop(0)

            if len(buf) == WIN:
                X = np.stack(buf, axis=0)
                X = (X - mu) / (std + 1e-6)
                xt = torch.from_numpy(X.T).unsqueeze(0).to(device)
                with torch.no_grad():
                    prob = torch.softmax(model(xt), dim=1).cpu().numpy()[0]
                prob_hist.append(prob)
                if len(prob_hist) > SMOOTH_N: prob_hist.pop(0)
                prob_s = np.mean(prob_hist, axis=0)

                p_wrong, p_correct = float(prob_s[0]), float(prob_s[1])
                is_correct = (p_correct >= THRESH_CORRECT)
                label_text = "正確" if is_correct else "錯誤"
                color = (0,255,0) if is_correct else (0,0,255)
                txt = f"Pred: {label_text} (p={p_correct:.2f})"
                frame = put_text_zh(frame, txt, xy=(20,40), color=color)

                if WRITE_PERFRAME_CSV:
                    per_frame_rows.append([fidx, int(is_correct), f"{p_correct:.4f}", f"{p_wrong:.4f}"])
            else:
                if WRITE_PERFRAME_CSV:
                    per_frame_rows.append([fidx, "", "", ""])

            writer.write(frame); fidx += 1
            bar.update(1)

    bar.close(); cap.release(); writer.release()
    print(f"🎞️ 輸出：{out_mp4}")

    if WRITE_PERFRAME_CSV:
        with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerows([["frame_index", "pred_is_correct(1/0)", "p_correct", "p_wrong"]] + per_frame_rows)
        print(f"📄 機率CSV：{out_csv}")
    return True

# ========= 主程式 =========
def main():
    print("=== 🧠 自動辨識啟動（門檻：p_correct >= %.2f 視為正確） ===" % THRESH_CORRECT)
    for d in (MODEL_DIR, INPUT_DIR, OUTPUT_DIR): ensure_dir(d)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model_pt, norm_npz = pick_model_and_norm(MODEL_DIR)
    print("使用模型：", model_pt)
    if not norm_npz:
        norm_npz = os.path.join(MODEL_DIR, "norm_auto.npz")
        make_norm_from_videos(INPUT_DIR, norm_npz)
    print("使用標準化：", norm_npz)

    model, mu, std = load_model_and_norm(model_pt, norm_npz, device)
    videos = list_videos(INPUT_DIR)
    if not videos:
        print("❌ 沒有影片可辨識"); return

    ok = fail = 0
    for v in videos:
        try:
            ok += int(process_video(v, OUTPUT_DIR, model, mu, std, device))
        except Exception as e:
            print(f"❌ 失敗：{v} -> {e}"); fail += 1

    print(f"=== 完成 ✅ 成功 {ok} 支；失敗 {fail} 支 ===")
    print(f"輸出路徑：{OUTPUT_DIR}")
    ding()

if __name__ == "__main__":
    main()
