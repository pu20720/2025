# -*- coding: utf-8 -*-
# LoRA on Breeze-7B-Instruct with messages(jsonl) + chat template + assistant-only loss
# 4bit 量化 + FlashAttention2(可選) + label masking
import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM, AutoTokenizer, TrainingArguments, Trainer, BitsAndBytesConfig
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

print(torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU(s):", torch.cuda.device_count(), torch.cuda.get_device_name(0))

# ========= 基本路徑 =========
model_path = "F:/test/model/models--MediaTek-Research--Breeze-7B-Instruct-v1_0"
data_path  = "F:/test/try.jsonl"  # 一行一筆，key = "messages"

# ========= Tokenizer =========
tokenizer = AutoTokenizer.from_pretrained(model_path, use_fast=True)
# 有些模型沒有 pad，統一用 eos 當 pad
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

# ========= 4-bit 量化設定 =========
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=torch.float16,  # 若 BF16 不穩，維持 FP16 計算
)

# ========= 載入模型 =========
model = AutoModelForCausalLM.from_pretrained(
    model_path,
    quantization_config=quantization_config,
    device_map="auto",
    torch_dtype=torch.bfloat16,            # 若報不支援，改成 torch.float16
    attn_implementation="flash_attention_2"  # 若環境不支援，移除此參數
)

# 4bit 微調前置（需要讓量化權重可訓練）
model = prepare_model_for_kbit_training(model)
# 一些模型需要這行確保輸入能求梯度
if hasattr(model, "enable_input_require_grads"):
    model.enable_input_require_grads()

# ========= LoRA 設定 =========
# 顯存吃緊r 調小、縮減 target_modules
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.05,
    bias="none",
    target_modules=[
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj"
    ],
    task_type="CAUSAL_LM",
)
model = get_peft_model(model, lora_config)

# ========= 載入資料 =========

raw_ds = load_dataset("json", data_files=data_path)
ds = raw_ds["train"]

# ========= 轉換成可訓練樣本 =========

def build_example(example):
    msgs = example["messages"]
    assert isinstance(msgs, list) and len(msgs) >= 2, "messages 至少要含 user/assistant"

  
    last_ass_idx = None
    for i in range(len(msgs) - 1, -1, -1):
        if msgs[i].get("role") == "assistant":
            last_ass_idx = i
            break
    if last_ass_idx is None:
       
        return {"input_ids": [], "labels": [], "attention_mask": []}

    
    prefix_msgs = msgs[:last_ass_idx]
    
    answer_text = msgs[last_ass_idx]["content"] + tokenizer.eos_token

    
    prefix_text = tokenizer.apply_chat_template(
        prefix_msgs, tokenize=False, add_generation_prompt=True
    )
    full_text = prefix_text + answer_text

    # tokenization
    tokenized = tokenizer(
        full_text,
        truncation=True,
        max_length=1024,          # 若顯存不足可降到 512
        padding="max_length"
    )
    input_ids = tokenized["input_ids"]
    attn = tokenized["attention_mask"]

    
    prefix_tok = tokenizer(
        prefix_text, truncation=True, max_length=1024, padding=False
    )
    answer_tok = tokenizer(
        answer_text, truncation=True, max_length=1024, padding=False
    )
    prefix_len = len(prefix_tok["input_ids"])

    labels = [-100] * len(input_ids)
    
    for i in range(prefix_len, min(prefix_len + len(answer_tok["input_ids"]), len(labels))):
        labels[i] = input_ids[i]

    return {
        "input_ids": input_ids,
        "labels": labels,
        "attention_mask": attn
    }

processed = ds.map(build_example, remove_columns=ds.column_names)

processed = processed.filter(lambda ex: len(ex["input_ids"]) > 0)

# ========= 訓練參數 =========
training_args = TrainingArguments(
    output_dir="F:/loratr",
    per_device_train_batch_size=1,
    gradient_accumulation_steps=16,
    num_train_epochs=3,
    learning_rate=2e-4,
    warmup_ratio=0.03,
    lr_scheduler_type="cosine",
    logging_dir="./logs",
    logging_steps=50,
    save_steps=500,
    save_total_limit=3,
    bf16=True,                    # 若 GPU 不支援 BF16，改 fp16=True
    optim="paged_adamw_8bit",     # 
    gradient_checkpointing=True,  # 降顯存
    report_to="none"
)

# ========= Trainer =========
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=processed,
)

trainer.train()

# ========= 儲存 =========
# 儲存 LoRA adapter 與 tokenizer（基座權重不會被覆寫）
model.save_pretrained("F:/lora-mr-breeze-7b")
tokenizer.save_pretrained("F:/lora-mr-breeze-7b")

print("Done. LoRA adapter saved to F:/lora-mr-breeze-7b")
