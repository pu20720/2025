from django.db import models

# Create your models here.


class TechnicalIndicator(models.Model):
    id = models.AutoField(primary_key=True)
    stock = models.ForeignKey(
        'stocks.Stock', on_delete=models.CASCADE, related_name='technical_indicators'
    )  # 關聯到股票
    date = models.DateField()  # 日期
    ma_5 = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True
    )  # 50日移動平均線
    ma_20 = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True
    )  # 20日移動平均線
    ma_60 = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True
    )  # 60日移動平均線
    rsi_5 = models.DecimalField(
        max_digits=5, decimal_places=2, blank=True, null=True
    )  # 5日相對強弱指標
    rsi_10 = models.DecimalField(
        max_digits=5, decimal_places=2, blank=True, null=True
    )  # 10日相對強弱指標
    dif = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True
    )  # MACD   (快線)
    macd = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True
    )  # MACD 信號線(慢線)
    osc = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True
    )  # MACD 柱狀圖
    kd_k = models.DecimalField(
        max_digits=5, decimal_places=2, blank=True, null=True
    )  # KD 指標 K 值
    kd_d = models.DecimalField(
        max_digits=5, decimal_places=2, blank=True, null=True
    )  # KD 指標 D 值

    def __str__(self):
        return f'{self.stock_id.symbol} - {self.date}'
