import logging
from stocks.models import Stock


def get_stocks_data(keyword=None) -> list:
    logger = logging.getLogger(__name__)
    try:
        queryset = Stock.objects.all()

        if keyword:
            queryset = queryset.filter(symbol__icontains=keyword)

        return list(queryset.values())  # list of dicts
    except Exception as e:
        logger.error(f'[Stock] 資料查詢失敗 {e}')
        return []
