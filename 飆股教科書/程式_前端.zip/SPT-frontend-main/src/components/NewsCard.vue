<script setup>
    import { useNews } from '@/stores/news'
    import { ref, onMounted, watchEffect } from 'vue'

    const { newsList, loading, loadNews } = useNews()

    const mainNews = ref(null)

    onMounted(() => {
        loadNews()
    })

    watchEffect(() => {
        if (loading.value || !newsList.value || newsList.value.length === 0) {
            mainNews.value = {
                image: 'https://placehold.co/600x400?text=No+Image',
                text: '請稍候，新聞資料載入中...',
                link: '#',
            }
            return
        }

        const found = newsList.value.find((item) => item.image && item.image.trim() !== '')

        if (found) {
            mainNews.value = found
        } else {
            mainNews.value = {
                image: 'https://placehold.co/600x400?text=No+Image',
                text: newsList.value[0].text,
                link: newsList.value[0].link,
            }
        }
    })
</script>

<template>
    <section class="page-section flex items-center justify-center min-h-screen bg-white px-0">
        <div
            class="flex flex-col md:flex-row justify-between items-start p-10 rounded-xl shadow-md max-w-[1200px] w-[90%] bg-white"
        >
            <div class="w-full md:w-1/2 flex flex-col items-center">
                <h2 class="font-bold mb-3 text-center text-xl w-full">
                    {{ mainNews.text }}
                </h2>

                <a :href="mainNews.link" target="_blank" class="w-full block transition-opacity">
                    <img
                        :src="mainNews.image"
                        :alt="mainNews.text"
                        class="w-full rounded-lg mb-3 object-cover"
                    />
                </a>
            </div>

            <div
                class="w-full md:w-1/2 flex flex-col justify-start items-start mt-6 md:mt-0 md:pl-8 text-center"
            >
                <h3 class="font-semibold mb-3 text-lg text-gray-700 w-full text-center">
                    最新新聞列表
                </h3>

                <div v-if="loading" class="text-gray-500 w-full text-center py-10">
                    資料載入中，請稍候...
                </div>

                <ul v-else class="pl-0 text-base leading-relaxed w-full flex flex-col items-start">
                    <li
                        v-for="(item, index) in newsList"
                        :key="index"
                        class="list-none mb-2 text-left"
                    >
                        <a
                            :href="item.link"
                            target="_blank"
                            class="no-underline text-gray-800 transition-all duration-150 hover:text-sky-600 active:scale-95 before:content-['›_']"
                        >
                            {{ item.text }}
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </section>
</template>
