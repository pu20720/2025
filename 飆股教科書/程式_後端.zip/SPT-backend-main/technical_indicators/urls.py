from django.urls import path
from .views import (
    MA5View,
    MA20View,
    MA60View,
    RSI5View,
    RSI10View,
    MACDView,
    KDView,
)

urlpatterns = [
    path(
        'ma5',
        MA5View.as_view(),
        name='ma5',
    ),
    path(
        'ma20',
        MA20View.as_view(),
        name='ma20',
    ),
    path(
        'ma60',
        MA60View.as_view(),
        name='ma60',
    ),
    path(
        'rsi5',
        RSI5View.as_view(),
        name='rsi5',
    ),
    path(
        'rsi10',
        RSI10View.as_view(),
        name='rsi10',
    ),
    path(
        'macd',
        MACDView.as_view(),
        name='macd',
    ),
    path(
        'kd',
        KDView.as_view(),
        name='kd',
    ),
]
