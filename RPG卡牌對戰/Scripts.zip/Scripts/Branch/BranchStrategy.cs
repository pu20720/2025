// 檔案路徑: Assets/Scripts/SceneManagers/Branch/BranchStrategy.cs
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 戰鬥分支策略的「抽象基底類別」
/// 所有分支 (Knight, Adventurer, Assassin) 都必須繼承此類別
/// </summary>
public abstract class BranchStrategy
{
    // 1. 內部引用 (由 BattleManager 設置)
    protected BattleManager battleManager;
    protected Character player;
    protected List<Character> enemies;

    /// <summary>
    /// 初始化策略 (由 BattleManager 在 Awake 時呼叫)
    /// </summary>
    public virtual void Initialize(BattleManager battleManager, Character player, List<Character> enemies)
    {
        this.battleManager = battleManager;
        this.player = player;
        this.enemies = enemies;
    }

    // 2. 事件掛鉤 (Event Hooks)
    public abstract void OnBattleStart();
    public abstract void OnPlayerTurnStart();
    public abstract void OnEnemyAction(EnemyAI ai, Character playerTarget);
    public abstract void OnUpdate();

    // 3. UI 掛鉤 (UI Hooks)
    public abstract void OnDialoguePanelClicked();

    // 4. 驗證掛鉤 (Validation Hooks)
    public abstract bool ValidateCardClick(CardData card);
    public abstract bool ValidateEndTurn();

    // 5. 覆蓋掛鉤 (Override Hooks)
    public abstract bool HandleTargetClick(CardData card, TargetIndicator target);

    // 6. 勝利/失敗掛鉤
    public abstract bool CheckForSpecialBattleEnd(out bool playerWon);

    // 7. 抽牌掛鉤
    public abstract bool CanDrawCards();

    // ▼▼▼ 【新增】存檔/讀檔系統所需 ▼▼▼

    /// <summary>
    /// (用於儲存) 獲取目前教學步驟的字串名稱 (例如 "WaitForCleave")
    /// </summary>
    public abstract string GetCurrentTutorialStepName();

    /// <summary>
    /// (用於讀取) 根據字串名稱，強制設定教學步驟
    /// </summary>
    public abstract void SetCurrentTutorialStep(string stepName);

    // ▲▲▲ 【新增結束】 ▲▲▲
}