# evaluate_pose.py
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# ========================
# Model 定義 (要跟 train_pose_model.py 相同)
# ========================
class TCNBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, d=1, p=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_ch, out_ch, kernel_size=k,
                      padding=d*(k-1)//2, dilation=d),
            nn.ReLU(),
            nn.Dropout(p),
            nn.Conv1d(out_ch, out_ch, kernel_size=k,
                      padding=d*(k-1)//2, dilation=d),
        )
        self.res = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(self.net(x) + self.res(x))

class TCNClassifier(nn.Module):
    def __init__(self, in_feats=132, num_classes=2):
        super().__init__()
        chs = [in_feats, 256, 256]
        dilations = [1, 2]
        blocks = []
        for i in range(len(chs)-1):
            blocks.append(TCNBlock(chs[i], chs[i+1], k=3, d=dilations[i], p=0.3))
        self.backbone = nn.Sequential(*blocks)
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(chs[-1], num_classes)
        )

    def forward(self, x):
        h = self.backbone(x)
        return self.head(h)

# ========================
# Evaluation
# ========================
def evaluate(npz_path, model_path):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 1) 載入資料
    d = np.load(npz_path, allow_pickle=True)
    X, Y = d["X"], d["Y"]
    print("Dataset shape:", X.shape, Y.shape)

    # 2) 用全資料計算 mu, std (這裡應該跟 train 一致)
    mu = X.mean(axis=(0,1), keepdims=True)
    std = X.std(axis=(0,1), keepdims=True) + 1e-6
    X = (X - mu) / std

    # 3) 轉成 (N, F, T)
    X = torch.from_numpy(X.astype(np.float32).transpose(0,2,1)).to(device)
    Y = torch.from_numpy(Y.astype(np.int64)).to(device)

    # 4) 載入模型
    model = TCNClassifier(in_feats=X.shape[1], num_classes=2).to(device)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()

    # 5) 預測
    with torch.no_grad():
        out = model(X)
        pred = out.argmax(1)

    # 6) 評估
    acc = accuracy_score(Y.cpu(), pred.cpu())
    f1 = f1_score(Y.cpu(), pred.cpu(), average="macro")
    cm = confusion_matrix(Y.cpu(), pred.cpu())

    print(f"Accuracy: {acc:.3f}, Macro-F1: {f1:.3f}")
    print("Confusion Matrix:\n", cm)

    # 7) 繪製混淆矩陣
    plt.figure(figsize=(5,4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["wrong","correct"],
                yticklabels=["wrong","correct"])
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title("Confusion Matrix")
    plt.show()

    return acc, f1, cm


if __name__ == "__main__":
    npz_path = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\dataset_underhandpass_test.npz"
    model_path = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\best_model_fold1.pt"

    evaluate(npz_path, model_path)
