import cv2 as cv, numpy as np, argparse, os, math, csv, sys

# ===== コート寸法（m）=====
COURT_W = 6.10
COURT_L = 13.40
SGL_W   = 5.18
NET_Y   = COURT_L / 2.0
SVC_SHORT = 1.98                 # ネットから短サーブ線まで
DBL_LONG  = 0.76                 # エンドからダブルス長サーブ線まで
LINE_WIDTH_M = 0.04              # 実線幅 ≈40mm

# ===== 回転ユーティリティ =====
def rotate_frame(img, mode):
    if mode == "none": return img
    tbl={"cw":cv.ROTATE_90_CLOCKWISE,"ccw":cv.ROTATE_90_COUNTERCLOCKWISE,"180":cv.ROTATE_180}
    return cv.rotate(img, tbl[mode])

# ===== コート線（モデル平面上）=====
def build_court_lines():
    lines = []
    # 外枠（閉じたポリライン：左辺が消える問題対応）
    outer = np.array([[0,0],[COURT_W,0],[COURT_W,COURT_L],[0,COURT_L]], np.float32) #外框線
    lines.append(("poly", outer))
    # シングルサイド
    off = (COURT_W - SGL_W)/2.0
    xL, xR = off, COURT_W-off
    lines += [("seg", np.array([[xL,0],[xL,COURT_L]],np.float32)),
              ("seg", np.array([[xR,0],[xR,COURT_L]],np.float32))] #單打線
    # 短サーブ線
    y1, y2 = NET_Y - SVC_SHORT, NET_Y + SVC_SHORT
    lines += [("seg", np.array([[0,y1],[COURT_W,y1]],np.float32)),
              ("seg", np.array([[0,y2],[COURT_W,y2]],np.float32))] #發球線
    # 中央線
    cx = COURT_W/2.0
    lines.append(("seg", np.array([[cx,0],[cx,COURT_L]],np.float32)))
    # ダブルス長サーブ線
    lines += [("seg", np.array([[0,DBL_LONG],[COURT_W,DBL_LONG]],np.float32)),
              ("seg", np.array([[0,COURT_L-DBL_LONG],[COURT_W,COURT_L-DBL_LONG]],np.float32))] #雙打發球線
    return lines

# ===== モデル->画像 投影 =====
def to_image_points(H_model2img, pts_model):
    pts = pts_model.reshape(-1,1,2).astype(np.float32)
    out = cv.perspectiveTransform(pts, H_model2img).reshape(-1,2) #將模型座標變csv
    return out

def draw_court(img, H_model2img, thickness=2, color=(0,255,0)): #停止後的畫面點線部分
    for kind, data in build_court_lines():
        pts_img = to_image_points(H_model2img, data)
        pts_i = np.round(pts_img).astype(np.int32)
        if kind == "poly":
            cv.polylines(img, [pts_i], isClosed=True, color=color, thickness=thickness, lineType=cv.LINE_AA)
        else:
            cv.line(img, tuple(pts_i[0]), tuple(pts_i[1]), color, thickness, cv.LINE_AA)

# ===== コート自動検出（外枠のみ使う軽量版）=====
def auto_detect_outer_corners(img):                                          #自動偵測外場框
    blur = cv.GaussianBlur(img, (5,5), 0)
    hsv = cv.cvtColor(blur, cv.COLOR_BGR2HSV)
    mask_w = cv.inRange(hsv, (0,0,200), (180,40,255))   #找白色線
    mask_y = cv.inRange(hsv, (15,60,150), (40,255,255))  #找黃色線
    mask = cv.bitwise_or(mask_w, mask_y)  #只保留羽毛球場的線條
    k = cv.getStructuringElement(cv.MORPH_RECT, (5,5))  
    mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, k, iterations=2)  #補線
    edges = cv.Canny(mask, 50, 150)
    lines = cv.HoughLinesP(edges, 1, np.pi/180, threshold=120,
                           minLineLength=img.shape[1]//5, maxLineGap=30)
    if lines is None: return None  #偵測現有沒有被看到沒有的話直接停止畫線
    horiz, vert = [], []  #橫"直
    for l in lines:
        x1,y1,x2,y2 = l[0]
        ang = abs(math.degrees(math.atan2(y2-y1, x2-x1)))
        if ang < 20 or ang > 160: horiz += [(x1,y1),(x2,y2)]
        elif 70<ang<110:          vert  += [(x1,y1),(x2,y2)]  #調整角度、知道水平或是垂直
    if len(horiz)<10 or len(vert)<10: return None
    yvals = [p[1] for p in horiz]; xvals = [p[0] for p in vert]
    top_y, bot_y = np.percentile(yvals,5),  np.percentile(yvals,95)
    left_x, right_x = np.percentile(xvals,5), np.percentile(xvals,95)  #尋找最上、下、左、右的線
    def near(pts,axis,val): return [p for p in pts if abs(p[axis]-val)<15]  
    top,bot = near(horiz,1,top_y), near(horiz,1,bot_y)
    left,right = near(vert,0,left_x), near(vert,0,right_x)
    if min(map(len,[top,bot,left,right]))<6: return None   #點少消失

    # 直線当てはめ
    def fit(pts, vertical=False):
        a=np.array(pts,np.float32)
        if vertical:
            A=np.vstack([a[:,1], np.ones(len(a))]).T; k,b = np.linalg.lstsq(A,a[:,0],rcond=None)[0]; return (1,-k,-b)
        else:
            A=np.vstack([a[:,0], np.ones(len(a))]).T; k,b = np.linalg.lstsq(A,a[:,1],rcond=None)[0]; return (-k,1,-b)     #用散亂的點成一條直線
    def inter(L1,L2):
        A1,B1,C1=L1; A2,B2,C2=L2; D=A1*B2-A2*B1
        if abs(D)<1e-6: return None  #回傳沒交點
        x=(B1*C2-B2*C1)/D; y=(C1*A2-C2*A1)/D
        return np.array([x,y],np.float32)

    L_top, L_bot = fit(top), fit(bot)  
    L_left, L_right = fit(left,True), fit(right,True)  #有交點後可以合成直線
    TL,TR,BL,BR = inter(L_top,L_left), inter(L_top,L_right), inter(L_bot,L_left), inter(L_bot,L_right)
    if any(p is None for p in [TL,TR,BL,BR]): return None
    return np.array([TL,TR,BR,BL], np.float32)  # 時計回り #任一邊平行，放棄

# ===== コート可視スコア（線が映っているかを簡易判定）=====
def court_presence_score(img, H_model2img, thickness_px=3):   #判斷球線是否清晰
    H,W = img.shape[:2]
    # 1) 投影した外枠が画面内＆面積しきい値
    outer = np.array([[0,0],[COURT_W,0],[COURT_W,COURT_L],[0,COURT_L]],np.float32)
    poly = to_image_points(H_model2img, outer)
    poly_i = np.round(poly).astype(np.int32)
    area = abs(cv.contourArea(poly_i))
    if area < 0.10 * W * H:  # 面積が小さすぎるならNG（しきい値は調整可）
        return 0.0

    # 2) コート線の色マスク（白/黄）に沿ってどれくらい反応があるか
    hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)
    mask_w = cv.inRange(hsv, (0,0,200), (180,40,255))
    mask_y = cv.inRange(hsv, (15,60,150), (40,255,255))
    mask = cv.bitwise_or(mask_w, mask_y)

    # 外枠ポリラインを太さ thickness_px で描いたマスクを作る
    stroke = np.zeros((H,W), np.uint8)
    cv.polylines(stroke, [poly_i], isClosed=True, color=255, thickness=thickness_px)
    on_line = cv.bitwise_and(mask, stroke)
    score = on_line.mean() / 255.0  # 0～1
    return float(score)

# ===== VideoWriter フォールバック =====
def pick_fourcc(path, prefer=None):
    if prefer: return prefer
    return "mp4v" if os.path.splitext(path)[1].lower()==".mp4" else "XVID"

def open_writer(path, fps, size, prefer=None):
    tried=[]
    for code in [pick_fourcc(path, prefer), "avc1", "XVID", "MJPG", "mp4v"]:
        vw = cv.VideoWriter(path, cv.VideoWriter_fourcc(*code), fps, size)
        ok = vw.isOpened()
        print(f"[writer] try FOURCC={code} opened={ok}")
        tried.append(code)
        if ok: return vw
    raise SystemExit(f"VideoWriterを開けません。試行={tried}")

# ===== 手動キャリブレーション（スペースで止めて四隅クリック）=====
_click_pts=[]
def _on_click(event,x,y,flags,param):
    global _click_pts
    img = param
    if event==cv.EVENT_LBUTTONDOWN and len(_click_pts)<4:
        _click_pts.append((x,y))
        cv.circle(img,(x,y),5,(0,0,255),-1)
        cv.imshow("Calibrate", img)

def calibrate_H(cap, rotate_mode):
    print("▶ キャリブレーション：スペースで停止→TL,TR,BR,BL の順に四隅をクリック（ESCで中止）")
    while True:
        ok, frame = cap.read()  #暫停那一frame 
        if not ok:
            raise SystemExit("動画読込が終了しました。コートが映る場面で停止できていません。") #如影片結束後未點擊以及或無偵測到直接放棄
        show = rotate_frame(frame.copy(), rotate_mode)
        cv.putText(show,"SPACE: 停止, ESC:中止",(20,40),cv.FONT_HERSHEY_SIMPLEX,1,(0,255,255),2)  #複製這frame 然後空白暫停、esc離開
        cv.imshow("Calibrate", show) #顯示我點的紅點畫面
        k=cv.waitKey(30)&0xFF
        if k==27: cv.destroyAllWindows(); raise SystemExit("中止") #離開或是暫停 點四腳前
        if k==32:
            img = show.copy()
            break
    cv.destroyAllWindows()  #關然後留那frame

    global _click_pts; _click_pts=[]  #初始不保留上次的
    cv.imshow("Calibrate", img)  #顯示剛剛的那frame
    cv.setMouseCallback("Calibrate", _on_click, img) #綁定 call on_click to param 
    while True:
        cv.imshow("Calibrate", img)   #點的時候可以離開
        k=cv.waitKey(30)&0xFF
        if k==27: cv.destroyAllWindows(); raise SystemExit("中止")
        if len(_click_pts)==4:
            cv.destroyAllWindows(); break
    pts_img = np.array(_click_pts, np.float32) #變數>計算
    # モデル→画像
    pts_model = np.array([[0,0],[COURT_W,0],[COURT_W,COURT_L],[0,COURT_L]], np.float32) #模型四點
    H_m2i, _ = cv.findHomography(pts_model, pts_img, method=0)  #模型四點、人工點的四點、模型座標轉換成影像座標
    return H_m2i

# ===== CSV 読み込み＆IN/OUT計算 =====
def load_csv(csv_path):    #讀取csv做numpy轉換
    frames=[]; pts=[]
    with open(csv_path, newline='', encoding='utf-8') as f:
        r=csv.DictReader(f)
        for row in r:
            frames.append(int(row["frame"]))
            pts.append([float(row["x"]), float(row["y"])])
    return np.array(frames), np.array(pts,np.float32)

def point_line_distance(p, a, b):   #點到線的距離
    p=np.array(p,np.float64); a=np.array(a); b=np.array(b)
    ab=b-a; ap=p-a
    denom=np.dot(ab,ab)
    if denom<1e-12: return np.linalg.norm(ap)
    t=np.clip(np.dot(ap,ab)/denom,0,1)
    proj=a+t*ab
    return float(np.linalg.norm(p-proj))

def build_line_segments_for_dist():   #建立線段
    segs=[]
    # 外枠
    outer=[(0,0),(COURT_W,0),(COURT_W,COURT_L),(0,COURT_L)]
    for i in range(4):
        a=np.array(outer[i],np.float32); b=np.array(outer[(i+1)%4],np.float32)
        segs.append((a,b))
    # シングルサイド/短サーブ/中央/ダブルス長サーブ
    off=(COURT_W-SGL_W)/2.0; xL,xR=off,COURT_W-off
    segs += [(np.array([xL,0],np.float32), np.array([xL,COURT_L],np.float32))]
    segs += [(np.array([xR,0],np.float32), np.array([xR,COURT_L],np.float32))]
    y1,y2=NET_Y-SVC_SHORT, NET_Y+SVC_SHORT
    segs += [(np.array([0,y1],np.float32), np.array([COURT_W,y1],np.float32))]
    segs += [(np.array([0,y2],np.float32), np.array([COURT_W,y2],np.float32))]
    segs += [(np.array([COURT_W/2,0],np.float32), np.array([COURT_W/2,COURT_L],np.float32))]
    segs += [(np.array([0,DBL_LONG],np.float32), np.array([COURT_W,DBL_LONG],np.float32))]
    segs += [(np.array([0,COURT_L-DBL_LONG],np.float32), np.array([COURT_W,COURT_L-DBL_LONG],np.float32))]
    return segs

def compute_inout_for_points(H_img2model, frames, pts_px, mode="singles", margin_cm=3.0):
    pts_m = cv.perspectiveTransform(pts_px.reshape(1,-1,2), H_img2model)[0]
    segs = build_line_segments_for_dist()
    margin_m = max(0.0, margin_cm/100.0)
    results=[]
    for i,(f,p) in enumerate(zip(frames, pts_m)):
        dmin = min(point_line_distance(p, a, b) for (a,b) in segs)
        on_line = dmin <= (LINE_WIDTH_M/2.0 + margin_m)
        x,y = p
        if mode=="singles":
            off=(COURT_W-SGL_W)/2.0
            inside = (off <= x <= COURT_W-off) and (0.0 <= y <= COURT_L)
        else:
            inside = (0.0 <= x <= COURT_W) and (0.0 <= y <= COURT_L)
        results.append((f, p, on_line, inside))
    return results

# ===== メイン =====
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input",  required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--rotate", choices=["none","cw","ccw","180"], default="none")
    ap.add_argument("--H", default=None, help="既存のH(npz: key=H_model2img) を使用")
    ap.add_argument("--saveH", default=None, help="キャリブ後にHを保存するnpzパス")
    ap.add_argument("--calibrate", action="store_true", help="起動時に四隅クリックでHを作る")
    ap.add_argument("--thickness", type=int, default=2)
    ap.add_argument("--fourcc", default=None, help="例: avc1 / XVID / MJPG")
    ap.add_argument("--presence_thresh", type=float, default=0.12, help="線マスクの平均強度 0..1")
    ap.add_argument("--reacquire_every", type=int, default=30, help="Nフレーム毎に可視性が低ければ自動再ロックを試す")
    ap.add_argument("--csv", default=None, help="(任意) frame,x,y のCSVを重ね表示＆IN/OUT判定")
    ap.add_argument("--mode", choices=["singles","doubles"], default="singles")
    ap.add_argument("--margin_cm", type=float, default=3.0)
    args = ap.parse_args()

    cap = cv.VideoCapture(args.input)
    if not cap.isOpened(): raise SystemExit("動画が開けません: "+args.input)
    fps = cap.get(cv.CAP_PROP_FPS) or 30
    ok, first = cap.read()
    if not ok: raise SystemExit("最初のフレームが読めません")
    cap.set(cv.CAP_PROP_POS_FRAMES, 0)
    first_r = rotate_frame(first, args.rotate)
    Hh, Ww = first_r.shape[:2]

    # H を用意（モデル→画像）
    if args.H:
        d = np.load(args.H)
        H_model2img = d["H"] if "H" in d else d["H_model2img"]
        print("[info] 既存Hを使用:", args.H)
    elif args.calibrate:
        H_model2img = calibrate_H(cap, args.rotate)
        if args.saveH:
            np.savez(args.saveH, H=H_model2img, H_model2img=H_model2img)
            print("[info] H を保存:", args.saveH)
        cap.set(cv.CAP_PROP_POS_FRAMES, 0)  # 再生位置を先頭へ
    else:
        # 自動検出で初期ロック
        print("[info] 自動検出で初期ロック中…")
        ok, frame0 = cap.read(); cap.set(cv.CAP_PROP_POS_FRAMES, 0)
        frame0 = rotate_frame(frame0, args.rotate)
        corners = auto_detect_outer_corners(frame0)
        if corners is None:
            raise SystemExit("初期ロック失敗。--calibrate で四隅クリック or --H を指定してください。")
        pts_model = np.array([[0,0],[COURT_W,0],[COURT_W,COURT_L],[0,COURT_L]], np.float32)
        H_model2img = cv.getPerspectiveTransform(pts_model, corners)
        print("[info] 初期ロック完了")

    H_img2model = np.linalg.inv(H_model2img)

    # 出力を開く（フォールバックあり）
    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    writer = open_writer(args.output, fps, (Ww,Hh), prefer=args.fourcc)

    # CSVがあるなら前処理
    csv_frames=None; csv_pts=None; inout_results=None; i_map={}
    if args.csv:
        csv_frames, csv_pts = load_csv(args.csv)
        inout_results = compute_inout_for_points(H_img2model, csv_frames, csv_pts, mode=args.mode, margin_cm=args.margin_cm)
        # frame番号→そのフレームの最新点インデックス
        for idx,f in enumerate(csv_frames): i_map[f]=idx

    presence_bad_streak = 0
    frame_idx=0
    while True:
        ok, frame = cap.read()
        if not ok: break
        img = rotate_frame(frame, args.rotate)

        # コートが映っているか評価
        score = court_presence_score(img, H_model2img, thickness_px=3)
        draw_now = score >= args.presence_thresh

        # 定期的に/見えないときは再ロックを試す
        if (frame_idx % max(1,args.reacquire_every)==0) or (not draw_now):
            corners = auto_detect_outer_corners(img)
            if corners is not None:
                pts_model = np.array([[0,0],[COURT_W,0],[COURT_W,COURT_L],[0,COURT_L]], np.float32)
                H_model2img = cv.getPerspectiveTransform(pts_model, corners)
                H_img2model = np.linalg.inv(H_model2img)
                score = court_presence_score(img, H_model2img, thickness_px=3)
                draw_now = score >= args.presence_thresh

        overlay = img.copy()
        if draw_now:
            draw_court(overlay, H_model2img, thickness=args.thickness, color=(0,255,0))
        else:
            # コートが見えていなければ描かない（顔アップ等の対策）
            pass

        # （任意）CSVの点とIN/OUT表示
        if csv_frames is not None and frame_idx in i_map:
            idx = i_map[frame_idx]
            x,y = map(int, csv_pts[idx])
            cv.circle(overlay, (x,y), 5, (0,0,255), -1)
            f, p_m, on_line, inside = inout_results[idx]
            cv.putText(overlay, f"LINE={on_line}  inside={inside}", (30,50),
                       cv.FONT_HERSHEY_SIMPLEX, 0.9, (0,255,255), 2)

        writer.write(overlay)
        frame_idx += 1
        if frame_idx % 100 == 0:
            print(f"[prog] {frame_idx} frames")

    cap.release(); writer.release()
    print("[done] 出力:", args.output)

if __name__ == "__main__":
    main()