import sys
import os
import json
import subprocess
import threading
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# =========================
# 路徑設定
# =========================
# 這支 launcher_gui.py 放在 F:\test\
BASE_DIR = Path(__file__).resolve().parent

# server.py 放在 F:\test\web\server.py
SERVER_DIR = BASE_DIR / "web"
SERVER_SCRIPT = SERVER_DIR / "server.py"

# 統一的設定檔
CONFIG_PATH = SERVER_DIR / "runtime_config.json"

# =========================
# GUI 顯示用預設值
# =========================
DEFAULT_CONFIG = {
    "LLM_PATH": "F:/test/model/models--MediaTek-Research--Breeze-7B-Instruct-v1_0",
    "LORA_PATH": "F:/lora-mr-breeze-7b",
    "COSYVOICE_PATH": "F:/test/model/CosyVoice/pretrained_models/CosyVoice2-0.5B",
    "ZERO_SHOT_PROMPT_WAV": "F:/test/model/CosyVoice/asset/zero_shot_prompt.wav",

    "BUDGET_CHARS": 150,
    "GRACE_TOKENS": 10,
    "USE_RAG": True,

    "REMOTE_HTTP": "http://192.168.192.32:5080/upload",
    "AUTH_TOKEN": "change-me-very-strong-token",

    "BRIDGE_PUSH_URL": "http://192.168.192.84:8000/push",
}


class LauncherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LLM + TTS 啟動器（啟動 / 套用設定並重啟 server）")
        self.geometry("1100x800")

        self.server_proc: Optional[subprocess.Popen] = None

        
        self.config_data = DEFAULT_CONFIG.copy()
        self._load_config_if_exists()

        
        self.last_user_msg = ""
        self.last_keywords = ""
        self._rag_ctx_collecting = False
        self._rag_ctx_lines = []

        self._build_ui()

    # ---------------- 設定讀取 ----------------
    def _load_config_if_exists(self):
        """程式啟動時，如果有 runtime_config.json，就讀進來當起始值。"""
        if not CONFIG_PATH.is_file():
            return
        try:
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                
                self.config_data.update(data)
        except Exception as e:
            
            print(f"[Launcher] 讀取設定檔失敗，改用預設值：{e}")

    # ---------------- UI ----------------
    def _build_ui(self):
        # === 上方：設定區 ===
        frm_cfg = ttk.LabelFrame(self, text="啟動設定（寫入 runtime_config.json）")
        frm_cfg.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)
        frm_cfg.columnconfigure(1, weight=1)

        # 綁變數
        self.var_llm = tk.StringVar(value=self.config_data["LLM_PATH"])
        self.var_lora = tk.StringVar(value=self.config_data["LORA_PATH"])
        self.var_cosy = tk.StringVar(value=self.config_data["COSYVOICE_PATH"])
        self.var_prompt = tk.StringVar(value=self.config_data["ZERO_SHOT_PROMPT_WAV"])

        self.var_budget = tk.StringVar(value=str(self.config_data["BUDGET_CHARS"]))
        self.var_grace = tk.StringVar(value=str(self.config_data["GRACE_TOKENS"]))
        self.var_use_rag = tk.BooleanVar(value=self.config_data["USE_RAG"])

        self.var_remote = tk.StringVar(value=self.config_data["REMOTE_HTTP"])
        self.var_auth = tk.StringVar(value=self.config_data["AUTH_TOKEN"])
        self.var_push = tk.StringVar(value=self.config_data["BRIDGE_PUSH_URL"])

        def add_path_row(row, label, var, is_file=True):
            ttk.Label(frm_cfg, text=label, width=20, anchor="e").grid(
                row=row, column=0, padx=5, pady=2, sticky="e"
            )
            entry = ttk.Entry(frm_cfg, textvariable=var)
            entry.grid(row=row, column=1, padx=5, pady=2, sticky="ew")
            btn = ttk.Button(
                frm_cfg,
                text="瀏覽",
                command=lambda: self._browse_path(var, is_file=is_file),
            )
            btn.grid(row=row, column=2, padx=5, pady=2)
            return entry

        r = 0
        add_path_row(r, "LLM_PATH", self.var_llm, is_file=False); r += 1
        add_path_row(r, "LORA_PATH", self.var_lora, is_file=False); r += 1
        add_path_row(r, "COSYVOICE_PATH", self.var_cosy, is_file=False); r += 1
        add_path_row(r, "ZERO_SHOT_PROMPT_WAV", self.var_prompt, is_file=True); r += 1

        ttk.Label(frm_cfg, text="BUDGET_CHARS", width=20, anchor="e").grid(
            row=r, column=0, padx=5, pady=2, sticky="e"
        )
        ttk.Entry(frm_cfg, textvariable=self.var_budget, width=10).grid(
            row=r, column=1, padx=5, pady=2, sticky="w"
        ); r += 1

        ttk.Label(frm_cfg, text="GRACE_TOKENS", width=20, anchor="e").grid(
            row=r, column=0, padx=5, pady=2, sticky="e"
        )
        ttk.Entry(frm_cfg, textvariable=self.var_grace, width=10).grid(
            row=r, column=1, padx=5, pady=2, sticky="w"
        ); r += 1

        ttk.Checkbutton(
            frm_cfg,
            text="啟用 RAG (USE_RAG)",
            variable=self.var_use_rag
        ).grid(row=r, column=1, padx=5, pady=2, sticky="w"); r += 1

        ttk.Label(frm_cfg, text="REMOTE_HTTP", width=20, anchor="e").grid(
            row=r, column=0, padx=5, pady=2, sticky="e"
        )
        ttk.Entry(frm_cfg, textvariable=self.var_remote).grid(
            row=r, column=1, padx=5, pady=2, sticky="ew"
        ); r += 1

        ttk.Label(frm_cfg, text="AUTH_TOKEN", width=20, anchor="e").grid(
            row=r, column=0, padx=5, pady=2, sticky="e"
        )
        ttk.Entry(frm_cfg, textvariable=self.var_auth).grid(
            row=r, column=1, padx=5, pady=2, sticky="ew"
        ); r += 1

        ttk.Label(frm_cfg, text="BRIDGE_PUSH_URL", width=20, anchor="e").grid(
            row=r, column=0, padx=5, pady=2, sticky="e"
        )
        ttk.Entry(frm_cfg, textvariable=self.var_push).grid(
            row=r, column=1, padx=5, pady=2, sticky="ew"
        ); r += 1

        # 按鈕列
        frm_btn = ttk.Frame(frm_cfg)
        frm_btn.grid(row=r, column=0, columnspan=3, pady=8, sticky="ew")
        frm_btn.columnconfigure(0, weight=1)
        frm_btn.columnconfigure(1, weight=1)
        frm_btn.columnconfigure(2, weight=1)

        self.btn_start = ttk.Button(
            frm_btn,
            text="啟動 server + LLM",
            command=self.start_server,
        )
        self.btn_start.grid(row=0, column=0, padx=5, sticky="ew")

        # 只套用設定
        self.btn_restart = ttk.Button(
            frm_btn,
            text="套用設定並重啟 server",
            command=self.apply_and_restart,
            state=tk.NORMAL,
        )
        self.btn_restart.grid(row=0, column=1, padx=5, sticky="ew")

        self.btn_stop = ttk.Button(
            frm_btn,
            text="停止 server",
            command=self.stop_server,
            state=tk.DISABLED,
        )
        self.btn_stop.grid(row=0, column=2, padx=5, sticky="ew")

        # === 中間：server 終端輸出 ===
        frm_log = ttk.LabelFrame(self, text="server.py 終端機輸出")
        frm_log.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.txt_log = tk.Text(frm_log, wrap="word")
        self.txt_log.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scroll = ttk.Scrollbar(frm_log, command=self.txt_log.yview)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.txt_log.configure(yscrollcommand=scroll.set)

        # === 下方：問答 & RAG 額外框 ===
        frm_bottom = ttk.Frame(self)
        frm_bottom.pack(side=tk.TOP, fill=tk.BOTH, expand=False, padx=10, pady=5)

        # 左：用戶問題 + LLM 回覆
        frm_qa = ttk.LabelFrame(frm_bottom, text="用戶問題 + LLM 回覆（解析自 log）")
        frm_qa.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        self.txt_qa = tk.Text(frm_qa, wrap="word", height=12)
        self.txt_qa.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scroll_qa = ttk.Scrollbar(frm_qa, command=self.txt_qa.yview)
        scroll_qa.pack(side=tk.RIGHT, fill=tk.Y)
        self.txt_qa.configure(yscrollcommand=scroll_qa.set)

        # 右：RAG 關鍵字 + 檢索內容
        frm_rag = ttk.LabelFrame(frm_bottom, text="RAG 關鍵字 + 檢索內容（解析自 log）")
        frm_rag.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(5, 0))

        self.txt_rag = tk.Text(frm_rag, wrap="word", height=12)
        self.txt_rag.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scroll_rag = ttk.Scrollbar(frm_rag, command=self.txt_rag.yview)
        scroll_rag.pack(side=tk.RIGHT, fill=tk.Y)
        self.txt_rag.configure(yscrollcommand=scroll_rag.set)

        # 關閉事件
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------- 小工具 ----------------
    def _browse_path(self, var: tk.StringVar, is_file=True):
        if is_file:
            path = filedialog.askopenfilename(title="選擇檔案")
        else:
            path = filedialog.askdirectory(title="選擇資料夾")
        if path:
            var.set(path)

    def append_log(self, text: str):
        def _append():
            self.txt_log.insert(tk.END, text)
            self.txt_log.see(tk.END)
        self.txt_log.after(0, _append)

    def append_qa(self, text: str):
        def _append():
            self.txt_qa.insert(tk.END, text)
            self.txt_qa.see(tk.END)
        self.txt_qa.after(0, _append)

    def _reset_rag_panel(self):
        """每一輪新對話時清空 RAG 視窗 & 狀態。"""
        def _reset():
            self.txt_rag.delete("1.0", tk.END)
        # 清空文字
        self.txt_rag.after(0, _reset)
        # 重置內部狀態
        self.last_keywords = ""
        self._rag_ctx_collecting = False
        self._rag_ctx_lines = []

    def append_rag(self, text: str):
        def _append():
            self.txt_rag.insert(tk.END, text)
            self.txt_rag.see(tk.END)
        self.txt_rag.after(0, _append)

    def collect_config(self) -> dict:
        try:
            budget = int(self.var_budget.get())
            grace = int(self.var_grace.get())
        except ValueError:
            messagebox.showerror("錯誤", "BUDGET_CHARS / GRACE_TOKENS 必須是整數")
            raise

        cfg = {
            "LLM_PATH": self.var_llm.get().strip(),
            "LORA_PATH": self.var_lora.get().strip(),
            "COSYVOICE_PATH": self.var_cosy.get().strip(),
            "ZERO_SHOT_PROMPT_WAV": self.var_prompt.get().strip(),

            "BUDGET_CHARS": budget,
            "GRACE_TOKENS": grace,
            "USE_RAG": bool(self.var_use_rag.get()),

            "REMOTE_HTTP": self.var_remote.get().strip(),
            "AUTH_TOKEN": self.var_auth.get(),

            "BRIDGE_PUSH_URL": self.var_push.get().strip(),
        }
        return cfg

    def write_config(self):
        cfg = self.collect_config()
        # 更新記憶中的 config_data，讓下次開啟 GUI 時 load 的也是最新值
        self.config_data = cfg.copy()

        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with CONFIG_PATH.open("w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        self.append_log(f"[Launcher] 已寫入設定檔：{CONFIG_PATH}\n")

    # ---------------- server 控制 ----------------
    def _parse_and_route_server_line(self, line: str):
        """
        從 server.py 的 stdout 單行 log 中，抽出：
        - 用戶問題（[user_msg] / [WS-USER]）
        - LLM 最終回覆（[push] final: ...）
        - RAG 關鍵字（[LLM-Router] 產生的 RAG 查詢關鍵字：xxx）
        - RAG context（[RAG-CTX-BEGIN]/[RAG-CTX-END] 或 [RAG-CTX] ...）
        """
        s = line.strip()
        if not s:
            return

        # === 1) 用戶問題 ===
        # 支援兩種 tag： [user_msg] / [WS-USER]
        if "[user_msg]" in s or "[WS-USER]" in s:
            # 擷取 tag 後面的東西
            if "[user_msg]" in s:
                msg = s.split("[user_msg]", 1)[1].strip()
            else:
                msg = s.split("[WS-USER]", 1)[1].strip()

            self.last_user_msg = msg

            # 每一輪新 user_msg 到來時，清空 RAG 檢索內容，只顯示該輪資料
            self._reset_rag_panel()

            self.append_qa(f"\n[User] {msg}\n")
            return

        # === LLM 回覆：從 /push 的 final ===
        # server.py /push 目前有：print(f"[push] {payload.event}: {preview}", flush=True)
        if s.startswith("[push] final:"):
            ans = s.split(":", 1)[1].strip() if ":" in s else ""
            if ans:
                self.append_qa(f"[LLM] {ans}\n")
            else:
                self.append_qa("[LLM] (final 但內容為空)\n")
            return

        # ===  RAG 關鍵字 ===
        # 來自 llm_tts 裡的 build_rag_query_with_llm：
        # print(f"[LLM-Router] 產生的 RAG 查詢關鍵字：{line}")
        if "LLM-Router" in s and "產生的 RAG 查詢關鍵字：" in s:
            parts = s.split("產生的 RAG 查詢關鍵字：", 1)
            if len(parts) == 2:
                kw = parts[1].strip()
                self.last_keywords = kw
                self.append_rag(f"[Keywords] {kw}\n\n")
            return

        # ===  RAG Context 多行模式 ===
        if "[RAG-CTX-BEGIN]" in s:
            # 開始收集 context（此時 RAG 視窗已在 [user_msg] 被清空過）
            self._rag_ctx_collecting = True
            self._rag_ctx_lines = []
            return

        if "[RAG-CTX-END]" in s:
            # 結束收集並輸出
            ctx = "\n".join(self._rag_ctx_lines).strip()
            self._rag_ctx_collecting = False
            self._rag_ctx_lines = []
            if ctx:
                self.append_rag(f"[Context]\n{ctx}\n")
            else:
                self.append_rag("[Context]\n（RAG 無內容）\n")
            return

        if self._rag_ctx_collecting:
            # 收集 RAG context 內文
            self._rag_ctx_lines.append(s)
            return

        # ===  RAG Context 單行模式 ===
        if s.startswith("[RAG-CTX]"):
            ctx = s[len("[RAG-CTX]"):].strip()
            if ctx:
                self.append_rag(f"[Context]\n{ctx}\n")
            else:
                self.append_rag("[Context]\n（RAG 無內容）\n")
            return

    def _server_log_loop(self, proc: subprocess.Popen):

        if proc.stdout is None:
            return

        for line in proc.stdout:
            # 先丟到原本的 log 視窗
            self.append_log(line)
            # 再試著解析，分流到問答 / RAG 視窗
            self._parse_and_route_server_line(line)

        self.append_log("\n[Launcher] server 已結束\n")

        def _unlock():
            # 只有當這個 proc 仍然是目前的 server_proc 時才重設按鈕狀態
            if self.server_proc is proc:
                self.btn_start.config(state=tk.NORMAL)
                self.btn_restart.config(state=tk.NORMAL)
                self.btn_stop.config(state=tk.DISABLED)
                self.server_proc = None

        self.txt_log.after(0, _unlock)

    def spawn_server(self) -> bool:
        if not SERVER_SCRIPT.is_file():
            messagebox.showerror("錯誤", f"找不到 server.py：{SERVER_SCRIPT}")
            return False

        cmd = [sys.executable, "-u", str(SERVER_SCRIPT)]
        self.append_log(f"[Launcher] 啟動 server：{' '.join(cmd)}\n")

        try:
            # 強制子程序（server.py）用 UTF-8 輸出，避免 cp950 解碼錯誤
            env = {**os.environ, "PYTHONIOENCODING": "utf-8"}

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,          # 直接拿到 str
                encoding="utf-8",   # 用 UTF-8 解碼
                errors="replace",   # 
                bufsize=1,          # line buffered
                env=env,
                cwd=str(SERVER_DIR),
            )
            self.server_proc = proc
        except Exception as e:
            messagebox.showerror("錯誤", f"啟動 server 失敗：{e}")
            self.server_proc = None
            return False

        self.btn_start.config(state=tk.DISABLED)
        self.btn_restart.config(state=tk.NORMAL)
        self.btn_stop.config(state=tk.NORMAL)

        # 將「這次啟動的 proc」傳進去，避免 race condition
        t = threading.Thread(target=self._server_log_loop, args=(proc,), daemon=True)
        t.start()
        return True

    # ---------- k server + 子程序（含 llm+tts） ----------
    def _kill_server_tree(self):
        """在 Windows 用 taskkill，把 server.py 以及底下 llm+tts 子程序一起砍掉。"""
        if self.server_proc is None:
            return

        pid = self.server_proc.pid
        self.append_log(f"[Launcher] 結束 server 及其子程序 (PID={pid})...\n")

        try:
            if os.name == "nt":
                # /T: 包含子程序, /F: 強制
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
            else:
                
                self.server_proc.terminate()
        except Exception as e:
            self.append_log(f"[Launcher] 結束 server 失敗：{e}\n")
        finally:
            self.server_proc = None
            self.btn_start.config(state=tk.NORMAL)
            self.btn_stop.config(state=tk.DISABLED)
            self.btn_restart.config(state=tk.NORMAL)

    # ---------- 按鈕邏輯 ----------
    def start_server(self):
        # 按下「啟動 server + LLM」
        if self.server_proc is not None and self.server_proc.poll() is None:
            messagebox.showinfo("提示", "server 已在執行中")
            return

        # 先把 GUI 裡的設定寫進 config
        try:
            self.write_config()
        except Exception:
            return

        self.spawn_server()

    def apply_and_restart(self):
        # 按下「套用設定並重啟 server」
        try:
            self.write_config()
        except Exception:
            return

        running = (self.server_proc is not None and self.server_proc.poll() is None)

        # 如果 server 沒開 只套用設定，不啟動
        if not running:
            self.append_log("[Launcher] 已套用設定（目前 server 未啟動，不自動重啟）。\n")
            self.btn_start.config(state=tk.NORMAL)
            self.btn_stop.config(state=tk.DISABLED)
            self.btn_restart.config(state=tk.NORMAL)
            return

        # 如果 server 有在跑  套用設定並重啟（包含 llm+tts 子程式）
        self.append_log("[Launcher] 正在套用設定並重啟 server（含 llm+tts）...\n")
        self._kill_server_tree()
        self.spawn_server()

    def stop_server(self):
        # 按下「停止 server」
        if self.server_proc is None or self.server_proc.poll() is not None:
            self.append_log("[Launcher] server 目前未執行。\n")
            return

        self.append_log("[Launcher] 使用者要求停止 server（含 llm+tts）\n")
        self._kill_server_tree()

    def on_close(self):
        # 關閉 GUI 時順便關掉 server + llm+tts
        if self.server_proc is not None and self.server_proc.poll() is None:
            self._kill_server_tree()
        self.destroy()


if __name__ == "__main__":
    app = LauncherApp()
    app.mainloop()
