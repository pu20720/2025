import cv2
import mediapipe as mp
import math

mp_hands = mp.solutions.hands
mpDraw = mp.solutions.drawing_utils

# 計算兩點距離
def dist(p1, p2):
    return math.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)

# 計算角度
def angle(v1, v2):
    try:
        return math.degrees(math.acos(
            (v1[0]*v2[0]+v1[1]*v2[1]) /
            ((v1[0]**2+v1[1]**2)**0.5*(v2[0]**2+v2[1]**2)**0.5)
        ))
    except:
        return 0

# 洗手七步判斷
def washing_step(left, right):
    lw = left[0]     # 左手手腕
    lp = left[9]     # 左掌心
    rw = right[0]    # 右手手腕
    rp = right[9]    # 右掌心

    d = dist(lp, rp)

    # Step 1 : 手心對手心
    if d < 40:
        return "1. Hand to Hand"

    # Step 2 : 手背刷掌
    if left[0][1] < right[0][1] and d < 80:
        return "2. Back of Hand"

    # Step 3 : 十指交錯
    if dist(left[8], right[12]) < 40 and dist(left[12], right[8]) < 40:
        return "3. Interlock Fingers"

    # Step 4 : 指背互扣
    if dist(left[6], right[6]) < 30 and dist(left[10], right[10]) < 30:
        return "4. Backs of Fingers"

    # Step 5 : 拇指旋轉
    if dist(left[4], right[0]) < 40 or dist(right[4], left[0]) < 40:
        return "5. Thumb Rotation"

    # Step 6 : 指尖刷掌心
    if dist(left[8], right[9]) < 30 or dist(right[8], left[9]) < 30:
        return "6. Fingertips"

    # Step 7 : 手腕旋轉
    if dist(left[0], right[0]) < 40:
        return "7. Wrist"

    return "Move hands..."

cap = cv2.VideoCapture(0)

with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=2,
        min_detection_confidence=0.7,
        min_tracking_confidence=0.6
) as hands:

    while True:
        ret, img = cap.read()
        img = cv2.resize(img, (800,600))
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        res = hands.process(rgb)

        h, w, _ = img.shape

        if res.multi_hand_landmarks and len(res.multi_hand_landmarks) == 2:

            all_hands = []

            for handLms in res.multi_hand_landmarks:
                pts = []
                for lm in handLms.landmark:
                    pts.append((int(lm.x*w), int(lm.y*h)))
                all_hands.append(pts)
                mpDraw.draw_landmarks(img, handLms, mp_hands.HAND_CONNECTIONS)

            left, right = all_hands
            step = washing_step(left, right)

            cv2.putText(img, step, (50,80),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1.5, (0,255,0), 3)

        cv2.imshow("Hand Washing Detector", img)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

cap.release()
cv2.destroyAllWindows()
