<template>
    <div class="w-full p-6 bg-gray-100 text-gray-800">
        <h1 class="text-4xl font-bold text-center text-violet-600 mb-6 tracking-wider">🤓自選股</h1>
        <div class="max-w-6xl mx-auto p-6 bg-gray-100 text-gray-800 hide-scrollbar">
            <div class="text-right mb-4">
                <Button
                    label="編輯自選股"
                    @click="openModal"
                    text
                    class="bg-custom-purple text-white px-4 py-2 rounded-lg hover:bg-violet-custom transition"
                />
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-xl shadow">
                    <thead>
                        <tr class="text-2xl text-white bg-custom-purple font-semibold">
                            <th class="px-5 py-5 text-center rounded-tl-xl">順序</th>
                            <th class="px-5 py-5 text-center">股票代碼</th>
                            <th class="px-5 py-5 text-center">股票名稱</th>
                            <th class="px-5 py-5 text-center">最新價</th>
                            <th class="px-5 py-5 text-center">漲跌</th>
                            <th class="px-5 py-5 text-center">漲跌%</th>
                            <th class="px-5 py-5 text-center rounded-tr-xl">成交(股)</th>
                        </tr>
                    </thead>
                    <draggable v-model="topStocks" tag="tbody" item-key="id" @end="handleDragEnd">
                        <template #item="{ element: stock, index }">
                            <tr
                                :class="index % 2 === 0 ? 'bg-white' : 'bg-gray-50'"
                                class="text-lg transition hover:bg-blue-50 cursor-move"
                                @click="goStock(stock.stock_symbol)"
                            >
                                <td class="px-4 py-3 cursor-pointer">
                                    <div
                                        class="border-2 border-gray-400 rounded-full px-4 py-1 font-bold text-center"
                                    >
                                        {{ index + 1 }}
                                    </div>
                                </td>
                                <td class="px-4 py-3 text-center font-bold cursor-pointer">
                                    <span class="text-violet-600 cursor-pointer">{{
                                        stock.stock_symbol
                                    }}</span>
                                </td>
                                <td class="px-4 py-3 text-center font-semibold cursor-pointer">
                                    {{ stock.stock_name }}
                                </td>
                                <td class="px-4 py-3 text-center font-semibold cursor-pointer">
                                    {{ stock.close_price }}
                                </td>
                                <td class="px-4 py-3 text-center font-semibold cursor-pointer">
                                    <span
                                        :class="{
                                            'text-red-600': stock.change_value > 0,
                                            'text-green-600': stock.change_value < 0,
                                            'text-gray-500': stock.change_value === 0,
                                        }"
                                    >
                                        {{ stock.change_value }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-center font-semibold cursor-pointer">
                                    <span
                                        :class="{
                                            'text-red-600': stock.change_percent > 0,
                                            'text-green-600': stock.change_percent < 0,
                                            'text-gray-500': stock.change_percent === 0,
                                        }"
                                    >
                                        {{ stock.change_percent }}%
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-center font-semibold cursor-pointer">
                                    {{ stock.volume }}
                                </td>
                            </tr>
                        </template>
                    </draggable>
                </table>
            </div>
        </div>

        <Dialog v-model:visible="showModal" modal header="編輯自選股" :style="{ width: '30rem' }">
            <div class="flex flex-col gap-4 p-2">
                <div
                    v-for="(stock, index) in tempStocks"
                    :key="stock._tempId"
                    class="flex items-center justify-between gap-2"
                >
                    <InputText
                        v-model="stock.stock_symbol"
                        placeholder="代碼"
                        class="w-24"
                        @input="clearStockDataOnInput(stock)"
                        @focus="$event.target.select()"
                    />
                    <span class="text-sm text-gray-500 flex-1 truncate">
                        {{ stock.stock_name || '-' }} | 價格: {{ stock.close_price || '-' }}
                    </span>
                    <div class="flex">
                        <Button
                            icon="pi pi-trash"
                            text
                            rounded
                            severity="danger"
                            @click="removeStock(index)"
                        />
                    </div>
                </div>
            </div>

            <div class="flex justify-between mt-6">
                <Button
                    text
                    label="新增股票"
                    icon="pi pi-plus"
                    @click="addStock"
                    class="bg-gray-200 text-gray-800 px-3 py-1 rounded hover:bg-gray-300"
                />
                <Button
                    text
                    label="儲存"
                    icon="pi pi-check"
                    @click="saveOrder"
                    class="bg-custom-purple text-white px-4 py-2 rounded-lg hover:bg-violet-custom transition"
                />
            </div>
        </Dialog>
    </div>
</template>

<script setup>
    import { ref, watch, onMounted } from 'vue'
    import { useRoute, useRouter } from 'vue-router'
    import { useWatchlist } from '@/stores/watchlist'
    import { useToast } from 'primevue/usetoast'
    import draggable from 'vuedraggable'

    import Dialog from 'primevue/dialog'
    import Button from 'primevue/button'
    import InputText from 'primevue/inputtext'

    let tempIdCounter = 0

    const route = useRoute()
    const router = useRouter()
    const toast = useToast()
    const { getUserWatchlist, addStockToWatchlist, deleteStockFromWatchlist, updateStockOrder } =
        useWatchlist()

    const showModal = ref(false)
    const topStocks = ref([])
    const tempStocks = ref([])

    onMounted(async () => {
        topStocks.value = await getUserWatchlist()

        const shouldShowToast = sessionStorage.getItem('showWatchlistToast')
        if (shouldShowToast) {
            toast.add({ severity: 'success', summary: '成功', detail: '自選股已更新', life: 3000 })
            sessionStorage.removeItem('showWatchlistToast')
        }
    })

    async function handleDragEnd() {
        const orderedIds = topStocks.value.map((stock) => stock.id)
        const success = await updateStockOrder(orderedIds)
        if (!success) {
            topStocks.value = await getUserWatchlist()
        }
    }

    async function saveOrder() {
        const originalSymbols = new Set(topStocks.value.map((stock) => stock.stock_symbol))

        const finalValidStocks = tempStocks.value.filter(
            (stock) => stock.stock_symbol && stock.stock_symbol.trim() !== '',
        )
        const finalSymbols = finalValidStocks.map((stock) => stock.stock_symbol)
        const finalSymbolsSet = new Set(finalSymbols)

        const symbolsToAdd = finalSymbols.filter((symbol) => !originalSymbols.has(symbol))
        const symbolsToDelete = [...originalSymbols].filter(
            (symbol) => !finalSymbolsSet.has(symbol),
        )

        const allPromises = [
            ...symbolsToAdd.map((symbol) => addStockToWatchlist(symbol)),
            ...symbolsToDelete.map((symbol) => deleteStockFromWatchlist(symbol)),
        ]

        if (allPromises.length === 0) {
            showModal.value = false
            return
        }

        const results = await Promise.all(allPromises)

        if (!results.includes(false)) {
            sessionStorage.setItem('showWatchlistToast', 'true')
            window.location.reload()
        }
    }

    function openModal() {
        tempStocks.value = JSON.parse(JSON.stringify(topStocks.value)).map((stock) => ({
            ...stock,
            _tempId: stock._tempId || tempIdCounter++,
        }))
        showModal.value = true
    }

    function removeStock(index) {
        tempStocks.value.splice(index, 1)
    }

    function addStock() {
        tempStocks.value.push({
            _tempId: tempIdCounter++,
            stock_symbol: '',
            stock_name: '',
            close_price: '',
            change_value: '',
            change_percent: '',
            volume: '',
        })
    }

    function clearStockDataOnInput(stock) {
        stock.stock_name = ''
        stock.close_price = ''
        stock.change_value = ''
        stock.change_percent = ''
        stock.volume = ''
    }

    function goStock(symbol) {
        if (symbol) {
            router.push(`/stock/${symbol}`)
        }
    }

    watch(route, () => {
        showModal.value = false
    })
</script>
