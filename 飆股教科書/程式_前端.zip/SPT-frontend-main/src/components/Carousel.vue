<template>
    <div class="carousel-container">
        <div class="tabs">
            <button
                v-for="tab in tabs"
                :key="tab"
                @click="activeTab = tab"
                :class="{ active: activeTab === tab }"
            >
                {{ tab }}
            </button>
        </div>

        <div class="tab-content">
            <div v-if="activeTab === '加權指'">
                <img src="@/assets/market1.png" alt="上市圖表" />
            </div>
            <div v-else-if="activeTab === '櫃買指'">
                <img src="@/assets/market2.png" alt="上櫃圖表" />
            </div>
            <div v-else-if="activeTab === '台指期'">
                <img src="@/assets/market3.png" alt="台指期圖表" />
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref } from 'vue'

    const tabs = ['加權指', '櫃買指', '台指期']
    const activeTab = ref('上市')
</script>

<style scoped>
    .carousel-container {
        width: 100%;
        max-width: 500px;
        margin: 0 auto;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .tabs {
        display: flex;
        border-bottom: 1px solid #ccc;
    }

    .tabs button {
        flex: 1;
        padding: 12px;
        background: none;
        border: none;
        border-bottom: 3px solid transparent;
        font-size: 16px;
        cursor: pointer;
        transition: 0.2s;
    }

    .tabs button.active {
        color: red;
        border-bottom: 3px solid red;
        font-weight: bold;
    }

    .tab-content {
        padding: 16px;
        text-align: center;
    }

    .tab-content img {
        max-width: 100%;
        height: auto;
        border-radius: 8px;
    }
</style>
