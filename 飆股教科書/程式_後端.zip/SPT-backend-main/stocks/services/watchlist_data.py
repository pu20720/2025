import logging
from django.db import transaction
from stocks.models import Watchlist
from stocks_price.models import StockPrices
from collections import Counter
from rest_framework.exceptions import ValidationError
from django.db.models import (
    DecimalField,
    IntegerField,
    BigIntegerField,
    ExpressionWrapper,
    Max,
    DateField,
    Value,
    OuterRef,
    Subquery,
    F,
    Case,
    When,
)


def get_watchlist_data(user) -> list[dict]:
    logger = logging.getLogger(__name__)
    try:
        # 找出資料庫中最新的日期
        latest_date = StockPrices.objects.aggregate(latest=Max('price_date'))['latest']
        if not latest_date:
            raise RuntimeError('資料庫沒有股價資料')

        yesterday_date = StockPrices.objects.filter(
            price_date__lt=latest_date
        ).aggregate(prev_date=Max('price_date'))['prev_date']

        # 取出最新開盤價
        latest_open_price = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('open_price')[:1]
        # 取出最新漲跌幅度
        latest_change_percent = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('change_percent')[:1]
        # 取出最新一筆股價
        latest_close_price = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('close_price')[:1]
        # 取出最新成交量
        latest_volume = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('volume')[:1]
        # 取出昨日收盤價
        yesterday_close_price = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=yesterday_date
        ).values('close_price')[:1]

        qs = Watchlist.objects.select_related('stock', 'user').annotate(
            stock_symbol=F('stock__symbol'),
            stock_name=F('stock__name'),
            open_price=Subquery(
                latest_open_price,
                output_field=DecimalField(max_digits=12, decimal_places=4),
            ),
            close_price=Subquery(
                latest_close_price,
                output_field=DecimalField(max_digits=12, decimal_places=4),
            ),
            yesterday_close=Subquery(
                yesterday_close_price,
                output_field=DecimalField(max_digits=12, decimal_places=4),
            ),
            change_percent=Subquery(
                latest_change_percent,
                output_field=DecimalField(max_digits=5, decimal_places=2),
            ),
            volume=Subquery(latest_volume, output_field=BigIntegerField()),
        )

        if user:
            qs = qs.filter(user=user)

        # 計算漲跌幅度
        change_value = ExpressionWrapper(
            F('close_price') - F('yesterday_close'),
            output_field=DecimalField(max_digits=12, decimal_places=4),
        )

        qs = qs.annotate(
            date=Value(latest_date, output_field=DateField()),
            change_value=change_value,
        )

        return list(
            qs.values(
                'id',
                'date',
                'stock_symbol',
                'stock_name',
                'open_price',
                'close_price',
                'volume',
                'change_value',
                'change_percent',
            )
        )

    except Exception as e:
        logger.error(f'[Watchlist] 資料查詢失敗 {e}')
        raise RuntimeError('資料查詢失敗')


def add_watchlist_data(user, stock):
    logger = logging.getLogger(__name__)
    try:
        watchlist, created = Watchlist.objects.get_or_create(user=user, stock=stock)

        if created and watchlist.position is None:
            # 自動排在最後一個
            max_pos = (
                Watchlist.objects.filter(user=user).aggregate(Max('position'))[
                    'position__max'
                ]
                or 0
            )
            watchlist.position = max_pos + 1
            watchlist.save()
        return watchlist, created
    except Exception as e:
        logger.error(f'[Watchlist] 新增失敗 {e}')
        raise RuntimeError('無法加入自選股')


def delete_watchlist_data(user, stock):
    logger = logging.getLogger(__name__)
    try:
        deleted, _ = Watchlist.objects.filter(user=user, stock=stock).delete()
        if not deleted:
            raise RuntimeError('自選股不存在')
    except Exception as e:
        logger.error(f'[Watchlist] 刪除失敗 {e}')
        raise RuntimeError('無法刪除自選股')


def reorder_watchlist_data(user, ids: list[int]):
    logger = logging.getLogger(__name__)
    try:
        # --- 驗證輸入 ---
        if not isinstance(ids, list) or not ids:
            raise ValueError('ids 必須是陣列')

        dupes = [i for i, c in Counter(ids).items() if c > 1]
        if dupes:
            raise ValidationError('[Watchlist] ids 有重複')

        qs = Watchlist.objects.filter(user=user, id__in=ids)
        if qs.count() != len(set(ids)):
            raise ValueError('包含不屬於你的項目或重複 id')

        # --- 主要邏輯 ---
        with transaction.atomic():
            # 清空 position（避免 unique constraint 暫時衝突）
            qs.update(position=None)

            # 重新依順序賦值
            cases = [When(id=pk, then=pos) for pos, pk in enumerate(ids, start=1)]
            qs.update(position=Case(*cases, output_field=IntegerField()))

        logger.info(f'[Watchlist] 使用者 {user.id} 排序更新成功: {ids}')
        return True

    except ValueError as ve:
        logger.error(f'[Watchlist] 排序失敗 {ve}')
        raise ve
    except ValidationError as ve:
        logger.error(f'[Watchlist] 排序失敗 {ve}')
        raise ve
    except Exception as e:
        logger.error(f'[Watchlist] 排序失敗 {e}')
        raise RuntimeError('無法更新順序')
