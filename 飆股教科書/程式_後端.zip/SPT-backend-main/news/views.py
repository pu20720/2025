import logging
from .models import News
from rest_framework import status
from .serializers import NewsSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from .services.import_news import import_news

logger = logging.getLogger(__name__)


class NewsView(APIView):
    def post(self, request):
        try:
            result = import_news()
            # 合併訊息與匯入結果
            data = {'message': '成功匯入新聞'}
            data.update(result)
            return Response(data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def get(self, request):
        try:
            news = News.objects.order_by('-published_at')[:5]
            serializer = NewsSerializer(news, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            (logger.error(f'[News] 查詢失敗 {e}'),)
            return Response(
                {'error': '查無新聞資料'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
