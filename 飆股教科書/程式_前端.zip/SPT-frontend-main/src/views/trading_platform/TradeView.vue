<script setup>
    import { ref, computed, watch, onMounted } from 'vue'

    import { useTrade } from '@/stores/trade.js'
    import { useStockSearch } from '@/stores/stockSearch.js'
    import { useToast } from 'primevue/usetoast'

    import { useHotStocks } from '@/stores/hotStocks.js' //

    const { postTrade } = useTrade()
    const { fuzzySearchStocks } = useStockSearch()
    const toast = useToast()

    const { getHotStocks } = useHotStocks()

    const searchQuery = ref('')
    const filteredStocks = ref([])
    const selectedStock = ref(null)

    const tradeForm = ref({
        type: 'buy',
        quantity: 1,
        price: 0,
    })

    const isSubmitting = ref(false)

    const canBuy = computed(() => tradeForm.value.quantity > 0 && selectedStock.value)
    const canSell = computed(() => tradeForm.value.quantity > 0 && selectedStock.value)

    const selectStockForTrade = (stock) => {
        selectedStock.value = stock
        tradeForm.value.price = getStockPrice(stock)
        tradeForm.value.quantity = 1
    }

    const getStockPrice = (stock) => {
        if (!stock) return 0
        return stock.close_price || stock.price || stock.current_price || stock.last_price || 0
    }

    const handleTrade = async () => {
        if (!selectedStock.value || isSubmitting.value) return

        isSubmitting.value = true
        const tradeData = {
            type: tradeForm.value.type.toUpperCase(),
            symbol: selectedStock.value.symbol,
            shares: tradeForm.value.quantity,
        }

        const result = await postTrade(tradeData)

        if (result.success) {
            toast.add({
                severity: 'success',
                summary: '交易成功',
                detail: `已成功${tradeForm.value.type === 'buy' ? '買入' : '賣出'} ${selectedStock.value.name}`,
                life: 3000,
            })
            selectedStock.value = null
            tradeForm.value = { type: 'buy', quantity: 1, price: 0 }
        }

        isSubmitting.value = false
        window.location.reload()
    }

    const totalAmount = computed(() => {
        if (!selectedStock.value) return '0.00'
        const price = tradeForm.value.price || 0
        const quantity = tradeForm.value.quantity || 0
        return safeToFixed(price * quantity)
    })

    const safeToFixed = (value, decimals = 2) => {
        if (value === null || value === undefined || isNaN(value)) {
            return '0.00'
        }
        return Number(value).toFixed(decimals)
    }

    const safeChangeFormat = (change) => {
        if (change === null || change === undefined || isNaN(change)) {
            return '+0.00%'
        }
        const sign = change >= 0 ? '+' : ''
        return `${sign}${safeToFixed(change)}%`
    }

    function debounce(func, delay) {
        let timeout
        return (...args) => {
            clearTimeout(timeout)
            timeout = setTimeout(() => {
                func.apply(this, args)
            }, delay)
        }
    }

    const formatStockData = (stock) => {
        return {
            ...stock,
            price: getStockPrice(stock),
            close_price: stock.close_price || stock.price || 0,
            change_percent: stock.change_percent || 0,
            name: stock.name || stock.stock_name || '未知股票',
            symbol: stock.symbol || stock.stock_code || 'N/A',
        }
    }

    const loadHotStocks = async () => {
        try {
            const stocks = await getHotStocks()
            filteredStocks.value = stocks.map(formatStockData)
        } catch (error) {
            console.error('加載熱門股票時發生錯誤:', error)
            filteredStocks.value = []
        }
    }

    const searchStocks = async () => {
        try {
            if (!searchQuery.value.trim()) {
                await loadHotStocks()
                return
            }
            const stocks = await fuzzySearchStocks(searchQuery.value)

            filteredStocks.value = stocks.map(formatStockData)
        } catch (error) {
            console.error('搜尋股票時發生錯誤:', error)
            filteredStocks.value = []
        }
    }

    const debouncedSearch = debounce(searchStocks, 300)
    watch(searchQuery, debouncedSearch)

    watch(selectedStock, (newStock) => {
        if (newStock) {
            tradeForm.value.price = getStockPrice(newStock)
        }
    })

    onMounted(() => {
        loadHotStocks()
    })
</script>

<template>
    <div>
        <div class="grid grid-cols-2 gap-4">
            <!-- 搜尋區 -->
            <div class="card">
                <div class="search-container">
                    <i class="fas fa-search search-icon"></i>
                    <input
                        v-model="searchQuery"
                        type="text"
                        class="search-input"
                        placeholder="搜尋股票代碼或公司名稱"
                    />
                </div>

                <h2 class="card-title">股票搜尋</h2>

                <div class="overflow-y-auto h-96">
                    <div
                        v-for="stock in filteredStocks"
                        :key="stock.symbol"
                        class="stock-item"
                        @click="selectStockForTrade(stock)"
                    >
                        <div class="stock-info">
                            <h3>{{ stock.name }}</h3>
                            <div class="stock-code">{{ stock.symbol }}</div>
                        </div>
                        <div class="stock-price">
                            <div
                                :class="['price', (stock.change_percent || 0) >= 0 ? 'up' : 'down']"
                            >
                                NT${{ safeToFixed(stock.price) }}
                            </div>
                            <div
                                :class="[
                                    'change-percent',
                                    (stock.change_percent || 0) >= 0 ? 'up' : 'down',
                                ]"
                            >
                                {{ safeChangeFormat(stock.change_percent) }}
                            </div>
                        </div>
                    </div>
                </div>

                <div
                    v-if="filteredStocks.length === 0 && searchQuery.trim() !== ''"
                    class="text-center p-4 text-gray-500"
                >
                    沒有找到相關股票
                </div>
                <div
                    v-if="filteredStocks.length === 0 && searchQuery.trim() === ''"
                    class="text-center p-4 text-gray-500"
                >
                    請輸入關鍵字開始搜尋
                </div>
            </div>

            <!-- 交易區 -->
            <div v-if="selectedStock" class="card">
                <h2 class="card-title">交易 - {{ selectedStock.name }}</h2>
                <div class="trade-form">
                    <div class="form-group">
                        <label class="form-label">交易類型</label>
                        <select v-model="tradeForm.type" class="form-input">
                            <option value="buy">買入</option>
                            <option value="sell">賣出</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">股數</label>
                        <input
                            v-model.number="tradeForm.quantity"
                            type="number"
                            class="form-input"
                            placeholder="請輸入股數"
                            min="1"
                        />
                    </div>

                    <div class="form-group">
                        <label class="form-label">價格 (僅供參考)</label>
                        <input
                            v-model.number="tradeForm.price"
                            type="number"
                            class="form-input"
                            step="0.01"
                            disabled
                        />
                    </div>

                    <div class="form-group">
                        <label class="form-label">總金額 (預估)</label>
                        <div class="form-input bg-gray-100">NT${{ totalAmount }}</div>
                    </div>

                    <div class="trade-buttons">
                        <button
                            @click="handleTrade"
                            :class="['btn', tradeForm.type === 'buy' ? 'btn-buy' : 'btn-sell']"
                            :disabled="
                                isSubmitting || (tradeForm.type === 'buy' ? !canBuy : !canSell)
                            "
                        >
                            <i
                                :class="
                                    tradeForm.type === 'buy'
                                        ? 'fas fa-arrow-up'
                                        : 'fas fa-arrow-down'
                                "
                            ></i>
                            {{ tradeForm.type === 'buy' ? '確認買入' : '確認賣出' }}
                            <span v-if="isSubmitting" class="ml-2">處理中...</span>
                        </button>
                    </div>
                </div>
            </div>

            <div v-else class="card">
                <h2 class="card-title">交易</h2>
                <p class="text-center p-10">請從左側列表選擇一支股票以進行交易。</p>
            </div>
        </div>
    </div>
</template>
