using System.Collections.Generic;
using UnityEngine;
using System.Linq;

// 特殊物品的類型定義
public enum SpecialItemType
{
    Passive,    // 被動 (如: 臭豆腐, 鐵血假面)
    Active,     // 主動 (如: 手槍, 德國科技)
    Trigger     // 觸發型 (如: 吸血鬼獵人)
}

[System.Serializable]
public class SpecialItemData
{
    public string id;
    public string itemName;
    [TextArea] public string description;
    public Sprite icon; // 實際專案中請透過 ArtLibrary 或 Resources 載入

    public SpecialItemType type;
    public int mpCost = 0;      // 啟動消耗 (若有)
    public int effectValue = 0; // 通用數值 (如治療量、增加屬性值)
    public int charges = 0;     // 次數限制 (如手槍 6發)

    // 系統標籤
    public bool isShopExclusive = false; // 是否僅商店出現 (The Loaf of Charity)
    public bool isSelectableAtStart = true; // 是否可作為開局遺物選擇
}

public static class SpecialItemDatabase
{
    private static List<SpecialItemData> allItems = new List<SpecialItemData>();
    private static bool isInitialized = false;

    // 您可以在這裡傳入一個 SpecialItemArtLibrary 來載入圖片
    public static void Initialize()
    {
        if (isInitialized) return;
        BuildDatabase();
        isInitialized = true;
    }

    private static void BuildDatabase()
    {
        allItems.Clear();

        // ========================================================================
        // 1. Return of the Emperor (帝王的回歸)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Return_of_the_Emperor",
            itemName = "Return of the Emperor",
            description = "Start of turn: Deduct 5% HP (3 turns). Afterwards: Gain 10% ATK (3 turns). (One time activation)",
            type = SpecialItemType.Active, // 或 Auto-Trigger
            isSelectableAtStart = true
        });

        // ========================================================================
        // 2. Russian Roulette (俄羅斯輪盤 - 手槍)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Russian_Roulette",
            itemName = "Russian Roulette",
            description = "Active: Instantly defeat target. 6 Rounds. Hit chance drops (100% -> 16%). Consumes turn.",
            type = SpecialItemType.Active,
            charges = 6,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 3. Iron Blood & Masquerade (鐵血與假面)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Iron_Blood_Masquerade",
            itemName = "Iron Blood & Masquerade",
            description = "Passive: If Enemy HP > Yours: +30% ATK. If Enemy HP < Yours: -30% ATK.",
            type = SpecialItemType.Passive,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 4. Vampire's Mask (吸血鬼面具 - 詛咒神像效果)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Vampires_Mask",
            itemName = "Vampire's Mask",
            description = "Our Turn: +200 ATK & +200 HP. Enemy Turn: -250 HP, -250 ATK.",
            type = SpecialItemType.Passive,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 5. 50-Meter Greatsword (50米大刀)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "50_Meter_Greatsword",
            itemName = "50-Meter Greatsword",
            description = "Active: Pay 100 MP to deal 80 True Damage to all enemies.",
            type = SpecialItemType.Active,
            mpCost = 100,
            effectValue = 80,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 6. Imperial Green Stinky Tofu (御用綠臭豆腐)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Imperial_Green_Stinky_Tofu",
            itemName = "Imperial Green Stinky Tofu",
            description = "Passive: Restores 50 HP when health is below 70%.",
            type = SpecialItemType.Passive, // 自動觸發
            effectValue = 50,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 7. German Science (德國科技)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "German_Science",
            itemName = "German Science",
            description = "Active: Pay 50 MP to gain +10 All Stats (ATK, HP, Armor).",
            type = SpecialItemType.Active,
            mpCost = 50,
            effectValue = 10,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 8. Solar Ripple Dash (波紋疾走)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Solar_Ripple_Dash",
            itemName = "Solar Ripple Dash",
            description = "Passive: When attacking Vampire Enemy (Dio), reduce their HP/ATK by 250.",
            type = SpecialItemType.Trigger,
            effectValue = 250,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 9. Perfect Biological Being (究極生物)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Perfect_Biological_Being",
            itemName = "Perfect Biological Being",
            description = "Active: Pay 600 MP to choose 1 Random Buff. (Subsequent cost: 200 MP)",
            type = SpecialItemType.Active,
            mpCost = 600,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 10. Mercy Enforcer (慈愛強制者 - 文本描述)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "Mercy_Enforcer",
            itemName = "Mercy Enforcer",
            description = "Passive: Killing B/C grade enemies counts as Mercy Route.",
            type = SpecialItemType.Passive,
            isSelectableAtStart = true
        });

        // ========================================================================
        // 11. The Loaf of Charity (慈善麵包 - 商店限定)
        // ========================================================================
        allItems.Add(new SpecialItemData
        {
            id = "The_Loaf_of_Charity",
            itemName = "The Loaf of Charity",
            description = "Crowd's Conviction: Non-hostile NPCs grant aid. Value: 500,000 Gold.",
            type = SpecialItemType.Passive,
            isShopExclusive = true, // 標記為商店限定
            isSelectableAtStart = false
        });
    }

    public static List<SpecialItemData> GetAllItems()
    {
        return new List<SpecialItemData>(allItems);
    }

    public static List<SpecialItemData> GetStarterItems()
    {
        return allItems.Where(x => x.isSelectableAtStart).ToList();
    }

    public static SpecialItemData GetItemByID(string id)
    {
        return allItems.FirstOrDefault(x => x.id == id);
    }
}