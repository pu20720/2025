// 檔案路徑: Assets/Scripts/SceneManagers/SaveManager.cs
using UnityEngine;
using System.IO;
using System;

public class SaveManager : MonoBehaviour
{
    public static SaveManager Instance { get; private set; }

    private const string SAVE_FILE_NAME = "savegame.json";

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void AutoCreate()
    {
        if (Instance != null) return;
        new GameObject(nameof(SaveManager)).AddComponent<SaveManager>();
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private string GetSavePath()
    {
        return Path.Combine(Application.persistentDataPath, SAVE_FILE_NAME);
    }

    public static void SaveStatic(SaveData data)
    {
        if (Instance == null) return;
        Instance.Save(data);
    }

    public static SaveData LoadStatic()
    {
        if (Instance == null) return null;
        return Instance.Load();
    }

    public void Save(SaveData data)
    {
        string path = GetSavePath();
        try
        {
            data.SaveTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string json = JsonUtility.ToJson(data, true);
            File.WriteAllText(path, json);
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to save to {path}. Error: {e.Message} {e.StackTrace}");
        }
    }

    public SaveData Load()
    {
        string path = GetSavePath();
        if (!File.Exists(path))
        {
            return null;
        }

        try
        {
            string json = File.ReadAllText(path);
            SaveData data = JsonUtility.FromJson<SaveData>(json);
            return data;
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to load from {path}. Error: {e.Message} {e.StackTrace}");
            return null;
        }
    }
}