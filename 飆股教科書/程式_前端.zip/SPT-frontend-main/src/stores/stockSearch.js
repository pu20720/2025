import { useRouter } from 'vue-router'
import api from '@/api/axios'
import { useToast } from 'primevue/usetoast'

export function useStockSearch() {
    const router = useRouter()
    const toast = useToast()

    /**
     * 搜尋指定股票資料
     * @param {string} stockCode - 股票代碼
     * @returns {Promise<boolean>} - 如果有資料則回傳 true，否則回傳 false
     */
    const checkStockExists = async (stockCode) => {
        try {
            const response = await api.get('prices/import/all/', { params: { keyword: stockCode } })
            const hasData = response.data && response.data.length > 0
            if (!hasData) {
                toast.add({
                    severity: 'warn',
                    summary: '查詢結果',
                    detail: `查無股票代碼 ${stockCode} 的資料`,
                    life: 4000,
                })
            }
            return hasData
        } catch (e) {
            toast.add({
                severity: 'error',
                summary: '查詢失敗',
                detail: e.message || '未知錯誤',
                life: 4000,
            })
            return false
        }
    } // 模糊搜尋股票
    const fuzzySearchStocks = async (stockCode) => {
        try {
            const response = await api.get('transaction/search', { params: { keyword: stockCode } })
            if (Array.isArray(response.data)) {
                return response.data
            } else if (response.data && typeof response.data === 'object') {
                return [response.data]
            } else {
                return []
            }
        } catch (e) {
            console.error('模糊搜尋錯誤:', e)
            return []
        }
    }

    /**
     * 導航至 /stock/:stockCode 頁面，並在導航前檢查資料是否存在
     * @param {string} stockCode - 股票代碼
     */
    const goToStockResult = async (stockCode) => {
        if (!stockCode) {
            toast.add({
                severity: 'warn',
                summary: '輸入錯誤',
                detail: '請輸入股票代碼！',
                life: 4000,
            })
            return
        }
        const hasData = await checkStockExists(stockCode)
        if (hasData) {
            router.push({ name: 'SearchResult', params: { stockCode } })
        }
    }

    /**
     * 導航至 /stock/:stockCode 頁面
     * @param {string} stockCode - 股票代碼
     */
    const fallingKeywordsRouter = async (stockCode) => {
        router.push({ name: 'SearchResult', params: { stockCode } })
    }

    const getAllStocks = async () => {
        try {
            const response = await api.get('stocks/')
            return response.data
        } catch (e) {
            toast.add({
                severity: 'error',
                summary: '資料取得失敗',
                detail: e.message || '無法取得股票資料',
                life: 4000,
            })
            return []
        }
    }

    // 取得特定股票資料
    const getPickedStock = async (stockCode) => {
        try {
            const response = await api.get('stocks/', { params: { keyword: stockCode } })
            return response.data
        } catch (e) {
            toast.add({
                severity: 'error',
                summary: '資料取得失敗',
                detail: e.message || `無法取得股票 ${stockCode} 的資料`,
                life: 4000,
            })
            return []
        }
    }

    // 取得特定股票財務資料
    const getPickedStockfinancial = async (stockCode) => {
        try {
            const response = await api.get('financial/', { params: { symbol: stockCode } })
            return response.data
        } catch (e) {
            toast.add({
                severity: 'error',
                summary: '財務資料失敗',
                detail: e.message || `無法取得股票 ${stockCode} 的財務資料`,
                life: 4000,
            })
            return []
        }
    }

    return {
        goToStockResult,
        checkStockExists,
        getAllStocks,
        getPickedStock,
        getPickedStockfinancial,
        fallingKeywordsRouter,
        fuzzySearchStocks,
    }
}
