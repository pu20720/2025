import requests
import logging
import os
from news.models import News
from django.utils.dateparse import parse_datetime

logger = logging.getLogger(__name__)


def import_news() -> dict:
    url = f'https://newsdata.io/api/1/latest?apikey={os.getenv("NEWSDATA_API_KEY")}&category=business&language=zh&country=tw&timezone=Asia/Taipei'

    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        fields = {
            'title': 'title',
            'url': 'link',
            'image': 'image_url',
            'published_at': 'pubDate',
        }

        created_count = 0
        skipped_count = 0
        updated_count = 0

        items = data.get('results', [])

        for item in items:
            news_data = {k: item.get(v, '') for k, v in fields.items()}
            if news_data.get('published_at'):
                news_data['published_at'] = parse_datetime(news_data['published_at'])
            try:
                obj = News.objects.get(title=news_data['url'])
                # 若已存在，檢查是否需要更新
                has_changes = any(
                    getattr(obj, key) != val for key, val in news_data.items()
                )
                if has_changes:
                    for key, val in news_data.items():
                        setattr(obj, key, val)
                    obj.save()
                    updated_count += 1
                else:
                    skipped_count += 1
            except News.DoesNotExist:
                News.objects.create(**news_data)
                created_count += 1

        return {
            'created': created_count,
            'updated': updated_count,
            'skipped': skipped_count,
            'total': len(items),
        }

    except requests.RequestException as e:
        logger.error(f'[NewsData] 資料擷取失敗：{e}')
        raise RuntimeError('NewsData API 錯誤')
    except Exception as e:
        logger.error(f'[NewsData] 匯入失敗：{e}')
        raise RuntimeError('資料處理失敗')
