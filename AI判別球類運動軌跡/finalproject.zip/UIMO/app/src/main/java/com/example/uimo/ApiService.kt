package com.example.uimo

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path

// --- データ形式の定義 ---

// /upload APIからのレスポンス
data class UploadResponse(
    val status: String,
    val job_id: String
)

// /status/{job_id} APIからのレスポンス
data class StatusResponse(
    val status: String,
    val original_filename: String,
    val result_video_name: String?, // 分析完了時のみ値が入る
    val message: String? // エラー時のみ値が入る
)


// --- APIエンドポイントの定義 ---

interface ApiService {
    // 変更点: レスポンスの型が UploadResponse に変わった
    @Multipart
    @POST("upload")
    suspend fun uploadVideo(
        @Part video: MultipartBody.Part,
        // 座標データを受け取る引数を追加
        @Part("corners_json") corners_json: RequestBody
    ): Response<UploadResponse>

    // 追加点: ステータス確認用のAPI
    @GET("status/{job_id}")
    suspend fun getStatus(
        @Path("job_id") jobId: String
    ): Response<StatusResponse>

    // ダウンロード用のエンドポイントは、URLを直接組み立てるため、
    // Retrofitの定義は不要です。
}
