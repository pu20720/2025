// 檔案路徑: Assets/Scripts/Data/TempLoadData.cs
using UnityEngine;

#pragma warning disable CS8632

public sealed class TempLoadData : MonoBehaviour
{
    public static TempLoadData Instance { get; private set; }

    private SaveData? pendingData;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void AutoCreate()
    {
        if (Instance != null) return;
        new GameObject(nameof(TempLoadData)).AddComponent<TempLoadData>();
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            if (pendingData != null)
                Instance.pendingData = pendingData;
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void SetData(SaveData data) => pendingData = data;

    public SaveData? GetData()
    {
        var data = pendingData;
        pendingData = null;
        return data;
    }
}