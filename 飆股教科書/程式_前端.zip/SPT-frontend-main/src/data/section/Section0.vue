<template>
    <div class="w-full px-4 md:px-16 py-12 bg-gray-50 min-h-screen">
        <div class="mb-10 max-w-5xl mx-auto">
            <div class="flex justify-between items-end mb-2">
                <h3 class="text-xl font-semibold text-blue-700 transition duration-300">
                    {{
                        slides[currentSlide].title.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]\s?/, '')
                    }}
                </h3>
                <span class="text-sm font-medium text-gray-500">
                    主題 {{ currentSlide + 1 }} / {{ slides.length }}
                </span>
            </div>
            <div class="w-full bg-gray-300 rounded-full h-2.5 overflow-hidden">
                <div
                    class="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
                    :style="{ width: ((currentSlide + 1) / slides.length) * 100 + '%' }"
                ></div>
            </div>
        </div>

        <transition name="slide-fade" mode="out-in">
            <div
                :key="currentSlide"
                class="bg-white rounded-2xl shadow-xl p-10 md:flex gap-12 items-start border border-gray-100 max-w-5xl mx-auto"
            >
                <div
                    :class="{
                        'md:w-2/3': slides[currentSlide].img,
                        'md:w-full': !slides[currentSlide].img,
                    }"
                    class="w-full"
                >
                    <h2 class="text-3xl font-extrabold mb-6 text-gray-800">
                        {{ slides[currentSlide].title }}
                    </h2>
                    <div
                        class="text-lg text-gray-700 leading-relaxed space-y-4"
                        v-html="slides[currentSlide].content"
                    ></div>
                </div>

                <div
                    v-if="slides[currentSlide].img"
                    class="md:w-1/3 w-full mt-10 md:mt-0 flex justify-center items-center"
                >
                    <img
                        :src="slides[currentSlide].img"
                        :alt="
                            slides[currentSlide].title.replace(
                                /[\uD800-\uDBFF][\uDC00-\uDFFF]\s?/,
                                '',
                            )
                        "
                        :class="`${slides[currentSlide].imgClass} object-contain rounded-xl shadow-lg border border-gray-200`"
                    />
                </div>
            </div>
        </transition>

        <div class="flex justify-between mt-16 max-w-5xl mx-auto">
            <button
                @click="prevSlide"
                :disabled="currentSlide === 0"
                class="px-7 py-2.5 rounded-full border border-blue-600 text-blue-600 font-medium hover:bg-blue-50 transition duration-300 disabled:opacity-40 disabled:border-gray-300 disabled:text-gray-400"
            >
                &larr; 上一主題
            </button>

            <button
                v-if="!isLastSlide"
                @click="nextSlide"
                class="px-9 py-2.5 rounded-full bg-blue-600 text-white font-semibold shadow-md shadow-blue-300 hover:bg-blue-700 hover:shadow-lg transition duration-300"
            >
                下一主題 &rarr;
            </button>

            <button
                v-else
                @click="goHome"
                class="px-9 py-2.5 rounded-full bg-green-600 text-white font-semibold shadow-md shadow-green-300 hover:bg-green-700 hover:shadow-lg transition duration-300"
            >
                回到課程首頁
            </button>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed } from 'vue'
    import { useRouter } from 'vue-router'
    import { useToast } from 'primevue/usetoast'

    const toast = useToast()
    const router = useRouter()
    const currentSlide = ref(0)

    // 僅保留您已 import 的圖片
    import accountOpenImg from '@/assets/account_open.png'
    import chooseBrokerImg from '@/assets/choose_broker.png'

    const slides = [
        {
            title: '📋 開戶前的準備條件',
            content: `<ul class="list-decimal list-inside space-y-3 text-gray-800 leading-relaxed">
                            <li><strong>年齡要求：</strong>年滿 <span class="font-bold text-red-600">18 歲</span> 可自行開戶</li>
                            <li><strong>銀行帳戶：</strong>需本人名下帳戶，用於資金轉入與轉出</li>
                            <li><strong>身分證明文件：</strong>
                            <ul class="list-disc list-inside ml-6 mt-2">
                                <li>國民身分證正本</li>
                                <li>第二證件（健保卡或駕照）</li></ul></li>
                            <li><strong>印章：</strong>開戶時需使用印鑑</li>
                        </ul>`,
            img: accountOpenImg,
            imgClass: 'h-64 md:w-80 h-auto', // 稍微增加圖片尺寸
        },
        {
            title: '🏦 選擇證券商',
            content: `
            <p class="mb-5 text-gray-700 leading-relaxed">選擇合適的證券商是開戶的第一步，建議可從以下幾個面向進行比較：</p>
            <ul class="list-disc list-inside space-y-4 text-gray-800 leading-relaxed">
                <li><span class="font-semibold text-blue-700">交易手續費優惠：</span> 瞭解折扣方案與活動優惠，長期交易可省下不少成本</li>
                <li><span class="font-semibold text-blue-700">操作介面友善度：</span> App／網頁是否直覺、穩定，操作體驗流暢與否影響很大</li>
                <li><span class="font-semibold text-blue-700">支援市場範圍：</span> 是否支援 <span class="text-blue-600">台股、美股、ETF</span> 等多市場交易</li>
                <li><span class="font-semibold text-blue-700">服務品質：</span> 客服回覆速度、據點便利性與專業程度</li>
            </ul>
            <hr class="my-8 border-gray-300"/>
            <p class="mb-4 font-bold text-xl text-gray-800">📊 台股主要券商交易手續費比較：</p>
            <div class="overflow-x-auto border rounded-lg">
                <table class="min-w-full text-sm text-gray-700">
                    <thead class="bg-blue-800 text-white sticky top-0">
                        <tr>
                            <th class="p-3 whitespace-nowrap">券商</th>
                            <th class="p-3 whitespace-nowrap">手續費折扣／低消</th>
                            <th class="p-3">備註</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-800 divide-y divide-gray-200">
                        <tr class="hover:bg-blue-50">
                            <td class="p-3 whitespace-nowrap">新光證券</td>
                            <td class="p-3 whitespace-nowrap font-medium">1折 / 20元</td>
                            <td class="p-3 text-gray-600 text-xs">限新戶，一年內，100萬內</td>
                        </tr>
                        <tr class="hover:bg-blue-50">
                            <td class="p-3 whitespace-nowrap">富邦證券</td>
                            <td class="p-3 whitespace-nowrap font-medium">1.8折 / 20元</td>
                            <td class="p-3 text-gray-600 text-xs">限新戶，100萬內（~2025/12/31）</td>
                        </tr>
                        <tr class="hover:bg-blue-50">
                            <td class="p-3 whitespace-nowrap">永豐金證券</td>
                            <td class="p-3 whitespace-nowrap font-medium">2折 / 1元</td>
                            <td class="p-3 text-gray-600 text-xs">需線上開戶，100萬內（~2025/12/31）</td>
                        </tr>
                        <tr class="hover:bg-blue-50">
                            <td class="p-3 whitespace-nowrap">統一證券（UMONEY）</td>
                            <td class="p-3 whitespace-nowrap font-medium">25折 ~ 1.68折 / 1元</td>
                            <td class="p-3 text-gray-600 text-xs">依庫存市值＋分戶帳餘額變動</td>
                        </tr>
                        <tr class="hover:bg-blue-50">
                            <td class="p-3 whitespace-nowrap">第一金證券</td>
                            <td class="p-3 whitespace-nowrap font-medium">2.8折 / 1元</td>
                            <td class="p-3 text-gray-600 text-xs">一般網路下單</td>
                        </tr>
                        <tr class="hover:bg-blue-50">
                            <td class="p-3 whitespace-nowrap">國泰證券</td>
                            <td class="p-3 whitespace-nowrap font-medium">2.8折 / 1元</td>
                            <td class="p-3 text-gray-600 text-xs">無專屬營業員</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <p class="mt-4 text-sm text-gray-500">
                註：折扣與低消資訊可能隨活動或帳戶類型變動，實際以各券商公告為準
            </p>
            `,
            img: chooseBrokerImg,
            imgClass: 'max-h-80 w-auto md:max-h-96', // 稍微增加圖片尺寸
        },
        {
            title: '💻 線上開戶流程',
            content: `
            <p class="mb-5 text-gray-700 leading-relaxed">若選擇線上開戶，步驟如下：</p>
            <ol class="list-decimal list-inside space-y-4 text-gray-800 leading-relaxed">
                <li><span class="font-semibold text-blue-700">下載 App 或進入官網：</span> 先選定欲開戶的證券商，使用官方 App 或網站</li>
                <li><span class="font-semibold text-blue-700">上傳身分資料：</span> 提交國民身分證、第二證件與自拍照以驗證身份</li>
                <li><span class="font-semibold text-blue-700">綁定銀行帳戶：</span> 輸入本人銀行帳號，用於資金轉入與轉出</li>
                <li><span class="font-semibold text-blue-700">通過驗證與審核：</span> 系統將自動比對資料，審核時間通常為 1–2 個工作天</li>
                <li><span class="font-semibold text-blue-700">收到通知後開始交易：</span> 開戶成功後即可登入交易系統進行下單</li>
            </ol>
            `,
            img: null, // 移除未提供的圖片
            imgClass: '',
        },
        {
            title: '🧾 臨櫃開戶流程',
            content: `
            <p class="mb-5 text-gray-700 leading-relaxed">若選擇臨櫃開戶，步驟如下：</p>
            <ol class="list-decimal list-inside space-y-4 text-gray-800 leading-relaxed">
                <li><span class="font-semibold text-blue-700">攜帶文件臨櫃：</span> 帶齊身分證、第二證件與印章至券商櫃檯</li>
                <li><span class="font-semibold text-blue-700">填寫申請書：</span> 依指示填寫開戶申請資料與風險評估問卷</li>
                <li><span class="font-semibold text-blue-700">綁定銀行帳戶：</span> 提供本人名下帳戶，簽署相關文件</li>
                <li><span class="font-semibold text-blue-700">等待審核通知：</span> 核對資料無誤後，將發送開戶完成通知</li>
                <li><span class="font-semibold text-blue-700">登入平台開始交易：</span> 取得帳號密碼後即可操作交易系統</li>
            </ol>
            `,
            img: null, // 移除未提供的圖片
            imgClass: '',
        },
        {
            title: '✅ 開戶完成後建議',
            content: `
            <p class="mb-5 text-gray-700 leading-relaxed">開戶完成後，建議依下列步驟確保帳戶安全並熟悉操作：</p>
            <ul class="list-disc list-inside space-y-4 text-gray-800 leading-relaxed">
                <li><span class="font-semibold text-blue-700">修改預設密碼：</span> 登入後立即更改預設密碼並設定雙重驗證</li>
                <li><span class="font-semibold text-blue-700">熟悉系統介面：</span> 了解下單方式、報價畫面與交易流程</li>
                <li><span class="font-semibold text-blue-700">學習交易規則：</span> 閱讀證交所規定與券商提供的教學資源</li>
                <li><span class="font-semibold text-blue-700">小額入金測試：</span> 先以少量資金練習下單，確認資金流與系統功能正常</li>
            </ul>
            `,
            img: null, // 移除未提供的圖片
            imgClass: '',
        },
    ]

    const isLastSlide = computed(() => currentSlide.value === slides.length - 1)

    function nextSlide() {
        if (currentSlide.value < slides.length - 1) currentSlide.value++
    }
    function prevSlide() {
        if (currentSlide.value > 0) currentSlide.value--
    }
    function goHome() {
        router.push('/learning')
        setTimeout(() => {
            toast.add({
                severity: 'success',
                summary: '🎉 恭喜你完成本單元！',
                life: 2500,
            })
        }, 300)
    }
</script>

<style scoped>
    table {
        border-collapse: collapse;
    }
</style>
