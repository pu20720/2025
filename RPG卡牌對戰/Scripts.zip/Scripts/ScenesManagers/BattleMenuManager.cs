using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System.Collections;
using TMPro;
using UnityEngine.InputSystem;

public class BattleMenuManager : MonoBehaviour
{
    [Header("Menu UI")]
    [SerializeField] private Button menuButton; // 左上角的 Menu 小按鈕
    [SerializeField] private GameObject pausePanel; // 中間那個大選單

    [Header("Panel Buttons")]
    [SerializeField] private Button resumeButton;
    [SerializeField] private Button saveButton;
    [SerializeField] private Button quitButton;

    [Header("Save Feedback")]
    [SerializeField] private TMP_Text saveStatusText;

    [Header("Game Data")]
    [SerializeField] private Inventory inventory;

    private Coroutine hideStatusCoroutine;

    private void Start()
    {
        // 1. 初始化狀態
        if (pausePanel != null) pausePanel.SetActive(false);
        if (saveStatusText != null) saveStatusText.gameObject.SetActive(false);

        // 2. 綁定按鈕 (使用 Lambda 方便 Debug)
        if (menuButton != null)
        {
            menuButton.onClick.RemoveAllListeners();
            menuButton.onClick.AddListener(() => {
                Debug.Log("[BattleMenu] Menu Button Clicked!"); // 測試點擊
                TogglePause();
            });
        }

        if (resumeButton != null)
        {
            resumeButton.onClick.RemoveAllListeners();
            resumeButton.onClick.AddListener(() => {
                Debug.Log("[BattleMenu] Resume Button Clicked!");
                TogglePause();
            });
        }

        if (saveButton != null)
        {
            saveButton.onClick.RemoveAllListeners();
            saveButton.onClick.AddListener(() => {
                Debug.Log("[BattleMenu] Save Button Clicked!");
                SaveGame();
            });
        }

        if (quitButton != null)
        {
            quitButton.onClick.RemoveAllListeners();
            quitButton.onClick.AddListener(() => {
                Debug.Log("[BattleMenu] Quit Button Clicked!");
                QuitGame();
            });
        }
    }

    private void Update()
    {
        // 鍵盤 ESC 測試
        if (Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            Debug.Log("[BattleMenu] ESC Key Pressed!");
            TogglePause();
        }
    }

    public void TogglePause()
    {
        if (pausePanel == null)
        {
            Debug.LogError("[BattleMenu] PausePanel is NULL!");
            return;
        }

        bool isPaused = !pausePanel.activeSelf;
        pausePanel.SetActive(isPaused);

        // 暫停時間 / 恢復時間
        Time.timeScale = isPaused ? 0f : 1f;

        Debug.Log($"[BattleMenu] Panel State Changed. Active: {isPaused}, TimeScale: {Time.timeScale}");

        if (!isPaused)
        {
            if (hideStatusCoroutine != null) StopCoroutine(hideStatusCoroutine);
            if (saveStatusText != null) saveStatusText.gameObject.SetActive(false);
        }
    }

    public void SaveGame()
    {
        if (inventory == null || BattleManager.Instance == null)
        {
            Debug.LogError("[BattleMenu] Missing References for Saving!");
            return;
        }

        SaveData data = new SaveData
        {
            PlayerName = ConversationManager.playerName,
            savedSceneName = SceneManager.GetActiveScene().name,
            Inventory = ConvertDictionaryToList(inventory.GetAllItems())
        };

        BattleManager.Instance.GatherSaveData(data);
        SaveManager.SaveStatic(data);

        if (saveStatusText != null)
        {
            if (hideStatusCoroutine != null) StopCoroutine(hideStatusCoroutine);
            hideStatusCoroutine = StartCoroutine(ShowSaveStatus());
        }
    }

    public void QuitGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }

    private IEnumerator ShowSaveStatus()
    {
        saveStatusText.gameObject.SetActive(true);
        // 使用 WaitForSecondsRealtime 因為 TimeScale 可能是 0
        yield return new WaitForSecondsRealtime(3f);
        saveStatusText.gameObject.SetActive(false);
        hideStatusCoroutine = null;
    }

    private List<InventoryItem> ConvertDictionaryToList(Dictionary<int, int> dict)
    {
        var list = new List<InventoryItem>();
        if (dict == null) return list;
        foreach (var kvp in dict) list.Add(new InventoryItem { id = kvp.Key, quantity = kvp.Value });
        return list;
    }
}