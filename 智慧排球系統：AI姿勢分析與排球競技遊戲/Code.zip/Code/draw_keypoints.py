# This script uses MediaPipe to detect pose landmarks in an image and visualize them.
# It includes the following steps:
# 1. Import necessary modules.
# 2. Load an image using OpenCV.
# 3. Create a PoseLandmarker object with the specified model.
# 4. Detect pose landmarks from the image.
# 5. Visualize the detected landmarks on the image and display it using OpenCV.
# 6. Save the annotated image to a file.
# 7. Clean up resources.

from mediapipe import solutions
from mediapipe.framework.formats import landmark_pb2
import numpy as np
import cv2

# Load the image using OpenCV
# Note: Make sure to have an image named "image.jpg" in the same directory or provide the correct path.
img = cv2.imread("play.jpg")
cv2.imshow("Original Image", img)
cv2.waitKey(0)  # Wait until a key is pressed
cv2.destroyAllWindows()  # Close the image window


def draw_landmarks_on_image(rgb_image, detection_result):
  pose_landmarks_list = detection_result.pose_landmarks
  annotated_image = np.copy(rgb_image)

  # Loop through the detected poses to visualize.
  for idx in range(len(pose_landmarks_list)):
    pose_landmarks = pose_landmarks_list[idx]

    # Draw the pose landmarks.
    pose_landmarks_proto = landmark_pb2.NormalizedLandmarkList()
    pose_landmarks_proto.landmark.extend([
      landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) for landmark in pose_landmarks
    ])
    solutions.drawing_utils.draw_landmarks(
      annotated_image,
      pose_landmarks_proto,
      solutions.pose.POSE_CONNECTIONS,
      solutions.drawing_styles.get_default_pose_landmarks_style())
  return annotated_image




  # STEP 1: Import the necessary modules.
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

# STEP 2: Create an PoseLandmarker object.
base_options = python.BaseOptions(model_asset_path='pose_landmarker_heavy.task')
options = vision.PoseLandmarkerOptions(
    base_options=base_options,
    output_segmentation_masks=True)
detector = vision.PoseLandmarker.create_from_options(options)

# STEP 3: Load the input image.
image = mp.Image.create_from_file("play.jpg")

# STEP 4: Detect pose landmarks from the input image.
detection_result = detector.detect(image)

# STEP 5: Process the detection result. In this case, visualize it.
annotated_image = draw_landmarks_on_image(image.numpy_view(), detection_result)
cv2.imshow("Annotated Image", cv2.cvtColor(annotated_image, cv2.COLOR_RGB2BGR))
cv2.waitKey(0)
cv2.destroyAllWindows()

# STEP 6: The annotated image is saved to a file.
cv2.imwrite("annotated_image.jpg", cv2.cvtColor(annotated_image, cv2.COLOR_RGB2BGR))

# STEP 7: Clean up resources.
detector.close()
image.close()