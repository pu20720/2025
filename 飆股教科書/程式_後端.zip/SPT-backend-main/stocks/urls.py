from django.urls import path
from .views import StockImportDB, Stock, Watchlist, HotStocks

urlpatterns = [
    path('stocks/', Stock.as_view(), name='stock-list'),
    path('stocks/import/', StockImportDB.as_view(), name='stock-import'),
    path('watchlist/', Watchlist.as_view(), name='watchlist'),
    path('hotstocks/', HotStocks.as_view(), name='hotstock-list'),
]
