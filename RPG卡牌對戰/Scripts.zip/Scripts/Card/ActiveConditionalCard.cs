// 檔案路徑: Assets/Scripts/Card/ActiveConditionalCard.cs
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

[RequireComponent(typeof(Image))]
public class ActiveConditionalCard : MonoBehaviour
{
    private CardData cardData;
    private Image cardImage;
    private int currentCharges;

    public void Initialize(CardData data)
    {
        this.cardData = data;
        this.currentCharges = data.charges;
        this.cardImage = GetComponent<Image>();

        Sprite cardBack = BattleManager.Instance.GetConditionalCardBack();
        if (cardBack != null)
        {
            this.cardImage.sprite = cardBack;
        }
    }

    public ConditionalTriggerType GetTriggerType()
    {
        return cardData.triggerType;
    }

    public bool TriggerEffect()
    {
        if (currentCharges <= 0) return false;

        currentCharges--;
        StartCoroutine(FlipAndRevertCoroutine());

        // ▼▼▼ 【修改】 確保日誌正確 ▼▼▼
        if (cardData.cardName.Trim() == "Threefold_Ward")
        {
            // (LogAction 已在 BattleManager.CheckForAttackNegation 中呼叫，這裡不再重複)
            return true;
        }
        // ▲▲▲ 【修改結束】 ▲▲▲

        return false;
    }

    private IEnumerator FlipAndRevertCoroutine()
    {
        cardImage.sprite = cardData.cardArt;
        yield return new WaitForSeconds(1.0f);

        if (currentCharges <= 0)
        {
            BattleManager.Instance.RemoveActiveConditional(this);
            Destroy(gameObject);
        }
        else
        {
            cardImage.sprite = BattleManager.Instance.GetConditionalCardBack();
        }
    }

    public ConditionalCardSaveData GatherSaveData()
    {
        if (cardData == null) return null;

        return new ConditionalCardSaveData
        {
            cardName = cardData.cardName,
            charges = this.currentCharges
        };
    }

    public void LoadFromSave(ConditionalCardSaveData data)
    {
        if (data == null) return;
        this.currentCharges = data.charges;
    }
}