// 檔案路徑: Assets/Scripts/UI/PlayerPanel.cs
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class PlayerPanel : MonoBehaviour
{
    [Header("Player Info")]
    [SerializeField] private TMP_Text playerNameText;
    [SerializeField] private TMP_Text playerHPText;

    [Header("Armor Slots")]
    [SerializeField] private Image helmetIcon;
    [SerializeField] private TMP_Text helmetArmorText;
    [SerializeField] private Image armorIcon;
    [SerializeField] private TMP_Text armorArmorText;
    [SerializeField] private Image gauntletsIcon;
    [SerializeField] private TMP_Text gauntletsArmorText;
    [SerializeField] private Image legArmorIcon;
    [SerializeField] private TMP_Text legArmorArmorText;

    [Header("Weapon")]
    [SerializeField] private Image weaponIcon;
    [SerializeField] private TMP_Text weaponAttackText;

    [Header("Status Effects")]
    [SerializeField] private Transform statusEffectParent;

    private Character targetCharacter;
    private CharacterStats stats;

    // 由 BattleManager 呼叫
    public void Initialize(Character target)
    {
        targetCharacter = target;
        stats = target.stats;

        if (targetCharacter == null || stats == null)
        {
            gameObject.SetActive(false);
            return;
        }

        UpdateStats();
    }

    // 由 BattleManager 呼叫
    public void UpdateStats()
    {
        if (targetCharacter == null || stats == null) return;

        // 1. 更新玩家資訊
        playerNameText.text = targetCharacter.characterName;

        // ▼▼▼ 修正：移除了 '/' 兩邊的空格 ▼▼▼
        playerHPText.text = $"HP:\n{stats.hp}/{stats.maxHp}";
        // ▲▲▲ 修正結束 ▲▲▲

        // 2. 更新四個護甲槽
        helmetArmorText.text = stats.helmet.currentArmor.ToString();
        armorArmorText.text = stats.armor.currentArmor.ToString();
        gauntletsArmorText.text = stats.gauntlets.currentArmor.ToString();
        legArmorArmorText.text = stats.legArmor.currentArmor.ToString();

        // 3. 更新武器 (已停用)
        // weaponAttackText.text = stats.attackValue.ToString();

        // 4. 更新狀態 (未來)
        UpdateStatusEffects();
    }

    private void UpdateStatusEffects()
    {
        // (未來實作)
    }
}