from django.urls import path
from .views import FinancialImportDB

urlpatterns = [
    path('', FinancialImportDB.as_view(), name='financial-list'),
]
