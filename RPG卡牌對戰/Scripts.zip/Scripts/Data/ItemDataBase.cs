using UnityEngine;
using System.Collections.Generic;
using System.Linq; // 用於簡化搜尋語法

[CreateAssetMenu(fileName = "ItemDatabase", menuName = "RPG/Item Database")]
public class ItemDatabase : ScriptableObject
{
    [Header("請把所有製作好的 ItemData 拖進這個清單")]
    public List<ItemData> allItems = new List<ItemData>();

    // 為了加速搜尋，我們在遊戲開始時建立一個字典
    private Dictionary<int, ItemData> itemDictionary = new Dictionary<int, ItemData>();
    private bool isInitialized = false;

    // 初始化字典
    public void Initialize()
    {
        itemDictionary.Clear();
        foreach (var item in allItems)
        {
            if (item != null && !itemDictionary.ContainsKey(item.itemID))
            {
                itemDictionary.Add(item.itemID, item);
            }
        }
        isInitialized = true;
    }

    // 給外部呼叫：透過 ID 找物品
    public ItemData GetItemByID(int id)
    {
        if (!isInitialized) Initialize();

        if (itemDictionary.ContainsKey(id))
        {
            return itemDictionary[id];
        }
        return null;
    }

    // 為了讓編輯器也能即時運作，我們確保在啟用時初始化
    private void OnEnable()
    {
        Initialize();
    }
}