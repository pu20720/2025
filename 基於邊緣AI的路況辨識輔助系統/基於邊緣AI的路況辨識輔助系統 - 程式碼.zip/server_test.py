from flask import Flask, request
import os
import time

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/upload', methods=['POST'])
def upload():
    if request.data:
        timestamp = int(time.time())
        filename = os.path.join(UPLOAD_FOLDER, 'latest.jpg')  #f'received_{timestamp}.jpg') , 'received.jpg')
        with open(filename, 'wb') as f:
            f.write(request.data)
        print("收到照片，存到:", filename)
        return 'Upload OK', 200
    else:
        return 'No data received', 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
