# train_pose_model.py
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# ========================
# Dataset
# ========================
class PoseSeqDataset(Dataset):
    def __init__(self, npz_path, idxs=None, mu=None, std=None):
        if not os.path.exists(npz_path):
            raise FileNotFoundError(f"NPZ file not found: {npz_path}")
        d = np.load(npz_path, allow_pickle=True)
        X = d["X"].astype(np.float32)   # (N, T, F=132)
        y = d["Y"].astype(np.int64)     # (N,)
        if idxs is not None:
            X, y = X[idxs], y[idxs]

        # 標準化
        if mu is None or std is None:
            mu = X.mean(axis=(0,1), keepdims=True)
            std = X.std(axis=(0,1), keepdims=True) + 1e-6
        X = (X - mu) / std

        # 調整成 (N, F, T) 方便 Conv1d
        self.X = torch.from_numpy(X.transpose(0,2,1))  # (N, 132, 30)
        self.y = torch.from_numpy(y)
        self.mu, self.std = mu, std

    def __len__(self): return len(self.y)
    def __getitem__(self, i): return self.X[i], self.y[i]

# ========================
# Model: TCN
# ========================
class TCNBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, d=1, p=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_ch, out_ch, kernel_size=k,
                      padding=d*(k-1)//2, dilation=d),
            nn.ReLU(),
            nn.Dropout(p),
            nn.Conv1d(out_ch, out_ch, kernel_size=k,
                      padding=d*(k-1)//2, dilation=d),
        )
        self.res = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(self.net(x) + self.res(x))

class TCNClassifier(nn.Module):
    def __init__(self, in_feats=132, num_classes=2):
        super().__init__()
        chs = [in_feats, 256, 256]
        dilations = [1, 2]

        blocks = []
        for i in range(len(chs)-1):
            blocks.append(TCNBlock(chs[i], chs[i+1], k=3, d=dilations[i], p=0.3))
        self.backbone = nn.Sequential(*blocks)

        self.head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(chs[-1], num_classes)
        )

    def forward(self, x):
        h = self.backbone(x)
        return self.head(h)

# ========================
# Training & Evaluation
# ========================
def train_eval(npz_path, num_classes=2, folds=5, epochs=100):
    data = np.load(npz_path, allow_pickle=True)
    y = data["Y"]
    skf = StratifiedKFold(n_splits=folds, shuffle=True, random_state=42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 儲存路徑
    save_dir = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1"
    os.makedirs(save_dir, exist_ok=True)

    all_acc, all_f1 = [], []
    cm_total = np.zeros((num_classes, num_classes), dtype=int)

    # 測試資料與模型 shape
    ds_test = PoseSeqDataset(npz_path, idxs=[0])
    x_sample, y_sample = ds_test[0]
    x_sample = x_sample.unsqueeze(0)  # batch 1
    model_test = TCNClassifier(in_feats=132, num_classes=num_classes)
    out_sample = model_test(x_sample)
    print(f"Sample input shape: {x_sample.shape}, Output shape: {out_sample.shape}")

    for fold, (tr_idx, te_idx) in enumerate(skf.split(y, y), 1):
        ds_tr_full = PoseSeqDataset(npz_path, idxs=tr_idx)
        ds_te = PoseSeqDataset(npz_path, idxs=te_idx,
                               mu=ds_tr_full.mu, std=ds_tr_full.std)

        dl_tr = DataLoader(ds_tr_full, batch_size=8, shuffle=True)
        dl_te = DataLoader(ds_te, batch_size=8)

        model = TCNClassifier(in_feats=132, num_classes=num_classes).to(device)
        criterion = nn.CrossEntropyLoss()
        opt = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-3)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=5)

        best_acc, bad, patience = 0.0, 0, 15
        best_state = None

        for ep in range(1, epochs+1):
            model.train()
            for x, t in dl_tr:
                x, t = x.to(device), t.to(device)
                opt.zero_grad()
                loss = criterion(model(x), t)
                loss.backward(); opt.step()

            model.eval(); correct, total = 0, 0
            y_true, y_pred = [], []
            with torch.no_grad():
                for x, t in dl_te:
                    x, t = x.to(device), t.to(device)
                    out = model(x)
                    pred = out.argmax(1)
                    correct += (pred==t).sum().item()
                    total += t.size(0)
                    y_true.extend(t.cpu().numpy())
                    y_pred.extend(pred.cpu().numpy())

            acc = correct / total
            f1 = f1_score(y_true, y_pred, average="macro")
            scheduler.step(1-acc)

            if acc > best_acc:
                best_acc, best_f1, bad = acc, f1, 0
                best_state = model.state_dict()
                save_path = os.path.join(save_dir, f"best_model_fold{fold}.pt")
                torch.save(best_state, save_path)
                print(f"[Fold {fold}, Epoch {ep}] Saved best model to: {save_path}")
            else:
                bad += 1

            if bad >= patience: 
                print(f"[Fold {fold}] Early stopping at epoch {ep}")
                break

        print(f"[Fold {fold}] Best Acc={best_acc:.3f}, Macro-F1={best_f1:.3f}")
        all_acc.append(best_acc)
        all_f1.append(best_f1)
        cm_total += confusion_matrix(y_true, y_pred, labels=list(range(num_classes)))

    print("="*40)
    print(f"CV Avg Acc={np.mean(all_acc):.3f}, Avg F1={np.mean(all_f1):.3f}")

    plt.figure(figsize=(6,5))
    sns.heatmap(cm_total, annot=True, fmt="d", cmap="Blues")
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.title("Confusion Matrix (Total)")
    plt.show()


if __name__ == "__main__":
    npz_path = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\dataset_spike.npz"
    train_eval(npz_path, num_classes=2, folds=5, epochs=100)
