using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using System.Linq;

public class BattleInventoryUI : MonoBehaviour
{
    [Header("Main Panel")]
    public GameObject panelRoot;

    [Tooltip("請拖曳場景左側的背包按鈕")]
    public Button toggleButton;

    [Header("Info Area")]
    public TextMeshProUGUI setBonusText;
    public Image selectedItemIcon;
    public TextMeshProUGUI selectedItemName;
    public TextMeshProUGUI selectedItemDesc;
    public Button useButton;
    public Button discardButton;

    [Header("Grid Areas")]
    [Tooltip("Consumable 的父物件 (需掛載 Grid Layout Group, Constraint=Fixed Column Count 5)")]
    public Transform consumableGridContent;
    [Tooltip("Special 的父物件 (需掛載 Grid Layout Group, Constraint=Fixed Column Count 3)")]
    public Transform specialGridContent;

    [Tooltip("用來生成物品的小格子 Prefab")]
    public GameObject itemSlotPrefab;

    private ItemData currentSelectedItem;
    private CanvasGroup canvasGroup;

    private void Awake()
    {
        // 確保有 CanvasGroup 以便控制顯示/隱藏
        canvasGroup = panelRoot.GetComponent<CanvasGroup>();
        if (canvasGroup == null) canvasGroup = panelRoot.AddComponent<CanvasGroup>();

        // 遊戲開始時隱藏背包
        SetVisible(false);
    }

    private void Start()
    {
        // 綁定按鈕事件
        if (toggleButton != null)
        {
            toggleButton.onClick.RemoveAllListeners();
            toggleButton.onClick.AddListener(TogglePanel);
        }

        if (useButton != null) useButton.onClick.AddListener(OnUseClicked);
        if (discardButton != null) discardButton.onClick.AddListener(OnDiscardClicked);

        ClearSelection();
    }

    // 開關面板
    public void TogglePanel()
    {
        bool isVisible = canvasGroup.alpha > 0.1f;
        SetVisible(!isVisible);

        if (!isVisible) // 如果即將開啟，刷新資料
        {
            RefreshGrid();
            UpdateSetBonusText();
        }
    }

    public void SetVisible(bool visible)
    {
        canvasGroup.alpha = visible ? 1f : 0f;
        canvasGroup.interactable = visible;
        canvasGroup.blocksRaycasts = visible;
    }

    private void RefreshGrid()
    {
        // 1. 清空舊格子
        if (consumableGridContent != null)
        {
            foreach (Transform child in consumableGridContent) Destroy(child.gameObject);
        }
        if (specialGridContent != null)
        {
            foreach (Transform child in specialGridContent) Destroy(child.gameObject);
        }

        if (InventoryManager.Instance == null)
        {
            Debug.LogError("[BattleInventoryUI] 找不到 InventoryManager Instance!");
            return;
        }

        var allSlots = InventoryManager.Instance.backpackSlots;

        // 2. 篩選並生成 Consumables
        var consumables = allSlots.Where(s => s.equippedCount > 0 && s.itemData.itemType == ItemType.Consumable).ToList();
        foreach (var slot in consumables)
        {
            CreateSlot(slot, consumableGridContent);
        }

        // 3. 篩選並生成 Specials
        var specials = allSlots.Where(s => s.equippedCount > 0 && s.itemData.itemType == ItemType.Special).ToList();
        foreach (var slot in specials)
        {
            CreateSlot(slot, specialGridContent);
        }
    }
    private void CreateSlot(InventorySlot slot, Transform parentTransform)
    {
        if (parentTransform == null || itemSlotPrefab == null) return;

        GameObject obj = Instantiate(itemSlotPrefab, parentTransform);

        // 嘗試獲取 Image 組件
        Image icon = obj.GetComponent<Image>();

        if (icon != null)
        {
            if (slot.itemData.icon != null)
            {
                // 有圖示：顯示圖示，顏色設為白 (不染色)
                icon.sprite = slot.itemData.icon;
                icon.color = Color.white;
            }
            else
            {
                // 沒圖示：清空 Sprite，使用 Data 定義的顏色
                icon.sprite = null;
                icon.color = slot.itemData.displayColor;
            }
        }

        // ★★★ 新增：防止 Button 組件的顏色過渡覆蓋掉我們的顏色 ★★★
        Button btn = obj.GetComponent<Button>();
        if (btn != null)
        {
            // 將過渡模式設為 None，這樣 Button 就不會去亂改 Image 的顏色
            btn.transition = Selectable.Transition.None;

            // 綁定點擊事件
            btn.onClick.AddListener(() => OnItemSelected(slot.itemData));
        }

        TMP_Text countText = obj.GetComponentInChildren<TMP_Text>();
        if (countText != null) countText.text = slot.equippedCount.ToString();
    }

    private void UpdateSetBonusText()
    {
        if (setBonusText != null && InventoryManager.Instance != null)
        {
            setBonusText.text = InventoryManager.Instance.GetActiveSetBonus();
        }
    }

    private void OnItemSelected(ItemData item)
    {
        currentSelectedItem = item;

        // 更新資訊欄顯示
        if (selectedItemIcon != null)
        {
            if (item.icon != null)
            {
                selectedItemIcon.sprite = item.icon;
                selectedItemIcon.color = Color.white;
            }
            else
            {
                selectedItemIcon.sprite = null;
                selectedItemIcon.color = item.displayColor;
            }
        }
        if (selectedItemName != null) selectedItemName.text = item.itemName;
        if (selectedItemDesc != null) selectedItemDesc.text = item.description;

        // 啟用操作按鈕
        if (useButton != null) useButton.interactable = true;
        if (discardButton != null) discardButton.interactable = true;
    }

    private void ClearSelection()
    {
        currentSelectedItem = null;
        if (selectedItemName != null) selectedItemName.text = "Select Item";
        if (selectedItemDesc != null) selectedItemDesc.text = "";
        if (selectedItemIcon != null) selectedItemIcon.color = Color.clear;

        if (useButton != null) useButton.interactable = false;
        if (discardButton != null) discardButton.interactable = false;
    }

    private void OnUseClicked()
    {
        if (currentSelectedItem == null) return;

        // 隱藏背包，呼叫 BattleManager 進入目標選擇模式
        SetVisible(false);

        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.SelectItem(currentSelectedItem);
        }
    }

    private void OnDiscardClicked()
    {
        if (currentSelectedItem == null) return;

        if (InventoryManager.Instance != null)
        {
            InventoryManager.Instance.TryDecreaseLoadout(currentSelectedItem);
        }

        // 刷新顯示 (物品可能消失或數量減少)
        RefreshGrid();
        ClearSelection();
    }
}