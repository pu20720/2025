using UnityEngine;

[System.Serializable]
public class CardData
{
    [Header("卡牌基本資訊")]
    public string cardName;
    [TextArea] public string description;
    public int mpCost;
    public CardType type;
    public Sprite cardArt;

    [Header("卡牌梯度")]
    public string cardGrade;

    // ▼▼▼ 【整合修復】 ▼▼▼
    public bool isStarterCard = true;
    // ▲▲▲

    [Header("卡牌效果")]
    public bool isCoveredCard = false;
    public int effectValue;
    public ArmorPart targetArmorPart = ArmorPart.Armor;
    public DamageType damageType = DamageType.Normal;

    [Header("Status Effects")]
    public StatusType statusToApply = StatusType.Bleed;
    public int statusStacks = 0;

    [Header("New Mechanics")]
    public bool cleanseDebuffs = false;
    public int drawCards = 0;
    public int cleaveDamage = 0;
    public int piercePercent = 0;
    public int itemPrice;
    public int durationTurns;
    public int damageReductionPercent;
    public int extraAttacks;
    public int hitCount;
    public float attackRatio;
    public int turnThreshold;

    [Header("Conditional Card Stats")]
    public int charges = 3;
    public ConditionalTriggerType triggerType = ConditionalTriggerType.None;
}