from django.contrib import admin
from .models import Stock  # 或你的模型名稱

admin.site.register(Stock)
