<template>
    <!-- 套用優化後的容器樣式：背景、大間距、最大寬度 -->
    <div class="w-full px-4 md:px-16 py-12 bg-gray-50 min-h-screen">
        <!-- 進度條區塊：自定義進度條與主題標籤 -->
        <div class="mb-10 max-w-5xl mx-auto">
            <div class="flex justify-between items-end mb-2">
                <h3 class="text-xl font-semibold text-blue-700 transition duration-300">
                    {{
                        slides[currentSlide].title.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]\s?/, '')
                    }}
                </h3>
                <span class="text-sm font-medium text-gray-500">
                    主題 {{ currentSlide + 1 }} / {{ slides.length }}
                </span>
            </div>
            <div class="w-full bg-gray-300 rounded-full h-2.5 overflow-hidden">
                <div
                    class="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
                    :style="{ width: ((currentSlide + 1) / slides.length) * 100 + '%' }"
                ></div>
            </div>
        </div>

        <!-- Slide 區塊：優化後的卡片樣式與 slide-fade 動畫 -->
        <transition name="slide-fade" mode="out-in">
            <div
                :key="currentSlide"
                class="bg-white rounded-2xl shadow-xl p-10 md:flex gap-12 items-start border border-gray-100 max-w-5xl mx-auto"
            >
                <!-- 內容區塊：由於沒有圖片，強制設定為 full-width -->
                <div class="md:w-full w-full">
                    <!-- 標題樣式 -->
                    <h2 class="text-3xl font-extrabold mb-6 text-gray-800">
                        {{ slides[currentSlide].title }}
                    </h2>
                    <!-- 內容樣式 -->
                    <div
                        class="text-lg text-gray-700 leading-relaxed space-y-4"
                        v-html="slides[currentSlide].content"
                    ></div>
                </div>

                <!-- 圖片區塊已移除，因為 img: null -->
            </div>
        </transition>

        <!-- 控制按鈕區塊：優化後的圓角按鈕和間距 -->
        <div class="flex justify-between mt-16 max-w-5xl mx-auto">
            <button
                @click="prevSlide"
                :disabled="currentSlide === 0"
                class="px-7 py-2.5 rounded-full border border-blue-600 text-blue-600 font-medium hover:bg-blue-50 transition duration-300 disabled:opacity-40 disabled:border-gray-300 disabled:text-gray-400"
            >
                &larr; 上一主題
            </button>

            <button
                v-if="!isLastSlide"
                @click="nextSlide"
                class="px-9 py-2.5 rounded-full bg-blue-600 text-white font-semibold shadow-md shadow-blue-300 hover:bg-blue-700 hover:shadow-lg transition duration-300"
            >
                下一主題 &rarr;
            </button>

            <button
                v-else
                @click="goHome"
                class="px-9 py-2.5 rounded-full bg-green-600 text-white font-semibold shadow-md shadow-green-300 hover:bg-green-700 hover:shadow-lg transition duration-300"
            >
                回到課程首頁
            </button>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed } from 'vue'
    import { useRouter } from 'vue-router'
    import { useToast } from 'primevue/usetoast'

    const toast = useToast()
    const router = useRouter()
    const currentSlide = ref(0)

    const slides = [
        {
            title: '💰 股票買賣單位',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">
        在台灣股票市場中，買賣單位與價格變動有明確規範，以下是基本概念：
      </p>

      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 whitespace-nowrap">項目</th>
                <th class="p-3">說明</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">基本單位</td>
                <td class="p-3">一「張」為 1,000 股一般投資人以「張」為交易單位</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">零股交易</td>
                <td class="p-3">
                  少於 1 張（&lt;1,000 股）稱為「零股」可於證交所「零股交易系統」掛單，<br>
                  以整股收盤價為參考，一日撮合一次（盤後）
                </td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">升降單位</td>
                <td class="p-3">
                  <ul class="list-disc list-inside ml-2">
                    <li>0.01–5 元 → 0.01 元</li>
                    <li>5–50 元 → 0.05 元</li>
                    <li>50–100 元 → 0.1 元</li>
                    <li>100–150 元 → 0.5 元</li>
                    <li>150–1000 元 → 1 元</li>
                    <li>1000 元以上 → 5 元</li>
                  </ul>
                </td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">每股價格</td>
                <td class="p-3">每股面額為 <span class="text-blue-700 font-semibold">10 元</span>（修法後多數已無此限制）</td>
              </tr>
            </tbody>
          </table>
      </div>
    `,
            img: null,
            imgClass: '',
        },
        {
            title: '🏛️ 三大法人介紹',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">
        台灣股市中有三大主要法人投資人類別，其動向常被視為市場風向指標：
      </p>
      
      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 whitespace-nowrap">類別</th>
                <th class="p-3">定義</th>
                <th class="p-3">特性與影響力</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">外資（FII）</td>
                <td class="p-3">外國投資機構、公司或個人經金管會核准後投資台股</td>
                <td class="p-3">資金量龐大、偏好電子股與權值股，買超常帶動指數上揚</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">投信</td>
                <td class="p-3">國內基金公司投資團隊運用募集資金操作股票或 ETF</td>
                <td class="p-3">長期操作、穩健風格；買超常代表中期市場看多</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">自營商</td>
                <td class="p-3">券商以自有資金進行買賣，含避險與套利</td>
                <td class="p-3">短線操作頻繁，影響盤中波動與流動性</td>
              </tr>
            </tbody>
          </table>
      </div>
    `,
            img: null,
            imgClass: '',
        },
        {
            title: '🏦 上市、上櫃、興櫃股票差異',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">
        台灣股市依公司規模與條件分為三大市場：
      </p>

      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 whitespace-nowrap">市場類別</th>
                <th class="p-3">財務要求</th>
                <th class="p-3">規模要求</th>
                <th class="p-3">漲跌幅限制</th>
                <th class="p-3">流動性</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">上市公司</td>
                <td class="p-3">近三年累計淨利達 2.5 億元，股東 1000 人以上</td>
                <td class="p-3">股本 6 億以上</td>
                <td class="p-3">±10%</td>
                <td class="p-3">高</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">上櫃公司</td>
                <td class="p-3">最近一年獲利達 4000 萬元，股東 300 人以上</td>
                <td class="p-3">股本 5000 萬以上</td>
                <td class="p-3">±10%</td>
                <td class="p-3">中</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">興櫃公司</td>
                <td class="p-3">無明確財務標準，只需公開財報</td>
                <td class="p-3">無限制</td>
                <td class="p-3">無限制</td>
                <td class="p-3">低</td>
              </tr>
            </tbody>
          </table>
      </div>
    `,
            img: null,
            imgClass: '',
        },
        {
            title: '📈 三大常見股票投資商品',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">
        初學者可依風險承受度選擇不同投資工具：
      </p>

      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 whitespace-nowrap">類別</th>
                <th class="p-3">投資對象</th>
                <th class="p-3">管理方式</th>
                <th class="p-3">風險程度</th>
                <th class="p-3">流動性</th>
                <th class="p-3">適合對象</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">個股</td>
                <td class="p-3">單一公司股票</td>
                <td class="p-3">自行選股</td>
                <td class="p-3 text-red-600 font-semibold">高</td>
                <td class="p-3">高</td>
                <td class="p-3">進階投資人</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">ETF</td>
                <td class="p-3">追蹤指數的一籃子股票</td>
                <td class="p-3">被動追蹤</td>
                <td class="p-3 text-yellow-600 font-semibold">中</td>
                <td class="p-3">高</td>
                <td class="p-3">想分散風險的新手</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">共同基金</td>
                <td class="p-3">多樣化資產，由經理人操盤</td>
                <td class="p-3">主動管理</td>
                <td class="p-3 text-green-700 font-semibold">中偏低</td>
                <td class="p-3">中</td>
                <td class="p-3">長期理財、低參與度投資者</td>
              </tr>
            </tbody>
          </table>
      </div>
    `,
            img: null,
            imgClass: '',
        },
    ]

    const isLastSlide = computed(() => currentSlide.value === slides.length - 1)

    function nextSlide() {
        if (currentSlide.value < slides.length - 1) currentSlide.value++
    }
    function prevSlide() {
        if (currentSlide.value > 0) currentSlide.value--
    }
    function goHome() {
        router.push('/learning')
        setTimeout(() => {
            toast.add({
                severity: 'success',
                summary: '🎉 恭喜你完成本單元！',
                life: 2500,
            })
        }, 300)
    }
</script>

<style scoped>
    table {
        border-collapse: collapse;
    }
</style>
