using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuestSlotUI : MonoBehaviour
{
    [Header("UI Components")]
    public TextMeshProUGUI rankText;
    public TextMeshProUGUI titleText;
    public Image enemyImage;
    public TextMeshProUGUI descriptionText;
    public Image backgroundImage;

    private QuestData myData;
    private AdventurerUI uiManager;

    // 這裡設為 public 以便您在 Inspector 檢查是否真的有抓到
    public Button selfButton;

    private void Awake()
    {
        // ▼▼▼ 【新增】 強制抓取按鈕，避免遺漏 ▼▼▼
        if (selfButton == null)
        {
            selfButton = GetComponent<Button>();
            // 如果物件本身沒有 Button，試著找子物件 (雖然通常是掛在自己身上)
            if (selfButton == null) selfButton = GetComponentInChildren<Button>();
        }
    }

    public void Setup(QuestData data, AdventurerUI ui)
    {
        myData = data;
        uiManager = ui;

        if (rankText) rankText.text = data.rank.ToString();
        if (titleText) titleText.text = data.title;
        if (descriptionText) descriptionText.text = data.description;

        if (enemyImage)
        {
            if (data.enemyImage != null) enemyImage.sprite = data.enemyImage;
            else enemyImage.color = Color.gray;
        }

        if (rankText)
        {
            switch (data.rank)
            {
                case QuestRank.S: rankText.color = Color.red; break;
                case QuestRank.A: rankText.color = new Color(1f, 0.5f, 0f); break;
                case QuestRank.B: rankText.color = Color.magenta; break;
                case QuestRank.C: rankText.color = Color.cyan; break;
                case QuestRank.D: rankText.color = Color.white; break;
            }
        }

        // ▼▼▼ 【修改】 綁定按鈕事件並加入 Debug ▼▼▼
        if (selfButton != null)
        {
            selfButton.onClick.RemoveAllListeners();
            selfButton.onClick.AddListener(OnClicked);
            // 確保按鈕是啟用的
            selfButton.interactable = true;
        }
        else
        {
            Debug.LogError($"[QuestSlotUI] 找不到 Button 組件！請確認 Prefab 上有 Button。 (Object: {gameObject.name})");
        }
    }

    private void OnClicked()
    {
        Debug.Log($"[QuestSlotUI] Clicked: {myData.title}");
        if (uiManager != null) uiManager.OnQuestSelected(this, myData);
    }

    public void SetSelected(bool isSelected)
    {
        if (backgroundImage != null)
        {
            // 選中變綠
            backgroundImage.color = isSelected ? new Color(0.7f, 1f, 0.7f) : Color.white;
        }
    }
}