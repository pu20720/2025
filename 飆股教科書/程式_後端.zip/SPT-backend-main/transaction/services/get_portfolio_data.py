import logging
from django.db.models import F
from transaction.models import Portfolio


def get_portfolio_data(user):
    logger = logging.getLogger(__name__)
    qs = Portfolio.objects.select_related('stock').annotate(
        stock_symbol=F('stock__symbol'),
        stock_name=F('stock__name'),
    )
    qs = qs.filter(user=user)

    data = list(qs.values())
    if not data:
        logger.warning(f'[Portfolio] 使用者 {user.id} 沒有投資組合資料')
    return data
