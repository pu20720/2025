import mediapipe as mp
from mediapipe import solutions
from mediapipe.framework.formats import landmark_pb2
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
import numpy as np
import pandas as pd
import cv2
import os
# from draw_keypoints import draw_landmarks_on_image


# 安全輸出
def safe_print(text):
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode('cp950', errors='ignore').decode('cp950'))


# 設定影片資料夾與 CSV 輸出位置（用絕對路徑沒問題）
video_folder = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\overhand"
# model_path = r"D:\\workspace\\Python\\Mediapipe Pose Landmark Detection\\pose_landmarker_heavy.task"  # 模型位置
# output_video_folder = r"D:\\workspace\\Python\\Mediapipe Pose Landmark Detection_1\\spike_annotated_output"
output_csv_folder = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\overhand_csv"
#　os.makedirs(output_video_folder, exist_ok=True)
os.makedirs(output_csv_folder, exist_ok=True)


'''# 初始化模型
base_options = python.BaseOptions(model_asset_path=model_path)
options = vision.PoseLandmarkerOptions(
    base_options=base_options,
    output_segmentation_masks=False)
detector = vision.PoseLandmarker.create_from_options(options)'''


rows = []


# 載入影片
valid_extensions = (".MOV", ".mp4")

# 讀取影片並標註
for file in os.listdir(video_folder):
    if file.endswith(valid_extensions):
        # 讀取影片基本資訊
        cap = cv2.VideoCapture(os.path.join(video_folder, file))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)

        start_frame = 0
        end_frame = total_frames - 1
        frame_count = end_frame - start_frame + 1

        # 嘗試從檔名推斷 action, angle, quality
        name = file.replace(".MOV" or ".mp4", "")

        parts = name.split("_")

        if len(parts) < 4:
            print(f"⚠️ 命名格式錯誤，請確認檔名格式：{file}")
            action, angle, quality = "", "", ""
        else:
            action = parts[0]
            angle = parts[1]
            quality = parts[2]

        rows.append({
            "filename": name,
            "action": action,
            "angle": angle,
            "quality": quality,
            "total_frames": total_frames,
            "start_frame": start_frame,
            "end_frame": total_frames,
            "frame_count": frame_count,
            "fps": fps,
            "notes": ""
        })

        # output_file = os.path.join(output_video_folder, file)
        # fourcc = cv2.VideoWriter_fourcc(*'MP4V')
        # out = cv2.VideoWriter(output_file, fourcc, fps, (width, height))

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # 將影格轉換為 MediaPipe 格式

# 輸出 CSV`
df = pd.DataFrame(rows)
csv_name = os.path.basename(video_folder.rstrip("\\/")) + ".csv"
output_csv_file = os.path.join(output_csv_folder, csv_name)
df.to_csv(output_csv_file, index=False, encoding='utf-8-sig')

print("✅ CSV 已儲存至：", output_csv_folder)
# print("✅ 影片已標註並儲存至：", output_video_folder)

'''# 關閉模型
detector.close()'''

# 關閉所有影片
cap.release()
# out.release()
cv2.destroyAllWindows()

