import pandas as pd
import numpy as np

# 路徑
file_path = r"C:\Users\user\Desktop\Mediapipe Pose Landmark Detection_1\Mediapipe Pose Landmark Detection_1\overhand_csv\overhand_poses_labeled.csv"

# 讀取資料
df = pd.read_csv(file_path)

# 1) 特徵：選取 x*, y*, z*, v* 欄位（涵蓋 x0 ~ v32 區間）
feature_cols = [c for c in df.columns if c.startswith(("x", "y", "z", "v"))]
#去掉video欄位
if 'video' in feature_cols:
    feature_cols.remove('video')    


X_flat = df[feature_cols].to_numpy()


# 2) 依每 30 列切成 3D： (n_slices, 30, n_features)
n_rows, n_features = X_flat.shape
n_slices = n_rows // 30
X = X_flat[: n_slices * 30].reshape(n_slices, 30, n_features)


# 3) 標籤：quality -> 0/1 映射（correct=1, wrong=0），並每 30 列合併為一個值
q = df["quality"].map({"correct": 1, "wrong": 0}).to_numpy()[: n_slices * 30].reshape(n_slices, 30)

# 全部正確才算 1（嚴格）
Y = q.min(axis=1)


# 4) 儲存為可重複載入之檔案
np.save("X.npy", X)
np.save("Y.npy", Y)
np.savez("dataset_overhand.npz", X=X, Y=Y)



print(X.shape)
print (len(X))
print(Y.shape)  
print (Y) 