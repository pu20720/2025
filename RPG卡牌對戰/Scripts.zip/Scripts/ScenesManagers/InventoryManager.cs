using System.Collections.Generic;
using UnityEngine;
using System.Linq;

[System.Serializable]
public class InventorySlot
{
    public ItemData itemData;
    public int quantity;
    public int equippedCount;
}

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager Instance;

    [Header("Money")]
    public int playerMoney = 1000;

    [Header("Database")]
    public List<InventorySlot> backpackSlots = new List<InventorySlot>();

    [Header("Loadout Limits")]
    public int maxConsumables = 10;
    public int maxCards = 64;
    public int maxCardDuplicates = 3;
    public int maxSpecials = 3;

    // [已移除] public InventoryUI inventoryUI; <-- 移除此行，避免跨場景遺失引用

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // ★ 關鍵：讓背包資料活過場景切換
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        // 如果是第一次執行 (背包是空的)，生成測試物品
        if (backpackSlots.Count == 0)
        {
            InitializeTestItems();
        }

        RefreshCurrentSceneUI();
    }

    void InitializeTestItems()
    {
        // 1. Bandage (紅色)
        ItemData bandage = ScriptableObject.CreateInstance<ItemData>();
        bandage.itemName = "Bandage";
        bandage.itemID = "Bandage".GetHashCode();
        bandage.itemType = ItemType.Consumable;
        bandage.displayColor = Color.red;
        bandage.description = "Restores HP";
        bandage.healAmount = 20;

        // 加入 10 個
        AddItem(bandage);
        var bandageSlot = backpackSlots.FirstOrDefault(x => x.itemData.itemID == bandage.itemID);
        if (bandageSlot != null) bandageSlot.quantity = 10;

        // 2. Mana Potion (藍色)
        ItemData mana = ScriptableObject.CreateInstance<ItemData>();
        mana.itemName = "Mana Potion";
        mana.itemID = "Mana Potion".GetHashCode();
        mana.itemType = ItemType.Consumable;
        mana.displayColor = Color.blue;
        mana.description = "Restores MP";

        // 加入 7 個
        AddItem(mana);
        var manaSlot = backpackSlots.FirstOrDefault(x => x.itemData.itemID == mana.itemID);
        if (manaSlot != null) manaSlot.quantity = 7;

        Debug.Log("[InventoryManager] 已生成初始物品：10 Bandage, 7 Mana Potion");
    }

    // 嘗試刷新當前場景的 UI (商店或戰鬥)
    public void RefreshCurrentSceneUI()
    {
        // 找商店 UI
        InventoryUI shopUI = FindFirstObjectByType<InventoryUI>();
        if (shopUI != null) shopUI.RefreshUI();

        // 戰鬥 UI 通常是被動刷新的 (打開時刷新)，所以這裡不一定需要強制呼叫
    }

    public void AddMoney(int amount)
    {
        playerMoney += amount;
        Debug.Log($"[InventoryManager] Added {amount} gold. Current: {playerMoney}");
    }

    public bool SpendMoney(int amount)
    {
        if (playerMoney >= amount)
        {
            playerMoney -= amount;
            RefreshCurrentSceneUI();
            return true;
        }
        return false;
    }

    public void AddItem(ItemData newItem)
    {
        bool isStackable = (newItem.itemType == ItemType.Consumable ||
                            newItem.itemType == ItemType.Special ||
                            newItem.itemType == ItemType.Card);

        if (isStackable)
        {
            InventorySlot existingSlot = backpackSlots.FirstOrDefault(x => x.itemData.itemID == newItem.itemID);
            if (existingSlot != null)
            {
                existingSlot.quantity++;
            }
            else
            {
                backpackSlots.Add(new InventorySlot { itemData = newItem, quantity = 1, equippedCount = 0 });
            }
        }
        else
        {
            backpackSlots.Add(new InventorySlot { itemData = newItem, quantity = 1, equippedCount = 0 });
        }

        RefreshCurrentSceneUI();
    }

    public void RemoveItemData(ItemData itemToRemove)
    {
        InventorySlot targetSlot = backpackSlots.FirstOrDefault(x => x.itemData.itemID == itemToRemove.itemID);
        if (targetSlot != null)
        {
            if (targetSlot.quantity > 1) targetSlot.quantity--;
            else backpackSlots.Remove(targetSlot);

            if (targetSlot.equippedCount > targetSlot.quantity && itemToRemove.itemType != ItemType.Card)
            {
                targetSlot.equippedCount = targetSlot.quantity;
            }

            RefreshCurrentSceneUI();
        }
    }

    public void SwapItems(int indexA, int indexB)
    {
        if (indexA < 0 || indexA >= backpackSlots.Count || indexB < 0 || indexB >= backpackSlots.Count) return;
        InventorySlot temp = backpackSlots[indexA];
        backpackSlots[indexA] = backpackSlots[indexB];
        backpackSlots[indexB] = temp;
    }

    public bool TryIncreaseLoadout(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= backpackSlots.Count) return false;
        InventorySlot slot = backpackSlots[slotIndex];

        bool ignoreQuantityCheck = (slot.itemData.itemType == ItemType.Card);

        if (!ignoreQuantityCheck)
        {
            if (slot.equippedCount >= slot.quantity) return false;
        }

        if (CheckCanAdd(slot))
        {
            if (slot.itemData.itemType == ItemType.Equipment)
            {
                UnequipSameSlot(slot.itemData.equipSlot);
                slot.equippedCount = 1;
            }
            else
            {
                slot.equippedCount++;
            }
            return true;
        }
        return false;
    }

    public bool TryDecreaseLoadout(ItemData item)
    {
        InventorySlot slot = backpackSlots.FirstOrDefault(x => x.itemData.itemID == item.itemID && x.equippedCount > 0);
        if (slot != null)
        {
            slot.equippedCount--;
            return true;
        }
        return false;
    }

    private bool CheckCanAdd(InventorySlot slot)
    {
        ItemData item = slot.itemData;
        switch (item.itemType)
        {
            case ItemType.Consumable:
                int totalConsumables = backpackSlots.Where(x => x.itemData.itemType == ItemType.Consumable).Sum(x => x.equippedCount);
                return (totalConsumables + 1) <= maxConsumables;

            case ItemType.Special:
                int totalSpecials = backpackSlots.Where(x => x.itemData.itemType == ItemType.Special).Sum(x => x.equippedCount);
                return (totalSpecials + 1) <= maxSpecials;

            case ItemType.Card:
                int totalCards = backpackSlots.Where(x => x.itemData.itemType == ItemType.Card).Sum(x => x.equippedCount);
                if (totalCards >= maxCards) return false;
                if (slot.equippedCount >= maxCardDuplicates) return false;
                return true;

            case ItemType.Equipment:
                return true;
        }
        return false;
    }

    private void UnequipSameSlot(EquipmentSlot slotType)
    {
        foreach (var s in backpackSlots)
        {
            if (s.equippedCount > 0 && s.itemData.itemType == ItemType.Equipment && s.itemData.equipSlot == slotType)
            {
                s.equippedCount = 0;
            }
        }
    }

    public string GetActiveSetBonus()
    {
        var equippedItems = backpackSlots
            .Where(x => x.equippedCount > 0 && x.itemData.itemType == ItemType.Equipment)
            .Select(x => x.itemData)
            .ToList();

        if (equippedItems.Count == 0) return "";

        var setCounts = equippedItems
            .Where(item => !string.IsNullOrEmpty(item.setBonusId))
            .GroupBy(item => item.setBonusId)
            .Select(group => new { SetID = group.Key, Count = group.Count() });

        foreach (var set in setCounts)
        {
            if (set.Count >= 4)
            {
                if (set.SetID == "Set_A") return "Set Bonus Active: Sky Guardian (MP Regen +5)";
                if (set.SetID == "Set_B") return "Set Bonus Active: Deep Sea (Defense +20)";
                if (set.SetID == "Set_Gold") return "Set Bonus Active: Golden Legend (All Stats +50)";
            }
        }
        return "";
    }
}