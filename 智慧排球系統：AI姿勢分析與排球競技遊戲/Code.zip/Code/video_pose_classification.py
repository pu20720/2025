import cv2
import mediapipe as mp
import numpy as np
import tensorflow as tf
from PIL import ImageFont, ImageDraw, Image

class VolleyballPoseDetector:
    def __init__(self, model_path='train_pose_model.py'):
        """
        初始化排球姿勢偵測器
        
        Args:
            model_path: 訓練好的模型路徑
        """
        # 初始化 MediaPipe Pose
        self.mp_pose = mp.solutions.pose
        self.mp_drawing = mp.solutions.drawing_utils
        self.pose = self.mp_pose.Pose(
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        
        # 載入訓練好的模型
        try:
            self.model = tf.keras.models.load_model(model_path)
            print(f"✓ 模型載入成功: {model_path}")
        except Exception as e:
            print(f"✗ 模型載入失敗: {e}")
            self.model = None
        
        # 動作類別名稱（根據你的訓練資料調整）
        self.class_names = ['發球', '接球', '扣球', '舉球', '其他']
        
        # 載入中文字體
        try:
            # Windows 系統 
            self.font_path = "C:/Windows/Fonts/msjh.ttc"  # 微軟正黑體
            self.font_chinese = ImageFont.truetype(self.font_path, 32)
            self.font_chinese_small = ImageFont.truetype(self.font_path, 24)
            print("✓ 中文字體載入成功")
        except:
            try:
                # macOS 系統
                self.font_path = "/System/Library/Fonts/PingFang.ttc"
                self.font_chinese = ImageFont.truetype(self.font_path, 32)
                self.font_chinese_small = ImageFont.truetype(self.font_path, 24)
                print("✓ 中文字體載入成功")
            except:
                print("⚠ 無法載入中文字體，將使用英文顯示")
                self.font_chinese = None
                self.font_chinese_small = None
        
        # 顯示設定
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        self.colors = {
            'correct': (0, 255, 0),      # 綠色
            'incorrect': (0, 0, 255),    # 紅色
            'neutral': (255, 255, 0)     # 黃色
        }
        
    def extract_landmarks(self, results):
        """
        從 MediaPipe 結果提取關鍵點特徵
        
        Returns:
            numpy array: 關鍵點特徵向量
        """
        if not results.pose_landmarks:
            return None
        
        landmarks = []
        for landmark in results.pose_landmarks.landmark:
            landmarks.extend([landmark.x, landmark.y, landmark.z, landmark.visibility])
        
        return np.array(landmarks).reshape(1, -1)
    
    def predict_pose(self, features):
        """
        預測姿勢類別
        
        Args:
            features: 關鍵點特徵
            
        Returns:
            tuple: (類別索引, 信心度, 類別名稱)
        """
        if self.model is None or features is None:
            return None, 0.0, "未知"
        
        # 預測
        predictions = self.model.predict(features, verbose=0)
        class_idx = np.argmax(predictions[0])
        confidence = predictions[0][class_idx]
        class_name = self.class_names[class_idx] if class_idx < len(self.class_names) else "未知"
        
        return class_idx, confidence, class_name
    
    def put_chinese_text(self, img, text, position, font, color=(255, 255, 255)):
        """
        在圖片上顯示中文
        
        Args:
            img: OpenCV 圖片
            text: 要顯示的文字
            position: 文字位置 (x, y)
            font: PIL 字體
            color: 文字顏色 (B, G, R)
        """
        if self.font_chinese is None:
            # 如果沒有中文字體，使用英文
            cv2.putText(img, text, position, self.font, 0.8, color, 2)
            return
        
        img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(img_pil)
        # 轉換顏色順序 BGR -> RGB
        color_rgb = (color[2], color[1], color[0])
        draw.text(position, text, font=font, fill=color_rgb)
        img[:] = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    
    def draw_info(self, image, class_name, confidence, is_correct):
        """
        在畫面上繪製資訊
        
        Args:
            image: 影像
            class_name: 動作名稱
            confidence: 信心度
            is_correct: 是否正確
        """
        h, w = image.shape[:2]
        
        # 選擇顏色
        if is_correct is None:
            color = self.colors['neutral']
            status = "偵測中..."
        elif is_correct:
            color = self.colors['correct']
            status = "✓ 動作正確"
        else:
            color = self.colors['incorrect']
            status = "✗ 動作需改進"
        
        # 繪製半透明背景
        overlay = image.copy()
        cv2.rectangle(overlay, (10, 10), (w-10, 140), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, image, 0.4, 0, image)
        
        # 繪製文字（使用中文字體）
        self.put_chinese_text(image, f"動作: {class_name}", (20, 20), 
                             self.font_chinese, (255, 255, 255))
        self.put_chinese_text(image, f"信心度: {confidence:.1%}", (20, 60), 
                             self.font_chinese_small, (255, 255, 255))
        self.put_chinese_text(image, status, (20, 100), 
                             self.font_chinese_small, color)
        
        # 繪製信心度條
        bar_width = int((w - 40) * confidence)
        cv2.rectangle(image, (20, 145), (20 + bar_width, 165), color, -1)
        cv2.rectangle(image, (20, 145), (w - 20, 165), (255, 255, 255), 2)
    
    def run(self, camera_id=0):
        """
        啟動即時偵測
        
        Args:
            camera_id: 攝影機 ID（預設 0）
        """
        cap = cv2.VideoCapture(camera_id)
        
        if not cap.isOpened():
            print("✗ 無法開啟攝影機")
            return
        
        print("=" * 50)
        print("排球姿勢即時辨識系統")
        print("=" * 50)
        print("操作說明:")
        print("  按 'q' 或 'ESC' 離開")
        print("  按 's' 截圖")
        print("=" * 50)
        
        frame_count = 0
        
        try:
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    print("✗ 無法讀取影像")
                    break
                
                frame_count += 1
                
                # 翻轉影像（鏡像效果）
                frame = cv2.flip(frame, 1)
                
                # 轉換顏色空間
                image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                # MediaPipe 姿勢偵測
                try:
                    results = self.pose.process(image_rgb)
                except Exception as e:
                    print(f"✗ MediaPipe 處理錯誤: {e}")
                    continue
                
                # 繪製骨架
                if results.pose_landmarks:
                    try:
                        self.mp_drawing.draw_landmarks(
                            frame,
                            results.pose_landmarks,
                            self.mp_pose.POSE_CONNECTIONS,
                            self.mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=2),
                            self.mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2)
                        )
                        
                        # 提取特徵並預測
                        features = self.extract_landmarks(results)
                        print(f"偵測到人體，特徵維度: {features.shape if features is not None else 'None'}")
                        
                        class_idx, confidence, class_name = self.predict_pose(features)
                        print(f"預測結果: {class_name}, 信心度: {confidence:.2%}")
                        
                        # 判斷動作是否正確（可根據信心度閾值調整）
                        is_correct = confidence > 0.7 if confidence > 0 else None
                        
                        # 繪製資訊
                        self.draw_info(frame, class_name, confidence, is_correct)
                    except Exception as e:
                        print(f"✗ 預測或繪製錯誤: {e}")
                        import traceback
                        traceback.print_exc()
                        self.draw_info(frame, "處理錯誤", 0.0, None)
                else:
                    # 沒有偵測到人體
                    self.draw_info(frame, "未偵測到", 0.0, None)
                
                # 顯示 FPS
                cv2.putText(frame, f"Frame: {frame_count}", (frame.shape[1] - 150, 30),
                           self.font, 0.6, (255, 255, 255), 1)
                
                # 顯示畫面
                cv2.imshow('Volleyball Pose Recognition', frame)
                
                # 按鍵處理 - 確保視窗在前景才能接收按鍵
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q') or key == ord('Q') or key == 27:  # 'q', 'Q' 或 ESC
                    print("\n偵測到關閉指令，正在關閉...")
                    break
                elif key == ord('s') or key == ord('S'):  # 截圖
                    filename = f'screenshot_{frame_count}.jpg'
                    cv2.imwrite(filename, frame)
                    print(f"✓ 截圖已儲存: {filename}")
                    
        except Exception as e:
            print(f"\n✗✗✗ 程式發生嚴重錯誤 ✗✗✗")
            print(f"錯誤訊息: {e}")
            import traceback
            traceback.print_exc()
        finally:
            # 釋放資源
            cap.release()
            cv2.destroyAllWindows()
            self.pose.close()
            print("\n程式已結束")


def main():
    """主程式"""
    # 初始化偵測器
    detector = VolleyballPoseDetector(
        model_path='train_pose_model.py'  # 你的模型路徑
    )
    
    # 啟動即時偵測
    detector.run(camera_id=0)


if __name__ == "__main__":
    main()