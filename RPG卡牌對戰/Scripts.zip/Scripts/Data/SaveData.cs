// 檔案路徑: Assets/Scripts/Data/SaveData.cs
using System.Collections.Generic;
using UnityEngine;

// (InventoryItem 保持不變)
[System.Serializable]
public class InventoryItem
{
    public int id;
    public int quantity;
}

// 【新增】用於儲存單一角色 (玩家或敵人) 狀態的 class
[System.Serializable]
public class CharacterSaveData
{
    // 用於重新生成敵人
    public string characterNameForLoad;
    public bool isDead;

    // 核心數值
    public int hp;
    public int maxHp;
    public int mp;
    public int attackValue;
    public int turnCount;

    // 狀態效果
    public int bleedStacks;
    public int poisonStacks;

    // 護甲 (我們需要儲存所有部位)
    public int helmetArmor;
    public int armor;
    public int gauntletsArmor;
    public int legArmor;

    // (未來可擴展：護甲最大值、是否破損、腐化層數等)
}

// 【新增】用於儲存牌組、手牌、棄牌堆狀態的 class
[System.Serializable]
public class DeckSaveData
{
    // 您的牌組是固定順序，所以我們只需要儲存「抽到第幾張」
    public int currentDeckIndex;

    // 我們需要儲存手牌上有哪些卡
    public List<string> handCardNames;
}

// 【新增】用於儲存覆蓋區域 (條件卡) 狀態的 class
[System.Serializable]
public class ConditionalCardSaveData
{
    public string cardName;
    public int charges;
}


// --- 這是您的主存檔 class，現已大幅擴展 ---
[System.Serializable]
public class SaveData
{
    // === 通用 ===
    public string savedSceneName = "OpeningDialogue"; // 儲存時所在的場景
    public string SaveTime = "";

    // === OpenDialogue 存檔 (保持不變) ===
    public string PlayerName = "";
    public string CurrentBranch = "";
    public int DialogueIndex = 0;
    public bool IsBranching = false;
    public bool IsWaitingForName = false;
    public bool IsDialogueComplete = false;

    // === 戰鬥中存檔 (全新欄位) ===

    [Header("Battle State")]
    public bool isInBattle = false; // 旗標：這是否是一個「戰鬥中」的存檔
    public int globalTurnCount; // 儲存目前是第幾回合
    public string chosenBranch;

    // 1. 儲存玩家和所有敵人的狀態
    public CharacterSaveData playerSaveData;
    public List<CharacterSaveData> enemiesSaveData;

    // 2. 儲存背包 (舊有欄位)
    public List<InventoryItem> Inventory = new List<InventoryItem>();

    // 3. 儲存牌組和手牌
    public DeckSaveData deckSaveData;

    // 4. 儲存覆蓋區域的條件卡
    public List<ConditionalCardSaveData> conditionalCardsSaveData;

    // 5. 儲存教學進度
    public string tutorialStepName; // 例如 "WaitForCleave"

    // ▼▼▼ 【新增】儲存「對話」本身 ▼▼▼
    [Header("Dialogue State (If In Battle)")]
    public string savedDialogueSpeaker = "";
    public string savedDialogueText = "";
    public bool savedIsInstructional = false;
    // ▲▲▲ 【新增結束】 ▲▲▲
}