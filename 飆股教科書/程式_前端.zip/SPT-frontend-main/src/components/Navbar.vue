<script setup>
    import { ref, computed } from 'vue'
    import InputText from 'primevue/inputtext'
    import Button from 'primevue/button'
    import NavItem from '@/components/Navbar/NavItem.vue'
    import { useRouter } from 'vue-router'
    import { useStockSearch } from '@/stores/stockSearch'
    import { useUserStore } from '@/stores/user.js'

    const isMobileMenuOpen = ref(false)
    const toggleMobileMenu = () => {
        isMobileMenuOpen.value = !isMobileMenuOpen.value
    }

    const router = useRouter()
    const userStore = useUserStore()

    const { goToStockResult: originalGoToStockResult } = useStockSearch()
    const stockCode = ref('')

    // 從 User Store 中提取響應式狀態
    const isLoggedIn = computed(() => !!userStore.accessToken)
    const userName = computed(() => userStore.userEmail)

    // --- Computed Props ---
    const leftNavItems = computed(() => router.options.routes.filter((r) => r.position === 'left'))
    const rightNavItems = computed(() =>
        router.options.routes.filter((r) => r.path === '/login' || r.path === '/register'),
    )

    // 使其在點擊後關閉手機選單
    function logoutUser() {
        userStore.logout()
        isMobileMenuOpen.value = false // 關閉選單
    }

    function goToStockResult(code) {
        if (!code) return
        originalGoToStockResult(code)
        stockCode.value = '' // 清空搜尋框
        isMobileMenuOpen.value = false // 關閉選單
    }
</script>

<template>
    <nav
        class="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-3 text-lg bg-slate-600 rounded-b-2xl"
    >
        <div class="hidden md:flex items-center gap-4">
            <NavItem
                v-for="item in leftNavItems"
                :key="item.name"
                :label="item.name"
                :to="item.path"
            />

            <InputText
                placeholder="搜尋"
                v-model="stockCode"
                @keyup.enter="goToStockResult(stockCode)"
                class="px-3 py-1.5 text-white text-base placeholder-white bg-transparent border border-white rounded-md placeholder-opacity-80"
            />
        </div>

        <div class="hidden md:flex items-center gap-4">
            <div v-if="isLoggedIn" class="flex items-center gap-3">
                <span class="text-white text-base font-medium">{{ userName }}</span>
                <Button
                    label="登出"
                    @click="logoutUser"
                    severity="secondary"
                    text
                    class="text-2xl p-button-sm text-white hover:text-white hover:bg-white/10 transition-colors duration-200"
                />
            </div>
            <div v-else class="flex items-center gap-4">
                <NavItem
                    v-for="item in rightNavItems"
                    :key="item.name"
                    :label="item.name"
                    :to="item.path"
                />
            </div>
        </div>

        <div class="md:hidden">
            <NavItem
                v-if="leftNavItems.length > 0"
                :label="leftNavItems[0].name"
                :to="leftNavItems[0].path"
            />
        </div>

        <div class="md:hidden">
            <Button
                :icon="isMobileMenuOpen ? 'pi pi-times' : 'pi pi-bars'"
                @click="toggleMobileMenu"
                text
                class="text-2xl text-white hover:bg-white/10 p-button-sm"
            />
        </div>

        <div
            v-if="isMobileMenuOpen"
            class="absolute top-full left-0 right-0 z-40 bg-slate-700 p-4 shadow-lg md:hidden"
        >
            <div class="flex flex-col gap-4">
                <InputText
                    placeholder="搜尋"
                    v-model="stockCode"
                    @keyup.enter="goToStockResult(stockCode)"
                    class="w-full px-3 py-1.5 text-white text-base placeholder-white bg-transparent border border-white rounded-md placeholder-opacity-80"
                />

                <NavItem
                    v-for="item in leftNavItems.slice(1)"
                    :key="item.name"
                    :label="item.name"
                    :to="item.path"
                    @click="isMobileMenuOpen = false"
                />

                <hr class="border-slate-500 my-2" />

                <div v-if="isLoggedIn" class="flex flex-col items-start gap-3">
                    <span class="text-white text-base font-medium">您好, {{ userName }}</span>
                    <Button
                        label="登出"
                        @click="logoutUser"
                        severity="secondary"
                        class="w-full p-button-sm bg-white/10 text-white"
                    />
                </div>
                <div v-else class="flex flex-col gap-4">
                    <NavItem
                        v-for="item in rightNavItems"
                        :key="item.name"
                        :label="item.name"
                        :to="item.path"
                        @click="isMobileMenuOpen = false"
                    />
                </div>
            </div>
        </div>
    </nav>
</template>
