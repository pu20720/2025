<script setup>
    import { ref, onMounted, onUnmounted, nextTick, watch } from 'vue'
    import NewsCard from '../components/NewsCard.vue'
    import SearchCenter from '../components/SearchCenter.vue'
    import FallingKeywords from '../components/FallingKeywords.vue'
    import '../assets/scroll.css'

    const sections = ref([])
    const currentSection = ref(0)
    let lastScrollTime = 0

    // 新增 isMobile ref 和 media query 變數
    const isMobile = ref(false)
    let mql = null

    // ===== 滾動邏輯  =====
    function scrollToSection(index) {
        if (sections.value[index]) {
            sections.value[index].scrollIntoView({ behavior: 'smooth' })
            currentSection.value = index
        }
    }

    function handleWheel(e) {
        // 確保在 isMobile 時不觸發
        if (isMobile.value) return

        const now = Date.now()
        if (now - lastScrollTime < 800) return
        lastScrollTime = now

        if (e.deltaY > 0 && currentSection.value < sections.value.length - 1) {
            scrollToSection(currentSection.value + 1)
        } else if (e.deltaY < 0 && currentSection.value > 0) {
            scrollToSection(currentSection.value - 1)
        }
    }

    // 將PC版滾動邏輯打包成函式
    function initDesktopScroll() {
        document.body.classList.add('no-scroll')
        window.addEventListener('wheel', handleWheel, { passive: false })
    }

    function cleanupDesktopScroll() {
        window.removeEventListener('wheel', handleWheel)
        document.body.classList.remove('no-scroll')
    }

    // 媒體查詢的處理函式
    function checkMobile(e) {
        isMobile.value = e.matches
    }

    // ===== 生命週期鉤子 =====
    onMounted(async () => {
        await nextTick()
        // 取得所有 section (無論PC/Mobile都需要)
        sections.value = Array.from(document.querySelectorAll('.page-section'))

        //  設定 media query 監聽
        mql = window.matchMedia('(max-width: 768px)') // md 斷點
        checkMobile(mql) // 立即檢查一次
        mql.addEventListener('change', checkMobile)

        // 只有在 PC 版時啟用滾動
        if (!isMobile.value) {
            initDesktopScroll()
        }
    })

    onUnmounted(() => {
        // 移除所有監聽
        mql.removeEventListener('change', checkMobile)
        cleanupDesktopScroll() // 確保無論如何都清除
    })

    // 監聽 isMobile 變化，動態增減 PC 版功能
    watch(isMobile, (newIsMobile) => {
        if (newIsMobile) {
            // 切換到手機版：清除 PC 滾動
            cleanupDesktopScroll()
        } else {
            // 切換到電腦版：啟用 PC 滾動
            initDesktopScroll()
        }
    })
</script>

<template>
    <div class="min-h-screen bg-gray-100">
        <section
            class="page-section relative flex flex-col items-center justify-center overflow-hidden p-6"
            :class="{
                'h-screen': !isMobile /* 電腦：強制 100vh */,
                'min-h-screen pt-20': isMobile /* 手機：至少 100vh + Navbar 內距 */,
            }"
        >
            <FallingKeywords v-if="currentSection === 0 && !isMobile" />
            <SearchCenter />
        </section>

        <section
            class="page-section relative p-6"
            :class="{
                'h-screen': !isMobile /* 電腦：強制 100vh */,
                'h-auto': isMobile /* 手機：自動高度 */,
            }"
        >
            <NewsCard />
        </section>
    </div>
</template>

<style scoped>
    .page-section {
        scroll-snap-align: start;
        scroll-snap-stop: always;
        height: 100vh; /* 確保滿版區塊 */
    }
</style>
