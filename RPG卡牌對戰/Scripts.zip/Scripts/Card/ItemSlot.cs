using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

// (這個腳本請掛載到您的 "ItemSlot_Prefab" 預製物上)
public class ItemSlot : MonoBehaviour, IPointerClickHandler
{
    // (您可以在這裡存放物品資料，例如 ItemData)
    // public ItemData currentItem; 

    public Image itemIcon; // (將您 Prefab 上的圖示 Image 拖到這裡)

    // (您可以在這裡新增一個函式來設定物品)
    /*
    public void SetItem(ItemData item)
    {
        currentItem = item;
        itemIcon.sprite = item.iconSprite;
        itemIcon.enabled = true;
    }
    */

    // 當玩家點擊這個欄位時
    public void OnPointerClick(PointerEventData eventData)
    {
        // 檢查是否真的有物品
        // if (currentItem != null)
        // {
        // (在這裡執行您 "選擇物品" 的邏輯)
        Debug.Log("點擊了物品!");

        // 範例：通知管理器您選擇了這個物品
        // InventoryManager.Instance.SelectItem(currentItem);
        // }
    }
}