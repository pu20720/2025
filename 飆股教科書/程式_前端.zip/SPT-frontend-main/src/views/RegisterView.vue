<script setup>
    import { ref, computed } from 'vue'
    import { useUserStore } from '@/stores/user.js'
    import router from '@/router'

    const email = ref('')
    const password = ref('')
    const passwordCheck = ref('')
    const username = ref('')
    const { registerUser } = useUserStore()

    async function registerUserRequest() {
        await registerUser(username.value, email.value, password.value)
    }
</script>

<template>
    <form @submit.prevent="registerUserRequest">
        <div class="flex items-center justify-center min-h-screen px-4 bg-gray-50">
            <div class="w-full max-w-md p-8 bg-white rounded-md shadow-2xl">
                <!-- 登入表單 -->

                <Toast position="bottom-left" />
                <div class="mb-4">
                    <label class="block mb-2 text-base font-medium">使用者名稱</label>
                    <InputText
                        v-model="username"
                        class="w-full text-base py-3"
                        placeholder="請輸入您的使用者名稱"
                    />
                </div>
                <div class="mb-4">
                    <label class="block mb-2 text-base font-medium">電子信箱</label>
                    <InputText
                        v-model="email"
                        class="w-full text-base py-3"
                        placeholder="請輸入電子信箱"
                    />
                </div>

                <div class="mb-4">
                    <label class="block mb-2 text-base font-medium">密碼</label>
                    <InputText
                        v-model="password"
                        type="password"
                        class="w-full text-base py-3"
                        placeholder="請輸入密碼"
                    />
                </div>

                <div class="mb-4">
                    <label class="block mb-2 text-base font-medium">確認密碼</label>
                    <InputText
                        v-model="passwordCheck"
                        type="password"
                        class="w-full text-base py-3"
                        placeholder="請再次確認密碼"
                    />
                </div>

                <Button
                    @click="registerUserRequest(username, email, password)"
                    label="註冊"
                    class="btn w-full mb-3"
                />
            </div>
        </div>
    </form>
</template>

<style scope>
    .btn {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px;
        border: none;
        border-radius: 10px;
        font-size: 1.1rem;
        font-weight: 500;
        cursor: pointer;
        transition: transform 0.3s ease;
    }
</style>
