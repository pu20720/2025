import logging
from stocks.models import HotStocks
from stocks_price.models import StockPrices
from django.db.models import (
    DecimalField,
    BigIntegerField,
    ExpressionWrapper,
    Max,
    OuterRef,
    Subquery,
    F,
)

logger = logging.getLogger(__name__)


def get_hot_stocks_data():
    try:
        # 找出資料庫中最新的日期
        latest_date = HotStocks.objects.aggregate(latest=Max('date'))['latest']
        if not latest_date:
            raise RuntimeError('沒有熱門股資料')

        yesterday_date = StockPrices.objects.filter(
            price_date__lt=latest_date
        ).aggregate(prev_date=Max('price_date'))['prev_date']

        # 取出最新開盤價
        latest_open_price = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('open_price')[:1]
        # 取出最新漲跌幅度
        latest_change_percent = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('change_percent')[:1]
        # 取出最新一筆股價
        latest_close_price = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('close_price')[:1]
        # 取出最新成交量
        latest_volume = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=latest_date
        ).values('volume')[:1]
        # 取出昨日收盤價
        yesterday_close_price = StockPrices.objects.filter(
            stock=OuterRef('stock'), price_date=yesterday_date
        ).values('close_price')[:1]

        qs = (
            HotStocks.objects.filter(date=latest_date)
            .select_related('stock')
            .annotate(
                symbol=F('stock__symbol'),
                stock_name=F('stock__name'),
                open_price=Subquery(
                    latest_open_price,
                    output_field=DecimalField(max_digits=12, decimal_places=4),
                ),
                close_price=Subquery(
                    latest_close_price,
                    output_field=DecimalField(max_digits=12, decimal_places=4),
                ),
                yesterday_close=Subquery(
                    yesterday_close_price,
                    output_field=DecimalField(max_digits=12, decimal_places=4),
                ),
                change_percent=Subquery(
                    latest_change_percent,
                    output_field=DecimalField(max_digits=5, decimal_places=2),
                ),
                volume=Subquery(latest_volume, output_field=BigIntegerField()),
            )
        )

        # 計算漲跌幅度
        change_value = ExpressionWrapper(
            F('close_price') - F('yesterday_close'),
            output_field=DecimalField(max_digits=12, decimal_places=4),
        )

        qs = qs.annotate(
            change_value=change_value,
        )

        return list(
            qs.values(
                'id',
                'date',
                'rank',
                'reason',
                'symbol',
                'stock_name',
                'close_price',
                'volume',
                'change_value',
                'change_percent',
            )
        )
    except Exception as e:
        logger.error(f'[HotStocks] 資料查詢失敗 {e}')
        raise RuntimeError('資料查詢失敗')
