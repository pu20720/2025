// 檔案路徑: Assets/Scripts/Inventory.cs
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    [Header("Database Reference")]
    [SerializeField] private ItemDatabase itemDatabase;

    [Header("Debugging / Starting Items")]
    [SerializeField] private List<ItemData> startingItems;

    // 核心儲存：ID -> 數量
    private Dictionary<int, int> items = new Dictionary<int, int>();

    private void Awake()
    {
        if (startingItems != null)
        {
            foreach (var item in startingItems)
            {
                if (item != null) AddItem(item.itemID, 1);
            }
        }
    }

    public void AddItem(int itemId, int count = 1)
    {
        if (items.ContainsKey(itemId))
            items[itemId] += count;
        else
            items[itemId] = count;

        Debug.Log($"Inventory: 獲得物品 ID: {itemId}, 目前總數: {items[itemId]}");
    }

    // ▼▼▼ 【補上：GetItemCount 方法】 解決 CS1061 錯誤 ▼▼▼
    public int GetItemCount(int itemId)
    {
        return items.ContainsKey(itemId) ? items[itemId] : 0;
    }
    // ▲▲▲ 【補上結束】 ▲▲▲

    public void RemoveItem(int itemId, int count = 1)
    {
        if (!items.ContainsKey(itemId)) return;
        items[itemId] -= count;
        if (items[itemId] <= 0)
            items.Remove(itemId);
    }

    // 存檔系統需要的函式 (BattleMenuManager 使用)
    public Dictionary<int, int> GetAllItems()
    {
        return new Dictionary<int, int>(items);
    }

    public void LoadItems(Dictionary<int, int> savedItems)
    {
        items.Clear();
        foreach (var (id, count) in savedItems)
            items[id] = count;

        Debug.Log($"Inventory: 成功從存檔中載入 {savedItems.Count} 種物品。");
    }

    public Dictionary<ItemData, int> GetItemsDataForUI()
    {
        var uiDictionary = new Dictionary<ItemData, int>();
        if (itemDatabase == null)
        {
            Debug.LogError("Inventory 錯誤：未綁定 ItemDatabase！");
            return uiDictionary;
        }

        foreach (var (id, count) in items)
        {
            ItemData data = itemDatabase.GetItemByID(id);
            if (data != null)
            {
                uiDictionary[data] = count;
            }
        }
        return uiDictionary;
    }

    public void RemoveItemData(ItemData item, int count = 1)
    {
        if (item != null)
        {
            RemoveItem(item.itemID, count);
        }
    }
}