import sys
import logging
import subprocess
from django.conf import settings
from django.core.management.base import BaseCommand

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = '更新 FinMind API Key 並匯入基本面資料'

    def add_arguments(self, parser):
        parser.add_argument(
            '--since', default='2020-01-01', help='匯入起始日期 (YYYY-MM-DD)'
        )

    def handle(self, *args, **options):
        # 1. 執行抓 token 的外部腳本（若存在）
        get_token_path = settings.BASE_DIR / 'command' / 'get_api_key.py    '
        if get_token_path.exists():
            self.stdout.write(
                self.style.NOTICE(f'執行取得 token 腳本：{get_token_path}')
            )
            # 失敗就直接中止，避免後續還在跑
            subprocess.run([sys.executable, str(get_token_path)], check=True)
        else:
            self.stdout.write(
                self.style.WARNING('找不到 COMMAND/get_api_key.py，略過產生 token')
            )

        # 2. 這裡才 import 需要 Django 初始化的模組
        from stocks.models import Stock
        from financial.services.import_financial import import_financial_data

        since = options['since']
        qs = Stock.objects.order_by('symbol')
        self.stdout.write(
            self.style.NOTICE(f'共 {qs.count()} 檔，自 {since} 起開始匯入…')
        )

        for stock in qs.iterator(chunk_size=500):
            symbol = stock.symbol
            try:
                import_financial_data(symbol, since)
                self.stdout.write(self.style.SUCCESS(f'[{symbol}] 匯入成功'))
            except Exception as e:
                logger.exception('匯入失敗')
                self.stderr.write(self.style.ERROR(f'[{symbol}] 匯入失敗：{e}'))
