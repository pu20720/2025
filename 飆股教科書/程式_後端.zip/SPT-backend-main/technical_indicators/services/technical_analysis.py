import logging
import numpy as np
import pandas as pd
import pandas_ta as ta  # noqa: F401
from typing import List
from decimal import Decimal
from stocks_price.models import StockPrices

logger = logging.getLogger(__name__)


def get_stocks_prices(
    stock_symbol: str, base_date=None, days: int = 2000
) -> List[StockPrices]:
    try:
        queryset = StockPrices.objects.filter(
            stock_id__symbol=stock_symbol,  # 注意是 stock_id__symbol
            price_date__lte=base_date,
        ).order_by('price_date')

        result = list(reversed(queryset))

        logger.debug(
            f'[TechnicalIndicator] 查詢交易日 {stock_symbol} 在 {base_date} 前查詢 {days} 個交易日，實際取得 {len(result)} 筆'
        )

        return result
    except Exception as e:
        logger.error(
            f'[TechnicalIndicator] 交易日查詢失敗{stock_symbol} {base_date}: {e}'
        )
        return []


def calculate_technical_indicators(stock_id: str, date=None) -> dict:
    try:
        raw_data = get_stocks_prices(
            stock_symbol=stock_id, base_date=date, days=2000
        )  # 或 None=全量

        df = pd.DataFrame(
            [
                {
                    'date': getattr(item, 'price_date', getattr(item, 'date', None)),
                    'open': _convert_to_float(
                        getattr(item, 'open_price', getattr(item, 'open', None))
                    ),
                    'high': _convert_to_float(
                        getattr(item, 'high_price', getattr(item, 'high', None))
                    ),
                    'low': _convert_to_float(
                        getattr(item, 'low_price', getattr(item, 'low', None))
                    ),
                    'close': _convert_to_float(
                        getattr(item, 'close_price', getattr(item, 'close', None))
                    ),
                    'volume': _convert_to_float(getattr(item, 'volume', 0)),
                }
                for item in raw_data
            ]
        )

        if df.empty:
            return {}

        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date').reset_index(drop=True)

        # 移動平均/RSI
        df.ta.sma(length=5, append=True)
        df.ta.sma(length=20, append=True)
        df.ta.sma(length=60, append=True)
        df.ta.rsi(length=5, append=True)
        df.ta.rsi(length=10, append=True)
        # MACD
        df.ta.macd(append=True)
        df.ta.stoch(
            high='high', low='low', close='close', k=9, d=3, smooth_k=3, append=True
        )
        # KD
        kdj = kdj_tse(df['close'], df['high'], df['low'], n=9, m1=3, m2=3)
        df = pd.concat([df, kdj], axis=1)

        # 取目標日（或最後一筆）
        row = df[df['date'] <= pd.to_datetime(date)].iloc[-1] if date else df.iloc[-1]

        indicators = {
            'ma_5': _get_value(row, 'SMA_5'),
            'ma_20': _get_value(row, 'SMA_20'),
            'ma_60': _get_value(row, 'SMA_60'),
            'rsi_5': _get_value(row, 'RSI_5'),
            'rsi_10': _get_value(row, 'RSI_10'),
            'dif': _get_value(row, 'MACD_12_26_9'),
            'macd': _get_value(row, 'MACDs_12_26_9'),
            'osc': _get_value(row, 'MACDh_12_26_9'),
            'kd_k': _get_value(row, 'K_9_3_3'),
            'kd_d': _get_value(row, 'D_9_3_3'),
        }
        return {k: v for k, v in indicators.items() if v is not None}
    except Exception as e:
        logger.error(f'[calculate_technical_indicators] 計算失敗 {stock_id}: {e}')
        import traceback

        traceback.print_exc()
        return {}


def _get_value(row, column_name) -> float:
    """
    取得欄位值，處理 NaN 和不存在的欄位
    """
    try:
        if column_name in row.index:
            value = row[column_name]
            if pd.isna(value):
                return None
            return round(float(value), 2)
        return None
    except (KeyError, ValueError, TypeError):
        return None


def _convert_to_float(value) -> float:
    """
    將各種數值類型轉換為 float，處理 Decimal 類型
    """
    if value is None:
        return np.nan

    try:
        if isinstance(value, Decimal):
            return float(value)
        elif isinstance(value, (int, float)):
            return float(value)
        elif isinstance(value, str):
            return float(value) if value.strip() != '' else np.nan
        else:
            return float(value)
    except (ValueError, TypeError):
        return np.nan


def kdj_tse(
    close: pd.Series,
    high: pd.Series,
    low: pd.Series,
    n: int = 9,
    m1: int = 3,
    m2: int = 3,
    seed: float = 50.0,
    clip: bool = True,
) -> pd.DataFrame:
    """
    KD（RSV → SMA 平滑  K0=D0=seed）
    SMA(X, N, M) 遞迴：Y_t = (M * X_t + (N - M) * Y_{t-1}) / N
    """
    # 1) 真正 n 期區間；前 n-1 期不計算
    ll = low.rolling(window=n, min_periods=n).min()
    hh = high.rolling(window=n, min_periods=n).max()

    # 2) 安全 RSV（處理分母為 0）
    rng = hh - ll
    rsv = np.where(rng > 0, (close - ll) / rng * 100.0, 0.0)
    rsv = pd.Series(rsv, index=close.index, dtype='float64')

    # 3) 台式 SMA 平滑（遞迴；K0=D0=seed）
    K = pd.Series(index=close.index, dtype='float64')
    D = pd.Series(index=close.index, dtype='float64')

    # 找到第一個有效 RSV 的位置
    first_valid = rsv.first_valid_index()
    if first_valid is None:
        # 沒資料就回空
        return pd.DataFrame({'K': K, 'D': D, 'J': pd.Series(dtype='float64')})

    # 初始化
    K.loc[first_valid] = seed
    D.loc[first_valid] = seed

    # 逐步遞迴（效能足夠，且能正確套用種子）
    idx = list(rsv.index)
    start_pos = idx.index(first_valid)

    for i in range(start_pos, len(idx)):
        t = idx[i]
        x = rsv.loc[t]
        if np.isnan(x):
            # RSV 無效就延用前值（也可選擇設為 NaN）
            if i > start_pos:
                K.loc[t] = K.loc[idx[i - 1]]
                D.loc[t] = D.loc[idx[i - 1]]
            continue
        if i == start_pos:
            # 第一筆已設 seed；可選擇先利用 x 再算一次
            pass
        else:
            K_prev = K.loc[idx[i - 1]]
            D_prev = D.loc[idx[i - 1]]
            K.loc[t] = (m1 * x + (n - m1) * K_prev) / n
            D.loc[t] = (m2 * K.loc[t] + (n - m2) * D_prev) / n

    if clip:
        K = K.clip(0, 100)
        D = D.clip(0, 100)

    kd = pd.DataFrame({f'K_{n}_{m1}_{m2}': K, f'D_{n}_{m1}_{m2}': D})
    return kd
