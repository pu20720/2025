// 檔案路徑: Assets/Scripts/Card/CardDisplay.cs
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

[RequireComponent(typeof(Image))]
[RequireComponent(typeof(TargetIndicator))]
// ▼▼▼ 修正：移除了 IPointerClickHandler，點擊邏輯轉移到 TargetIndicator ▼▼▼
public class CardDisplay : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    // ▲▲▲ 修正結束 ▲▲▲
    private CardData cardData;
    private Image cardImage;

    private RectTransform rectTransform;

    private Transform handArea;
    private bool isSelected = false;
    private Vector3 originalPosition;
    private float raiseAmount = 30f;

    void Awake()
    {
        cardImage = GetComponent<Image>();
        rectTransform = GetComponent<RectTransform>();

        if (cardImage == null) { }
        else { cardImage.color = Color.white; }

        if (rectTransform != null)
        {
            rectTransform.sizeDelta = new Vector2(360f, 360f);
        }
    }

    public void Initialize(CardData data, Transform parentHand)
    {
        if (data == null)
        {
            return;
        }

        cardData = data;
        handArea = parentHand;

        if (cardImage != null)
        {
            cardImage.sprite = cardData.cardArt;
        }

        isSelected = false;
        originalPosition = Vector3.zero;
    }

    // ▼▼▼ 修正：OnPointerClick 方法已被移除 ▼▼▼
    // (所有點擊邏輯現在由 TargetIndicator.cs 處理)
    // ▲▲▲ 修正結束 ▲▲▲

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!isSelected && handArea != null)
        {
            transform.localScale = Vector3.one * 1.1f;
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (!isSelected)
        {
            transform.localScale = Vector3.one;
        }
    }

    public void Select()
    {
        if (!isSelected)
        {
            originalPosition = transform.localPosition;
        }
        isSelected = true;
        transform.localScale = Vector3.one * 1.1f;
        transform.localPosition = originalPosition + Vector3.up * raiseAmount;
    }

    public void Deselect()
    {
        if (!isSelected) return;
        isSelected = false;
        transform.localScale = Vector3.one;
        transform.localPosition = originalPosition;
    }

    public CardData GetCardData() { return cardData; }
}