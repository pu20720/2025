import logging
import requests
from decimal import Decimal
from typing import Optional
from stocks.models import Stock
from datetime import date, datetime, timedelta
from stocks_price.models import StockPrices
from technical_indicators.services.import_technical_indicators import (
    import_technical_indicators,
)

logger = logging.getLogger(__name__)


def import_yesterday_price(symbol: str, start_from: Optional[date] = None) -> dict:
    """
    匯入股票從資料庫最新日期之後的價格資料。
    若尚無資料，則從上市日開始。
    """
    try:
        stock = Stock.objects.get(symbol=symbol)
        today = datetime.today().date()

        # 從資料庫查該股票的最新日期
        latest_price = (
            StockPrices.objects.filter(stock=stock).order_by('-price_date').first()
        )

        if start_from:
            pass
        elif latest_price:
            start_from = latest_price.price_date + timedelta(days=1)
        else:
            start_from = stock.listed_date

        # 若起始日超過今天，代表已經是最新資料
        if start_from > today:
            return {
                'status': 'done',
                'symbol': symbol,
                'message': '資料已是最新',
                'latest_date': (
                    latest_price.price_date.strftime('%Y-%m-%d')
                    if latest_price
                    else None
                ),
            }

        success_total = 0
        error_months = []
        current = start_from.replace(day=1)

        while current <= today:
            yyyymm = current.strftime('%Y%m')
            date_param = f'{yyyymm}01'
            url = (
                f'https://www.twse.com.tw/exchangeReport/STOCK_DAY'
                f'?response=json&date={date_param}&stockNo={symbol}'
            )

            try:
                response = requests.get(url)
                response.raise_for_status()
                result = response.json()

                if result.get('stat') != 'OK':
                    logger.warning(
                        f'[StockPrice] {symbol} {yyyymm} 回傳錯誤: {result.get("stat")}'
                    )
                    error_months.append(yyyymm)
                    current += timedelta(days=32)
                    current = current.replace(day=1)
                    continue

                prev_close_cache = None  # 🔹 用來暫存上一次收盤價，減少 DB 查詢
                for row in result['data']:
                    try:
                        # 日期轉換：民國 → 西元
                        raw_date = row[0].strip().replace('/', '-')
                        year, month, day = map(int, raw_date.split('-'))
                        year += 1911
                        price_date = datetime(year, month, day).date()

                        if price_date < start_from or price_date > today:
                            continue

                        # 價格資料
                        open_price = float(row[3].replace(',', ''))
                        high_price = float(row[4].replace(',', ''))
                        low_price = float(row[5].replace(',', ''))
                        close_price = float(row[6].replace(',', ''))
                        volume = int(row[1].replace(',', ''))

                        # 🔹 計算漲跌幅
                        if prev_close_cache:
                            prev_close = Decimal(prev_close_cache)
                        else:
                            previous = (
                                StockPrices.objects.filter(
                                    stock=stock, price_date__lt=price_date
                                )
                                .order_by('-price_date')
                                .first()
                            )
                            prev_close = (
                                Decimal(previous.close_price)
                                if previous
                                else Decimal(close_price)
                            )

                        change_percent = round(
                            ((Decimal(close_price) - prev_close) / prev_close) * 100, 2
                        )

                        # 更新快取
                        prev_close_cache = close_price

                        _, created = StockPrices.objects.update_or_create(
                            stock=stock,
                            price_date=price_date,
                            defaults={
                                'open_price': open_price,
                                'high_price': high_price,
                                'low_price': low_price,
                                'close_price': close_price,
                                'volume': volume,
                                'change_percent': change_percent,
                            },
                        )

                        import_technical_indicators(symbol, price_date)
                        if created:
                            success_total += 1

                    except Exception as e:
                        logger.warning(f'[StockPrice] 解析失敗 {symbol} {row} -> {e}')
                        continue

            except Exception as e:
                logger.warning(f'[StockPrice] API錯誤 {symbol} {yyyymm} => {e}')
                error_months.append(yyyymm)

            current += timedelta(days=32)
            current = current.replace(day=1)

        return {
            'status': 'done',
            'symbol': symbol,
            'created': success_total,
            'start_from': start_from.strftime('%Y-%m-%d'),
            'end_date': today.strftime('%Y-%m-%d'),
            'error_months': error_months,
        }

    except Stock.DoesNotExist:
        return {'status': 'error', 'message': f'找不到代號為 {symbol} 的股票'}
    except Exception as e:
        logger.error(f'[StockPrice] {symbol} 匯入失敗: {e}')
        return {'status': 'error', 'message': str(e)}
