<template>
    <!-- 套用優化後的容器樣式：背景、大間距、最大寬度 -->
    <div class="w-full px-4 md:px-16 py-12 bg-gray-50 min-h-screen">
        <!-- 進度條區塊：自定義進度條與主題標籤 -->
        <div class="mb-10 max-w-5xl mx-auto">
            <div class="flex justify-between items-end mb-2">
                <h3 class="text-xl font-semibold text-blue-700 transition duration-300">
                    {{
                        slides[currentSlide].title.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]\s?/, '')
                    }}
                </h3>
                <span class="text-sm font-medium text-gray-500">
                    主題 {{ currentSlide + 1 }} / {{ slides.length }}
                </span>
            </div>
            <div class="w-full bg-gray-300 rounded-full h-2.5 overflow-hidden">
                <div
                    class="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
                    :style="{ width: ((currentSlide + 1) / slides.length) * 100 + '%' }"
                ></div>
            </div>
        </div>

        <!-- Slide 區塊：優化後的卡片樣式與 slide-fade 動畫 -->
        <transition name="slide-fade" mode="out-in">
            <div
                :key="currentSlide"
                class="bg-white rounded-2xl shadow-xl p-10 md:flex gap-12 items-start border border-gray-100 max-w-5xl mx-auto"
            >
                <!-- 內容區塊：由於沒有圖片，強制設定為 full-width -->
                <div class="md:w-full w-full">
                    <!-- 標題樣式 -->
                    <h2 class="text-3xl font-extrabold mb-6 text-gray-800">
                        {{ slides[currentSlide].title }}
                    </h2>
                    <!-- 內容樣式 -->
                    <div
                        class="text-lg text-gray-700 leading-relaxed space-y-4"
                        v-html="slides[currentSlide].content"
                    ></div>
                </div>

                <!-- 圖片區塊已移除 -->
            </div>
        </transition>

        <!-- 控制按鈕區塊：優化後的圓角按鈕和間距 -->
        <div class="flex justify-between mt-16 max-w-5xl mx-auto">
            <button
                @click="prevSlide"
                :disabled="currentSlide === 0"
                class="px-7 py-2.5 rounded-full border border-blue-600 text-blue-600 font-medium hover:bg-blue-50 transition duration-300 disabled:opacity-40 disabled:border-gray-300 disabled:text-gray-400"
            >
                &larr; 上一主題
            </button>

            <button
                v-if="!isLastSlide"
                @click="nextSlide"
                class="px-9 py-2.5 rounded-full bg-blue-600 text-white font-semibold shadow-md shadow-blue-300 hover:bg-blue-700 hover:shadow-lg transition duration-300"
            >
                下一主題 &rarr;
            </button>

            <button
                v-else
                @click="goHome"
                class="px-9 py-2.5 rounded-full bg-green-600 text-white font-semibold shadow-md shadow-green-300 hover:bg-green-700 hover:shadow-lg transition duration-300"
            >
                回到課程首頁
            </button>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed } from 'vue'
    import { useRouter } from 'vue-router'
    import { useToast } from 'primevue/usetoast'

    const toast = useToast()
    const router = useRouter()
    const currentSlide = ref(0)

    const slides = [
        {
            title: '股利種類與意義',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">公司在年度營運獲利後，會依盈餘分配政策發放「股利」給股東股利主要分為：</p>
      
      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 w-1/4 whitespace-nowrap">股利類型</th>
                <th class="p-3">說明</th>
                <th class="p-3 w-1/4 whitespace-nowrap">對公司影響</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold text-blue-700 whitespace-nowrap">現金股利</td>
                <td class="p-3">
                  公司以現金方式分配盈餘，投資人可直接收到現金入帳，
                  <span class="text-green-700 font-medium">可立即轉為現金收益</span>
                </td>
                <td class="p-3">公司現金資產減少</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold text-fuchsia-700 whitespace-nowrap">股票股利</td>
                <td class="p-3">
                  公司以股票方式分配盈餘，投資人持股數增加，
                  <span class="text-yellow-700 font-medium">但股價會依股本膨脹而下調</span>
                </td>
                <td class="p-3">股本增加、每股盈餘被稀釋</td>
              </tr>
            </tbody>
          </table>
      </div>
      
      <div class="mt-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-md text-gray-700 text-base">
          <strong class="text-blue-700">📘 小提醒：</strong><br>
          公司可同時發放現金股利與股票股利，稱為「混合股利」<br>
          發放比例由股東會決議，通常反映公司獲利與資金狀況
      </div>
    `,
            img: null,
            imgClass: '',
        },

        {
            title: '除權息與參考價計算',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">股利發放後，股票會進行「除權」或「除息」調整，代表公司已分配權益給股東<br>除權息後股價會自動調整，以反映資本變動：</p>
      
      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 w-1/4 whitespace-nowrap">項目</th>
                <th class="p-3">說明</th>
                <th class="p-3 w-1/3 whitespace-nowrap">參考價計算公式</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">除權</td>
                <td class="p-3">
                  發放 <span class="font-semibold text-blue-700">股票股利</span> 時適用，
                  代表投資人持股數增加但每股價值下降
                </td>
                <td class="p-3">
                  除權參考價 = 前一交易日收盤價 ÷ (1 + 配股率)
                  <br><small class="text-gray-500">配股率 = 股票股利 ÷ 每股面額（10 元）</small>
                </td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">除息</td>
                <td class="p-3">
                  發放 <span class="font-semibold text-red-700">現金股利</span> 時適用，
                  代表公司現金減少，股價會相對下調
                </td>
                <td class="p-3">
                  除息參考價 = 除息前收盤價 − 現金股利
                </td>
              </tr>
            </tbody>
          </table>
      </div>
      
      <div class="mt-6 bg-green-50 border-l-4 border-green-600 p-4 rounded-md text-gray-700 text-base">
          <strong class="text-green-700">📘 舉例：</strong><br>
          若股票 A 收盤價為 100 元，配發現金股利 3 元、股票股利 10%，<br>
          除權息後參考價 = (100 − 3) ÷ (1 + 0.1) = **88.18 元**
      </div>
    `,
            img: null,
            imgClass: '',
        },
    ]

    const isLastSlide = computed(() => currentSlide.value === slides.length - 1)

    function nextSlide() {
        if (currentSlide.value < slides.length - 1) currentSlide.value++
    }
    function prevSlide() {
        if (currentSlide.value > 0) currentSlide.value--
    }
    function goHome() {
        router.push('/learning')
        setTimeout(() => {
            toast.add({
                severity: 'success',
                summary: '🎉 恭喜你完成本單元！',
                life: 2500,
            })
        }, 300)
    }
</script>

<style scoped>
    /* 確保表格邊框美觀 */
    table {
        border-collapse: collapse;
    }
    /* 沿用上一個組件的彈性滑動動畫 */
    .slide-fade-enter-active,
    .slide-fade-leave-active {
        transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.35);
    }
    .slide-fade-enter-from {
        opacity: 0;
        transform: translateX(30px);
    }
    .slide-fade-leave-to {
        opacity: 0;
        transform: translateX(-30px);
    }
</style>
