from ultralytics import YOLO
import os
import time

# 匯出目標路徑
onnx_path = "/home/lab504/Desktop/yolo10/best.onnx"

# 載入模型
model = YOLO("best.pt")

# 匯出為 ONNX（會自動存在當前目錄）
model.export(
    format="onnx",
    opset=13,
    #file=onnx_path,
    #include_preprocess=True
)

# 等待一點時間讓檔案寫入完成
time.sleep(2)

# 檢查是否匯出成功
if os.path.exists(onnx_path):
    print(f"✅ ONNX 模型成功保存到 {onnx_path}")
else:
    print(f"❌ 匯出失敗，找不到 {onnx_path}，請手動確認。")
