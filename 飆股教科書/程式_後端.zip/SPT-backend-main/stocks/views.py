from rest_framework import status
from .models import Stock as StockModel
from rest_framework import permissions
from rest_framework.views import APIView
from .serializers import WatchlistSerializer
from rest_framework.response import Response
from .services.get_stocks_data import get_stocks_data
from .services.get_hot_stocks_data import get_hot_stocks_data
from .services.import_stocks_data import import_twse_stock_data
from .services.watchlist_data import (
    get_watchlist_data,
    add_watchlist_data,
    delete_watchlist_data,
    reorder_watchlist_data,
)


class StockImportDB(APIView):
    def post(self, request):
        try:
            result = import_twse_stock_data()
            return Response(
                {
                    'message': f'成功匯入 {result["created"]} 筆資料（共 {result["total"]} 筆）'
                },
                status=status.HTTP_200_OK,
            )
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class Stock(APIView):
    def get(self, request):
        try:
            result = get_stocks_data(keyword=request.query_params.get('keyword', None))
            return Response(result, status=status.HTTP_200_OK)
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class Watchlist(APIView):
    serializer_class = WatchlistSerializer
    permission_classes = [permissions.IsAuthenticated]  # 需要登入才能存取

    # 取得目前使用者的自選股清單（依 position 排序）
    def get(self, request):
        try:
            result = get_watchlist_data(user=request.user)
            return Response(result, status=status.HTTP_200_OK)
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    # 新增一檔自選股（如果已存在就忽略）
    def post(self, request):
        symbol = request.data.get('symbol')
        if not symbol:
            return Response(
                {'error': 'symbol 為必填欄位'}, status=status.HTTP_400_BAD_REQUEST
            )
        try:
            stock = StockModel.objects.get(symbol=symbol)
        except StockModel.DoesNotExist:
            return Response({'error': '股票不存在'}, status=status.HTTP_404_NOT_FOUND)
        try:
            _, created = add_watchlist_data(user=request.user, stock=stock)
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        if created:
            return Response({'message': '已加入自選股'}, status=status.HTTP_201_CREATED)
        else:
            return Response(
                {'message': '已存在，未重複新增'}, status=status.HTTP_200_OK
            )

    # 從自選股刪除一檔股票
    def delete(self, request):
        symbol = request.data.get('symbol')
        try:
            stock = StockModel.objects.get(symbol=symbol)
        except StockModel.DoesNotExist:
            return Response({'error': '股票不存在'}, status=status.HTTP_404_NOT_FOUND)
        try:
            delete_watchlist_data(user=request.user, stock=stock)
            return Response({'message': '已從自選股刪除'}, status=status.HTTP_200_OK)
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    # 批次排序（前端拖拉後呼叫）
    def patch(self, request):
        ids = request.data.get('ids')
        if not isinstance(ids, list) or not ids:
            return Response(
                {'error': 'ids 必須是非空陣列'}, status=status.HTTP_400_BAD_REQUEST
            )
        try:
            reorder_watchlist_data(user=request.user, ids=ids)
            return Response({'message': '排序成功'}, status=status.HTTP_200_OK)
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class HotStocks(APIView):
    # 取得熱門股票清單
    def get(self, request):
        try:
            result = get_hot_stocks_data()
            return Response(result, status=status.HTTP_200_OK)
        except RuntimeError as e:
            return Response(
                {'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
