<template>
    <!-- 套用優化後的容器樣式：背景、大間距、最大寬度 -->
    <div class="w-full px-4 md:px-16 py-12 bg-gray-50 min-h-screen">
        <!-- 進度條區塊：自定義進度條與主題標籤 -->
        <div class="mb-10 max-w-5xl mx-auto">
            <div class="flex justify-between items-end mb-2">
                <h3 class="text-xl font-semibold text-blue-700 transition duration-300">
                    {{
                        slides[currentSlide].title.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]\s?/, '')
                    }}
                </h3>
                <span class="text-sm font-medium text-gray-500">
                    主題 {{ currentSlide + 1 }} / {{ slides.length }}
                </span>
            </div>
            <div class="w-full bg-gray-300 rounded-full h-2.5 overflow-hidden">
                <div
                    class="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
                    :style="{ width: ((currentSlide + 1) / slides.length) * 100 + '%' }"
                ></div>
            </div>
        </div>

        <!-- Slide 區塊：優化後的卡片樣式與 slide-fade 動畫 -->
        <transition name="slide-fade" mode="out-in">
            <div
                :key="currentSlide"
                class="bg-white rounded-2xl shadow-xl p-10 md:flex gap-12 items-start border border-gray-100 max-w-5xl mx-auto"
            >
                <!-- 內容區塊：由於沒有圖片，強制設定為 full-width -->
                <div class="md:w-full w-full">
                    <!-- 標題樣式 -->
                    <h2 class="text-3xl font-extrabold mb-6 text-gray-800">
                        {{ slides[currentSlide].title }}
                    </h2>
                    <!-- 內容樣式 -->
                    <div
                        class="text-lg text-gray-700 leading-relaxed space-y-4"
                        v-html="slides[currentSlide].content"
                    ></div>
                </div>

                <!-- 圖片區塊已移除 -->
            </div>
        </transition>

        <!-- 控制按鈕區塊：優化後的圓角按鈕和間距 -->
        <div class="flex justify-between mt-16 max-w-5xl mx-auto">
            <button
                @click="prevSlide"
                :disabled="currentSlide === 0"
                class="px-7 py-2.5 rounded-full border border-blue-600 text-blue-600 font-medium hover:bg-blue-50 transition duration-300 disabled:opacity-40 disabled:border-gray-300 disabled:text-gray-400"
            >
                &larr; 上一主題
            </button>

            <button
                v-if="!isLastSlide"
                @click="nextSlide"
                class="px-9 py-2.5 rounded-full bg-blue-600 text-white font-semibold shadow-md shadow-blue-300 hover:bg-blue-700 hover:shadow-lg transition duration-300"
            >
                下一主題 &rarr;
            </button>

            <button
                v-else
                @click="goHome"
                class="px-9 py-2.5 rounded-full bg-green-600 text-white font-semibold shadow-md shadow-green-300 hover:bg-green-700 hover:shadow-lg transition duration-300"
            >
                回到課程首頁
            </button>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed } from 'vue'
    import { useRouter } from 'vue-router'
    import { useToast } from 'primevue/usetoast'

    const toast = useToast()
    const router = useRouter()
    const currentSlide = ref(0)

    const slides = [
        {
            title: '股票交易時間',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">台灣證券交易所提供多種交易制度，以滿足不同投資需求，以下為各交易時段與內容：</p>
      
      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 whitespace-nowrap">交易種類</th>
                <th class="p-3 whitespace-nowrap">交易時間</th>
                <th class="p-3">交易內容</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">一般交易</td>
                <td class="p-3">09:00～13:30</td>
                <td class="p-3 text-left">
                  <ul class="list-disc list-inside space-y-1">
                    <li>交易單位：1 張 = 1,000 股</li>
                    <li>漲跌幅限制：±10%</li>
                    <li>結算週期：T+2</li>
                    <li>手續費：成交金額 × 0.1425%</li>
                    <li>證交稅：賣出 0.3%</li>
                  </ul>
                </td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">鉅額交易</td>
                <td class="p-3">08:00～08:30、09:00～17:00</td>
                <td class="p-3 text-left">
                  <ul class="list-disc list-inside space-y-1">
                    <li>目的：避免大額委託造成劇烈波動</li>
                    <li>門檻：500 張或金額 ≥ 1,500 萬元</li>
                    <li>方式：配對或逐筆交易</li>
                  </ul>
                </td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">零股交易</td>
                <td class="p-3">09:10～13:30、13:40～14:30</td>
                <td class="p-3 text-left">
                  <ul class="list-disc list-inside space-y-1">
                    <li>少於 1 張的零股可單獨交易</li>
                    <li>盤中：每 5 秒集合競價</li>
                    <li>盤後：14:30 集合競價成交</li>
                  </ul>
                </td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold whitespace-nowrap">盤後定價交易</td>
                <td class="p-3">14:00～14:30</td>
                <td class="p-3 text-left">
                  <ul class="list-disc list-inside space-y-1">
                    <li>目的：以當日收盤價交易</li>
                    <li>成交價：固定為收盤價</li>
                    <li>成交時間：14:30 自動撮合</li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>
      </div>
    `,
            img: null,
            imgClass: '',
        },

        {
            title: '委託條件（Order Types）',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">投資人下單時可選擇不同委託條件，控制掛單在市場的存留時間與成交方式：</p>
      
      <div class="overflow-x-auto border rounded-lg">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-800 text-white">
              <tr>
                <th class="p-3 w-1/6 whitespace-nowrap">條件代碼</th>
                <th class="p-3 whitespace-nowrap">條件名稱</th>
                <th class="p-3">說明</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold">ROD</td>
                <td class="p-3">當日有效單 (Rest of Day)</td>
                <td class="p-3">委託後若未成交，會持續掛單至當日收盤前；一般投資人常用</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold">IOC</td>
                <td class="p-3">立即成交否則取消 (Immediate or Cancel)</td>
                <td class="p-3">未成交部分立即刪除，不會留在委託簿；常見於高頻或程式交易</td>
              </tr>
              <tr class="hover:bg-blue-50">
                <td class="p-3 font-semibold">FOK</td>
                <td class="p-3">全部成交否則取消 (Fill or Kill)</td>
                <td class="p-3">若無法全數成交，則整筆刪單；法人或鉅額交易常使用</td>
              </tr>
            </tbody>
          </table>
      </div>
    `,
            img: null,
            imgClass: '',
        },

        {
            title: '交易種類',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">台灣股市主要交易方式可分為「現股交易」與「信用交易」：</p>
      <ul class="list-disc pl-5 space-y-3 text-gray-800 leading-relaxed">
        <li><span class="font-semibold text-blue-700">現股交易：</span>投資人以自有資金直接買進股票，完全擁有股票所有權，可享受股利與股東權益</li>
        <li><span class="font-semibold text-red-600">信用交易</span>(融資融券)：
          <ul class="list-disc ml-6 mt-2 space-y-1">
            <li><strong>融資（看漲）：</strong> 投資人借錢買股票，預期上漲後賣出獲利</li>
            <li><strong>融券（看跌）：</strong> 投資人借股票賣出，預期下跌後買回歸還，賺取價差（放空）</li>
          </ul>
        </li>
      </ul>
      <div class="mt-6 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-md text-gray-700 text-base">
          <strong class="text-yellow-700">📌 補充說明：</strong><br>
          融資、融券合稱「信用交易」，需開立信用帳戶並通過券商審核<br>
          若融資維持率低於規定（約 130%），將面臨追繳保證金或強制平倉（斷頭）
      </div>
    `,
            img: null,
            imgClass: '',
        },

        {
            title: '交割制度（T+2）',
            content: `
      <p class="mb-4 text-gray-700 leading-relaxed">「T+2」代表 <span class="text-blue-600 font-semibold">交易日（T）後第二個營業日完成交割</span></p>
      <ul class="list-disc pl-5 space-y-3 text-gray-800 leading-relaxed">
        <li>若於週一成交（T），則週三完成交割（T+2）</li>
        <li>買方需於 T+2 前付款；賣方於 T+2 收款</li>
        <li>若遇假日則順延至下個營業日</li>
      </ul>
      <div class="mt-6 bg-green-50 border-l-4 border-green-500 p-4 rounded-md text-gray-700 text-base">
          <strong class="text-green-700">📘 範例：</strong>
          你在週一買進台積電，款項將於週三（T+2）正式扣款並完成交割
      </div>
    `,
            img: null,
            imgClass: '',
        },
    ]

    const isLastSlide = computed(() => currentSlide.value === slides.length - 1)

    function nextSlide() {
        if (currentSlide.value < slides.length - 1) currentSlide.value++
    }
    function prevSlide() {
        if (currentSlide.value > 0) currentSlide.value--
    }
    function goHome() {
        router.push('/learning')
        setTimeout(() => {
            toast.add({
                severity: 'success',
                summary: '🎉 恭喜你完成本單元！',
                life: 2500,
            })
        }, 300)
    }
</script>

<style scoped>
    /* 確保表格邊框美觀 */
    table {
        border-collapse: collapse;
    }
    /* 沿用上一個組件的彈性滑動動畫 */
    .slide-fade-enter-active,
    .slide-fade-leave-active {
        transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.35);
    }
    .slide-fade-enter-from {
        opacity: 0;
        transform: translateX(30px);
    }
    .slide-fade-leave-to {
        opacity: 0;
        transform: translateX(-30px);
    }
</style>
