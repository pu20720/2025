using UnityEngine;
using System.Collections.Generic;

// ▼▼▼ 【修正】刪除了重複的 ItemType 定義，直接使用 RPEnums.cs 的定義 ▼▼▼
// (原本這裡的 public enum ItemType { ... } 已移除)
// ▲▲▲ 修正結束 ▲▲▲

// 2. 定義單個物品的基礎資料結構
[System.Serializable]
public class RPGItemData
{
    [Header("基礎資訊")]
    public string id;           // 程式用的唯一 ID (例如 "Hero_Skin_Red", "Enemy_Goblin")
    public string displayName;  // 顯示名稱 (例如 "紅色勇者造型", "哥布林")
    public Sprite icon;         // 在編輯器/背包中顯示的圖示
    [TextArea] public string description; // 物品描述

    [Header("外觀/變身設定 (僅特殊物品或敵人使用)")]
    // 若此物品是用來改變外觀，這裡設定目標與新圖片
    public string targetCharacterID; // 目標對象 ID (對應場景中 GameObject 的名稱)
    public Sprite targetNewSprite;   // 變身後要替換成的 Sprite
}

// 3. 建立資料庫容器
// 這是一個 ScriptableObject，能讓您在 Project 視窗右鍵建立實體資料庫檔案
[CreateAssetMenu(fileName = "NewRPGDatabase", menuName = "RPG/Database")]
public class RPGDatabaseSO : ScriptableObject
{
    // 我們用四個 List 分類存放，方便在編輯器視窗管理
    public List<RPGItemData> cards = new List<RPGItemData>();
    public List<RPGItemData> consumables = new List<RPGItemData>();
    public List<RPGItemData> enemies = new List<RPGItemData>();
    public List<RPGItemData> specialItems = new List<RPGItemData>();

    // 輔助方法：透過 ID 尋找物品 (Runtime 讀取用)
    public RPGItemData GetItemByID(string searchID)
    {
        RPGItemData item = null;

        // 依序搜尋所有清單
        item = specialItems.Find(x => x.id == searchID);
        if (item != null) return item;

        item = cards.Find(x => x.id == searchID);
        if (item != null) return item;

        item = consumables.Find(x => x.id == searchID);
        if (item != null) return item;

        item = enemies.Find(x => x.id == searchID);
        if (item != null) return item;

        return null; // 找不到
    }
}