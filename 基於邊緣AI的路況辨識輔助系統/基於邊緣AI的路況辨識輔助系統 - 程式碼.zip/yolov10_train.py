from ultralytics import YOLO

if __name__ == '__main__':

    model = YOLO("yolov10m.pt")

    model.train(
        data="yolov10_20250915_640/data.yaml",
        epochs=300,              
        imgsz=416,               
        batch=4,                 
        patience=50,             # 提前停止
        scale=0.2,

        mosaic=1.0,              # 強化小物件
        mixup=0.2,               # MixUp 增強
        copy_paste=0.1,          # Copy-Paste 增強 (適合行人、車輛)
        flipud=0.0,              # 上下翻轉關掉
        fliplr=0.5,              # 左右翻轉保留

        label_smoothing=0.0,
        warmup_epochs=3,         # 前期暖身
        device=0,
        project='20250915_m',
        name='train',

        workers=2,               # 減少 dataloader 線程，降低顯存/記憶體佔用
        amp=True,                # 確保啟用混合精度訓練 (省顯存)
    )
