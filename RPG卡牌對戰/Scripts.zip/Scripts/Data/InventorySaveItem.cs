// 檔案路徑: Assets/Scripts/Data/InventorySaveItem.cs
using System; // Needed ONLY for [System.Serializable]

// ▼▼▼ InventorySaveItem 的唯一定義 ▼▼▼
[System.Serializable]
public struct InventorySaveItem
{
    public string itemName;
    public int quantity;
}
// ▲▲▲ InventorySaveItem 的唯一定義 ▲▲▲

// ***** 確保此檔案下方沒有其他程式碼 *****