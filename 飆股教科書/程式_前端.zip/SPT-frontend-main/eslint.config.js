import vue from 'eslint-plugin-vue'
import js from '@eslint/js'
import prettier from 'eslint-config-prettier'
import vueParser from 'vue-eslint-parser'

export default [
    {
        ignores: [
            'dist/**',
            'node_modules/**/*',
            'build/**/*',
            'coverage/**/*',
            'public/**/*',
            '.vscode/**/*',
            '*.min.js',
        ],
    },

    {
        files: ['*.vue', '*.js', '*.jsx'],

        languageOptions: {
            parser: vueParser,
            parserOptions: {
                ecmaVersion: 'latest',
                sourceType: 'module',
            },
            globals: {
                window: 'readonly',
                document: 'readonly',
                localStorage: 'readonly',
                console: 'readonly',
            },
        },

        plugins: {
            vue,
        },

        rules: {
            ...js.configs.recommended.rules,
            'no-unused-vars': 'warn',
            'vue/multi-word-component-names': 'off',
            'vue/no-v-html': 'off',
            'vue/require-default-prop': 'off',
            'vue/no-unused-vars': 'warn',
            'vue/require-v-for-key': 'error',
            'vue/max-attributes-per-line': ['error', { singleline: 3, multiline: 1 }],
            'vue/html-self-closing': [
                'error',
                {
                    html: { void: 'never', normal: 'always', component: 'always' },
                    svg: 'always',
                    math: 'always',
                },
            ],
        },
    },

    prettier,
]
