# line_serial_bot.py
import serial
import threading
import time
from flask import Flask, request, abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError, LineBotApiError
from linebot.models import MessageEvent, TextMessage, TextSendMessage
# ====== 配置區 ======
LINE_CHANNEL_ACCESS_TOKEN = "omLi2JTLgICU2/rOauXXhqIowEiIdgCCRDJ4KCOEKC1euuQg3O5O8+4Zvr4Tlz8sywe3uKpCqWU2KQYK0S/y2RNpJ2NhObvQ9Gw3WsBypbkU/TUYN1uxzd0BjNza0kCJEDY24lSPrJ1Hn1GXe9hU1wdB04t89/1O/w1cDnyilFU="
LINE_CHANNEL_SECRET = "cdcdd2d0ca2cce116cb724c6b4195679"

# 你給的 User ID（會用來 push message）
LINE_USER_ID = "U115b2d40943998704071ee043b727477"

# Serial 設定
SERIAL_PORT = "COM3"
BAUD_RATE = 115200

# ====== 初始化 ======
app = Flask(__name__)
line_bot_api = LineBotApi(LINE_CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(LINE_CHANNEL_SECRET)

ser = None

def open_serial():
    global ser
    while True:
        try:
            ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
            print(f"[Serial] 已連上 {SERIAL_PORT} @ {BAUD_RATE}")
            break
        except Exception as e:
            print(f"[Serial] 連接失敗: {e} — 5秒後重試")
            time.sleep(5)

open_serial()

# ====== Serial 監聽緒 ======
def serial_listener():
    global pending_reply_token

    while True:
        try:
            raw = ser.readline()
            if not raw:
                continue

            line = raw.decode(errors="ignore").strip()
            if not line:
                continue

            print("[Arduino] >", line)

            # Arduino 回報：定時餵食開始
            if ("定時投餵開始" in line or "⏰" in line) and pending_reply_token:
                try:
                    line_bot_api.reply_message(
                        pending_reply_token,
                        TextSendMessage(text="投餵開始！")
                    )
                    print("[LINE] 已回覆: 定時投餵開始")
                except Exception as e:
                    print("[LINE] reply 失敗:", e)
                finally:
                    pending_reply_token = None  # reply_token 用一次後必須清掉

            # Arduino 回報：完成
            elif ("投餵完成" in line or "✅" in line) and pending_reply_token:
                try:
                    line_bot_api.reply_message(
                        pending_reply_token,
                        TextSendMessage(text="✅ 投餵完成！")
                    )
                    print("[LINE] 已回覆: 投餵完成")
                except Exception as e:
                    print("[LINE] reply 失敗:", e)
                finally:
                    pending_reply_token = None  # reply_token 用一次後必須清掉

        except Exception as e:
            print("[Serial Listener] 發生錯誤:", e)



listener_thread = threading.Thread(target=serial_listener, daemon=True)
listener_thread.start()

# ====== LINE webhook ======
@app.route("/callback", methods=['POST'])
def callback():
    signature = request.headers.get('X-Line-Signature', '')
    body = request.get_data(as_text=True)

    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)

    return 'OK'

# ====== 使用者訊息處理 ======
command_map = {
    "搖晃觸發": "SHAKE",
    "定時餵食": "FEED_NOW",
}

pending_reply_token = None

@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    global pending_reply_token

    text = event.message.text.strip()


    if text in command_map:
        cmd = command_map[text]
        try:
            # 發送指令給 Arduino
            ser.write((cmd + "\n").encode())
            print(f"[Serial] 寄出: {cmd}")

            # 儲存 reply_token（等待 Arduino 回覆再用）
            pending_reply_token = event.reply_token

            # 暫時不回覆（避免用掉唯一一次 reply_token）
            # 等到 Arduino 回覆後才真正 reply_message()

        except Exception as e:
            # 如果 Serial 壞掉，就直接回覆錯誤（這是立即回覆，不用等）
            line_bot_api.reply_message(
                event.reply_token,
                TextSendMessage(text="Serial 傳送失敗")
            )
            print("[Serial] 寄出失敗:", e)

    else:
        # 不在 command_map 裡 → 直接立即回覆
        reply = "請選擇：搖晃觸發 / 定時餵食"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply)
        )


# ====== 啟動 ======
if __name__ == "__main__":
    print("LINE-Serial Bridge 已啟動")
    app.run(host="0.0.0.0", port=80, debug=False)