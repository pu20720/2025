<template>
    <div class="min-h-screen bg-gray-100">
        <div style="height: 60px"></div>
        <Navbar />
        <router-view></router-view>

        <Toast position="bottom-left" />
        <ChatWidget />
    </div>
</template>
