using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ConversationManager : MonoBehaviour
{
    // ▼▼▼ [修復] 補回 BattleManager 需要的變數 ▼▼▼
    public static string chosenBranch = "";
    public static string playerName = "Player";
    // ▲▲▲ [修復結束] ▲▲▲

    [Header("UI References")]
    [SerializeField] private GameObject dialoguePanel;

    public static List<RPGItemData> playerInventory = new List<RPGItemData>();

    private void Start()
    {
        if (dialoguePanel != null) dialoguePanel.SetActive(false);

        if (GameSession.SelectedStartingItem != null)
        {
            ReceiveStartingItem(GameSession.SelectedStartingItem);
        }

        StartCoroutine(StartOpeningDialogue());
    }

    private void ReceiveStartingItem(RPGItemData item)
    {
        playerInventory.Add(item);
        Debug.Log($"[系統] 獲得起始物品: {item.displayName}");
        GameSession.ClearSession();
    }

    public void ApplySkinEffect(RPGItemData item)
    {
        if (item == null || string.IsNullOrEmpty(item.targetCharacterID)) return;
        GameObject target = GameObject.Find(item.targetCharacterID);
        if (target != null)
        {
            SpriteRenderer sr = target.GetComponent<SpriteRenderer>();
            if (sr != null && item.targetNewSprite != null) sr.sprite = item.targetNewSprite;
        }
    }

    private IEnumerator StartOpeningDialogue()
    {
        yield return new WaitForSeconds(0.5f);
        if (dialoguePanel != null) dialoguePanel.SetActive(true);
    }
}