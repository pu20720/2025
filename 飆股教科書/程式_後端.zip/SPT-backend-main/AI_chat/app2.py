# SPT-backend/app.py
import os
import uuid
import re
import json
import requests
import chromadb
from google import genai
from typing import List
from flask_cors import CORS
from dotenv import load_dotenv
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from sentence_transformers import SentenceTransformer, CrossEncoder


# === 初始化 ===
load_dotenv()
google_client = genai.Client()


# === 股票代碼對照表 ===
def load_stock_data(file_path: str) -> dict:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f'找不到股票資料檔案: {file_path}')
        return {}


STOCK_DATA = load_stock_data('stock_data.json')
# 初始化嵌入模型
embedding_model = SentenceTransformer('shibing624/text2vec-base-chinese')

# 初始化 Chroma 資料庫
chromadb_client = chromadb.PersistentClient(path='./chromadb.db')
chromadb_collection = chromadb_client.get_or_create_collection(
    name='default',
    metadata={'hnsw:space': 'cosine'},  # 使用 "cosine" 作為計算標準
)

# CrossEncoder
cross_encoder = CrossEncoder('cross-encoder/mmarco-mMiniLMv2-L12-H384-v1')

FINMIND_TOKEN = os.getenv('FINMIND_TOKEN')

# === Flask App ===

app = Flask(__name__)
CORS(app)


# === 函數區 ===
def embed_chunk(chunk: str) -> List[float]:
    return embedding_model.encode(chunk).tolist()


def retrieve(query: str, top_k: int = 5) -> List[str]:
    query_embedding = embed_chunk(query)
    results = chromadb_collection.query(
        query_embeddings=[query_embedding], n_results=top_k
    )
    return results['documents'][0]


def rerank(query: str, retrieved_chunks: List[str], top_k: int = 3) -> List[str]:
    pairs = [(query, chunk) for chunk in retrieved_chunks]
    scores = cross_encoder.predict(pairs)
    chunk_with_score_list = sorted(
        zip(retrieved_chunks, scores), key=lambda pair: pair[1], reverse=True
    )
    return [chunk for chunk, _ in chunk_with_score_list[:top_k]]


def parse_stock_query(query: str) -> (str, str, List[str]):
    """
    從查詢中解析出股票 ID、股票名稱和關鍵字。

    返回: (stock_id, stock_name, keywords_list)
    """
    stock_id, stock_name = None, None

    # 1. 優先比對股票名稱 (因為 STOCK_DATA 比較準確)
    for name, id in STOCK_DATA.items():
        if name in query:
            stock_id = id
            stock_name = name
            break

    # 2. 如果沒有名稱，再比對股票代碼 (4位數字)
    if not stock_id:
        match = re.search(r'(\d{4})', query)
        if match:
            stock_id = match.group(1)
            # 嘗試從 ID 反查名稱
            stock_name = next(
                (name for name, id_val in STOCK_DATA.items() if id_val == stock_id),
                stock_id,
            )

    # 如果連 ID 都沒有，直接返回
    if not stock_id:
        return None, None, []

    # 3. 提取關鍵字
    # 移除股票名稱、ID 和 "新聞" 字眼
    query_cleaned = (
        query.replace(stock_name, '').replace(stock_id, '').replace('新聞', '').strip()
    )
    # 將剩餘的字串用空白切開，作為關鍵字
    keywords = [k for k in query_cleaned.split() if k]

    return stock_id, stock_name, keywords


# === 新增：Step 1 - 判斷問題是否與知識庫相關 ===
def is_relevant(
    query: str,
    sim_threshold: float = 0.5,
    avg_topk_threshold: float = 0.35,
    cross_threshold: float = 0.35,
    top_k: int = 5,
) -> bool:
    """
    複合判準的相關性檢查：
      - sim_threshold: 任一檢索距離轉成相似度 (1 - distance) 的最大值達此門檻即視為相關
      - avg_topk_threshold: 取前 top_k 的相似度平均值作次要判準
      - cross_threshold: 若 reranker (CrossEncoder) 的最高分 >= 該值，也視為相關
    回傳 True 表示相關，否則 False。
    """
    # 1) 用向量檢索拿到 distances & documents
    query_embedding = embed_chunk(query)
    results = chromadb_collection.query(
        query_embeddings=[query_embedding], n_results=top_k
    )

    # 若沒有返回結構，直接判定不相關
    if not results or not results.get('distances') or not results.get('documents'):
        return False

    distances = results['distances'][0]  # list of distances
    docs = results['documents'][0]  # list of docs (strings)

    if not distances:
        return False

    # 2) 把 distance 轉成 similarity（假設距離範圍可以用 1 - d）
    sims = [1 - d for d in distances]
    max_sim = max(sims)
    # top-k 的平均相似度（若實際結果小於 top_k，會自動做平均）
    top_k_vals = sorted(sims, reverse=True)[: min(len(sims), top_k)]
    avg_topk = sum(top_k_vals) / len(top_k_vals) if top_k_vals else 0.0

    # 3) 若最高相似度足夠，直接回 True（fast path）
    if max_sim >= sim_threshold:
        return True

    # 4) 若 top-k 平均達標，也回 True（避免單筆噪音）
    if avg_topk >= avg_topk_threshold:
        return True

    # 5) 如果以上都不夠，嘗試用 CrossEncoder 做語義重排分數判斷（較慢但更準）
    try:
        pairs = [(query, doc) for doc in docs]
        scores = cross_encoder.predict(pairs)  # higher = more relevant
        if len(scores) and max(scores) >= cross_threshold:
            return True
    except Exception as e:
        # 若 reranker 出問題，不阻斷流程，直接當作未通過
        print(f'[is_relevant] cross_encoder failed: {e}')

    # 6) 全部門檻都沒過，回 False
    return False


def generate(query: str, chunks: List[str]) -> str:
    if not chunks:
        return '抱歉，我沒有找到相關資料。'

    prompt = f"""
你是一位股票學習知識助手，請根據用戶問題和下列片段生成準確的回答。
請僅根據提供的片段內容回答，不要使用常識或自行推測。
如果片段中沒有足夠資訊，請直接回答：「抱歉，知識庫中沒有相關資料。」

用戶問題:
{query}

相關片段:
{'\n\n'.join(chunks)}

請開始回答：
"""

    response = google_client.models.generate_content(
        model='gemini-2.5-flash', contents=prompt
    )
    return response.text


# === 新聞摘要專用 ===
def generate_news_summary(chunks: List[str]) -> str:
    if not chunks:
        return '抱歉，沒有找到相關新聞內容。'

    prompt = f"""你是一位金融新聞分析助手，請閱讀以下新聞並統整出重點。
強調該股票可能的市場影響與投資人應注意的事項，不要逐字抄寫。
請將回答整理成 3 個重點，並使用條列式清單（如 1. 2. 3.）。
請在每個重點的開頭加上相關的**新聞標題**，接著再分析其**市場影響**和**投資人應注意**事項，並在每個重點的結尾附上 Markdown 超連結格式的**完整新聞連結**。
請將回答控制在250字內，簡潔明瞭。最後一段使用****並且30字內將全部投資建議說清楚：
{'\n\n'.join(chunks)}
"""

    response = google_client.models.generate_content(
        model='gemini-2.5-flash', contents=prompt
    )
    return response.text


def get_stock_news(
    stock_id: str, days: int = 30, keywords: List[str] = []
) -> List[str]:
    """
    獲取股票新聞。
    - days: 搜尋過去 N 天
    - keywords: 如果提供，將過濾標題必須包含 *所有* 關鍵字的新聞
    - 返回: 用於生成摘要的 Chunks 列表，或 None
    """
    try:
        if not FINMIND_TOKEN:
            print('未設定 FinMind API Token')
            return None

        start_date = (datetime.today() - timedelta(days=days)).strftime('%Y-%m-%d')
        url = 'https://api.finmindtrade.com/api/v4/data'
        params = {
            'dataset': 'TaiwanStockNews',
            'data_id': stock_id,
            'start_date': start_date,
            'token': FINMIND_TOKEN,
        }
        resp = requests.get(url, params=params).json()

        if not resp.get('data'):
            return None  # API 回傳沒有資料

        news_items = resp['data']

        # --- 關鍵字過濾邏輯 ---
        filtered_items = []
        if keywords:
            for item in news_items:
                title = item.get('title', '')
                # 檢查標題是否 *同時* 包含 *所有* 關鍵字
                if all(keyword.lower() in title.lower() for keyword in keywords):
                    filtered_items.append(item)

            if not filtered_items:
                return None  # 有新聞，但沒有一則符合關鍵字
        else:
            # 如果沒有關鍵字，就直接使用 API 回傳的 (通常是最新)
            filtered_items = news_items

        # --- 整理 Chunks ---
        # 最多取 5 則來做摘要
        chunks = [
            f'標題: {item["title"]} ({item["date"]})\n連結: {item["link"]}\n內文: {item.get("content", "")}'
            for item in filtered_items[:5]
        ]

        return chunks if chunks else None

    except Exception as e:
        print(f'取得新聞失敗: {str(e)}')
        return None


# === 文件切片與寫入 ChromaDB ===
def split_into_chunks(file_path: str) -> List[str]:
    """
    讀取 .md 文件並使用 \n\n\n (三個換行/兩個空行) 作為分隔符來切片。
    使用 r'\n{3,}' (三個或三個以上的換行符) 作為分割點。
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()

        # 使用正則表達式 r'\n{3,}' 來分割
        # 這代表 "連續三個或三個以上的 \n"
        chunks = re.split(r'\n{3,}', text)

        # 過濾掉可能因開頭/結尾的 \n\n\n 而產生的空字串
        # 修正您程式碼中的變數名稱錯誤 (tokens -> chunk)
        valid_chunks = [chunk.strip() for chunk in chunks if chunk.strip()]

        # 直接返回依 \n\n\n 切分好的區塊列表
        return valid_chunks

    except FileNotFoundError:
        print(f'⚠️ 找不到文件 {file_path}，無法進行切片。')
        return []
    except Exception as e:
        print(f'⚠️ 切片時發生錯誤: {e}')
        return []


def save_embeddings(chunks: List[str], embeddings: List[List[float]]):
    ids = [str(uuid.uuid4()) for _ in chunks]
    chromadb_collection.add(ids=ids, documents=chunks, embeddings=embeddings)


def embed_chunks(chunks: List[str]) -> List[List[float]]:
    return [embed_chunk(chunk) for chunk in chunks]


# === 路由 ===
@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    query = data.get('query', '').strip()

    # === 股票新聞查詢 (全新邏輯) ===
    if '新聞' in query:
        # 1. 解析查詢
        stock_id, stock_name, keywords = parse_stock_query(query)

        if stock_id:
            # 2. 嘗試獲取特定新聞 (搜尋 30 天)
            news_chunks = get_stock_news(stock_id, days=30, keywords=keywords)

            if news_chunks:
                # 情況 A: 成功找到！
                answer = generate_news_summary(news_chunks)
                return jsonify({'answer': answer})
            else:
                # 情況 B: 找不到特定新聞，啟動備案 (Fallback)

                # 備案：改為抓取 "元大台灣50 (0050)" 作為市場大盤新聞
                fallback_stock_id = '0050'
                fallback_stock_name = '元大台灣50'

                # 避免用戶剛好就在查 0050 又查不到，造成無限迴圈
                if stock_id == fallback_stock_id:
                    return jsonify(
                        {
                            'answer': f'抱歉，找不到 {stock_name} ({stock_id}) 的相關新聞。'
                        }
                    )

                # 抓 0050 最近 7 天的新聞 (不需要關鍵字)
                fallback_chunks = get_stock_news(fallback_stock_id, days=7, keywords=[])

                if fallback_chunks:
                    # 情況 C: 備案成功
                    fallback_summary = generate_news_summary(fallback_chunks)
                    answer = (
                        f'抱歉，我找不到關於「{query}」的特定新聞。\n\n'
                        f'不過，這裡有一些關於 **{fallback_stock_name} ({fallback_stock_id})** 的整體市場動態，供您參考：\n\n{fallback_summary}'
                    )
                    return jsonify({'answer': answer})
                else:
                    # 情況 D: 連備案都失敗
                    return jsonify(
                        {
                            'answer': f'抱歉，我找不到 {stock_name} ({stock_id}) 的相關新聞，也無法取得其他市場新聞。'
                        }
                    )
        else:
            # 情況 E: 連股票代碼/名稱都解析不出來
            return jsonify({'answer': '抱歉，我無法辨識您想查詢的新聞股票名稱或代碼。'})

    # === RAG 知識庫查詢 (保持不變) ===

    # === Step 1: 相關性檢查 ===
    if not is_relevant(
        query, sim_threshold=0.3, avg_topk_threshold=0.35, cross_threshold=0.3, top_k=5
    ):
        return jsonify({'answer': '抱歉，這個問題似乎不在我目前的知識庫範圍內。'})

    # === Step 2: RAG 正常流程 ===
    retrieved_chunks = retrieve(query, 5)
    reranked_chunks = rerank(query, retrieved_chunks, 3)
    answer = generate(query, reranked_chunks)

    return jsonify({'answer': answer})


if __name__ == '__main__':
    #
    # 步驟 1: 檢查您的知識庫檔案名稱是否正確
    #
    file_path = '文件.md'  # <--- 確保這就是您包含 ##K線 標籤的檔案

    #
    # 步驟 2: 檢查現有的 ChromaDB 狀態
    #
    NEEDS_REBUILD = False
    try:
        # 嘗試取得 collection
        collection = chromadb_client.get_collection(name='default')

        # 檢查演算法是否為 'cosine'
        if collection.metadata.get('hnsw:space') != 'cosine':
            print('🔍 發現舊的(L2)資料庫，正在刪除並重建 (Cosine)...')
            chromadb_client.delete_collection(name='default')
            collection = chromadb_client.create_collection(
                name='default', metadata={'hnsw:space': 'cosine'}
            )
            print('✅ 已建立新的(Cosine)資料庫。')
            NEEDS_REBUILD = True
        else:
            # 演算法正確，檢查是否為空
            if collection.count() == 0:
                print('⚠️ (Cosine)資料庫為空，將載入資料...')
                NEEDS_REBUILD = True
            else:
                print(
                    f'✅ (Cosine)資料庫已存在且包含 {collection.count()} 筆資料，略過初始化。'
                )
                NEEDS_REBUILD = False

    except Exception as e:
        # 捕獲 Collection 不存在或其他錯誤
        print(f'🔍 找不到資料庫或發生錯誤 ({e})，正在建立新的(Cosine)資料庫...')
        try:
            # 嘗試刪除可能存在的損壞 collection
            chromadb_client.delete_collection(name='default')
        except Exception:
            pass  # 忽略刪除失敗 (因為可能本來就不存在)

        collection = chromadb_client.create_collection(
            name='default', metadata={'hnsw:space': 'cosine'}
        )
        print('✅ 已建立新的(Cosine)資料庫。')
        NEEDS_REBUILD = True

    #
    # 步驟 3: 如果需要，才載入並儲存資料
    #
    if NEEDS_REBUILD and os.path.exists(file_path):
        print(f"⏳ 正在讀取並切分 '{file_path}'...")
        #
        # ⚠️ 關鍵：確保 split_into_chunks 使用 r'\n{2,}' (兩個換行)
        #
        chunks = split_into_chunks(file_path)  #

        if chunks:
            print(f'⏳ 正在將 {len(chunks)} 個區塊轉換為向量並儲存...')
            embeddings = embed_chunks(chunks)
            save_embeddings(chunks, embeddings)
            print('✅ 向量資料庫初始化完成！')
        else:
            print(f'⚠️ {file_path} 中沒有讀取到任何資料。')

    elif NEEDS_REBUILD and not os.path.exists(file_path):
        print(f'⚠️ 找不到文件 {file_path}，RAG 初始化失敗')

    #
    # 步驟 4: 執行啟動測試 (無論是否重建都執行)
    #
    print('\n--- 執行啟動測試 ---')
    query = 'K線圖怎麼看?'

    is_rel = is_relevant(query)
    print(f'📘 測試「{query}」的相關性: {is_rel}')

    if is_rel:
        retrieved_chunks = retrieve(query, top_k=5)
        reranked_chunks = rerank(query, retrieved_chunks, top_k=3)
        answer = generate(query, reranked_chunks)
        print(f'📘 測試查詢回答：\n{answer}')
    else:
        print('📘 測試查詢回答：\n(未通過相關性檢查，這是正常的 RAG 流程)')

    print('--- 測試完畢 ---')

    #
    # 步驟 5: 啟動 Flask
    #
    print('\n🚀 啟動 Flask 伺服器...')
    # debug=False 確保 __main__ 不會被執行兩次
    app.run(host='0.0.0.0', port=5000, debug=False)
