<script setup>
    import { ref } from 'vue'
    import { useUserStore } from '@/stores/user.js'

    const email = ref('')
    const password = ref('')
    const mode = ref('login') // 'login' or 'reset'
    const { loginUser } = useUserStore()

    async function loginUserRequest() {
        await loginUser(email.value, password.value)
    }
</script>

<template>
    <div class="flex items-center justify-center min-h-screen px-4 bg-gray-50">
        <div class="w-full max-w-md p-8 bg-white rounded-md shadow-2xl">
            <!-- 登入表單 -->
            <template v-if="mode === 'login'">
                <form @submit.prevent="loginUserRequest">
                    <div class="mb-4">
                        <label class="block mb-2 text-base font-medium">電子信箱</label>
                        <InputText
                            v-model="email"
                            class="w-full text-base py-3"
                            placeholder="請輸入電子信箱"
                        />

                        <div class="mb-4">
                            <label class="block mb-2 text-base font-medium">密碼</label>
                            <InputText
                                v-model="password"
                                type="password"
                                class="w-full text-base py-3"
                                placeholder="請輸入密碼"
                            />
                        </div>

                        <Button type="submit" label="登入" class="btn w-full mb-3" />
                        <Button
                            label="忘記密碼?"
                            class="w-full mb-3 border-none bg-none"
                            @click.prevent="mode = 'reset'"
                            severity="secondary"
                        />
                    </div>
                </form>
            </template>

            <!-- 重設密碼表單 -->
            <template v-else>
                <div class="login-form">
                    <div>
                        <label class="block mb-2 text-base font-medium">電子信箱</label>
                        <InputText
                            v-model="email"
                            class="w-full text-base py-3"
                            placeholder="請輸入原來的信箱"
                        />
                    </div>

                    <div class="flex justify-between gap-4">
                        <Button
                            label="取消"
                            class="block mb-2 text-base font-medium flex-1"
                            text
                            severity="danger"
                            @click="mode = 'login'"
                        />
                        <Button label="重設密碼" class="block mb-2 text-base font-medium flex-1" />
                    </div>
                </div>
            </template>
        </div>
    </div>
</template>

<style scope>
    .btn {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px;
        border: none;
        border-radius: 10px;
        font-size: 1.1rem;
        font-weight: 500;
        cursor: pointer;
        transition: transform 0.3s ease;
    }
</style>
