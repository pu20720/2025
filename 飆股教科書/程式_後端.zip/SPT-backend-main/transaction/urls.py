from django.urls import path
from users.views import UserInvestmentView
from .views import UsersPortfolioView, TradeView, TransactionHistoryView, SearchBarView

urlpatterns = [
    path('', UsersPortfolioView.as_view(), name='users_portfolio'),  # 使用者投資組合
    path('trade/', TradeView.as_view(), name='trade'),  # 買賣股票
    path(
        'investment/', UserInvestmentView.as_view(), name='user_investment'
    ),  # 模擬投資總表
    path(
        'history/', TransactionHistoryView.as_view(), name='transaction_history'
    ),  # 交易歷史
    path('search/', SearchBarView.as_view(), name='search_bar'),  # 搜尋股票
]
