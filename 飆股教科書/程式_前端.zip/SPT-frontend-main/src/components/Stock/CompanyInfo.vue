<script setup>
    import { useStockSearch } from '@/stores/stockSearch.js'
    import { ref, watch, computed } from 'vue'
    import { useRoute } from 'vue-router'
    const { getPickedStock, getPickedStockfinancial } = useStockSearch()
    const route = useRoute()
    const companyInfo = ref(null)
    const financialInfo = ref(null)
    const loading = ref(true)
    watch(
        () => route.params.stockCode,
        async (newStockCode) => {
            const companyInfoResult = await getPickedStock(newStockCode)
            const financialResult = await getPickedStockfinancial(newStockCode)
            companyInfo.value = companyInfoResult[0]
            financialInfo.value = financialResult[0]
            loading.value = false
        },
        { immediate: true },
    )

    // 新增這個格式化函式
    /**
     * 格式化數值
     * @param {string} key - 資料的鍵名 (e.g., 'capital', 'revenue')
     * @param {string | number} value - 要格式化的值
     */
    const formatValue = (key, value) => {
        // 定義哪些 key 需要被格式化為數字
        const numericKeys = ['capital', 'roe', 'revenue', 'net_income', 'eps']

        if (numericKeys.includes(key)) {
            const num = parseFloat(value)
            if (!isNaN(num)) {
                // 使用 toLocaleString() 自動加上千分位 (comma)
                return num.toLocaleString()
            }
        }
        return value
    }

    // ===== 用 computed 整理要渲染的欄位 =====
    const companyFields = computed(() =>
        companyInfo.value
            ? [
                  { label: '公司名稱', key: 'name' },
                  { label: '產業別', key: 'industry' },
                  { label: '成立日期', key: 'founded_date' },
                  { label: '上市日期', key: 'listed_date' },
                  { label: '資本額', key: 'capital' },
              ]
            : [],
    )
    const financialFields = computed(() =>
        financialInfo.value
            ? [
                  { label: '股東權益報酬率 (ROE)', key: 'roe' },
                  { label: '營收', key: 'revenue' },
                  { label: '淨利', key: 'net_income' },
                  { label: '每股盈餘 (EPS)', key: 'eps' },
              ]
            : [],
    )
</script>

<template>
    <div class="mt-6 p-4">
        <div v-if="loading" class="text-gray-500 text-lg py-4">載入中...</div>

        <div v-else>
            <h2 class="text-3xl font-bold mb-4 text-gray-800 border-b pb-2">🏢公司簡介</h2>
            <div
                class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4 text-lg mb-4 px-4"
            >
                <div v-for="field in companyFields" :key="field.key" class="detail-item">
                    <span class="font-bold">{{ field.label }}：</span>
                    <span v-if="field.key === 'name'" class="text-xl text-gray-900">{{
                        companyInfo[field.key]
                    }}</span>
                    <span v-else-if="field.key === 'symbol'" class="text-lg font-bold">{{
                        companyInfo[field.key]
                    }}</span>

                    <span v-else>{{ formatValue(field.key, companyInfo[field.key]) }}</span>
                </div>
            </div>
            <h2 class="text-3xl font-bold mb-4 text-gray-800 border-b pb-2">📊主要財務指標</h2>
            <div
                class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4 text-lg mb-4 px-4"
            >
                <div v-for="field in financialFields" :key="field.key" class="detail-item">
                    <strong>{{ field.label }}：</strong>

                    <span>{{ formatValue(field.key, financialInfo[field.key]) }}</span>
                </div>
            </div>
        </div>
    </div>
</template>
