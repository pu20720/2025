import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'
import PrimeVue from 'primevue/config'

import 'primevue/resources/themes/aura-light-green/theme.css'
import 'primeicons/primeicons.css'
import ToastService from 'primevue/toastservice'
import Toast from 'primevue/toast'
import persistedstate from 'pinia-plugin-persistedstate'
import Tooltip from 'primevue/tooltip'

const app = createApp(App)
const pinia = createPinia()

app.use(router)
pinia.use(persistedstate)
app.use(pinia)
app.use(PrimeVue)
app.use(ToastService)
app.directive('tooltip', Tooltip)

app.component('Toast', Toast)
router.isReady().then(() => app.mount('#app'))
