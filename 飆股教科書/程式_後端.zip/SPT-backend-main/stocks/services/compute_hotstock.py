import os
import django
import logging
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Any, List, Optional
from django.db import transaction
import argparse
import sys
from django.db.models import Max

logger = logging.getLogger(__name__)

# ▼▼▼ 1. 強制設定 Python 搜尋路徑 ▼▼▼
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)
# ▲▲▲ 路徑設定結束 ▲▲▲

# === 初始化 Django ===
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

logger = logging.getLogger(__name__)

from stocks.models import Stock, HotStocks  # noqa: E402
from technical_indicators.models import TechnicalIndicator  # noqa: E402
from financial.models import Financial  # noqa: E402

# 嘗試 import Price model
try:
    from stocks_price.models import StockPrices as Price

    HAS_PRICE_MODEL = True
except Exception:
    Price = None
    HAS_PRICE_MODEL = False
    logger.warning(
        '找不到 Price model，將使用 TechnicalIndicator 的最新日期作為基準。'
    )  # <-- 修正提示文字

# 嘗試 import 價格服務函式
try:
    from stocks_price.services.get_stocks_price import get_stocks_prices

    HAS_PRICE_SERVICE = True
except ImportError:
    get_stocks_prices = None
    HAS_PRICE_SERVICE = False
    logger.warning(
        "!!! 找不到 'stocks_price.services.get_stocks_price' 服務函式 !!!"
    )  # <-- 修正提示文字


# ---------- 工具 ---------- (保持不變)
def _q2_decimal(x: Optional[float]) -> Optional[Decimal]:
    if x is None:
        return None
    return Decimal(str(x)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def normalize_min_max(values: List[Decimal]) -> List[Decimal]:
    if not values:
        return []
    mn, mx = min(values), max(values)
    if mn == mx:
        return [Decimal('0.5')] * len(values)
    denom = mx - mn
    return [(v - mn) / denom for v in values]


def is_technical_bearish(tech: TechnicalIndicator) -> bool:
    try:
        osc = float(tech.osc or 0)
        rsi5 = float(tech.rsi_5 or 50)
        k = float(tech.kd_k or 50)
        d = float(tech.kd_d or 50)
        return (osc < 0) and (rsi5 < 50) and (k < d)
    except Exception:
        return False


# ---------- 基本面 (重構版) ---------- (保持不變)
def score_fundamental_for_stock(stock: Stock, as_of_date) -> Dict[str, Any]:
    qrs = Financial.objects.filter(stock_id=stock).order_by('-year', '-quarter')[:8]
    periods = []
    seen = set()
    for f in qrs:
        key = (f.year, f.quarter)
        if key in seen:
            continue
        seen.add(key)
        periods.append(f)
        if len(periods) >= 4:
            break

    score, reasons, strategy_hints = 0, [], set()
    if not periods:
        return {'score': 0, 'reasons': ['查無財報資料'], 'strategy': '資料不足'}

    eps_values = [float(p.eps) for p in periods if p.eps is not None]
    if eps_values:
        latest_eps = eps_values[0]
        eps_growth = (
            all(eps_values[i] > eps_values[i + 1] for i in range(len(eps_values) - 1))
            if len(eps_values) >= 2
            else False
        )
        if eps_growth:
            score += 15
            reasons.append(' 近 4 季 EPS 連續成長')
            strategy_hints.add('成長股')
        elif latest_eps > 2:
            score += 10
            reasons.append(f' 最新 EPS > 2 (達 {latest_eps:.2f})')
            strategy_hints.add('績優股')
        if latest_eps < 0:
            score -= 10
            reasons.append(f'❌ 最新 EPS 為負 (達 {latest_eps:.2f})')
            strategy_hints.add('避開')

    roe_values = [float(p.roe) for p in periods if getattr(p, 'roe', None) is not None]
    if roe_values:
        latest_roe = roe_values[0]
        if latest_roe >= 15:
            score += 15
            reasons.append(f' 最新 ROE > 15% (達 {latest_roe:.2f}%)')
            strategy_hints.add('績優股')
        elif latest_roe >= 10:
            score += 8
            reasons.append(f' 最新 ROE > 10% (達 {latest_roe:.2f}%)')

    revenue_values = [
        float(p.revenue) for p in periods if getattr(p, 'revenue', None) is not None
    ]
    if revenue_values:
        revenue_growth = (
            all(
                revenue_values[i] > revenue_values[i + 1]
                for i in range(len(revenue_values) - 1)
            )
            if len(revenue_values) >= 2
            else False
        )
        if revenue_growth:
            score += 15
            reasons.append(' 近 4 季營收連續成長')
            strategy_hints.add('成長股')
        elif len(revenue_values) >= 2 and revenue_values[0] > revenue_values[1]:
            score += 5
            reasons.append('最新一季營收成長')
        if revenue_values[0] <= 0:
            reasons.append('❌ 最新營收為負或零')

    net_values = [
        float(p.net_income)
        for p in periods
        if getattr(p, 'net_income', None) is not None
    ]
    if net_values and revenue_values and revenue_values[0] != 0:
        latest_net_income, latest_revenue = net_values[0], revenue_values[0]
        net_margin = latest_net_income / latest_revenue
        if net_margin > 0.15:
            score += 10
            reasons.append(f'淨利率 > 15% (達 {net_margin:.1%})')
            strategy_hints.add('高毛利')
        elif net_margin > 0.05:
            score += 5
            reasons.append(f'淨利率 > 5% (達 {net_margin:.1%})')
        if latest_net_income <= 0:
            score -= 10
            reasons.append('❌ 最新淨利為負')
            strategy_hints.add('避開')

    strategy = '建議觀望'
    if score >= 30 and '績優股' in strategy_hints:
        strategy = '基本面強勁，可長期關注'
    elif score >= 20 and '成長股' in strategy_hints:
        strategy = '成長動能強，可列入觀察'
    elif '避開' in strategy_hints:
        strategy = '基本面有疑慮，建議避開'
    if not reasons:
        reasons = ['基本面無明顯亮點']
    return {'score': max(0, min(score, 60)), 'reasons': reasons, 'strategy': strategy}


# ---------- 技術面 (重構版) ---------- (保持不變)
def score_technical_for_stock(
    stock: Stock, tech: TechnicalIndicator, price_close: Optional[Decimal]
) -> Dict[str, Any]:
    score, reasons, strategy_hints = 0, [], set()
    osc = float(getattr(tech, 'osc', 0) or 0)
    if osc > 0:
        score += 8
        reasons.append('MACD 多頭 (OSC > 0)')
        strategy_hints.add('趨勢偏多')
    prev_tech = (
        TechnicalIndicator.objects.filter(stock_id=stock, date__lt=tech.date)
        .order_by('-date')
        .first()
    )
    if prev_tech and getattr(prev_tech, 'osc', None) is not None:
        prev_osc = float(prev_tech.osc)
        if prev_osc < 0 < osc:
            score += 5
            reasons.append('MACD 黃金交叉 (OSC 負轉正)')
            strategy_hints.add('短期轉強')

    ma20 = float(getattr(tech, 'ma_20', 0) or 0)
    ma60 = float(getattr(tech, 'ma_60', 0) or 0)
    if price_close and ma20 and ma60 and price_close > ma20 > ma60:
        score += 10
        reasons.append('強多頭排列 (股價 > 月線 > 季線)')
        strategy_hints.add('趨勢偏多')
    elif price_close and (price_close < ma20 or price_close < ma60):
        reasons.append('股價位於月線或季線之下')
        strategy_hints.add('趨勢偏空')

    rsi5 = float(getattr(tech, 'rsi_5', 50) or 50)
    if rsi5 < 30:
        score += 5
        reasons.append('RSI < 30 (超賣區，留意反彈)')
        strategy_hints.add('留意反彈')
    elif rsi5 > 70:
        score -= 5
        reasons.append('RSI > 70 (超買區，留意修正)')
        strategy_hints.add('留意修正')
    elif rsi5 > 50:
        score += 5
        reasons.append('RSI > 50 (多方動能區)')
        strategy_hints.add('趨勢偏多')

    k = float(getattr(tech, 'kd_k', 50) or 50)
    d = float(getattr(tech, 'kd_d', 50) or 50)
    if k < 20 and d < 20:
        score += 5
        reasons.append('KD < 20 (超賣區，留意反彈)')
        strategy_hints.add('留意反彈')
    elif k > 80 and d > 80:
        score -= 5
        reasons.append('KD > 80 (超買區，留意修正)')
        strategy_hints.add('留意修正')
    elif k > d and k < 80:
        score += 8
        reasons.append('KD 黃金交叉 (K>D)')
        strategy_hints.add('短期轉強')
    elif k < d:
        reasons.append('KD 死亡交叉 (K<D)')

    strategy = '訊號不明顯'
    if '留意反彈' in strategy_hints and '趨勢偏空' not in strategy_hints:
        strategy = '短期超賣，可留意反彈'
    elif '趨勢偏多' in strategy_hints:
        strategy = '短期趨勢偏多'
    elif '短期轉強' in strategy_hints:
        strategy = '出現短期轉強訊號'
    elif '趨勢偏空' in strategy_hints:
        strategy = '短期趨勢偏空'
    if not reasons:
        reasons = ['技術面無明顯訊號']
    return {'score': max(0, min(score, 40)), 'reasons': reasons, 'strategy': strategy}


# ---------- 主流程 (重構版 + 高效能版 + 自動最新日期) ----------
def compute_hotstock(date_arg=None, top_n=20, dry_run=False):
    # ▼▼▼ 修改 base_date 獲取邏輯：改回自動查找最新日期 ▼▼▼
    if date_arg:
        base_date = date_arg
        print(f'ℹ️ 使用者指定日期: {base_date}')
    else:
        # 如果使用者沒有指定 --date，自動查找資料庫中的最新日期
        base_date = None
        latest_date_obj = None  # 用來存儲找到的日期物件

        # 1. 優先嘗試從 Price model 獲取最新日期
        if HAS_PRICE_MODEL and Price:
            try:
                latest_date_obj = Price.objects.aggregate(Max('price_date'))[
                    'price_date__max'
                ]
                if latest_date_obj:
                    print(f'ℹ️ Price Model 最新日期為: {latest_date_obj.isoformat()}')
                else:
                    logger.warning('Price Model 中沒有資料。')
            except Exception as e:
                logger.warning(f'從 Price model 獲取最新日期失敗: {e}')

        # 2. 如果 Price model 失敗或沒有資料，才使用 TechnicalIndicator
        if latest_date_obj is None:
            try:
                latest_date_obj = TechnicalIndicator.objects.aggregate(Max('date'))[
                    'date__max'
                ]
                if latest_date_obj:
                    print(
                        f'ℹ️ TechnicalIndicator Model 最新日期為: {latest_date_obj.isoformat()}'
                    )
                else:
                    logger.error(
                        'Price 和 TechnicalIndicator Model 中都沒有任何日期資料！'
                    )  # 改成 Error
            except Exception as e:
                logger.warning(f'從 TechnicalIndicator 獲取最新日期失敗: {e}')

        # 將找到的日期物件轉換成字串
        if latest_date_obj:
            base_date = latest_date_obj.isoformat()

    if base_date is None:
        print('❌ 找不到可用的基準日期，請檢查 Price 或 TechnicalIndicator 資料庫。')
        return
    # ▲▲▲ base_date 邏輯修改結束 ▲▲▲

    print(f'📅 使用基準日期 {base_date} 計算熱門股票排行 (top {top_n})')

    stocks_list = Stock.objects.all()
    stock_map = {s.id: s for s in stocks_list}

    volumes: Dict[int, Decimal] = {}
    amounts: Dict[int, Decimal] = {}
    ratios: Dict[int, Decimal] = {}
    closes: Dict[int, Decimal] = {}

    service_succeeded = False

    # ▼▼▼ 資料獲取邏輯 (使用 base_date 抓取 Price 資料) ▼▼▼
    if HAS_PRICE_SERVICE and get_stocks_prices:
        print(
            f"ℹ️ 正在使用 'get_stocks_prices' 服務函式獲取 {base_date} 的股價/成交量資料..."
        )
        try:
            price_data_list = get_stocks_prices(date=base_date)
            for p_data in price_data_list:
                sid = None
                volume = None
                close_price = None
                if isinstance(p_data, dict):
                    sid = p_data.get('stock_id')
                    volume = p_data.get('volume')
                    close_price = p_data.get('close_price')
                elif hasattr(p_data, 'stock_id'):
                    sid = p_data.stock_id
                    volume = getattr(p_data, 'volume', None)
                    close_price = getattr(p_data, 'close_price', None)
                elif hasattr(p_data, 'stock') and hasattr(p_data.stock, 'id'):
                    sid = p_data.stock.id
                    volume = getattr(p_data, 'volume', None)
                    close_price = getattr(p_data, 'close_price', None)
                stock_obj = stock_map.get(sid)
                if stock_obj is None:
                    continue
                vol = Decimal(volume or 0)
                close = Decimal(close_price or 0)
                amount = vol * close
                outstanding_shares = Decimal(
                    getattr(stock_obj, 'outstanding_shares', 0) or 0
                )
                ratio = Decimal(0)
                if outstanding_shares > 0:
                    ratio = (vol * 1000) / outstanding_shares
                volumes[sid] = vol
                closes[sid] = close
                amounts[sid] = amount
                ratios[sid] = ratio
            print(f"✅ 'get_stocks_prices' 服務函式成功獲取 {len(volumes)} 筆資料。")
            service_succeeded = True
        except Exception as e:
            logger.error(f'❌ 呼叫 get_stocks_prices({base_date}) 失敗: {e}')
            logger.error('將退回 (fallback) 使用舊的資料庫查詢邏輯...')

    if not service_succeeded:
        logger.warning(
            f'正在使用舊的資料庫查詢邏輯 (Fallback) 獲取 {base_date} 的股價/成交量資料...'
        )
        if HAS_PRICE_MODEL and Price:
            price_qs = Price.objects.filter(price_date=base_date).select_related(
                'stock'
            )
            for p in price_qs:
                stock_obj = stock_map.get(p.stock_id)
                if stock_obj is None:
                    continue
                sid = p.stock_id
                vol = Decimal(p.volume or 0)
                close = Decimal(p.close_price or 0)
                amount = vol * close
                outstanding_shares = Decimal(
                    getattr(stock_obj, 'outstanding_shares', 0) or 0
                )
                ratio = Decimal(0)
                if outstanding_shares > 0:
                    ratio = (vol * 1000) / outstanding_shares
                volumes[sid] = vol
                closes[sid] = close
                amounts[sid] = amount
                ratios[sid] = ratio
        else:
            logger.warning(
                f'沒有 Price model 可用來 fallback 獲取 {base_date} 的資料。熱門度可能不準確。'
            )
    # ▲▲▲ 資料獲取邏輯結束 ▲▲▲

    # ▼▼▼ 熱門度計算 (此部分不變) ▼▼▼
    norm_amount = normalize_min_max(list(amounts.values()))
    norm_map_amount = {sid: norm_amount[i] for i, sid in enumerate(amounts.keys())}
    norm_volume = normalize_min_max(list(volumes.values()))
    norm_map_volume = {sid: norm_volume[i] for i, sid in enumerate(volumes.keys())}
    norm_ratio = normalize_min_max(list(ratios.values()))
    norm_map_ratio = {sid: norm_ratio[i] for i, sid in enumerate(ratios.keys())}
    W_AMOUNT = Decimal('0.4')
    W_RATIO = Decimal('0.4')
    W_VOLUME = Decimal('0.2')
    # ▲▲▲ 熱門度計算結束 ▲▲▲

    # ▼▼▼ 【高效能修改】 預載技術指標 (使用 base_date) ▼▼▼
    print(f'ℹ️ 正在一次性預先載入所有 <= {base_date} 的最新技術指標...')
    all_techs_qs = TechnicalIndicator.objects.filter(date__lte=base_date).order_by(
        'stock_id', '-date'
    )

    tech_map: Dict[int, TechnicalIndicator] = {}
    for tech in all_techs_qs:
        if tech.stock_id not in tech_map:
            tech_map[tech.stock_id] = tech
    print(f' 成功載入 {len(tech_map)} 檔股票的最新技術指標。')
    # ▲▲▲ 【修改結束】 ▲▲▲

    results = []
    for stock in stocks_list:
        sid = stock.id

        # 計算熱門度
        score_amount = norm_map_amount.get(sid, Decimal(0))
        score_volume = norm_map_volume.get(sid, Decimal(0))
        score_ratio = norm_map_ratio.get(sid, Decimal(0))
        hot_score_decimal = (
            (score_amount * W_AMOUNT)
            + (score_ratio * W_RATIO)
            + (score_volume * W_VOLUME)
        )
        hot_score = float(hot_score_decimal * 10000)

        # 從預載的字典獲取技術指標
        tech = tech_map.get(sid)
        price_close = closes.get(sid)

        # 獲取評分結果 (dict)
        fund_data = score_fundamental_for_stock(stock, base_date)

        tech_data = {'score': 0, 'reasons': ['查無技術指標'], 'strategy': '資料不足'}
        tech_bearish = False
        if tech:
            tech_data = score_technical_for_stock(stock, tech, price_close)
            tech_bearish = is_technical_bearish(tech)
            if tech.date.isoformat() != base_date:
                logger.debug(
                    f'[{stock.symbol}] 使用的技術指標日期為: {tech.date.isoformat()} (基準日: {base_date})'
                )

        total_score = fund_data['score'] + tech_data['score']

        # 決定最終策略
        strategy = f'基本面: {fund_data["strategy"]} | 技術面: {tech_data["strategy"]}'
        if fund_data['score'] > 30 and tech_data['score'] > 20:
            strategy = '基本面與技術面雙強，可積極關注'

        # 警告
        warning = (score_ratio > Decimal('0.9') or tech_bearish) and hot_score > 3000

        results.append(
            {
                'stock': stock,
                'hot_score': float(hot_score),
                'fund_score': fund_data['score'],
                'tech_score': tech_data['score'],
                'total_score': total_score,
                'warning': warning,
                'fund_reasons': fund_data['reasons'],
                'tech_reasons': tech_data['reasons'],
                'strategy': strategy,
            }
        )

    results.sort(key=lambda x: x['hot_score'], reverse=True)
    top_results = results[:top_n]

    # print("\n🔥 熱門股票排行 (依照 綜合熱門度) 🔥")
    # print("熱門度 = 40%*成交金額 + 40%*周轉率 + 20%*成交量")
    report_strings_to_save = []
    # # 輸出 (此部分不變)
    for i, r in enumerate(top_results, 1):
        #     warn = "⚠️" if r["warning"] else ""
        #     print("\n" + "="*50)
        #     print(f"#{i}. {r['stock'].symbol} {r['stock'].name} {warn}")
        #     print(f"  - 熱門度: {r['hot_score']:.1f} | 總分: {r['total_score']} (基本面: {r['fund_score']} + 技術面: {r['tech_score']})")
        #     print(f"  - 💡 投資策略: {r['strategy']}")
        #     print(f"  - 📊 基本面理由:")
        #     for reason in r['fund_reasons']: print(f"    - {reason}")
        #     print(f"  - 📈 技術面理由:")
        #     for reason in r['tech_reasons']: print(f"    - {reason}")
        report_lines = []
        report_lines.append(
            f'熱門度: {r["hot_score"]:.1f} | 總分: {r["total_score"]} (基本面: {r["fund_score"]} + 技術面: {r["tech_score"]})'
        )
        report_lines.append(f'投資策略: {r["strategy"]}')
        report_lines.append('\n基本面理由:')
        for reason in r['fund_reasons']:
            report_lines.append(f'  - {reason}')
        report_lines.append('\n技術面理由:')
        for reason in r['tech_reasons']:
            report_lines.append(f'  - {reason}')
        report_text = '\n'.join(report_lines)
        report_strings_to_save.append(report_text)

    if dry_run:
        print('\n' + '=' * 50)
        print('\n(dry-run，不寫入資料庫)')
        return

    # 寫入資料庫 (使用 base_date)
    with transaction.atomic():
        HotStocks.objects.filter(date=base_date).delete()
        for rank, r in enumerate(top_results, start=1):
            HotStocks.objects.create(
                stock=r['stock'],
                rank=rank,
                date=base_date,
                reason=report_strings_to_save[rank - 1],
            )

    # print(f"\n✅ 已寫入 {len(top_results)} 筆 HotStocks (date={base_date})")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='計算熱門股票排行')
    # ▼▼▼ 修改 help 文字 ▼▼▼
    parser.add_argument(
        '--date',
        type=str,
        default=None,
        help='指定日期 YYYY-MM-DD (若不指定，預設自動查找資料庫最新日期)',
    )
    parser.add_argument(
        '--top', type=int, default=10, help='取前 N 名'
    )  # <-- 這裡保留 default=10，你可以改成 50
    parser.add_argument('--dry-run', action='store_true', help='只輸出不寫入資料庫')
    args = parser.parse_args()

    compute_hotstock(date_arg=args.date, top_n=args.top, dry_run=args.dry_run)
