import requests
import logging
from datetime import datetime, timedelta
from stocks.models import Stock
from stocks_price.models import StockPrices

logger = logging.getLogger(__name__)


"""
匯入所有歷史價格資料
"""


def import_all_history_prices(symbol: str) -> dict:
    # 有沒抓完可以用這個跳過前面已抓過的資料，改symbol為你要跳過的股票代號
    # if symbol < "3042":
    #     logger.warning(f"[跳過] {symbol}")
    #     return {
    #         "status": "skipped",
    #         "symbol": symbol,
    #         "message": "已手動設定略過此股票"
    #     }
    try:
        stock = Stock.objects.get(symbol=symbol)
        start_date = stock.listed_date.replace(day=1)
        today = datetime.today().date()
        success_total = 0
        error_months = []

        while start_date <= today:
            yyyymm = start_date.strftime('%Y%m')
            date_param = f'{yyyymm}01'
            url = f'https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date={date_param}&stockNo={symbol}'

            try:
                response = requests.get(url)
                response.raise_for_status()
                result = response.json()

                if result.get('stat') != 'OK':
                    error_months.append(yyyymm)
                    start_date += timedelta(days=32)
                    start_date = start_date.replace(day=1)
                    continue

                previous_close = None
                for row in result['data']:
                    raw_date = row[0].strip().replace('/', '-')
                    year, month, day = map(int, raw_date.split('-'))
                    year += 1911
                    price_date = datetime(year, month, day).date()

                    if StockPrices.objects.filter(
                        stock=stock, price_date=price_date
                    ).exists():
                        continue
                    try:
                        open_price = float(row[3].replace(',', ''))
                        high_price = float(row[4].replace(',', ''))
                        low_price = float(row[5].replace(',', ''))
                        close_price = float(row[6].replace(',', ''))
                        volume = int(row[1].replace(',', ''))
                        if previous_close:
                            change_percent = round(
                                ((close_price - previous_close) / previous_close) * 100,
                                2,
                            )
                        else:
                            change_percent = 0.0

                        previous_close = close_price
                    except Exception as e:
                        logger.warning(f'[StockPrice] 解析失敗 {symbol} {row} -> {e}')
                        continue

                    _, created = StockPrices.objects.update_or_create(
                        stock=stock,
                        price_date=price_date,
                        defaults={
                            'open_price': open_price,
                            'high_price': high_price,
                            'low_price': low_price,
                            'close_price': close_price,
                            'volume': volume,
                            'change_percent': change_percent,
                        },
                    )
                    if created:
                        success_total += 1

            except Exception as e:
                logger.warning(f'[StockPrice] API錯誤 {symbol} {yyyymm} => {e}')
                error_months.append(yyyymm)

            start_date += timedelta(days=32)
            start_date = start_date.replace(day=1)

        return {
            'status': 'done',
            'symbol': symbol,
            'created': success_total,
            'errors': error_months,
        }

    except Stock.DoesNotExist:
        return {'status': 'error', 'message': f'找不到代號為 {symbol} 的股票'}
