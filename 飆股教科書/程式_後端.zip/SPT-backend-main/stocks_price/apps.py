from django.apps import AppConfig


class StocksPriceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stocks_price'
