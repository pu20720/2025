<script setup>
    import { ref, computed } from 'vue'
    import { useRouter } from 'vue-router'

    const router = useRouter()
    const selectedPeriod = ref('日')

    function selectPeriod(period) {
        selectedPeriod.value = period
    }
    const stock = ref({
        code: '2330',
        name: '台積電',
        price: 785,
        change: 10,
        changePercent: 1.29,
        open: 780,
        high: 790,
        low: 775,
        prevClose: 775,
        volume: 32145,
        turnover: 252.6,
        marketCap: 20345,
        avgPrice: 782,
        peRatio: 22.5,
        pbRatio: 4.5,
        grossMargin: 51.2,
        operatingMargin: 43.1,
        netMargin: 38.5,
        eps: 32.1,
        recentEPS: 1.54,
        bookValue: 13.01,
        dividend: 9.5,
        swing: 1.94,
        turnoverRate: 0.78,
        totalShares: 259,
        limitUp: 852,
        limitDown: 698,
        high52W: 815,
        low52W: 485,
        bidVolume: 13400,
        askVolume: 14500,
        seasonAvgVolume: 28000,
        description: '台積電為全球領先的半導體製造公司，專注於晶圓代工業務，總部位於台灣新竹。',
    })

    const lastUpdated = new Date().toLocaleString()

    const priceClass = computed(() =>
        stock.value.change > 0
            ? 'text-red-600'
            : stock.value.change < 0
              ? 'text-green-600'
              : 'text-gray-600',
    )

    function goBack() {
        router.push('/watchlist')
    }
</script>

<template>
    <div class="max-w-6xl mx-auto p-6 bg-white shadow-lg rounded-xl">
        <!-- 標題 -->
        <div class="flex items-center justify-between mb-6">
            <div>
                <h1 class="text-5xl font-bold text-violet-600">
                    {{ stock.name }} ({{ stock.code }})
                </h1>

                <!-- 新增的股價資訊 -->
                <div class="mt-1 flex items-baseline space-x-3">
                    <span :class="['text-4xl font-bold', priceClass]">{{ stock.price }}</span>
                    <span :class="['text-2xl', priceClass]">{{ stock.change }}</span>
                    <span :class="['text-2xl', priceClass]">{{ stock.changePercent }}%</span>
                </div>

                <p class="text-gray-500 text-sm mt-1">更新時間：{{ lastUpdated }}</p>
            </div>

            <button @click="goBack" class="text-violet-600 hover:text-violet-800 font-medium">
                ⬅ 回自選股
            </button>
        </div>
        <!-- 技術分析輪播器 -->
        <div class="bg-gray-50 border border-gray-200 rounded-xl mb-6 p-4 relative">
            <!-- 輪播按鈕：均分且字大，方框 -->
            <div class="flex mb-4 text-lg font-semibold text-violet-700">
                <button
                    @click="selectPeriod('日')"
                    :class="[
                        'flex-1 py-3 mx-1 border border-violet-500',
                        selectedPeriod === '日'
                            ? 'bg-violet-600 text-white'
                            : 'hover:bg-violet-100',
                    ]"
                >
                    日
                </button>
                <button
                    @click="selectPeriod('月')"
                    :class="[
                        'flex-1 py-3 mx-1 border border-violet-500',
                        selectedPeriod === '月'
                            ? 'bg-violet-600 text-white'
                            : 'hover:bg-violet-100',
                    ]"
                >
                    月
                </button>
                <button
                    @click="selectPeriod('年')"
                    :class="[
                        'flex-1 py-3 mx-1 border border-violet-500',
                        selectedPeriod === '年'
                            ? 'bg-violet-600 text-white'
                            : 'hover:bg-violet-100',
                    ]"
                >
                    年
                </button>
            </div>

            <!-- 圖片區塊 -->
            <div class="flex justify-center items-center bg-white border rounded-xl h-64">
                <img
                    src="../assets/技術分析圖表.png"
                    alt="技術圖表"
                    class="max-h-full object-contain"
                />
            </div>

            <!-- 左下角下拉選單 -->
            <div class="absolute bottom-4 left-4">
                <label class="text-sm text-gray-600 mr-2">指標：</label>
                <select class="border rounded px-2 py-1 text-sm">
                    <option>MA</option>
                    <option>BBAND</option>
                    <option>CDP</option>
                    <option>KD</option>
                    <option>VOL</option>
                    <option>RSI</option>
                </select>
            </div>
        </div>

        <!-- 報價區塊 -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 text-sm mb-6">
            <div><strong>最新價：</strong> {{ stock.price }} 元</div>
            <div :class="priceClass"><strong>漲跌：</strong> {{ stock.change }} 元</div>
            <div :class="priceClass"><strong>漲跌幅：</strong> {{ stock.changePercent }}%</div>
            <div><strong>今開：</strong> {{ stock.open }}</div>
            <div><strong>最高：</strong> {{ stock.high }}</div>
            <div><strong>最低：</strong> {{ stock.low }}</div>
            <div><strong>昨收：</strong> {{ stock.prevClose }}</div>
            <div><strong>成交量：</strong> {{ stock.volume }} 張</div>
            <div><strong>成交金額：</strong> {{ stock.turnover }} 億</div>
            <div><strong>總市值：</strong> {{ stock.marketCap }} 億</div>
            <div><strong>均價：</strong> {{ stock.avgPrice }}</div>
            <div><strong>本益比：</strong> {{ stock.peRatio }}</div>
            <div><strong>本淨比：</strong> {{ stock.pbRatio }}</div>
            <div><strong>毛利率：</strong> {{ stock.grossMargin }}%</div>
            <div><strong>營益率：</strong> {{ stock.operatingMargin }}%</div>
            <div><strong>淨利率：</strong> {{ stock.netMargin }}%</div>
            <div><strong>EPS：</strong> {{ stock.eps }}</div>
            <div><strong>近EPS：</strong> {{ stock.recentEPS }}</div>
            <div><strong>每股淨值：</strong> {{ stock.bookValue }}</div>
            <div><strong>年股利：</strong> {{ stock.dividend }}</div>
            <div><strong>振幅：</strong> {{ stock.swing }}%</div>
            <div><strong>週轉率：</strong> {{ stock.turnoverRate }}%</div>
            <div><strong>發行股：</strong> {{ stock.totalShares }} 億</div>
            <div><strong>漲停：</strong> {{ stock.limitUp }}</div>
            <div><strong>跌停：</strong> {{ stock.limitDown }}</div>
            <div><strong>52W高：</strong> {{ stock.high52W }}</div>
            <div><strong>52W低：</strong> {{ stock.low52W }}</div>
            <div><strong>內盤量：</strong> {{ stock.bidVolume }}</div>
            <div><strong>外盤量：</strong> {{ stock.askVolume }}</div>
        </div>

        <!-- 公司簡介 -->
        <div class="mt-6">
            <h2 class="text-xl font-semibold mb-2">公司簡介</h2>
            <p class="text-gray-700 leading-relaxed">
                {{ stock.description || '尚未提供公司簡介資料。' }}
            </p>
        </div>
    </div>
</template>
