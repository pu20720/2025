using UnityEngine;

[System.Serializable]
public class SpeakerIconEntry
{
    public string speakerKey;
    public Sprite speakerIcon;
}