public enum CardRarity { White, Green, Blue, Gold }
public enum ItemType { Card, Equipment, Consumable, Special }
public enum EquipmentSlot { None, Helmet, Armor, Gauntlets, LegArmor }
public enum ArmorPart { Helmet, Armor, Gauntlets, LegArmor }
public enum DamageType { Normal, Pierce, True }
public enum StatusType { Bleed, Poison, Corruption, Stun, Freeze }
public enum CardType { Armor, Weapon, Magic, Conditional, Buff, Debuff, Attack }
public enum TargetCategory { Player, Enemy, PlayerArmorSlot, Special, EnemyArmorSlot, CardInHand }
public enum ConditionalTriggerType { None, OnPlayerAttacked }
public enum QuestRank { D, C, B, A, S }