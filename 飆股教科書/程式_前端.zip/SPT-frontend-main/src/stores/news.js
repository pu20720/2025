import { ref } from 'vue'
import api from '@/api/axios'
import { useToast } from 'primevue/usetoast'

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export function useNews() {
    const newsList = ref([])
    const loading = ref(false)
    const toast = useToast()

    const API_ENDPOINT = 'news/'

    //  更新新聞資料（POST）
    const updateNews = async () => {
        try {
            await api.post(API_ENDPOINT)
            return true
        } catch (err) {
            return false
        }
    }

    //  取得新聞列表（GET）
    const fetchNews = async () => {
        const maxRetries = 3
        const retryDelay = 2000

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const res = await api.get(API_ENDPOINT)
                newsList.value = res.data.map((item) => ({
                    text: item.title,
                    link: item.url,
                    image: item.image,
                    published_at: item.published_at,
                }))
                return true
            } catch (err) {
                if (attempt === maxRetries) {
                    toast.add({
                        severity: 'error',
                        summary: '無法載入新聞資料',
                        detail: err.message,
                        life: 2500,
                    })
                    return false
                }
                await sleep(retryDelay)
            }
        }
    }

    const loadNews = async () => {
        loading.value = true
        await fetchNews()
        loading.value = false
    }

    return {
        newsList,
        loading,
        loadNews,
    }
}
