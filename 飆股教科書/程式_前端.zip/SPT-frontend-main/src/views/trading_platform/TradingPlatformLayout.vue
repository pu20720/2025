<script setup>
    import { ref, onMounted, computed } from 'vue'
    import '@/assets/tradingcss.css'
    import { useUserStore } from '@/stores/user.js'

    const userStore = useUserStore()

    const searchQuery = ref('')
    const portfolioValue = ref(0)
    const user = ref({ balance: 0 })
    const totalReturn = ref(0)

    const totalAssets = computed(() => {
        return user.value.balance + portfolioValue.value
    })

    onMounted(async () => {
        const data = await userStore.getUserInvestments()
        if (data) {
            user.value.balance = data.available_funds
            portfolioValue.value = data.portfolio_value
            totalReturn.value = data.total_return_rate
        }
    })

    const menuItems = ref([
        { id: 'trade', name: '股票交易', icon: 'fas fa-exchange-alt' },
        { id: 'portfolio', name: '投資組合', icon: 'fas fa-briefcase' },
        { id: 'history', name: '交易歷史', icon: 'fas fa-history' },
    ])
</script>

<template>
    <div class="app-container">
        <div class="sidebar">
            <div class="logo">
                <h1><i class="fas fa-chart-line"></i> 瘋之股交易所</h1>
            </div>
            <nav class="nav-menu">
                <router-link
                    v-for="item in menuItems"
                    :key="item.id"
                    :to="item.id ? `/trading_platform/${item.id}` : '/trading_platform/dashboard'"
                    class="nav-item text-black"
                    exact-active-class="active"
                >
                    <i :class="item.icon"></i>
                    {{ item.name }}
                </router-link>
            </nav>
        </div>

        <div class="main-content">
            <div class="grid grid-2 mb-5">
                <div class="stat-card">
                    <div class="stat-value">NT${{ totalAssets.toLocaleString() }}</div>
                    <div class="stat-label">總資產</div>
                </div>
                <div class="stat-card">
                    <div
                        class="stat-value"
                        :class="totalReturn > 0 ? 'up' : totalReturn < 0 ? 'down' : 'zero'"
                    >
                        {{ totalReturn > 0 ? '+' : '' }}{{ totalReturn.toFixed(2) }}%
                    </div>
                    <div class="stat-label">總報酬率</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">NT${{ user.balance.toLocaleString() }}</div>
                    <div class="stat-label">可用資金</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">NT${{ portfolioValue.toLocaleString() }}</div>
                    <div class="stat-label">持股價值</div>
                </div>
            </div>

            <router-view />
        </div>
    </div>
</template>
