from users.models import User
from stocks.models import Stock
from django.db import transaction
from rest_framework.exceptions import ValidationError
from transaction.models import Transaction, Portfolio


@transaction.atomic
def execute_trade(user: User, stock: Stock, trade_type: str, shares: int):
    """執行買入或賣出交易"""
    # 取得或建立投資組合
    portfolio, _ = Portfolio.objects.get_or_create(user=user, stock=stock)

    price = portfolio.get_latest_price()  # 取得市價(最新價格)

    amount = price * shares

    if trade_type == 'BUY':
        # 檢查資金是否足夠
        if user.available_funds < amount:
            raise ValidationError('可用資金不足')

        # 更新 Portfolio 平均成本與持股
        total_cost = portfolio.average_price * portfolio.shares + amount
        new_shares = portfolio.shares + shares
        portfolio.average_price = total_cost / new_shares
        portfolio.shares = new_shares
        portfolio.current_price = price
        portfolio.update_metrics()  # 已有 portfolio.save() 在裡面

        # 扣除使用者資金
        user.available_funds -= amount
        user.save()

    elif trade_type == 'SELL':
        if portfolio.shares < shares:
            raise ValidationError('持股不足，無法賣出')

        # 減少持股
        portfolio.shares -= shares
        portfolio.current_price = price
        portfolio.update_metrics()

        # 若賣光該股票，刪除紀錄
        if portfolio.shares == 0:
            portfolio.delete()

        # 增加使用者資金
        user.available_funds += amount
        user.save()
    else:
        raise ValueError('交易類型錯誤，必須是 BUY 或 SELL')

    # 建立交易紀錄
    Transaction.objects.create(
        user=user,
        stock=stock,
        transaction_type=trade_type,
        shares=shares,
        price=price,
        amount=amount,
    )

    return {
        'status': 'success',
        'message': f'{trade_type} 成功',
        '可用資金': user.available_funds,
    }
