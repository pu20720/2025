<script setup>
    import { ref } from 'vue'

    const notifications = ref([
        { text: '您的訂單已出貨', link: '/orders/1' },
        { text: '您有新的訊息', link: '/messages' },
    ])

    const op = ref()
    const toggleDropdown = (event) => {
        op.value.toggle(event)
    }
</script>

<template>
    <!-- <div> -->
    <Button icon="pi pi-bell" text class="text-sm text-white rounded-lg" @click="toggleDropdown" />
    <OverlayPanel ref="op" class="w-64">
        <p class="mb-2 text-lg">您有 {{ notifications.length }} 則新通知</p>
        <ul class="space-y-1 text-blue-600">
            <li v-for="(msg, index) in notifications" :key="index">
                <router-link :to="msg.link" class="text-lg hover:underline">{{
                    msg.text
                }}</router-link>
            </li>
        </ul>
    </OverlayPanel>

    <!-- </div> -->
</template>
