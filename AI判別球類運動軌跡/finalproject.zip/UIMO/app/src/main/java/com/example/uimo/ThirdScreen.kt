package com.example.uimo.ui.screens

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.uimo.ThirdViewModel
import com.example.uimo.UiState
import com.example.uimo.ui.theme.UIMOTheme
import android.util.Log
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThirdScreen(
    navController: NavHostController,
    videoUri: Uri,
    cornersJson: String, // AppNavigationから座標JSONを受け取る
    viewModel: ThirdViewModel = viewModel()
) {
    val context = LocalContext.current
    val state = viewModel.uiState.value

    LaunchedEffect(key1 = Unit) {
        // ViewModelの分析処理を開始する
        viewModel.startProcessing(context, videoUri, cornersJson)
    }



    Log.d("StateCheck", "ThirdScreen is in state: $state")


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("分析画面") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "戻る")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {



            Spacer(modifier = Modifier.height(32.dp))

            // UIの状態に応じた表示
            when (state) {
                is UiState.Idle -> {
                    Button(
                        onClick = {
                            Log.d("ButtonCheck", "分析を開始ボタンが押されました！")
                            viewModel.startProcessing(context, videoUri, cornersJson) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("分析を開始", fontSize = 20.sp)
                    }
                }
                is UiState.Uploading -> {
                    CircularProgressIndicator()
                    Text("動画をアップロード中...", modifier = Modifier.padding(top = 16.dp))
                }
                is UiState.Processing -> {
                    CircularProgressIndicator()
                    Text("サーバーで分析中です...\n完了まで数分かかることがあります。",
                        textAlign = TextAlign.Center, modifier = Modifier.padding(top = 16.dp))
                }
                is UiState.Complete -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("分析が完了しました！", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                // URLをエンコードしてFourthScreenへ渡す
                                val encodedUrl = Uri.encode(state.resultVideoUrl)
                                navController.navigate("fourth/$encodedUrl")
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("プレビューを見る", fontSize = 20.sp)
                        }
                    }
                }
                is UiState.Error -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("エラーが発生しました", color = MaterialTheme.colorScheme.error)
                        Text(state.message, color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { viewModel.startProcessing(context, videoUri, cornersJson) }) {
                            Text("リトライ")
                        }
                    }
                }
            }
        }
    }
}
