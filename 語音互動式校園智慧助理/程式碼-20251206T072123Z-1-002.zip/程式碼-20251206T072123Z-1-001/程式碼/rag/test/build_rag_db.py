import os
import pandas as pd
from langchain_text_splitters import RecursiveCharacterTextSplitter 
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings


# ======== 設定區 ========
DATA_DIR = r"F:\test\rag\test\data"          # 你的資料夾路徑（放爬蟲抓下來的csv或txt）
CHROMA_DIR = r"F:\test\rag\test\chroma_db"   #  向量資料庫儲存位置
CHUNK_SIZE = 400             # 每段文字最大長度
CHUNK_OVERLAP = 0           # 段落重疊長度

HUGGINGFACE_EMBEDDING_MODEL = "BAAI/bge-small-zh-v1.5"
# =========================

def load_text_from_file(file_path):
    """讀取單一檔案（支援 csv 與 txt）"""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".csv":
        df = pd.read_csv(file_path)
        # 確保有必要欄位
        required_cols = ["name", "instructor", "time", "description", "grading", "url"]
        for c in required_cols:
            if c not in df.columns:
                print(f"⚠️ 檔案 {file_path} 缺少欄位 {c}，已略過。")
                return []
        docs = []
        for _, row in df.iterrows():
            content = f"""
課程名稱：{row['name']}
授課教師：{row['instructor']}
時間地點：{row['time']}
課程簡介：{row['description']}
評分方式：{row['grading']}
課程連結：{row['url']}
"""
            docs.append(content)
        return docs
    elif ext == ".txt":
        with open(file_path, "r", encoding="utf-8") as f:
            return [f.read()]
    else:
        print(f" 不支援的檔案格式：{file_path}")
        return []

def build_chroma():
    """主流程：讀取資料 → 分段 → 建立 Chroma 資料庫"""
    all_docs = []
    metadatas = []

    # ===  讀取資料夾中所有檔案 ===
    for file in os.listdir(DATA_DIR):
        path = os.path.join(DATA_DIR, file)
        if os.path.isfile(path):
            texts = load_text_from_file(path)
            # 處理 metadatas，確保每個文件都有來源資訊
            for t in texts:
                all_docs.append(t)
                metadatas.append({"source": file})

    print(f" 共讀取 {len(all_docs)} 筆資料，開始分段...")

    # ===  分段 ===
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n", "。", "！", "？", "；"]
    )

    split_texts = []
    split_meta = []
    for i, doc in enumerate(all_docs):
        chunks = splitter.split_text(doc)
        split_texts.extend(chunks)
        # 確保 metadata 與分段後的 texts 數量一致
        split_meta.extend([metadatas[i]] * len(chunks))

    print(f" 已分成 {len(split_texts)} 段文字")

    # ===  建立 Chroma 向量資料庫 ===
    # 使用 HuggingFace BGE 模型
    embedding = HuggingFaceEmbeddings(
        model_name=HUGGINGFACE_EMBEDDING_MODEL,
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True},
    )

    vectorstore = Chroma.from_texts(
        texts=split_texts,
        embedding=embedding,
        metadatas=split_meta,
        persist_directory=CHROMA_DIR,
        collection_name="courses_rag",   # 隨便取，之後要用同一個名字
    )
   


    print(f" 向量資料庫建立完成！已儲存於 {CHROMA_DIR}")

    return vectorstore

def query_chroma(vectorstore):
    """查詢範例"""
    print("\n 輸入想查詢的問題（輸入 exit 結束）")
    while True:
        q = input("問題：")
        if q.lower() == "exit":
            break
        # similarity_search 只進行向量相似度搜尋，無需 LLM
        results = vectorstore.similarity_search(q, k=3) 
        for i, r in enumerate(results):
            print(f"\n--- 結果 {i+1} ---")
            print(r.page_content)
            print("來源：", r.metadata["source"])

if __name__ == "__main__":
    # 若資料夾不存在就建立
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # 建立資料庫
    vectorstore = build_chroma()

    # 查詢範例
    query_chroma(vectorstore)