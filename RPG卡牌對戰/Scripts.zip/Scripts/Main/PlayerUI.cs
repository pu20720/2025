// 檔案路徑: Assets/Scripts/UI/PlayerUI.cs
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class PlayerUI : MonoBehaviour
{
    [Header("Player Info")]
    [SerializeField] private TMP_Text playerNameText;
    [SerializeField] private TMP_Text playerHPText;

    [Header("Armor Slots (UI Targets)")]
    [SerializeField] private Image helmetIcon;
    [SerializeField] private TMP_Text helmetArmorText;
    [SerializeField] private Image armorIcon;
    [SerializeField] private TMP_Text armorArmorText;
    [SerializeField] private Image gauntletsIcon;
    [SerializeField] private TMP_Text gauntletsArmorText;
    [SerializeField] private Image legArmorIcon;
    [SerializeField] private TMP_Text legArmorArmorText;

    [Header("Status Effects (General)")]
    [SerializeField] private Transform statusEffectParent;

    [Tooltip("BleedIcon_Prefab")]
    [SerializeField] private GameObject bleedStatusIconPrefab;

    [Tooltip("OverloadIcon_Prefab")]
    [SerializeField] private GameObject overloadStatusIconPrefab;

    [Tooltip("StunIcon_Prefab")]
    [SerializeField] private GameObject stunStatusIconPrefab;

    [Tooltip("PauseIcon_Prefab")]
    [SerializeField] private GameObject pauseStatusIconPrefab;

    // ▼▼▼ 【新增】腐化專用覆蓋層 Prefab ▼▼▼
    [Header("Corruption Specific")]
    [Tooltip("請製作一個包含 Image(背景) 和 TMP_Text(數字) 的 Prefab")]
    [SerializeField] private GameObject corruptionOverlayPrefab;
    // ▲▲▲ 【新增結束】 ▲▲▲

    // 用於一般狀態 (流血/暈眩等) 的追蹤清單
    private List<GameObject> activeStatusIcons = new List<GameObject>();

    // ▼▼▼ 【新增】用於追蹤「護甲腐化覆蓋層」的字典 (Key: 部位, Value: 覆蓋層物件) ▼▼▼
    private Dictionary<ArmorPart, GameObject> activeCorruptionOverlays = new Dictionary<ArmorPart, GameObject>();
    // ▲▲▲ 【新增結束】 ▲▲▲

    private Character targetCharacter;
    private CharacterStats stats;

    public void Initialize(Character target)
    {
        targetCharacter = target;
        stats = target.stats;

        // 初始化字典
        activeCorruptionOverlays.Clear();

        if (targetCharacter == null || stats == null)
        {
            gameObject.SetActive(false);
            return;
        }

        UpdateStats();
    }

    public void UpdateStats()
    {
        if (targetCharacter == null || stats == null) return;

        // 1. 更新文字資訊
        playerNameText.text = targetCharacter.characterName;
        playerHPText.text = $"HP:\n{stats.hp}/{stats.maxHp}";

        // 2. 更新護甲數值
        helmetArmorText.text = stats.helmet.currentArmor.ToString();
        armorArmorText.text = stats.armor.currentArmor.ToString();
        gauntletsArmorText.text = stats.gauntlets.currentArmor.ToString();
        legArmorArmorText.text = stats.legArmor.currentArmor.ToString();

        // 3. 更新一般狀態圖示 (流血、暈眩等)
        UpdateStatusEffects();

        // 4. 【新增】更新腐化覆蓋層
        UpdateCorruptionOverlays();
    }

    // ▼▼▼ 【新增】處理特定部位腐化的邏輯 ▼▼▼
    private void UpdateCorruptionOverlays()
    {
        if (corruptionOverlayPrefab == null) return;

        // 分別檢查四個部位
        HandleSlotOverlay(ArmorPart.Helmet, stats.helmet.corruptStacks, helmetIcon.transform);
        HandleSlotOverlay(ArmorPart.Armor, stats.armor.corruptStacks, armorIcon.transform);
        HandleSlotOverlay(ArmorPart.Gauntlets, stats.gauntlets.corruptStacks, gauntletsIcon.transform);
        HandleSlotOverlay(ArmorPart.LegArmor, stats.legArmor.corruptStacks, legArmorIcon.transform);
    }

    private void HandleSlotOverlay(ArmorPart part, int stacks, Transform targetParent)
    {
        // 情況 A: 有腐化層數
        if (stacks > 0)
        {
            GameObject overlay;

            // 1. 檢查是否已經存在覆蓋層
            if (!activeCorruptionOverlays.ContainsKey(part) || activeCorruptionOverlays[part] == null)
            {
                // 不存在則生成，設為目標圖示的「子物件」
                overlay = Instantiate(corruptionOverlayPrefab, targetParent);
                activeCorruptionOverlays[part] = overlay;

                // 強制設定 RectTransform 填滿父物件 (Stretch)
                RectTransform rt = overlay.GetComponent<RectTransform>();
                if (rt != null)
                {
                    rt.anchorMin = Vector2.zero; // 左下
                    rt.anchorMax = Vector2.one;  // 右上
                    rt.pivot = new Vector2(0.5f, 0.5f);
                    rt.sizeDelta = Vector2.zero; // 邊距歸零，填滿
                    rt.localPosition = Vector3.zero;
                    rt.localScale = Vector3.one;
                }
            }
            else
            {
                overlay = activeCorruptionOverlays[part];
            }

            // 2. 更新層數數字
            TMP_Text countText = overlay.GetComponentInChildren<TMP_Text>();
            if (countText != null)
            {
                countText.text = stacks.ToString();
            }
        }
        // 情況 B: 沒有腐化層數 (或已解除)
        else
        {
            if (activeCorruptionOverlays.ContainsKey(part))
            {
                if (activeCorruptionOverlays[part] != null)
                {
                    Destroy(activeCorruptionOverlays[part]);
                }
                activeCorruptionOverlays.Remove(part);
            }
        }
    }
    // ▲▲▲ 【新增結束】 ▲▲▲

    private void UpdateStatusEffects()
    {
        // 清除舊的一般狀態圖示
        foreach (GameObject icon in activeStatusIcons)
        {
            if (icon != null) Destroy(icon);
        }
        activeStatusIcons.Clear();

        if (stats == null || statusEffectParent == null) return;

        // 1. 流血
        if (stats.bleedStacks > 0 && bleedStatusIconPrefab != null)
        {
            CreateStatusIcon(bleedStatusIconPrefab, stats.bleedStacks);
        }

        // 2. Overload (負載)
        int ovLevel = stats.GetOverloadLevel();
        if (ovLevel > 0 && overloadStatusIconPrefab != null)
        {
            CreateStatusIcon(overloadStatusIconPrefab, ovLevel);
        }

        // 3. 暈眩
        if (stats.stunTurns > 0 && stunStatusIconPrefab != null)
        {
            CreateStatusIcon(stunStatusIconPrefab, stats.stunTurns);
        }

        // 4. 暫停
        if (stats.frozenTurns > 0 && pauseStatusIconPrefab != null)
        {
            CreateStatusIcon(pauseStatusIconPrefab, stats.frozenTurns);
        }
    }

    private void CreateStatusIcon(GameObject prefab, int number)
    {
        GameObject iconGO = Instantiate(prefab, statusEffectParent);
        TMP_Text stackText = iconGO.GetComponentInChildren<TMP_Text>();
        if (stackText != null)
        {
            stackText.text = number.ToString();
        }
        activeStatusIcons.Add(iconGO);
    }
}