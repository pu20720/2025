
import os
os.environ["MPLBACKEND"] = "Agg"   # 抑制 TkAgg 互動後端訊息

import time
import html
import re
from threading import Thread
from queue import Queue
from pathlib import Path
import wave
import numpy as np

import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TextIteratorStreamer,
    StoppingCriteria,
    StoppingCriteriaList,
)
from opencc import OpenCC

# === HuggingFace / PEFT 相容補丁：補 EntryNotFoundError + LocalEntryNotFoundError ===
import importlib

try:
    hf_errors = importlib.import_module("huggingface_hub.errors")
except Exception as e:
    hf_errors = None
    print(f"[Compat] 無法載入 huggingface_hub.errors：{e}")

if hf_errors is not None:
    # 先補 EntryNotFoundError（peft 會用到）
    if not hasattr(hf_errors, "EntryNotFoundError"):
        class EntryNotFoundError(Exception):
            """Compat shim for huggingface_hub.errors.EntryNotFoundError"""
            pass

        hf_errors.EntryNotFoundError = EntryNotFoundError
        print("[Compat] 已注入 huggingface_hub.errors.EntryNotFoundError")

    # 再補 LocalEntryNotFoundError，繼承上面的 EntryNotFoundError
    if not hasattr(hf_errors, "LocalEntryNotFoundError"):
        class LocalEntryNotFoundError(hf_errors.EntryNotFoundError):
            """Compat shim for huggingface_hub.errors.LocalEntryNotFoundError"""
            pass

        hf_errors.LocalEntryNotFoundError = LocalEntryNotFoundError
        print("[Compat] 已注入 huggingface_hub.errors.LocalEntryNotFoundError")

# === LoRA
from peft import PeftModel  # 只在推論時需要這個（merge 後可卸載）

# === RAG Backend ===
#  rag_backend.py 跟這支程式在相同（或在 PYTHONPATH）
from rag_backend import search_context

# ============== 使用者可調參數 ==============
TXT_SWITCH = 1
TTS_TEXT_FILE = "F:/test/output_tts.txt"

LLM_PATH = "F:/test/model/models--MediaTek-Research--Breeze-7B-Instruct-v1_0"
LORA_PATH = "F:/lora-mr-breeze-7b"   #  LoRA 輸出資料夾 

COSYVOICE_PATH = "F:/test/model/CosyVoice/pretrained_models/CosyVoice2-0.5B"
ZERO_SHOT_PROMPT_WAV = "F:/test/model/CosyVoice/asset/zero_shot_prompt.wav"

FORCE_SAMPLE_RATE = None   # 例如 24000，None 則用 cosyvoice 預設
OUTPUT_DIR = Path("F:/test/tts_out")  # 本機暫存資料夾（先寫本機，再推送到 Unity）
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SAFE_WRITE = True          # 先寫 .part 再原子改名 → 防止讀到半檔
SAVE_WORKERS = 4           #  2~4
LOG_SAVE_TIME = False

# 字數預算（以「字元數」計）
BUDGET_CHARS = 500         #  字數上限（中文/英文皆以字元數估）
GRACE_TOKENS = 50          #  超過上限後的最少收尾 token 數

# （）把硬上限往前預留一點，讓模型有空間補句點
INTERNAL_BUDGET_FOR_STOPPER = max(1, BUDGET_CHARS - 10)
USE_INTERNAL_BUDGET = True

# 是否啟用 RAG
USE_RAG = True
# ==========================================

# ============== HTTP 推送設定 ==============
REMOTE_HTTP = "http://192.168.192.32:5080/upload"  #   Unity 節點 
AUTH_TOKEN  = "change-me-very-strong-token"        # 與 Unity 端 authToken 一致；不用就留空字串
UPLOADER_WORKERS = 2
HTTP_TIMEOUT = 8.0
MAX_RETRY = 5
# =========================
# Bridge: 主動把 LLM 文字推到 server /push
# =========================
import requests
BRIDGE_PUSH_URL = "http://192.168.192.84:8000/push"   # 伺服器位址

_session = requests.Session()
def bridge_push(event: str, text: str = ""):
    try:
        _session.post(BRIDGE_PUSH_URL, json={"event": event, "text": text}, timeout=2.0)
    except Exception:
        pass
# =========================================================

# OpenCC
cc_t2s = OpenCC('t2s')     # 給 TTS：繁→簡
cc_s2t = OpenCC('s2t')     # 給字幕：簡→繁

# =========================
# 計時工具
# =========================
_start_time = 0.0
def start__time():
    global _start_time
    _start_time = time.time()

def end__time(label="耗時"):
    execution_time = time.time() - _start_time
    print(f"{label}：{execution_time:.2f}秒")

# =========================
# 初始化 LLM（含 LoRA）
# =========================
print("[Init] 載入 Tokenizer…")
tokenizer = AutoTokenizer.from_pretrained(LLM_PATH, use_fast=True)

#
quant_config = BitsAndBytesConfig(
    load_in_4bit=False,
    bnb_4bit_compute_dtype=torch.float16
)

print("[Init] 載入 Base 模型…")
model = AutoModelForCausalLM.from_pretrained(
    LLM_PATH,
    device_map="auto",
    torch_dtype=torch.float16,
    attn_implementation="flash_attention_2",
    quantization_config=quant_config
)

# === LoRA：載入 LoRA 權重並合併到模型
if LORA_PATH and Path(LORA_PATH).exists():
    print(f"[Init][LoRA] 載入並合併 LoRA：{LORA_PATH}")
    model = PeftModel.from_pretrained(model, LORA_PATH, device_map="auto", torch_dtype=torch.float16)
    # 合併權重到 base，推論時不再依賴 LoRA 模組
    model = model.merge_and_unload()  # 保留 PEFT 結構，註解
else:
    print("[Init][LoRA] 未設定/找不到 LoRA 路徑，使用原始 Base")

model.config.pad_token_id = tokenizer.eos_token_id
model.eval()
torch.backends.cuda.matmul.allow_tf32 = True


# =========================
# 初始化 TTS
# =========================
print("[Init] 載入 CosyVoice2…]")
from cosyvoice.cli.cosyvoice import CosyVoice2
from cosyvoice.utils.file_utils import load_wav

cosyvoice = CosyVoice2(
    COSYVOICE_PATH,
    load_jit=False, load_trt=False, fp16=True
)

prompt_speech_16k = load_wav(ZERO_SHOT_PROMPT_WAV, 15250)
tts_sample_rate = cosyvoice.sample_rate if FORCE_SAMPLE_RATE is None else FORCE_SAMPLE_RATE
print(f"[Init] TTS 採樣率：{tts_sample_rate}")

# =========================
# 對話歷史
# =========================
import sys_prompt_set  # 系統提示集合
chat_history = sys_prompt_set.sys_set()
print("[Init] 初始對話歷史：", chat_history)

def chat_history_user(user_input: str):
    global chat_history
    chat_history.append({"role": "user", "content": user_input})

def chat_history_llm(response: str):
    global chat_history
    chat_history.append({"role": "assistant", "content": response})

def chat_history_check(history):
    global chat_history
    if len(history) > 6:
        chat_history = chat_history[-6:]

# =========================
# RAG 查詢 + augment 工具
# =========================
def build_rag_augmented_user_input(user_input: str) -> str:
    """
    呼叫 rag_backend.search_context() 取得相關知識庫內容，
    把 context 包成同一則使用者訊息，丟給 Breeze。
    並且明確禁止條列式回答。
    """
    if not USE_RAG:
        return user_input

    try:
        context = search_context(user_input, k=4)
    except Exception as e:
        print(f"[RAG] 查詢失敗：{e}")
        return user_input

    if not context:
        return user_input

    augmented = f"""你正在回答用戶的問題。
[使用者原始問題]
{user_input}

---
以下是系統從課程/校園知識庫中檢索到的相關內容：

{context}

請你根據上面這些資料回答使用者的問題，並嚴格遵守以下「回答風格」規則：

1. 回答請用自然、口語化、簡短的中文，好像在跟學生聊天。
2. **不要使用任何條列式、編號或項目符號**：
   - 不要出現「1.」、「2.」、「(1)」、「(2)」、「- 」、「•」等格式。
   - 不要把內容寫成清單或列表。
   - 請用 1～3 段完整的「連續段落」來說明即可。
3. 不要在開頭說「根據資料檢索結果」或「根據上面資料」這類話，
   直接用正常對話語氣開始回答，例如：
   「如果你對某個領域有興趣，可以考慮這門課……」這種開頭。
4. 優先引用資料中的內容，不要憑空捏造。
5. 如果資料裡沒有提到某些細節，就說「資料中沒有相關資訊」或「資料裡沒有提到」，不要亂猜。
6. 回答中不要出現網址。
7. 這些都是靜宜大學相關的資料。
8. 如果檢索結果裡的人名、課名、地點等關鍵資訊和使用者問題「明顯不一致」，請說明「檢索資料和問題不完全吻合」，只引用真正符合的部分，其餘請忽略。
9. 上面「檢索到的相關內容」裡，只要有任何一門課程或老師「大致上跟問題有關」，就不要說
   「資料中沒有找到符合『{user_input}』的項目」。
   - 這種說法只允許在你真的完全看不到任何課程 / 老師資訊，或內容明顯跟問題無關的情況下使用。
   - 如果你覺得只有「部分相關」或「名字不完全一樣」，請改說：
     「目前資料中只有以下幾門看起來比較接近的課程，可能不完全符合你的條件：……」

請直接輸出給使用者看的最終答案，不要重複以上說明，也不要再自己列出新的 1. 2. 3. 清單。
"""
    return augmented

# =========================
# 文本紀錄執行緒（）
# =========================
text_queue: "Queue[str | None]" = Queue()

def txt_in_worker(queue: "Queue[str | None]"):
    while True:
        text = queue.get()
        if text is None:
            break
        if not TXT_SWITCH:
            continue
        time.sleep(0.1)
        with open(TTS_TEXT_FILE, "a", encoding="utf-8") as f:
            f.write(text)
            f.flush()

txt_thread = Thread(target=txt_in_worker, args=(text_queue,), daemon=True)
txt_thread.start()

# =========================
# 寫檔（多執行）
# =========================
class SaveJob:
    __slots__ = ("base", "segment_text", "audio_concat", "sr")
    def __init__(self, base: str, segment_text: str, audio_concat: np.ndarray, sr: int):
        self.base = base
        self.segment_text = segment_text
        self.audio_concat = audio_concat
        self.sr = sr

save_queue: "Queue[SaveJob | None]" = Queue()
_workers: list[Thread] = []

# ====== 序號（每輪從 1 開始；不使用 Lock，主線程取號）======
_global_seq = 0
def reset_seq():
    
    global _global_seq
    _global_seq = 0

def next_seq():
    
    global _global_seq
    _global_seq += 1
    return _global_seq
# =======================================================

def write_wav_pcm16(path: Path, samples: np.ndarray, sr: int):
    
    s = np.clip(samples, -1.0, 1.0)
    s16 = (s * 32767.0).astype(np.int16)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(sr)
        wf.writeframes(s16.tobytes())

# =========================
# 上傳 W（HTTP 推送到 Unity）
# =========================
from dataclasses import dataclass

@dataclass
class UploadTask:
    base: str
    wav_path: Path
    txt_path: Path | None

upload_queue: "Queue[UploadTask | None]" = Queue()
_uploaders: list[Thread] = []

def uploader_loop():
    s = requests.Session()
    headers = {"X-Auth": AUTH_TOKEN} if AUTH_TOKEN else {}
    while True:
        task = upload_queue.get()
        if task is None:
            break
        if not REMOTE_HTTP:
            continue

        for attempt in range(1, MAX_RETRY + 1):
            try:
                # 開啟檔案
                files = {
                    "base": (None, task.base),
                    "wav": (task.wav_path.name, open(task.wav_path, "rb"), "audio/wav"),
                }
                if task.txt_path and task.txt_path.exists():
                    files["txt"] = (task.txt_path.name, open(task.txt_path, "rb"), "text/plain")

                try:
                    r = s.post(REMOTE_HTTP, files=files, headers=headers, timeout=HTTP_TIMEOUT)
                finally:
                    # 無論成功失敗，都確保檔案有關閉
                    try:
                        files["wav"][1].close()
                    except Exception:
                        pass
                    if "txt" in files:
                        try:
                            files["txt"][1].close()
                        except Exception:
                            pass

                if r.status_code == 200:
                    print(f"[UPLOAD] {task.wav_path.name} → OK")

                    try:
                        if task.wav_path.exists():
                            task.wav_path.unlink()
                    except Exception as e:
                        print(f"[UPLOAD] 刪除本機 WAV 失敗：{task.wav_path}  err={e}")

                    if task.txt_path:
                        try:
                            if task.txt_path.exists():
                                task.txt_path.unlink()
                        except Exception as e:
                            print(f"[UPLOAD] 刪除本機 TXT 失敗：{task.txt_path}  err={e}")

                    break # 結束 retry 迴圈
                else:
                    raise RuntimeError(f"HTTP {r.status_code}: {r.text[:120]}")

            except Exception as e:
                if attempt >= MAX_RETRY:
                    print(f"[UPLOAD] 最終失敗({attempt}/{MAX_RETRY}) {task.wav_path.name}: {e}")
                    break
                wait = min(2 ** attempt, 30)  # 2,4,8,16,30
                print(f"[UPLOAD] 失敗({attempt}/{MAX_RETRY}) {task.wav_path.name}: {e} → {wait}s 後重試")
                time.sleep(wait)


def start_uploader_workers(n=1):
    for _ in range(max(1, n)):
        th = Thread(target=uploader_loop, daemon=True)
        th.start()
        _uploaders.append(th)

def stop_uploader_workers():
    for _ in _uploaders:
        upload_queue.put(None)
    for th in _uploaders:
        th.join(timeout=3.0)

# =========================
# TTS 合成 W（由主線程丟段落進來）
# =========================
class TtsJob:
    __slots__ = ("text", "base")
    def __init__(self, text: str, base: str):
        self.text = text
        self.base = base

tts_queue: "Queue[TtsJob | None]" = Queue()
_tts_workers: list[Thread] = []

def tts_worker_loop():
    while True:
        job = tts_queue.get()
        if job is None:
            break
        seg = job.text.strip()
        if not seg:
            continue
        # 合成並丟給寫檔佇列
        chunk_list = []
        for out in cosyvoice.inference_zero_shot(
            seg,
            '美好的时光总是过得那么快，下次再见啦。',
            prompt_speech_16k,
            stream=False,
            text_frontend=True,
            speed=0.81
        ):
            speech = out['tts_speech'].squeeze(0).cpu().numpy().astype(np.float32)
            chunk_list.append(speech)
        enqueue_save_job(job.base, seg, chunk_list, tts_sample_rate)

def start_tts_workers(n=2):
    for _ in range(max(1, n)):
        th = Thread(target=tts_worker_loop, daemon=True)
        th.start()
        _tts_workers.append(th)

def stop_tts_workers():
    for _ in _tts_workers:
        tts_queue.put(None)
    for th in _tts_workers:
        th.join(timeout=3.0)

# =========================
# 寫檔 W 主迴圈
# =========================
def save_worker_loop():
    while True:
        job = save_queue.get()
        if job is None:
            break
        t0 = time.time()

        base = job.base
        wav_path  = OUTPUT_DIR / f"{base}.wav"
        txt_path  = OUTPUT_DIR / f"{base}.txt"
        part_path = OUTPUT_DIR / f"{base}.part"

        try:
            #  先寫 .part
            write_wav_pcm16(part_path, job.audio_concat, job.sr)

            #  寫字幕（簡→繁）
            trad_text = cc_s2t.convert(job.segment_text.strip())
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write(trad_text)

            # s改名 .part → .wav
            if SAFE_WRITE:
                try:
                    if wav_path.exists():
                        wav_path.unlink()
                except Exception:
                    pass
                part_path.replace(wav_path)
            else:
                write_wav_pcm16(wav_path, job.audio_concat, job.sr)

            if LOG_SAVE_TIME:
                dt = time.time() - t0
                print(f"[TTS][SAVE] {wav_path.name} ok ({len(job.audio_concat)/job.sr:.2f}s audio)  寫檔耗時：{dt:.3f}s")
            else:
                print(f"[TTS] 輸出：{wav_path.name}（{len(job.audio_concat)/job.sr:.2f}s）")

            # 排入上傳（HTTP 推送）
            if REMOTE_HTTP:
                upload_queue.put(UploadTask(base=base, wav_path=wav_path, txt_path=txt_path))

        except Exception as e:
            print(f"[TTS][SAVE] 寫檔失敗：{base}  err={e}")

def start_save_workers(n_workers: int):
    global _workers
    for _ in range(max(1, n_workers)):
        th = Thread(target=save_worker_loop, daemon=True)
        th.start()
        _workers.append(th)

def stop_save_workers():
    for _ in _workers:
        save_queue.put(None)  # 
    for th in _workers:
        th.join(timeout=3.0)

def enqueue_save_job(base: str, segment_text: str, audio_chunks: list[np.ndarray], sr: int):
    """主線程已決定好 base（含序號與時間戳），這裡只負責合併與入列"""
    if not audio_chunks:
        return
    audio_concat = np.concatenate(audio_chunks, axis=0)
    job = SaveJob(base=base, segment_text=segment_text, audio_concat=audio_concat, sr=sr)
    save_queue.put(job)

# 啟動 worker
start_save_workers(SAVE_WORKERS)
start_uploader_workers(UPLOADER_WORKERS)
start_tts_workers(2)

# =========================
# 文字處理工具
# =========================
def split_text_by_punctuation_with_min_length(text, min_length=12):
    segments = re.split(r'(，|。|：|；|！|！|？|\?|,|\.)', text)
    combined_segments = []
    temp = ""
    for segment in segments:
        if segment in " 　":  
            temp += " "
            continue
        if segment in "，。：；！？?,.":
            temp += segment
            combined_segments.append(temp)
            temp = ""
        else:
            temp += segment
    if temp:
        combined_segments.append(temp)

    result = []
    temp = ""
    for segment in combined_segments:
        temp += segment
        if len(temp.strip()) >= min_length:
            result.append(temp.strip())
            temp = ""
    if temp:
        result.append(temp.strip())
    return result

def clamp_to_50chars_full_sentence(text, max_chars=50):
    t = text.strip()
    if len(t) <= max_chars and any(t.endswith(p) for p in "。！？!?；;,.，"):
        return t
    sub = t[:max_chars]
    puncts = "。！？!?；;,.，"
    cut_positions = [sub.rfind(p) for p in puncts]
    cut = max(cut_positions) if cut_positions else -1
    if cut != -1:
        return sub[:cut+1]
    return sub + "。"

def extract_assistant_text(generated: str) -> str:
    """從可能含模板回聲的輸出取出最後一段助理回覆。"""
    t = (generated or "").strip()
    if '[/INST]' in t:
        t = t.split('[/INST]')[-1]
    return html.unescape(t).strip()

def ensure_sentence_closed(s: str):
    s = s.rstrip()
    if not s:
        return s
    if s[-1] in "。！？!?；;….,，":
        return s
    return s + "。"

# =========================
#  收斂（生成後後處理）
# =========================
_MAJOR_END = "。！？!?."          # 主要句末（含英文句點）
_MINOR_END = "；;，,、：:)"       # 次級停頓（必要時回退用）

def finalize_with_budget(text: str, max_chars: int) -> str:
    t = (text or "").strip()
    if not t:
        return t
    if len(t) <= max_chars and (t[-1] in _MAJOR_END or t[-1] == "…"):
        return t
    rough = t[:max_chars].rstrip()
    last_major = max(rough.rfind(ch) for ch in _MAJOR_END)
    if last_major != -1:
        return rough[:last_major+1].strip()
    last_minor = max(rough.rfind(ch) for ch in _MINOR_END)
    if last_minor != -1:
        trimmed = rough[:last_minor+1].strip()
        if trimmed and trimmed[-1] not in "。！？!?":
            trimmed += "。"
        return trimmed
    return rough + "。"

# =========================
#  字數預算收尾
# =========================
class CharBudgetSentenceStopper(StoppingCriteria):
    def __init__(self, tokenizer, prompt_len_tokens: int, max_chars: int = 280, grace_tokens: int = 16):
        self.tok = tokenizer
        self.prompt_len_tokens = prompt_len_tokens
        self.max_chars = max_chars
        self.base_grace_tokens = grace_tokens
        self.triggered = False
        self.trigger_step = None
        self.ends_major = set(list("。！？!?."))   
        self.ends_ellipsis = set(list("…"))       

    def _decoded_tail(self, input_ids):
        gen_ids = input_ids[0, self.prompt_len_tokens:].tolist()
        if not gen_ids:
            return ""
        return self.tok.decode(gen_ids, skip_special_tokens=True)

    def _ends_with_sentence_punct(self, text: str):
        t = text.strip()
        return len(t) > 0 and (t[-1] in self.ends_major or t[-1] in self.ends_ellipsis)

    def __call__(self, input_ids, scores, **kwargs):
        seq_len = input_ids.shape[1]
        gen_len_tokens = seq_len - self.prompt_len_tokens
        if gen_len_tokens <= 0:
            return False

        text = self._decoded_tail(input_ids)
        gen_len_chars = len(text.replace("\n", " "))

        if not self.triggered:
            if gen_len_chars >= self.max_chars:
                self.triggered = True
                self.trigger_step = gen_len_tokens
                return self._ends_with_sentence_punct(text)
            return False

        grace_tokens = self.base_grace_tokens + 6
        if self._ends_with_sentence_punct(text):
            return True
        if gen_len_tokens - self.trigger_step >= grace_tokens:
            return True
        return False

# =========================
# 主迴圈
# =========================
try:
    while True:
        
        user_input = input("輸入文字：").strip()
        if user_input.lower() == "exit":
            break

        # ===== RAG
        rag_aug_input = build_rag_augmented_user_input(user_input)
        if rag_aug_input != user_input:
            print("\n[RAG] 已加入知識庫內容輔助回答。")
        else:
            print("\n[RAG] 沒有可用的知識庫內容或 RAG 關閉，直接用原始問題。")

        chat_history_user(rag_aug_input)
        start__time()

        formatted_prompt = tokenizer.apply_chat_template(
            chat_history,
            tokenize=False,
            add_generation_prompt=True
        )
        inputs = tokenizer(formatted_prompt, return_tensors="pt", padding=True).to("cuda")

        #  準備字數預算的停止條件（batch=1）
        prompt_len_tokens = inputs["input_ids"].shape[1]
        stopper_budget = INTERNAL_BUDGET_FOR_STOPPER if USE_INTERNAL_BUDGET else BUDGET_CHARS
        stopper = CharBudgetSentenceStopper(
            tokenizer,
            prompt_len_tokens=prompt_len_tokens,
            max_chars=stopper_budget,
            grace_tokens=GRACE_TOKENS
        )
        stopping_criteria = StoppingCriteriaList([stopper])

        streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)

        generation_kwargs = {
            "input_ids": inputs["input_ids"],
            "attention_mask": inputs["attention_mask"],
            "max_new_tokens": 512,      # 寬鬆上限； stopper 控制
            "min_new_tokens": 20,
            "do_sample": True,
            "temperature": 0.7,
            "top_p": 0.9,
            "use_cache": True,
            "streamer": streamer,
            "eos_token_id": tokenizer.eos_token_id,
            "no_repeat_ngram_size": 4,
            "stopping_criteria": stopping_criteria,
        }

        # LLM 生成
        LLM_thread = Thread(target=model.generate, kwargs=generation_kwargs)
        LLM_thread.start()

        # 邊收 token 邊印
        response = ""
        # 向 server 推流（只送 LLM 文字）
        bridge_push("start", "")

        for new_text in streamer:
            response += new_text
            print(new_text, end="", flush=True)
            text_queue.put(new_text)
            bridge_push("delta", new_text)

        # --- LLM 最終輸出處理 ---
        assistant_only = extract_assistant_text(response) or (response or "").strip()

        # 先做句尾智慧收斂，確保語義完整落在句末
        assistant_only = finalize_with_budget(assistant_only, BUDGET_CHARS)
        # 保底再補句尾
        assistant_only = ensure_sentence_closed(assistant_only)

        

        # 全文給 TTS（繁→簡）
        tts_text_full = cc_t2s.convert(assistant_only).replace("\n", " ").strip()

        
        bridge_push("final", assistant_only)   # 如果想顯示簡體就改成 tts_text_full

        bridge_push("done", "")  # ←宣告這輪結束
        
        display_short = clamp_to_50chars_full_sentence(tts_text_full, max_chars=50)
        print("\n" + display_short)

        # === 新對話 檔名序號歸零 ===
        reset_seq()
        # 通知 Unity（顯式回合旗標），放在相同 OUTPUT_DIR
        (Path(OUTPUT_DIR) / f"__round__.{int(time.time()*1000)}.flag").touch()

        # 分段給 TTS（全文 → 逐段丟給 TTS worker）
        text_segments = split_text_by_punctuation_with_min_length(tts_text_full, min_length=12)
        if not text_segments:
            text_segments = [tts_text_full]

        for segment in text_segments:
            seg = segment.strip()
            if not seg:
                continue
            # 主線程取號並決定本段檔名
            seq = next_seq()
            ts = int(time.time() * 1000)
            base = f"{seq:06d}_{ts}"  

            print(f"\n處理段落: {seg}")
            tts_queue.put(TtsJob(seg, base))  # worker 只負責合成與寫檔
            if not LOG_SAVE_TIME:
                end__time("段落排入合成/落盤/上傳")

        chat_history_llm(assistant_only)

        # 清空文字檔（若有開啟）
        if TXT_SWITCH:
            time.sleep(0.5)
            with open(TTS_TEXT_FILE, "w", encoding="utf-8") as f:
                f.truncate(0)

        chat_history_check(chat_history)

except KeyboardInterrupt:
    print("\n[Exit] 使用者中斷")

finally:
    try:
        text_queue.put(None)
    except Exception:
        pass

    # 停止各 worker
    stop_tts_workers()
    stop_save_workers()
    stop_uploader_workers()

    time.sleep(0.2)
    print("[Exit] 已送出結束訊號。")
