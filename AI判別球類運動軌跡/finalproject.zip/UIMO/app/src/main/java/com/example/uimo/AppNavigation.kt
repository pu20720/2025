package com.example.uimo.navigation

import android.net.Uri
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.uimo.ui.screens.FirstScreen
import com.example.uimo.ui.screens.FourthScreen
import com.example.uimo.ui.screens.SecondScreen
import com.example.uimo.ui.screens.ThirdScreen
import com.example.uimo.ui.screens.CourtSetupScreen

@Composable
fun AppNavigation(navController: NavHostController) {
    // アプリ全体のナビゲーションを管理する NavController

    // NavHost で画面遷移を定義
    NavHost(navController = navController, startDestination = "first") {
        // "first" というルート（最初の画面）
        composable("first") {
            FirstScreen(navController = navController)
        }
        // "second" というルート（動画選択/撮影画面）
        composable("second") {
            // SecondScreen に navController を渡す
            SecondScreen(navController = navController)
        }

        // コート設定専用の新しいスクリーン
        composable(
            route = "courtSetup/{videoUri}",
            arguments = listOf(navArgument("videoUri") { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedUri = backStackEntry.arguments?.getString("videoUri")
            if (encodedUri != null) {
                val videoUri = Uri.parse(Uri.decode(encodedUri))
                CourtSetupScreen(navController = navController, videoUri = videoUri)
            } else {
                navController.popBackStack() // URIがなければ戻る
            }
        }

        // "third/{videoUri}" というルート（判定画面）
        // {videoUri} の部分で動画のURIを引数として受け取る
        composable("third/{videoUri}/{cornersJson}",
            arguments = listOf(
                navArgument("videoUri") { type = NavType.StringType },
                navArgument("cornersJson") { type = NavType.StringType }
            )
            ) { backStackEntry ->
            Log.d("NavCheck", "AppNavigation: 'third/{videoUri}' ルートが呼び出されました。")
            val videoUriString = backStackEntry.arguments?.getString("videoUri")
            val encodedCornersJson = backStackEntry.arguments?.getString("cornersJson")
            Log.d("NavCheck", "AppNavigation: 受け取ったURI文字列: $videoUriString")
            if (videoUriString != null) {
                val decodeUri = Uri.parse(Uri.decode(videoUriString))
                val cornersJson = Uri.decode(encodedCornersJson)
                ThirdScreen(
                    navController = navController,
                    videoUri = decodeUri, // URIをデコードして渡す
                    cornersJson = cornersJson // 座標JSONを渡す

                )
            } else {
                navController.popBackStack() // 引数が足りなければ戻る
            }
        }
        composable(
            "fourth/{videoUrl}",
            arguments = listOf(navArgument("videoUrl") { type = NavType.StringType })
        ) { backStackEntry ->
            val videoUrlString = backStackEntry.arguments?.getString("videoUrl")
            if (videoUrlString != null) {
                val decodedUrl = Uri.decode(videoUrlString)
                FourthScreen(navController = navController, videoUrl = decodedUrl)
            }
        }
    }
}