from django.db import models
from django.contrib.auth.models import (
    AbstractBaseUser,
    PermissionsMixin,
    BaseUserManager,
)


class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra):
        if not email:
            raise ValueError('Email 必填')
        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra)
        if not password:
            raise ValueError('Password 必填')
        user.set_password(password)  # 會用 PBKDF2 雜湊
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra):
        extra.setdefault('is_staff', True)
        extra.setdefault('is_superuser', True)
        extra.setdefault('is_active', True)
        return self.create_user(username, email, password, **extra)


class User(AbstractBaseUser, PermissionsMixin):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(max_length=254, unique=True)
    available_funds = models.DecimalField(
        max_digits=15, decimal_places=2, default=1000000.00
    )  # 可用資金，預設 1,000,000
    portfolio_value = models.PositiveBigIntegerField(default=0)  # 持股價值
    total_return_rate = models.DecimalField(
        max_digits=6, decimal_places=2, default=0.00
    )  # 總報酬率
    is_staff = models.BooleanField(default=False)  # 可登入 admin
    is_active = models.BooleanField(default=True)
    date_joined = models.DateTimeField(auto_now_add=True)

    objects = UserManager()

    # 這兩個是 Django 需要的重點
    USERNAME_FIELD = 'email'  # 你也可改成 'username'
    REQUIRED_FIELDS = ['username']  # 建 superuser 時會要求

    class Meta:
        ordering = ['-date_joined']

    def __str__(self):
        return self.username
