// 檔案路徑: Assets/Scripts/SceneManagers/Branch/AdventurerTutorialStrategy.cs
using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System;

public class AdventurerTutorialStrategy : BranchStrategy
{
    private Character targetEnemy;
    private KnightTutorialStep currentTutorialStep = KnightTutorialStep.None;
    private bool hasShownLowMPWarning = false;
    private bool hasShownOverloadWarning = false;
    private bool hasShownTargetNothingWarning = false;

    public override void Initialize(BattleManager battleManager, Character player, List<Character> enemies)
    {
        base.Initialize(battleManager, player, enemies);
        this.targetEnemy = enemies.FirstOrDefault(e => e.characterName == "Target");
    }

    // 2. 事件：戰鬥開始
    public override void OnBattleStart()
    {
        currentTutorialStep = KnightTutorialStep.Start_0_Intro;
        // 【分支對話】
        battleManager.ShowTutorialDialogue("Adventurer Coach", "Bro, destroy the Armor! I'm sure it's not hard for you!");
    }

    // 2. 事件：玩家回合開始
    public override void OnPlayerTurnStart()
    {
        if (currentTutorialStep == KnightTutorialStep.Enemy_1_Nothing)
        {
            AdvanceTutorial(currentTutorialStep);
        }
        else if (currentTutorialStep == KnightTutorialStep.Enemy_2_Scratch)
        {
            AdvanceTutorial(currentTutorialStep);
        }
    }

    public override void OnEnemyAction(EnemyAI ai, Character playerTarget)
    {
        if (ai.enemyData.aiLogic == EnemyAILogic.TutorialTarget)
        {
            if (currentTutorialStep == KnightTutorialStep.Enemy_1_Nothing)
            {
                battleManager.LogAction("The Target uses Nothing. It's a target, what did you expect?");
            }
            if (currentTutorialStep == KnightTutorialStep.FreePlay && !hasShownTargetNothingWarning)
            {
                if (player.stats.turnCount == 4 || (player.stats.turnCount > 4 && (player.stats.turnCount - 4) % 3 == 0))
                {
                    hasShownTargetNothingWarning = true;
                    battleManager.ShowTutorialDialogue("Player", "Nice... it's playing dumb.");
                }
            }
        }
    }

    public override void OnUpdate()
    {
        if (player == null || player.stats == null) return;

        CardDisplay selectedCard = battleManager.GetSelectedCardDisplay();

        if (!hasShownLowMPWarning && selectedCard != null)
        {
            CardData card = selectedCard.GetCardData();
            if (card != null && player.stats.mp < card.mpCost)
            {
                hasShownLowMPWarning = true;
                battleManager.ShowTutorialDialogue("Player", "My magic teacher always told me not to use mana recklessly, but I still forget...");
                battleManager.LogAction("Not enough MP!");
            }
        }

        if (!hasShownOverloadWarning && player.stats.mp >= 200)
        {
            hasShownOverloadWarning = true;
            battleManager.ShowTutorialDialogue("Player", "Overloaded already? You've got to be kidding me. Better play some cards quickly...");
        }
    }

    public override bool ValidateCardClick(CardData card)
    {
        Debug.Log($"[KnightStrategy] ValidateCardClick: 檢查卡牌 '{card.cardName}' (Type: {card.type})。目前步驟: {currentTutorialStep}");

        switch (currentTutorialStep)
        {
            case KnightTutorialStep.WaitForCleave:
                if (card.type == CardType.Attack) return true;
                break;
            case KnightTutorialStep.WaitForThreefold:
                if (card.type == CardType.Conditional) return true;
                break;

            case KnightTutorialStep.WaitForSharpen:
                if (card.type == CardType.Buff) return true;

                if (card.type == CardType.Weapon && battleManager.GetSelectedCardDisplay() != null && battleManager.GetSelectedCardDisplay().GetCardData().type == CardType.Buff)
                {
                    Debug.Log("[KnightStrategy] ValidateCardClick: PASSED. (WaitForSharpen & Target is Weapon)");
                    return true;
                }

                break;

            case KnightTutorialStep.WaitForSharpBlade:
                if (card.type == CardType.Weapon) return true;
                break;
            case KnightTutorialStep.WaitForDivineRadiance:
                if (card.type == CardType.Magic) return true;
                break;

            case KnightTutorialStep.FreePlay:
                return true;
        }

        battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
        Debug.LogWarning($"[KnightStrategy] ValidateCardClick: REJECTED. 步驟為 {currentTutorialStep} 但點擊了 {card.type}。");
        return false;
    }

    public override bool ValidateEndTurn()
    {
        if (currentTutorialStep == KnightTutorialStep.WaitForEndTurn1 ||
            currentTutorialStep == KnightTutorialStep.WaitForEndTurn2 ||
            currentTutorialStep == KnightTutorialStep.FreePlay)
        {
            if (currentTutorialStep == KnightTutorialStep.WaitForEndTurn1) currentTutorialStep = KnightTutorialStep.Enemy_1_Nothing;
            if (currentTutorialStep == KnightTutorialStep.WaitForEndTurn2) currentTutorialStep = KnightTutorialStep.Enemy_2_Scratch;
            return true;
        }

        battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
        Debug.LogWarning($"[KnightStrategy] ValidateEndTurn: REJECTED. 步驟為 {currentTutorialStep}。");
        return false;
    }

    public override bool HandleTargetClick(CardData card, TargetIndicator target)
    {
        if (card == null || target == null)
        {
            Debug.LogError($"[KnightStrategy] HandleTargetClick FAILED: 傳入的 card 或 target 是 null。");
            return false;
        }
        Debug.Log($"[KnightStrategy] HandleTargetClick: 1. 檢查卡牌 '{card.cardName}' (Type: {card.type})。目前步驟: {currentTutorialStep}");

        bool isAttackCard = (card.type == CardType.Attack || card.type == CardType.Weapon);
        bool isInstructionalOrFreeplay =
            (currentTutorialStep >= KnightTutorialStep.WaitForCleave && currentTutorialStep <= KnightTutorialStep.WaitForEndTurn2) ||
            currentTutorialStep == KnightTutorialStep.FreePlay;

        if (isAttackCard && isInstructionalOrFreeplay && target.GetCategory() == TargetCategory.Enemy)
        {
            battleManager.ShowTutorialDialogue("Player", "I don't have the habit to wasting time on this......", true);
            battleManager.DeselectCard();
            Debug.LogWarning($"[KnightStrategy] HandleTargetClick: REJECTED. (玩家試圖攻擊敵人本體)。");
            return true;
        }

        if (currentTutorialStep == KnightTutorialStep.WaitForCleave && card.type == CardType.Attack)
        {
            if (target.GetCategory() == TargetCategory.EnemyArmorSlot)
            {
                Debug.Log($"[KnightStrategy] HandleTargetClick: 3. 執行 Cleave 成功。推進教學至 Cleave_1_After。");
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = KnightTutorialStep.Cleave_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
            battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
            Debug.LogWarning($"[KnightStrategy] HandleTargetClick: REJECTED. (點擊了非護甲槽的目標)。");
            battleManager.DeselectCard();
            return true;
        }

        if (currentTutorialStep == KnightTutorialStep.WaitForThreefold && card.type == CardType.Conditional)
        {
            if (target.GetCategory() == TargetCategory.Special)
            {
                Debug.Log($"[KnightStrategy] HandleTargetClick: 3. 執行 Threefold_Ward 成功。推進教學至 Threefold_1_After。");
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().MoveCardFromHand(battleManager.GetSelectedCardDisplay().gameObject);
                UnityEngine.Object.Destroy(battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = KnightTutorialStep.Threefold_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        if (currentTutorialStep == KnightTutorialStep.WaitForSharpen && card.type == CardType.Buff)
        {
            if (target.GetCategory() == TargetCategory.CardInHand && target.GetCardDisplay().GetCardData().type == CardType.Weapon)
            {
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = KnightTutorialStep.Sharpen_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        if (currentTutorialStep == KnightTutorialStep.WaitForSharpBlade && card.type == CardType.Weapon)
        {
            if (target.GetCategory() == TargetCategory.EnemyArmorSlot && target.GetArmorPart() == ArmorPart.Armor)
            {
                Debug.Log($"[KnightStrategy] HandleTargetClick: 3. 執行 Sharp Blade 成功。推進教學至 Blade_1_After。");
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = KnightTutorialStep.Blade_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
            else
            {
                Debug.LogWarning($"[KnightStrategy] HandleTargetClick: REJECTED. (點擊了非護甲槽的目標)。");
                battleManager.ShowTutorialDialogue("Player", "That's not what I should do.......", true);
                battleManager.DeselectCard();
                return true;
            }
        }

        if (currentTutorialStep == KnightTutorialStep.WaitForDivineRadiance && card.type == CardType.Magic)
        {
            if (target.GetCategory() == TargetCategory.Player)
            {
                Debug.Log($"[KnightStrategy] HandleTargetClick: 3. 執行 Divine_Radiance 成功。推進教學至 Divine_1_After。");
                battleManager.PlayCard(card, target);
                battleManager.GetDeckManager().PlayCardToDiscard(card, battleManager.GetSelectedCardDisplay().gameObject);
                battleManager.DeselectCard();
                currentTutorialStep = KnightTutorialStep.Divine_1_After;
                AdvanceTutorial(currentTutorialStep);
                return true;
            }
        }

        Debug.LogWarning($"[KnightStrategy] HandleTargetClick: 4. 點擊未被任何教學步驟處理。回傳 false。");
        return false;
    }

    // 5. 勝利/失敗
    public override bool CheckForSpecialBattleEnd(out bool playerWon)
    {
        if (player != null && player.stats.isDead)
        {
            battleManager.LogAction("Player was defeated. Game Over.");
            battleManager.StartCoroutine(battleManager.EndTutorialGame(false));
            playerWon = false;
            return true;
        }

        if (targetEnemy != null && targetEnemy.stats.armor.isBroken)
        {
            battleManager.LogAction("Target's Armor is broken. Victory!");
            battleManager.ShowTutorialDialogue("Adventurer Coach", "Not bad! I look forward to your performance, bro!");
            battleManager.StartCoroutine(battleManager.EndTutorialGame(true));
            playerWon = true;
            return true;
        }

        playerWon = false;
        return false;
    }

    // 6. 抽牌 (與 Knight 相同)
    public override bool CanDrawCards()
    {
        return (currentTutorialStep == KnightTutorialStep.FreePlay ||
                currentTutorialStep == KnightTutorialStep.Enemy_1_Nothing ||
                currentTutorialStep == KnightTutorialStep.Enemy_2_Scratch);
    }

    // -------------------------------------------------------------------
    // 教學狀態機 (Helper Methods)
    // -------------------------------------------------------------------

    public override void OnDialoguePanelClicked()
    {
        bool isInstruction = battleManager.IsDialogueInstructional();

        switch (currentTutorialStep)
        {
            case KnightTutorialStep.WaitForCleave:
            case KnightTutorialStep.WaitForThreefold:
            case KnightTutorialStep.WaitForSharpen:
            case KnightTutorialStep.WaitForSharpBlade:
            case KnightTutorialStep.WaitForDivineRadiance:
            case KnightTutorialStep.WaitForEndTurn1:
            case KnightTutorialStep.WaitForEndTurn2:
                if (isInstruction)
                {
                    Debug.LogWarning($"[KnightStrategy] OnDialoguePanelClicked: 點擊被忽略。正在等待遊戲動作 (目前狀態: {currentTutorialStep})。");
                    return;
                }
                break;

            case KnightTutorialStep.FreePlay:
                Debug.Log($"[KnightStrategy] OnDialoguePanelClicked: 點擊有效 (FreePlay)。清除對話框。");
                battleManager.ClearTutorialDialogue();
                return;
        }

        Debug.Log($"[KnightStrategy] OnDialoguePanelClicked: 點擊有效。推進對話 (目前狀態: {currentTutorialStep})。");
        AdvanceTutorial(currentTutorialStep);
    }

    private void AdvanceTutorial(KnightTutorialStep requiredStep)
    {
        if (currentTutorialStep != requiredStep) return;

        switch (currentTutorialStep)
        {
            // --- 初始對話 (點擊螢幕推進) ---
            case KnightTutorialStep.Start_0_Intro:
                currentTutorialStep = KnightTutorialStep.Start_1_PlayerCheck;
                battleManager.ShowTutorialDialogue("Player", "Let's check if I'm prepared first.");
                break;
            case KnightTutorialStep.Start_1_PlayerCheck:
                currentTutorialStep = KnightTutorialStep.Start_2_PlayerCheck;
                battleManager.ShowTutorialDialogue("Player", "I don't want to be like those story protagonists who are missing everything at the start...");
                break;
            case KnightTutorialStep.Start_2_PlayerCheck:
                currentTutorialStep = KnightTutorialStep.Start_3_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "Here is all the basic information.");
                break;
            case KnightTutorialStep.Start_3_Rules:
                currentTutorialStep = KnightTutorialStep.Start_4_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "When any piece of armor on a character (including yourself) is broken, the opponent can deal damage to that character's HP.");
                break;
            case KnightTutorialStep.Start_4_Rules:
                currentTutorialStep = KnightTutorialStep.Start_5_Rules;
                battleManager.ShowTutorialDialogue("Narrator", "The victory goal in a normal game is to reduce the opponent's HP to below 0.");
                break;
            case KnightTutorialStep.Start_5_Rules:
                currentTutorialStep = KnightTutorialStep.Start_6_WinCon;
                battleManager.ShowTutorialDialogue("Narrator", "But there are other ways to win awaiting players to explore.\nThis tutorial is won simply by destroying the armor.");
                break;
            case KnightTutorialStep.Start_6_WinCon:
                currentTutorialStep = KnightTutorialStep.Start_7_Ready;
                battleManager.ShowTutorialDialogue("Player", "Great, looks like I can start.");
                break;
            case KnightTutorialStep.Start_7_Ready:
                currentTutorialStep = KnightTutorialStep.Start_8_CleaveIntro;
                battleManager.ShowTutorialDialogue("Player", "If I had to say what I learned best from the military academy, it's attacking.");
                break;
            case KnightTutorialStep.Start_8_CleaveIntro:
                currentTutorialStep = KnightTutorialStep.Start_9_CleaveIntro;
                battleManager.ShowTutorialDialogue("Player", "I'm not bragging, but when everyone else was learning 'Straight Attack', I learned 'Cleave' first.");
                break;
            case KnightTutorialStep.Start_9_CleaveIntro:
                currentTutorialStep = KnightTutorialStep.WaitForCleave;
                battleManager.ShowTutorialDialogue("Narrator", "(Click Cleave, then click the Target's Armor to deal damage)", true);
                battleManager.StartPlayerTurnInternal();
                break;

            case KnightTutorialStep.WaitForCleave:
                break;

            case KnightTutorialStep.Cleave_1_After:
                currentTutorialStep = KnightTutorialStep.Cleave_2_ThreefoldIntro;
                battleManager.ShowTutorialDialogue("Player", "That being said, it doesn't seem very necessary this time...");
                break;
            case KnightTutorialStep.Cleave_2_ThreefoldIntro:
                currentTutorialStep = KnightTutorialStep.Cleave_3_ThreefoldIntro;
                battleManager.ShowTutorialDialogue("Player", "The defense instructor always said, 'Defense is the best offense.'");
                break;

            case KnightTutorialStep.Cleave_3_ThreefoldIntro:
                currentTutorialStep = KnightTutorialStep.Cleave_4_ThreefoldPreWard;
                battleManager.ShowTutorialDialogue("Player", "Although the opponent is just a target, let's use it anyway...");
                break;
            case KnightTutorialStep.Cleave_4_ThreefoldPreWard:
                currentTutorialStep = KnightTutorialStep.WaitForThreefold;
                battleManager.ShowTutorialDialogue("Player", "(Click Threefold Ward, then click the Play Area to pre-block the enemy's attack)", true);
                break;

            case KnightTutorialStep.WaitForThreefold:
                break;

            case KnightTutorialStep.Threefold_1_After:
                currentTutorialStep = KnightTutorialStep.Threefold_2_Observe;
                battleManager.ShowTutorialDialogue("Player", "That instructor also taught: 'Observe the enemy, then act.'");
                break;
            case KnightTutorialStep.Threefold_2_Observe:
                currentTutorialStep = KnightTutorialStep.Threefold_3_Observe;
                battleManager.ShowTutorialDialogue("Player", "I've seen him 'Ora Ora' without any hesitation...");
                break;
            case KnightTutorialStep.Threefold_3_Observe:
                currentTutorialStep = KnightTutorialStep.WaitForEndTurn1;
                battleManager.ShowTutorialDialogue("Player", "(Press End Turn to end the turn)", true);
                break;
            case KnightTutorialStep.WaitForEndTurn1:
                break;

            case KnightTutorialStep.Enemy_1_Nothing:
                currentTutorialStep = KnightTutorialStep.Turn2_0_SharpenIntro;
                AdvanceTutorial(currentTutorialStep);
                break;

            case KnightTutorialStep.Turn2_0_SharpenIntro:
                currentTutorialStep = KnightTutorialStep.Turn2_1_SharpenIntro;
                battleManager.ShowTutorialDialogue("Player", "The equipment instructor always said, 'To do a good job, one must first sharpen one's tools.'");
                break;

            case KnightTutorialStep.Turn2_1_SharpenIntro:
                currentTutorialStep = KnightTutorialStep.Turn2_2_SharpenInstruction;
                battleManager.ShowTutorialDialogue("Player", "I'm tired of hearing it, but thanks to that, I still remember to enhance my weapon.");
                break;
            case KnightTutorialStep.Turn2_2_SharpenInstruction:
                currentTutorialStep = KnightTutorialStep.WaitForSharpen;
                battleManager.ShowTutorialDialogue("Player", "(Click Sharpen, then click Sharp Blade to enhance it)", true);
                break;

            case KnightTutorialStep.WaitForSharpen:
                break;

            case KnightTutorialStep.Sharpen_1_After:
                currentTutorialStep = KnightTutorialStep.Sharpen_2_BladeIntro;
                battleManager.ShowTutorialDialogue("Player", "How many throwing knives did I use back then...");
                break;
            case KnightTutorialStep.Sharpen_2_BladeIntro:
                currentTutorialStep = KnightTutorialStep.Sharpen_3_BladeIntro;
                battleManager.ShowTutorialDialogue("Player", "Forget it. Can you count how many loaves of bread you've eaten in your life?");
                break;
            case KnightTutorialStep.Sharpen_3_BladeIntro:
                currentTutorialStep = KnightTutorialStep.WaitForSharpBlade;
                battleManager.ShowTutorialDialogue("Player", "(Click Sharp Blade, then click the opponent to attack)", true);
                break;
            case KnightTutorialStep.WaitForSharpBlade:
                break;

            case KnightTutorialStep.Blade_1_After:
                currentTutorialStep = KnightTutorialStep.Blade_2_EndTurn;
                battleManager.ShowTutorialDialogue("Player", "Let's just keep going like this.");
                break;
            case KnightTutorialStep.Blade_2_EndTurn:
                currentTutorialStep = KnightTutorialStep.WaitForEndTurn2;
                battleManager.ShowTutorialDialogue("Player", "(Press End Turn to end the turn)", true);
                break;
            case KnightTutorialStep.WaitForEndTurn2:
                currentTutorialStep = KnightTutorialStep.Enemy_2_Scratch;
                break;

            case KnightTutorialStep.Enemy_2_Scratch:
                currentTutorialStep = KnightTutorialStep.Turn3_0_PostScratch;
                AdvanceTutorial(currentTutorialStep);
                break;

            case KnightTutorialStep.Turn3_0_PostScratch:
                currentTutorialStep = KnightTutorialStep.Turn3_1_CleanseIntro;
                battleManager.ShowTutorialDialogue("Player", "Seriously? This target is hacking?");
                break;

            case KnightTutorialStep.Turn3_1_CleanseIntro:
                currentTutorialStep = KnightTutorialStep.Turn3_2_CleanseInstruction;
                battleManager.ShowTutorialDialogue("Player", "Quick, do as the survival instructor said, cleanse myself.");
                break;
            case KnightTutorialStep.Turn3_2_CleanseInstruction:
                currentTutorialStep = KnightTutorialStep.WaitForDivineRadiance;
                battleManager.ShowTutorialDialogue("Player", "(Use Divine Radiance to remove the status effect)", true);
                break;

            case KnightTutorialStep.WaitForDivineRadiance:
                break;

            case KnightTutorialStep.Divine_1_After:
                currentTutorialStep = KnightTutorialStep.FreePlay;
                battleManager.ShowTutorialDialogue("Narrator", "Use what you have learned to defeat the enemy!");
                break;

            case KnightTutorialStep.FreePlay:
                battleManager.ClearTutorialDialogue();
                break;

            default:
                battleManager.ClearTutorialDialogue();
                break;
        }
    }

    // ▼▼▼ 【修正 CS0534 錯誤】 新增遺失的函式 ▼▼▼
    public override string GetCurrentTutorialStepName()
    {
        return currentTutorialStep.ToString();
    }

    public override void SetCurrentTutorialStep(string stepName)
    {
        if (Enum.TryParse(stepName, out KnightTutorialStep newStep))
        {
            currentTutorialStep = newStep;
            Debug.Log($"[AdventurerStrategy] SetCurrentTutorialStep:  succesvol ingesteld op {currentTutorialStep}");
        }
        else
        {
            Debug.LogError($"[AdventurerStrategy] SetCurrentTutorialStep: Poging om stap in te stellen op '{stepName}' mislukt!");
            currentTutorialStep = KnightTutorialStep.FreePlay; // 安全後備
        }
    }
    // ▲▲▲ 【修正結束】 ▲▲▲
}