// 檔案路徑: Assets/Scripts/Character.cs
using UnityEngine;
using System.Collections;

public class Character : MonoBehaviour
{
    [Header("數值設定檔")]
    public RPGStatsData statsData;

    [Header("角色基礎數值")]
    public string characterName = "Default Name";
    public int initialMaxHp = 100;
    public int initialAttack = 0;
    public DamageType attackDamageType = DamageType.Normal;

    [Header("建立盔甲 (Initial Armor)")]
    public int initialHelmetArmor = 50;
    public int initialArmor = 50;
    public int initialGauntletsArmor = 50;
    public int initialLegArmor = 50;

    public CharacterStats stats;
    private SpriteRenderer spriteRenderer;
    private bool isPlayer = false;

    void Awake()
    {
        stats = new CharacterStats();
        spriteRenderer = GetComponentInChildren<SpriteRenderer>(true);
        stats.OnDied += HandleDeath;
    }

    public void InitializeAsPlayer(string playerName)
    {
        this.isPlayer = true;
        this.characterName = playerName;
        this.gameObject.name = playerName;

        if (statsData == null) { stats.Initialize(null, initialMaxHp, initialAttack, this.characterName); }
        else { stats.Initialize(statsData, initialMaxHp, initialAttack, this.characterName); }

        stats.EquipArmor(ArmorPart.Helmet, initialHelmetArmor);
        stats.EquipArmor(ArmorPart.Armor, initialArmor);
        stats.EquipArmor(ArmorPart.Gauntlets, initialGauntletsArmor);
        stats.EquipArmor(ArmorPart.LegArmor, initialLegArmor);

        if (spriteRenderer != null)
        {
            spriteRenderer.sortingLayerName = "Gameplay";
            spriteRenderer.sortingOrder = 10;
        }
    }

    public void InitializeFromData(EnemyData data)
    {
        this.isPlayer = false;

        if (data == null) { return; }
        SpriteRenderer sr = GetComponentInChildren<SpriteRenderer>(true);
        if (sr != null)
        {
            if (data.characterSprite != null) { sr.sprite = data.characterSprite; }
            sr.sortingLayerName = "Gameplay";
            sr.sortingOrder = 5;
        }
        this.characterName = data.characterName;
        this.gameObject.name = data.characterName;
        this.attackDamageType = data.attackDamageType;
        if (data.statsData == null) { stats.Initialize(null, data.initialMaxHp, data.initialAttack, this.characterName); }
        else { stats.Initialize(data.statsData, data.initialMaxHp, data.initialAttack, this.characterName); }
        stats.EquipArmor(ArmorPart.Helmet, data.initialHelmetArmor);
        stats.EquipArmor(ArmorPart.Armor, data.initialArmor);
        stats.EquipArmor(ArmorPart.Gauntlets, data.initialGauntletsArmor);
        stats.EquipArmor(ArmorPart.LegArmor, data.initialLegArmor);
    }

    public void SetCharacterSprite(Sprite sprite)
    {
        if (spriteRenderer == null)
        {
            spriteRenderer = GetComponentInChildren<SpriteRenderer>(true);
        }
        if (spriteRenderer != null && sprite != null)
        {
            spriteRenderer.sprite = sprite;
        }
    }

    // ▼▼▼ 【修改】 移除 damageSource 參數，回傳傷害值 ▼▼▼
    public int PerformAttack(Character target)
    {
        if (stats == null) { return 0; }
        if (target?.stats == null || target.stats.isDead) return 0;

        if (BattleManager.Instance != null && BattleManager.Instance.CheckForAttackNegation(target))
        {
            return 0; // 傷害被免疫
        }

        return target.stats.TakeDamage(this.stats.attackValue, this.attackDamageType, ArmorPart.Armor);
    }
    // ▲▲▲ 【修改結束】 ▲▲▲

    public void UseItem(int itemId, object target = null)
    {
        if (stats == null) { return; }
        if (itemId == 1 && BattleManager.Instance != null)
        {
            stats.Heal(20);
            BattleManager.Instance.LogAction($"{characterName} used Healing Potion (+20 HP).");
        }
        if (BattleManager.Instance != null) BattleManager.Instance.UpdateBattleUI();
    }

    public void OnTurnStart()
    {
        if (stats != null) { stats.UpdateStatuses(); }
        if (BattleManager.Instance != null) { BattleManager.Instance.UpdateBattleUI(); }
    }

    private void HandleDeath()
    {
        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.LogAction($"{characterName} is defeated!");
        }

        if (!isPlayer)
        {
            EnemyAI ai = GetComponent<EnemyAI>();
            if (ai != null)
            {
                ai.enabled = false;
            }

            if (BattleManager.Instance != null)
            {
                BattleManager.Instance.OnEnemyDied(this);
            }
        }

        StartCoroutine(FadeOutAndDestroyCoroutine(3.0f));
    }

    private IEnumerator FadeOutAndDestroyCoroutine(float duration)
    {
        if (spriteRenderer == null)
        {
            spriteRenderer = GetComponentInChildren<SpriteRenderer>(true);
        }
        if (spriteRenderer == null)
        {
            Destroy(gameObject);
            yield break;
        }

        float timer = 0f;
        Color startColor = spriteRenderer.color;
        Color endColor = new Color(startColor.r, startColor.g, startColor.b, 0f);

        while (timer < duration)
        {
            timer += Time.deltaTime;
            spriteRenderer.color = Color.Lerp(startColor, endColor, timer / duration);
            yield return null;
        }

        spriteRenderer.color = endColor;
        Destroy(gameObject);
    }
}