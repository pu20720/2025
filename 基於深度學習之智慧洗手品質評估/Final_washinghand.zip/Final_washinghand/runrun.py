import torch
from ultralytics import YOLO  # 🚀 替換原有的模型和工具導入
import cv2
import numpy as np

# 注意：使用 ultralytics 框架時，您不再需要手動定義 letterbox 函式和 NMS 邏輯，
# 因為 YOLO 類會在內部處理所有預處理和後處理。
# 刪除原有的 letterbox 函式，因為 YOLOv10/ultralytics 內建處理

# --- 設定 ---
# 設定設備 (CPU 或 GPU)
# 設備選擇將由 YOLO 類自動處理
device = 'cuda:0' if torch.cuda.is_available() else 'cpu'

# 載入模型 (使用 YOLOv10 格式)
# 請將 'yolov10n.pt' 替換成您自己的 YOLOv10 模型路徑，例如 'best.pt'
model_path = 'best.pt'  # 您的模型路徑
# 確保您的模型已經是 YOLOv10/YOLOv8 格式，否則需要轉換
model = YOLO(model_path)
model.to(device)  # 將模型移到指定設備

# 類別名稱與顏色 (從模型中獲取或手動定義)
# 假設您的模型只有三個類別：
class_names = ['left', 'right', 'all']
colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255)]  # 分別為紅、綠、藍
# 如果模型載入後有內建的 class names，可以使用 model.names
# 假設您的類別 ID 從 0 開始

# 信心水準閾值
CONF_THRESHOLD = 0.4

cap = cv2.VideoCapture(0)

# 設置目標影像尺寸 (YOLOv10 預設通常是 640)
IMG_SIZE = 640

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # --- 推論 ---
    # 使用 model.predict 進行推論，它會自動處理影像預處理、推論和 NMS
    results = model.predict(
        source=frame,
        imgsz=IMG_SIZE,
        conf=CONF_THRESHOLD,
        iou=0.45,
        device=device,
        verbose=False  # 禁用詳細輸出
    )

    # 取得第一個結果 (因為我們只處理一幀影像)
    if results:
        res = results[0]

        # 繪製結果
        h, w = frame.shape[:2]

        # 遍歷所有的偵測結果
        # results.boxes 包含所有邊界框信息
        for box in res.boxes:
            # 獲取邊界框坐標 (xyxy 格式)
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())

            # 獲取信心水準和類別 ID
            conf = box.conf.item()
            cls = int(box.cls.item())

            # 取得類別名稱與顏色
            cls_name = class_names[cls] if cls < len(class_names) else f"Class {cls}"
            color = colors[cls % len(colors)]  # 根據類別選擇顏色

            # 繪製框與文字
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            label = f"{cls_name} {conf:.2f}"

            # 繪製文字 (確保文字不會超出頂部邊界)
            text_y = y1 - 10 if y1 > 20 else y2 + 20
            cv2.putText(frame, label, (x1, text_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

    # 顯示畫面
    cv2.imshow('YOLOv10 Detection (Ultralytics)', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()