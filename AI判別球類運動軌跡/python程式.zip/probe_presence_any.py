# probe_presence_any.py  -- 修正版（パーセンタイルでしきい値を推奨）
import cv2 as cv, numpy as np, argparse, csv, os, statistics as st

COURT_W, COURT_L = 6.10, 13.40
outer = np.array([[0,0],[COURT_W,0],[COURT_W,COURT_L],[0,COURT_L]], np.float32)

def rotate(img, m):
    if m=="none": return img
    tbl={"cw":cv.ROTATE_90_CLOCKWISE,"ccw":cv.ROTATE_90_COUNTERCLOCKWISE,"180":cv.ROTATE_180}
    return cv.rotate(img, tbl[m])

def to_img(H, pts):
    return cv.perspectiveTransform(pts.reshape(-1,1,2).astype(np.float32), H).reshape(-1,2)

def presence_score(img, Hm2i, thickness_px=5):
    Hh, Ww = img.shape[:2]
    poly = np.round(to_img(Hm2i, outer)).astype(np.int32)
    area = abs(cv.contourArea(poly))
    if area < 0.10 * Ww * Hh:   # コートが小さすぎる時は0
        return 0.0
    hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)
    # programming3_video_court_overlay.py と同じ（必要なら広げてOK）
    mask_w = cv.inRange(hsv, (0,0,200), (180,40,255))
    mask_y = cv.inRange(hsv, (15,60,150), (40,255,255))
    mask = cv.bitwise_or(mask_w, mask_y)

    stroke = np.zeros((Hh,Ww), np.uint8)
    cv.polylines(stroke, [poly], True, 255, thickness=thickness_px)
    on_line = cv.bitwise_and(mask, stroke)

    # ※「画面全体平均」方式 → 値がとても小さくなるのが正常
    return float(on_line.mean()/255.0)

def suggest_thresholds_from_percentiles(vals):
    """分布の四分位点から、ゆるめ/標準/きつめのしきい値を推奨"""
    if not vals:
        return 0.0, 0.0, 0.0
    v = np.array(vals, dtype=np.float64)
    p25 = np.percentile(v, 25)
    med = float(st.median(v))
    p75 = np.percentile(v, 75)
    eps = 1e-7  # すべて極小でもゼロ割回避
    lenient  = max(eps, 0.5*(p25 + med))   # 出やすい
    balanced = max(eps, 0.5*(med + p75))   # まずはコレ
    strict   = max(eps, 0.9*p75)           # 出にくい
    return float(lenient), float(balanced), float(strict)

def main():    #
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--H", required=True)
    ap.add_argument("--rotate", choices=["none","cw","ccw","180"], default="none")
    ap.add_argument("--max_frames", type=int, default=1000)
    ap.add_argument("--step", type=int, default=1, help="何フレームごとにサンプルするか")
    ap.add_argument("--thickness_px", type=int, default=5)
    ap.add_argument("--out_csv", default="presence_scores.csv")
    args = ap.parse_args()

    d = np.load(args.H)
    H = d.get("H_model2img", d.get("H", None))
    if H is None: raise SystemExit("NPZに H がありません（key: H または H_model2img）")

    cap = cv.VideoCapture(args.input)
    if not cap.isOpened(): raise SystemExit("動画が開けません: "+args.input)

    scores = []
    total = int(cap.get(cv.CAP_PROP_FRAME_COUNT)) or 0
    fidx = 0; taken = 0
    while taken < args.max_frames:
        cap.set(cv.CAP_PROP_POS_FRAMES, fidx)
        ok, frame = cap.read()
        if not ok: break
        img = rotate(frame, args.rotate)
        s = presence_score(img, H, thickness_px=args.thickness_px)
        scores.append((fidx, s))
        taken += 1
        fidx += args.step
        if fidx >= total and total>0: break
    cap.release()  #

    if not scores:
        print("[warn] サンプルが取れませんでした"); return

    vals = [s for _,s in scores]
    stats = dict(
        frames=len(vals),
        min=float(np.min(vals)), p05=float(np.percentile(vals,5)), p25=float(np.percentile(vals,25)),
        median=float(st.median(vals)), p75=float(np.percentile(vals,75)), p95=float(np.percentile(vals,95)),
        max=float(np.max(vals)), mean=float(np.mean(vals))
    )
    len_thr, bal_thr, str_thr = suggest_thresholds_from_percentiles(vals)

    # CSV保存
    os.makedirs(os.path.dirname(args.out_csv) or ".", exist_ok=True)
    with open(args.out_csv, "w", newline="", encoding="utf-8") as g:
        w = csv.writer(g); w.writerow(["frame","presence"]); w.writerows(scores)

    # 表示
    print("\n=== presence 計測結果 ===")
    for k in ["frames","min","p05","p25","median","p75","p95","max","mean"]:
        v = stats[k]
        print(f"{k:>7}: {v:.6f}" if isinstance(v,float) else f"{k:>7}: {v}")
    print("\n推奨しきい値（この動画用）：")
    print(f"  lenient : {len_thr:.6f}  （出やすい・誤描画やや増）")
    print(f"  balanced: {bal_thr:.6f}  （まずはコレから）")
    print(f"  strict  : {str_thr:.6f}  （出にくい・誤描画減）")

    print("\n例）本番コマンド（balanced）:")
    print(f'python programming3_video_court_overlay.py ^\n'
          f'  --input  "{args.input}" ^\n'
          f'  --output "C:\\badminton\\overlay_auto.mp4" ^\n'
          f'  --rotate {args.rotate} ^\n'
          f'  --H "{args.H}" ^\n'
          f'  --fourcc avc1 ^\n'
          f'  --presence_thresh {bal_thr:.6f} ^\n'
          f'  --reacquire_every 8 ^\n'
          f'  --thickness 4')
    print(f"\n保存: {args.out_csv}")

if __name__ == "__main__":
    main()