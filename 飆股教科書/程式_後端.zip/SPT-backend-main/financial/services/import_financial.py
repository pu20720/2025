import os
import logging
import requests
from dotenv import load_dotenv
from stocks.models import Stock
from django.conf import settings
from financial.models import Financial
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Tuple, List, Any, Iterable

logger = logging.getLogger(__name__)

# 不在 import 當下就決定 API_KEYS；改成 lazy + 可重載
_env_loaded = False
_API_KEYS: List[str] | None = None
_api_usage_count = 0
_current_key_index = 0


def _ensure_env_loaded(force_reload: bool = False) -> None:
    """
    確保 .env 已載入到 os.environ
    - 預設僅第一次載入
    - 當外部流程（例如 subprocess）剛剛更新了 .env 時，可帶 force_reload=True 重新載入
    """
    global _env_loaded
    env_path = settings.BASE_DIR / '.env'
    if not _env_loaded or force_reload:
        # override=True 確保新值覆蓋舊的環境變數
        load_dotenv(env_path, override=True)
        _env_loaded = True
        logger.info(f'.env 已載入（override={True}）: {env_path}')


def _load_api_keys(force_reload: bool = False) -> List[str]:
    """
    從環境變數讀取多組 FinMind API key
    支援在執行中要求重載（當 .env 被更新後）
    """
    global _API_KEYS
    if _API_KEYS is None or force_reload:
        _ensure_env_loaded(force_reload=force_reload)
        keys = [
            os.getenv('finmindkey1'),
            os.getenv('finmindkey2'),
            os.getenv('finmindkey3'),
            os.getenv('finmindkey4'),
        ]
        _API_KEYS = [k for k in keys if k]
        if not _API_KEYS:
            # 這裡不要在 import 階段就 raise，所以放在函式裡
            raise RuntimeError('沒有找到任何 finmindkey（請確認 .env 或系統環境變數）')
        logger.info(f'已載入 {len(_API_KEYS)} 組 FinMind API key')
    return _API_KEYS


_api_usage_count = 0
_current_key_index = 0


def get_token(force_reload: bool = False) -> str:
    """
    根據使用次數，循環切換 API key
    """
    global _api_usage_count, _current_key_index
    keys = _load_api_keys(force_reload=force_reload)

    _api_usage_count += 1
    if _api_usage_count > 580:
        _api_usage_count = 1
        _current_key_index = (_current_key_index + 1) % len(keys)
        logger.info(f'API key 切換至第 {_current_key_index + 1} 組')

    return keys[_current_key_index]


def import_financial_data(symbol: str, date: str) -> dict:
    """
    匯入財務資料主函式

    回傳：
    {
        "created": 10,
        "updated": 5,
        "skipped": 2,
        "total": 17
    }
    """
    try:
        # 抓取並處理資料
        basic_data = fetch_financial_data(symbol, date)
        assets_data = fetch_financial_assets(symbol, date)
        roe_data = fetch_financial_roe(basic_data, assets_data)

        # 整合所有資料
        rows = integrate_all_data(basic_data, roe_data, assets_data)
        # 儲存到資料庫
        result = save_to_database(rows, symbol)

        return result

    except Exception as e:
        logger.error(f'財務數據匯入失敗：{e}')
        raise RuntimeError('財務數據匯入失敗')


def filter_financial_data_by_type(json_data: dict, wanted_types: list[str]) -> dict:
    """
    從原始 JSON（包含 msg/status/data）中，篩出需要的 type，並保留原始結構格式
    """
    if not json_data or 'data' not in json_data:
        return json_data  # 原樣回傳，避免 None 或缺 key

    filtered_data = [
        item for item in json_data['data'] if item.get('type') in wanted_types
    ]

    # 保留 msg / status，但 data 改成篩過的
    return {**json_data, 'data': filtered_data}


def fetch_financial_data(symbol: str, date: str) -> dict:
    """
    擷取基本財務數據（營收、EPS、稅後淨利）

    資料來源：
    台灣證券交易所 OpenAPI - t187ap14_L
    """
    url = 'https://api.finmindtrade.com/api/v4/data'
    headers = {'Authorization': f'Bearer {get_token()}'}
    parameter = {
        'dataset': 'TaiwanStockFinancialStatements',
        'data_id': symbol,
        'start_date': date,
    }

    try:
        response = requests.get(url, headers=headers, params=parameter)
        response.raise_for_status()
        json_data = response.json()
        json_data = filter_financial_data_by_type(
            json_data, ['EPS', 'Revenue', 'IncomeAfterTaxes']
        )
        return json_data

    except requests.RequestException as e:
        logger.error(f'財務數據擷取失敗：{e}')
        raise RuntimeError('擷取基本財務數據失敗')


def _build_assets_index(assets_data: list) -> dict:
    """
    建立資產數據的複合索引
    """
    assets_by_key = {}
    for asset in assets_data:
        symbol = asset.get('stock_id')
        date = asset.get('date')
        type_name = asset.get('type')
        value = asset.get('value', 0)

        key = (symbol, date)
        if key not in assets_by_key:
            assets_by_key[key] = {}
        assets_by_key[key][type_name] = value

    return assets_by_key


def _calculate_single_roe(symbol: str, date: str, net_income: float, assets_data: dict):
    """
    計算單筆ROE數據
    """
    key = (symbol, date)

    if key not in assets_data:
        logger.warning(f'找不到股票 {symbol} 日期 {date} 的資產數據')
        return None

    total_assets = assets_data[key].get('TotalAssets', 0)
    liabilities = assets_data[key].get('Liabilities', 0)
    shareholders_equity = total_assets - liabilities

    if shareholders_equity == 0:
        logger.warning(f'股票 {symbol} 日期 {date} 的股東權益為零，無法計算ROE')
        return {
            'error': '股東權益為零，無法計算ROE',
        }

    roe = (net_income / shareholders_equity) * 100
    return {
        'stock_id': symbol,
        'date': date,
        'roe': round(roe, 4),
    }


def fetch_financial_roe(basic_json: dict, assets_json: dict):
    """
    計算財務ROE（股東權益報酬率）
    """
    try:
        # 驗證數據
        if not basic_json.get('data') or not assets_json.get('data'):
            logger.warning('基本財務數據或資產數據為空')
            return {'status': 'error', 'message': '數據為空', 'data': []}

        basic_data = basic_json['data']
        assets_data = assets_json['data']

        # 建立資產數據索引
        assets_index = _build_assets_index(assets_data)

        # 計算ROE
        roe_results = []
        for basic_item in basic_data:
            if basic_item.get('type') != 'IncomeAfterTaxes':
                continue

            symbol = basic_item.get('stock_id')
            date = basic_item.get('date')
            net_income = basic_item.get('value', 0)

            roe_data = _calculate_single_roe(symbol, date, net_income, assets_index)
            if roe_data:
                roe_results.append(roe_data)

        return roe_results

    except Exception as e:
        logger.error(f'ROE計算失敗：{e}')
        return []


def fetch_financial_assets(symbol: str, date: str) -> dict:
    """
    擷取財務資產數據（總資產、負債）

    資料來源：
    FinMind API - TaiwanStockBalanceSheet
    """
    url = 'https://api.finmindtrade.com/api/v4/data'
    headers = {'Authorization': f'Bearer {get_token()}'}
    parameter = {
        'dataset': 'TaiwanStockBalanceSheet',
        'data_id': symbol,
        'start_date': date,
    }

    try:
        response = requests.get(url, headers=headers, params=parameter)
        response.raise_for_status()
        json_data = response.json()
        json_data = filter_financial_data_by_type(
            json_data, ['TotalAssets', 'Liabilities']
        )
        return json_data

    except requests.RequestException as e:
        logger.error(f'資產數據擷取失敗：{e}')
        raise RuntimeError('擷取財務資產資料失敗')


def _to_year_quarter(date_str: str) -> Tuple[int, int]:
    """
    'YYYY-MM-DD' -> (year, quarter)
    """
    y, m, _ = date_str.split('-')
    m = int(m)
    if m <= 3:
        q = 1
    elif m <= 6:
        q = 2
    elif m <= 9:
        q = 3
    else:
        q = 4

    return int(y), q


def _q2(x) -> Decimal | None:
    """
    四捨五入至兩位小數（給 eps/roe）
    """
    if x is None:
        return None
    return Decimal(str(x)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def integrate_all_data(
    basic_json: dict,
    roe_data: list | dict,
    assets_json: dict,
) -> List[Dict[str, Any]]:
    """
    將 Basic / ROE / Assets 三塊資料整合成「每期一筆」的 rows（不碰資料庫）
    回傳欄位：year, quarter, eps, roe, revenue, net_income, assets, liabilities
    """
    basic_rows = (basic_json or {}).get('data', []) or []
    assets_rows = (assets_json or {}).get('data', []) or []
    # 兼容 list 與 {"data": [...]} 兩種寫法
    if isinstance(roe_data, dict):
        roe_rows = roe_data.get('data', []) or []
    else:
        roe_rows = roe_data or []

    periods: Dict[Tuple[int, int], Dict[str, Any]] = {}

    def ensure_period(date_str: str) -> Dict[str, Any]:
        y, q = _to_year_quarter(date_str)
        key = (y, q)
        if key not in periods:
            periods[key] = {'year': y, 'quarter': q}
        return periods[key]

    # Basic Data
    basic_map = {'EPS': 'eps', 'Revenue': 'revenue', 'IncomeAfterTaxes': 'net_income'}
    for r in basic_rows:
        if not r or 'date' not in r or 'type' not in r:
            continue
        p = ensure_period(r['date'])
        t = r.get('type')
        if t in basic_map:
            field = basic_map[t]
            val = r.get('value')
            if field == 'eps':
                p[field] = _q2(val)
            elif val is not None:
                p[field] = int(val)
            else:
                p[field] = None

    # Assets Data
    assets_map = {'TotalAssets': 'assets', 'Liabilities': 'liabilities'}
    for r in assets_rows:
        if not r or 'date' not in r or 'type' not in r:
            continue
        p = ensure_period(r['date'])
        t = r.get('type')
        if t in assets_map:
            field = assets_map[t]
            val = r.get('value')
            p[field] = int(val) if val is not None else None

    # ROE
    for r in roe_rows:
        if not r or 'date' not in r:
            continue
        p = ensure_period(r['date'])
        if 'roe' in r and r['roe'] is not None:
            p['roe'] = _q2(r['roe'])
        if 'net_income' in r and r['net_income'] is not None:
            p['net_income'] = int(r['net_income'])
        if 'total_assets' in r and r['total_assets'] is not None:
            p['assets'] = int(r['total_assets'])
        if 'liabilities' in r and r['liabilities'] is not None:
            p['liabilities'] = int(r['liabilities'])

    rows = list(periods.values())
    rows.sort(key=lambda d: (d['year'], d['quarter']))
    return rows


def save_to_database(rows: Iterable[Dict[str, Any]], stock) -> dict:
    """
    以 (stock, year, quarter) 為鍵 upsert
    - 缺少必要欄位的資料不存
    - 資料庫已有相同資料則不存

    回傳：
    {
        "created": 10,
        "updated": 5,
        "skipped": 2,
        "total": 17
    }
    """
    created = 0
    updated = 0
    skipped = 0
    total = 0

    stock = Stock.objects.get(symbol=stock)

    for r in rows:
        total += 1

        # 必要欄位檢查（可依需求調整檢查範圍）
        required_fields = [
            'eps',
            'roe',
            'revenue',
            'net_income',
            'assets',
            'liabilities',
        ]
        if any(r.get(f) is None for f in required_fields):
            skipped += 1
            continue

        # 查找資料庫是否已有完全相同的紀錄
        existing = Financial.objects.filter(
            stock_id=stock, year=r['year'], quarter=r['quarter']
        ).first()

        defaults = {
            'eps': r.get('eps'),
            'roe': r.get('roe'),
            'revenue': r.get('revenue'),
            'net_income': r.get('net_income'),
            'assets': r.get('assets'),
            'liabilities': r.get('liabilities'),
        }

        if existing:
            # 檢查內容是否相同（全部欄位值一致）
            same_data = all(getattr(existing, k) == v for k, v in defaults.items())
            if same_data:
                skipped += 1
                continue
            # 資料不同則更新
            for k, v in defaults.items():
                setattr(existing, k, v)
            existing.save(update_fields=list(defaults.keys()))
            updated += 1
        else:
            # 新增資料
            Financial.objects.create(
                stock_id=stock, year=r['year'], quarter=r['quarter'], **defaults
            )
            created += 1

    return {'created': created, 'updated': updated, 'skipped': skipped, 'total': total}
