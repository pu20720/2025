using System.Collections.Generic;
using UnityEngine;

public static class EnemyDatabase
{
    private static Dictionary<string, EnemyData> allEnemies = new Dictionary<string, EnemyData>();
    private static bool isInitialized = false;

    public static void Initialize(EnemyArtLibrary artLibrary, RPGStatsData defaultStatsData)
    {
        if (isInitialized) return;
        allEnemies.Clear();
        Dictionary<string, Sprite> art = new Dictionary<string, Sprite>();
        if (artLibrary != null)
        {
            foreach (var entry in artLibrary.enemyArtEntries)
                if (!art.ContainsKey(entry.enemyName)) art.Add(entry.enemyName, entry.enemySprite);
        }

        // ... (C 級敵人保持不變) ...
        CreateStandardEnemy("Goblin", "C", 5000, EnemyAILogic.SimpleAttack, defaultStatsData, art);
        CreateStandardEnemy("Target", "C", 100000, EnemyAILogic.TutorialTarget, defaultStatsData, art);
        CreateStandardEnemy("Morwen", "C", 10000, EnemyAILogic.MaddeningLogic, defaultStatsData, art, isMaddening: true);
        CreateStandardEnemy("Yantarlion", "C", 12000, EnemyAILogic.SpiderKingLogic, defaultStatsData, art, isSpiderKing: true);
        CreateStandardEnemy("Fenris", "C", 120000, EnemyAILogic.HowlerLogic, defaultStatsData, art, isHowler: true);

        // ... (B 級敵人保持不變) ...
        CreateStandardEnemy("Killer", "B", 15000, EnemyAILogic.HeavyHitter, defaultStatsData, art, dmgType: DamageType.Pierce);
        CreateStandardEnemy("Frederick", "B", 200000, EnemyAILogic.FrederickLogic, defaultStatsData, art, isFrederick: true);
        CreateStandardEnemy("Dio Brando", "B", 120000, EnemyAILogic.DioLogic, defaultStatsData, art, isDio: true);
        CreateStandardEnemy("Amber", "B", 150000, EnemyAILogic.CalamityLogic, defaultStatsData, art, isCalamity: true);
        CreateStandardEnemy("Mary", "B", 180000, EnemyAILogic.BloodyLogic, defaultStatsData, art, isBloody: true);
        CreateStandardEnemy("Julius", "B", 100000, EnemyAILogic.CaesarLogic, defaultStatsData, art, isCaesar: true);
        CreateStandardEnemy("Grog", "B", 120000, EnemyAILogic.GargantuanLogic, defaultStatsData, art, isGargantuan: true);
        CreateStandardEnemy("Carnivorous Rex", "B", 120000, EnemyAILogic.BloomLogic, defaultStatsData, art, isBloom: true);
        CreateStandardEnemy("Despair Knight", "B", 120000, EnemyAILogic.DespairLogic, defaultStatsData, art, isDespair: true);
        CreateStandardEnemy("Kai", "B", 120000, EnemyAILogic.ShadowLogic, defaultStatsData, art, isShadow: true);
        CreateStandardEnemy("Phantom", "B", 120000, EnemyAILogic.WhisperLogic, defaultStatsData, art, isWhisper: true);

        // ... (A 級與 S 級保持不變) ...
        CreateStandardEnemy("Assassin", "A", 30000, EnemyAILogic.TutorialAssassinHard, defaultStatsData, art, dmgType: DamageType.Pierce);
        CreateStandardEnemy("Garroth", "A", 400000, EnemyAILogic.GarrothLogic, defaultStatsData, art, overrideAtk: 18);
        CreateStandardEnemy("Verminus", "A", 400000, EnemyAILogic.VerminusLogic, defaultStatsData, art);
        CreateStandardEnemy("The Darkborn", "A", 400000, EnemyAILogic.HeavyHitter, defaultStatsData, art, isAbysmal: true, overrideAtk: 80, overrideArmor: 300);
        CreateStandardEnemy("Anna", "A", 260000, EnemyAILogic.Debuffer, defaultStatsData, art);
        CreateStandardEnemy("Li Huowang", "A", 320000, EnemyAILogic.Debuffer, defaultStatsData, art);
        CreateStandardEnemy("Zurg", "A", 200000, EnemyAILogic.HeavyHitter, defaultStatsData, art, overrideArmor: 375);
        CreateStandardEnemy("Kaien", "A", 200000, EnemyAILogic.SimpleAttack, defaultStatsData, art);
        CreateStandardEnemy("Evil Dragon", "S", 1800000, EnemyAILogic.HeavyHitter, defaultStatsData, art, overrideArmor: 500);
        CreateStandardEnemy("Assassin Leader", "S", 1000000, EnemyAILogic.TutorialAssassinHard, defaultStatsData, art, overrideArmor: 400);

        CreateMechanicalEnemy("Aurelion", 400000, 30, defaultStatsData, art);
        CreateMechanicalEnemy("Deus Ex Machina", 2600000, 50, defaultStatsData, art, DamageType.True, overrideArmor: 80000);

        // =========================================================
        // 6. NPC (修正 Plague Doctor 數值)
        // =========================================================
        // ▼▼▼ 【修正】HP 改為 50 ▼▼▼
        allEnemies.Add("Plague Doctor", new EnemyData
        {
            characterName = "Plague Doctor",
            statsData = defaultStatsData,
            initialMaxHp = 50,
            initialAttack = 0,
            initialHelmetArmor = 0,
            initialArmor = 0,
            initialGauntletsArmor = 0,
            initialLegArmor = 0,
            isPlagueDoctor = true,
            aiLogic = EnemyAILogic.Passive,
            characterSprite = art.ContainsKey("Plague Doctor") ? art["Plague Doctor"] : null
        });
        // ▲▲▲ 修正結束 ▲▲▲

        isInitialized = true;
    }

    // (保留原本的 CreateStandardEnemy 與 CreateMechanicalEnemy 方法，內容不變)
    private static void CreateStandardEnemy(string name, string grade, int reward, EnemyAILogic ai, RPGStatsData stats, Dictionary<string, Sprite> art, DamageType dmgType = DamageType.Normal, int overrideAtk = -1, int overrideArmor = -1,
        bool isHowler = false, bool isSpiderKing = false, bool isDio = false, bool isCalamity = false, bool isBloody = false,
        bool isCaesar = false, bool isGargantuan = false, bool isBloom = false, bool isDespair = false, bool isShadow = false,
        bool isWhisper = false, bool isAbysmal = false, bool isMaddening = false, bool isFrederick = false)
    {
        int hp = reward / 100;
        int baseAtk = 10;
        int baseArmor = 100;

        switch (grade)
        {
            case "S": baseAtk = 40; baseArmor = 250; break;
            case "A": baseAtk = 30; baseArmor = 250; break;
            case "B": baseAtk = 20; baseArmor = 200; break;
            case "C": baseAtk = 10; baseArmor = 100; break;
        }

        int finalAtk = (overrideAtk != -1) ? overrideAtk : baseAtk;
        int finalArmor = (overrideArmor != -1) ? overrideArmor : baseArmor;

        allEnemies.Add(name, new EnemyData
        {
            characterName = name,
            statsData = stats,
            initialMaxHp = hp,
            initialAttack = finalAtk,
            attackDamageType = dmgType,
            initialHelmetArmor = finalArmor,
            initialArmor = finalArmor,
            initialGauntletsArmor = finalArmor,
            initialLegArmor = finalArmor,
            aiLogic = ai,
            characterSprite = art.ContainsKey(name) ? art[name] : null,
            isHowler = isHowler,
            isSpiderKing = isSpiderKing,
            isDio = isDio,
            isCalamity = isCalamity,
            isBloody = isBloody,
            isCaesar = isCaesar,
            isGargantuan = isGargantuan,
            isBloom = isBloom,
            isDespair = isDespair,
            isShadow = isShadow,
            isWhisper = isWhisper,
            isAbysmal = isAbysmal,
            isMaddening = isMaddening,
            isFrederick = isFrederick
        });
    }

    private static void CreateMechanicalEnemy(string name, int reward, int atk, RPGStatsData stats, Dictionary<string, Sprite> art, DamageType dmgType = DamageType.Pierce, int overrideArmor = -1)
    {
        int armorVal = (overrideArmor != -1) ? overrideArmor : (reward / 100);
        allEnemies.Add(name, new EnemyData
        {
            characterName = name,
            statsData = stats,
            initialMaxHp = 1,
            initialAttack = atk,
            attackDamageType = dmgType,
            initialHelmetArmor = armorVal,
            initialArmor = armorVal,
            initialGauntletsArmor = armorVal,
            initialLegArmor = armorVal,
            aiLogic = EnemyAILogic.SimpleAttack,
            characterSprite = art.ContainsKey(name) ? art[name] : null,
            isMechanical = true
        });
    }

    public static EnemyData GetEnemyDataByName(string name) => allEnemies.ContainsKey(name) ? allEnemies[name] : null;
}