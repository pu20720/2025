using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class ShopManager : MonoBehaviour
{
    [Header("Settings")]
    public int startingMoney = 9999;
    public int maxRefreshes = 3;

    [Header("Default Icon")]
    public Sprite defaultIcon;

    [Header("UI References")]
    public GameObject cardPrefab;
    public Transform[] spawnPoints;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI refreshText;

    [Header("Buttons")]
    public Button refreshButton;
    public Button confirmBuyButton;
    public Button departButton;

    private List<ShopCardData> poolWhite = new List<ShopCardData>();
    private List<ShopCardData> poolGreen = new List<ShopCardData>();
    private List<ShopCardData> poolBlue = new List<ShopCardData>();
    private List<ShopCardData> poolGold = new List<ShopCardData>();
    private List<ShopCardData> currentShopInventory = new List<ShopCardData>();

    private int currentMoney;
    private int remainingRefreshes;
    private ShopCardDisplay selectedCardDisplay;

    private EquipmentSlot[] slots = { EquipmentSlot.Helmet, EquipmentSlot.Armor, EquipmentSlot.Gauntlets, EquipmentSlot.LegArmor };

    // ▼▼▼ 【修正】改在 Awake 綁定，保證按鈕功能一定會生效 ▼▼▼
    void Awake()
    {
        if (departButton != null)
        {
            departButton.onClick.RemoveAllListeners();
            departButton.onClick.AddListener(OnDepartClicked);
            Debug.Log("[ShopManager] Depart 按鈕綁定成功！");
        }
        else
        {
            Debug.LogError("[ShopManager] 嚴重錯誤：Depart Button 沒在 Inspector 中綁定！");
        }

        if (refreshButton != null)
            refreshButton.onClick.AddListener(() => RefreshShop(false));

        if (confirmBuyButton != null)
            confirmBuyButton.onClick.AddListener(BuySelectedCard);
    }

    void Start()
    {
        currentMoney = startingMoney;
        remainingRefreshes = maxRefreshes;
        UpdateUI();

        // 即使這裡生成報錯，也不會影響上面的按鈕綁定
        GenerateSimulatedData();
        RefreshShop(true);
    }

    // ▼▼▼ 【核心】出發邏輯 + 詳細除錯 ▼▼▼
    void OnDepartClicked()
    {
        Debug.Log("[ShopManager] Depart 按鈕被點擊了！正在檢查條件...");

        // 1. 檢查 QuestManager 是否存在
        if (QuestManager.Instance == null)
        {
            Debug.LogError("[ShopManager] 找不到 QuestManager！請確認您是從 Adventurer 場景開始遊戲的。");
            return;
        }

        // 2. 檢查是否有接任務
        if (QuestManager.Instance.currentAcceptedQuest == null)
        {
            Debug.LogWarning("[ShopManager] QuestManager 存在，但 'currentAcceptedQuest' 是空的。您可能沒按 Accept 就跳過來了？");
            return;
        }

        QuestData quest = QuestManager.Instance.currentAcceptedQuest;

        Debug.Log($"[ShopManager] 條件符合！前往戰鬥。\n目標: {quest.title} (Enemy: {quest.targetEnemyName})");

        // 3. 設定分支與轉場
        ConversationManager.chosenBranch = "Quest";
        SceneManager.LoadScene("Battle");
    }
    // ▲▲▲ 【修正結束】 ▲▲▲

    void GenerateSimulatedData()
    {
        int price = 1;
        GenerateTier(poolWhite, CardRarity.White, Color.white, 16, 8, ref price);
        GenerateTier(poolGreen, CardRarity.Green, Color.green, 8, 4, ref price);

        for (int i = 0; i < 2; i++)
        {
            ItemData item = CreateCard("Blue Card " + (i + 1), Color.cyan);
            poolBlue.Add(new ShopCardData(price++, CardRarity.Blue, item));
        }

        Color lightBlue = new Color(0.4f, 0.8f, 1f);
        CreateSet(poolBlue, CardRarity.Blue, lightBlue, "Sky Set", "Set_A", ref price);

        Color darkBlue = new Color(0.0f, 0.0f, 0.6f);
        CreateSet(poolBlue, CardRarity.Blue, darkBlue, "Deep Set", "Set_B", ref price);

        for (int i = 0; i < 2; i++)
        {
            ItemData item = CreateCard("Gold Card " + (i + 1), Color.yellow);
            poolGold.Add(new ShopCardData(price++, CardRarity.Gold, item));
        }
        CreateSet(poolGold, CardRarity.Gold, Color.yellow, "Legendary", "Set_Gold", ref price);
    }

    void GenerateTier(List<ShopCardData> pool, CardRarity rarity, Color color, int cardCount, int equipPerSlot, ref int price)
    {
        for (int i = 0; i < cardCount; i++)
        {
            ItemData item = CreateCard($"{rarity} Card {i + 1}", color);
            pool.Add(new ShopCardData(price++, rarity, item));
        }
        for (int i = 0; i < equipPerSlot; i++)
        {
            foreach (EquipmentSlot slot in slots)
            {
                ItemData item = CreateEquipment($"{rarity} {slot}", color, slot, "");
                pool.Add(new ShopCardData(price++, rarity, item));
            }
        }
    }

    void CreateSet(List<ShopCardData> pool, CardRarity rarity, Color color, string setName, string setId, ref int price)
    {
        foreach (EquipmentSlot slot in slots)
        {
            ItemData item = CreateEquipment($"{setName} {slot}", color, slot, setId);
            item.description = $"Part of {setName}.\nCollect all 4 for bonus!";
            pool.Add(new ShopCardData(price++, rarity, item));
        }
    }

    ItemData CreateCard(string name, Color c)
    {
        ItemData item = ScriptableObject.CreateInstance<ItemData>();
        item.itemID = name.GetHashCode();
        item.itemName = name;
        item.itemType = ItemType.Card;
        item.icon = defaultIcon;
        item.displayColor = c;
        return item;
    }

    ItemData CreateEquipment(string name, Color c, EquipmentSlot slot, string setId)
    {
        ItemData item = ScriptableObject.CreateInstance<ItemData>();
        item.itemID = name.GetHashCode();
        item.itemName = name;
        item.itemType = ItemType.Equipment;
        item.equipSlot = slot;
        item.setBonusId = setId;
        item.icon = defaultIcon;
        item.displayColor = c;
        return item;
    }

    public void RefreshShop(bool isFirstOpen)
    {
        if (!isFirstOpen)
        {
            if (remainingRefreshes <= 0) return;
            remainingRefreshes--;
            ReturnUnboughtCardsToPool();
        }
        selectedCardDisplay = null;
        ClearShopUI();

        List<ShopCardData> cardsToSpawn = new List<ShopCardData>();
        ExtractCards(poolGold, 1, cardsToSpawn);
        ExtractCards(poolBlue, 2, cardsToSpawn);
        ExtractCards(poolGreen, 3, cardsToSpawn);
        ExtractCards(poolWhite, 4, cardsToSpawn);
        ShuffleList(cardsToSpawn);
        SpawnCards(cardsToSpawn);
        UpdateUI();
    }

    void ExtractCards(List<ShopCardData> sourcePool, int count, List<ShopCardData> destination)
    {
        for (int i = 0; i < count; i++)
        {
            if (sourcePool.Count > 0)
            {
                int randomIndex = Random.Range(0, sourcePool.Count);
                destination.Add(sourcePool[randomIndex]);
                sourcePool.RemoveAt(randomIndex);
            }
        }
    }

    void SpawnCards(List<ShopCardData> cards)
    {
        currentShopInventory = new List<ShopCardData>(cards);
        int spawnLimit = Mathf.Min(cards.Count, spawnPoints.Length);
        for (int i = 0; i < spawnLimit; i++)
        {
            GameObject cardObj = Instantiate(cardPrefab, spawnPoints[i]);
            cardObj.transform.localPosition = Vector3.zero;
            RectTransform rect = cardObj.GetComponent<RectTransform>();
            if (rect != null) rect.sizeDelta = new Vector2(180f, 200f);
            ShopCardDisplay display = cardObj.GetComponent<ShopCardDisplay>();
            if (display != null) display.Setup(cards[i], this);
        }
    }

    public void SelectCard(ShopCardDisplay display)
    {
        if (selectedCardDisplay != null) selectedCardDisplay.SetSelected(false);
        selectedCardDisplay = display;
        selectedCardDisplay.SetSelected(true);
    }

    public void BuySelectedCard()
    {
        if (selectedCardDisplay == null) return;
        ShopCardData data = selectedCardDisplay.Data;
        if (currentMoney >= data.price)
        {
            currentMoney -= data.price;
            currentShopInventory.Remove(data);
            if (InventoryManager.Instance != null) InventoryManager.Instance.AddItem(data.itemRef);
            Destroy(selectedCardDisplay.gameObject);
            selectedCardDisplay = null;
            UpdateUI();
        }
    }

    void ReturnUnboughtCardsToPool()
    {
        foreach (var card in currentShopInventory)
        {
            switch (card.rarity)
            {
                case CardRarity.White: poolWhite.Add(card); break;
                case CardRarity.Green: poolGreen.Add(card); break;
                case CardRarity.Blue: poolBlue.Add(card); break;
                case CardRarity.Gold: poolGold.Add(card); break;
            }
        }
        currentShopInventory.Clear();
    }

    void ClearShopUI() { foreach (Transform point in spawnPoints) foreach (Transform child in point) Destroy(child.gameObject); }
    void ShuffleList<T>(List<T> list) { int n = list.Count; while (n > 1) { n--; int k = Random.Range(0, n + 1); T value = list[k]; list[k] = list[n]; list[n] = value; } }
    void UpdateUI() { if (moneyText != null) moneyText.text = $"Money: {currentMoney}"; if (refreshText != null) refreshText.text = $"Refreshes: {remainingRefreshes}"; if (refreshButton != null) refreshButton.interactable = (remainingRefreshes > 0); }
}