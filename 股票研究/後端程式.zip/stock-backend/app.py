from flask import Flask, request, jsonify
from flask_cors import CORS
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta, date, timezone
import requests
import os
import re
from dotenv import load_dotenv
load_dotenv() 

print(" FINMIND_TOKEN 已設定:", bool(os.getenv("FINMIND_TOKEN")))

def _yf_candidates(symbol: str):
    """
    回傳 yfinance 可能可用的代號清單。
    - 2330        -> ["2330.TW", "2330.TWO"]  （先試上市TW，失敗再試上櫃TWO）
    - 2330.TW/TWO -> ["2330.TW"] / ["2330.TWO"]
    - 其他像 AAPL -> ["AAPL"]
    """
    s = (symbol or "").strip().upper()
    m = re.match(r"^(\d{4})(?:\.(TW|TWO))?$", s)
    if m:
        code, suf = m.groups()
        return [f"{code}.{suf}"] if suf else [f"{code}.TW", f"{code}.TWO"]
    return [s]

app = Flask(__name__)
CORS(app)  # 允許前端跨域

# ---------------------------
# 工具：把 yfinance 代號轉為台股四碼
# e.g. 2330.TW -> 2330, 2603.TW -> 2603
# 若本來就是四碼(全數字)就直接回傳
# ---------------------------
def normalize_tw_id(symbol: str) -> str:
    if not symbol:
        return symbol
    symbol = symbol.strip().upper()
    m = re.match(r"^(\d{4})\.(TW|TWO)$", symbol)
    if m:
        return m.group(1)
    m2 = re.match(r"^(\d{4})$", symbol)
    if m2:
        return m2.group(1)
    # 若不是台股代碼，就原樣回傳，方便排錯
    return symbol

# ---------------------------
# EPS 抓取：預設往回 8 季
# 使用 FinMind TaiwanStockFinancialStatements (report_type=季報)
# ---------------------------
def fetch_eps_recent_quarters(stock_id: str, quarters: int = 8, token: str = ""):
    import pandas as pd
    from datetime import datetime

    url = "https://api.finmindtrade.com/api/v4/data"
    stock_id = normalize_tw_id(stock_id)
    finmind_token = os.getenv("FINMIND_TOKEN", token or "")

    params = {
        "dataset": "TaiwanStockFinancialStatements",
        "data_id": stock_id,
        "report_type": "季報",
        "start_date": "2010-01-01",
        "end_date": datetime.today().strftime("%Y-%m-%d"),
    }
    if finmind_token:
        params["token"] = finmind_token

    try:
        res = requests.get(url, params=params, timeout=30)
        res.raise_for_status()
        payload = res.json()
        data = payload.get("data", [])
        if not data:
            return pd.DataFrame()

        df = pd.DataFrame(data)

        # 只留 EPS 類欄位
        def is_eps_type(t: str) -> bool:
            if not isinstance(t, str):
                return False
            t_strip = t.strip()
            t_upper = t_strip.upper()
            if "EPS" in t_upper or "EARNINGSPERSHARE" in t_upper:
                return True
            return ("每股" in t_strip)

        df = df[df["type"].apply(is_eps_type)].copy()
        if df.empty:
            return pd.DataFrame()

        # 日期 & 數值
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        df = df.dropna(subset=["date"]).sort_values("date", ascending=False)

        def to_float_safe(x):
            try:
                return float(x)
            except Exception:
                return None
        df["eps"] = df["value"].apply(to_float_safe)

        # 公告月 → 年/季（全年覆蓋）
        def infer_year_season(d: pd.Timestamp):
            """
            修正：确保季度与日期对应关系正确。
            """
            m, y = d.month, d.year
            if 1 <= m <= 3:
                return y, 1  # Q1: 1月到3月
            elif 4 <= m <= 6:
                return y, 2  # Q2: 4月到6月
            elif 7 <= m <= 9:
                return y, 3  # Q3: 7月到9月
            else:
                return y, 4  # Q4: 10月到12月   

        ys = df["date"].apply(infer_year_season)
        df["year"] = ys.apply(lambda t: t[0])
        df["season"] = ys.apply(lambda t: t[1])

        df = df.dropna(subset=["year", "season"])

        # 若同一季有多種 EPS 欄位，做優先順序
        def type_rank(t: str) -> int:
            if not isinstance(t, str):
                return 999
            t = t.strip()
            if "基本" in t and "每股" in t:
                return 0
            tu = t.upper()
            if "EPS" in tu:
                return 1
            if "EARNINGSPERSHARE" in tu:
                return 2
            if "每股" in t:
                return 3
            return 9

        df["type_rank"] = df["type"].apply(type_rank)

        # 先依 年/季/日期，再依 type_rank
        df = df.sort_values(
            ["year", "season", "date", "type_rank"],
            ascending=[False, False, False, True]
        ).drop_duplicates(subset=["year", "season"], keep="first")

        # 取最近 N 季（新到舊）
        df = df.sort_values(["year", "season"], ascending=[False, False]).head(quarters)

        # 展示用季範圍
        def season_range(y, s):
            y = int(y); s = int(s)
            if s == 1: return f"{y}-01-01~{y}-03-31"
            if s == 2: return f"{y}-04-01~{y}-06-30"
            if s == 3: return f"{y}-07-01~{y}-09-30"
            if s == 4: return f"{y}-10-01~{y}-12-31"
            return ""

        df["range"] = df.apply(lambda r: season_range(r["year"], r["season"]), axis=1)

        return df.sort_values(["year", "season"], ascending=[False, False])[
            ["year", "season", "eps", "range"]
        ].reset_index(drop=True)

    except Exception as e:
        print(f"[EPS] {stock_id} 抓取失敗：{e}")
        return pd.DataFrame()

# ===========================
# 既有：收盤價折線圖資料
# ===========================
@app.route("/api/stock", methods=["POST"])
def get_stock_data():
    data = request.json
    symbol = data.get("symbol")
    start = data.get("start")
    end = data.get("end")

    if not symbol or not start or not end:
        return jsonify({"error": "請提供 symbol, start, end"}), 400

    try:
        end_date = datetime.strptime(end, "%Y-%m-%d") + timedelta(days=1)

        # 嘗試多個候選代號
        chosen = None
        stock = pd.DataFrame()
        for s in _yf_candidates(symbol):
            tmp = yf.download(s, start=start, end=end_date.strftime("%Y-%m-%d"))
            tmp = tmp.loc[start:end]
            if not tmp.empty:
                chosen = s
                stock = tmp
                break

        if stock.empty:
            return jsonify({"error": "查無資料"}), 404

        close_series = stock["Close"]
        if isinstance(close_series, pd.DataFrame):
            close_series = close_series.squeeze()

        response_data = {
            "symbol_used": chosen or symbol,
            "dates": stock.index.strftime("%Y-%m-%d").tolist(),
            "close_prices": close_series.round(2).tolist(),
        }
        return jsonify(response_data)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ===========================
# 既有：K 線
# ===========================
@app.route("/api/kline", methods=["POST"])
def get_kline_data():
    data = request.json
    symbol = data.get("symbol")
    start = data.get("start")
    end = data.get("end")

    if not symbol or not start or not end:
        return jsonify({"error": "請提供 symbol, start, end"}), 400

    try:
        end_dt = datetime.strptime(end, "%Y-%m-%d") + timedelta(days=1)

        chosen = None
        stock = pd.DataFrame()
        for s in _yf_candidates(symbol):
            tmp = yf.download(s, start=start, end=end_dt.strftime("%Y-%m-%d"))
            tmp = tmp.loc[start:end]
            if not tmp.empty:
                chosen = s
                stock = tmp
                break

        if stock.empty:
            return jsonify({"error": "查無資料"}), 404

        kline_data = []
        for dt_idx in stock.index:
            row = stock.loc[dt_idx]
            kline_data.append(
                {
                    "date": dt_idx.strftime("%Y-%m-%d"),
                    "open": float(row["Open"]),
                    "high": float(row["High"]),
                    "low": float(row["Low"]),
                    "close": float(row["Close"]),
                    "volume": int(row["Volume"]),
                }
            )

        return jsonify({"symbol_used": chosen or symbol, "data": kline_data})

    except Exception as e:
        print("❌ 錯誤：", e)
        return jsonify({"error": str(e)}), 500

# ===========================
# EPS API
# ===========================
@app.route("/api/eps", methods=["POST"])
def get_eps():
    body = request.json or {}
    stock_id = body.get("stock_id")
    if not stock_id:
        return jsonify({"error": "請提供 stock_id（如：2330 或 2330.TW）"}), 400
    quarters = int(body.get("quarters", 8))
    token = body.get("token", "")

    try:
        df_eps = fetch_eps_recent_quarters(stock_id, quarters=quarters, token=token)
        if df_eps.empty:
            return jsonify({"error": "查無 EPS 資料"}), 404

        items = df_eps[["year", "season", "eps", "range"]].to_dict(orient="records")
        return jsonify({"stock_id": normalize_tw_id(stock_id), "items": items})
    except Exception as e:
        return jsonify({"error": f"EPS 抓取發生錯誤：{str(e)}"}), 500

# ===========================
# 三大法人近 N 日（預設 20 日）
# 正確彙總 + 單位（股/張）+ 是否包含今日
# GET /api/inst?stock=2330&days=20&unit=lot&include_today=0
# ===========================
@app.get("/api/inst")
def get_institutional_flows():
    from collections import defaultdict

    raw = request.args.get("stock", "")
    stock_id = normalize_tw_id(raw)
    if not stock_id or not stock_id.isdigit():
        return jsonify({"error": "請提供正確的台股代號，例如 ?stock=2330"}), 400

    # 參數
    try:
        days = int(request.args.get("days", 20))
    except Exception:
        days = 20
    days = max(1, min(days, 365))
    unit = (request.args.get("unit", "lot") or "lot").lower()  # lot=張, share=股
    include_today = request.args.get("include_today", "0").lower() in ("1", "true", "yes")

    FINMIND_API = "https://api.finmindtrade.com/api/v4/data"
    FINMIND_TOKEN = os.getenv("FINMIND_TOKEN", "")

    # 多抓一些天，避開連假
    start_date = (date.today() - timedelta(days=days + 12)).isoformat()
    params = {
        "dataset": "TaiwanStockInstitutionalInvestorsBuySell",
        "data_id": stock_id,
        "start_date": start_date,
    }
    if FINMIND_TOKEN:
        params["token"] = FINMIND_TOKEN

    try:
        r = requests.get(FINMIND_API, params=params, timeout=20)
        r.raise_for_status()
        data = r.json().get("data", [])
    except Exception as e:
        return jsonify({"error": f"外部來源連線失敗：{e}"}), 502

    # 彙總（同日 3~4 筆 -> 一筆）
    by_date = defaultdict(lambda: {"foreign": 0.0, "it": 0.0, "dealer": 0.0})
    for it in data:
        d = it.get("date")
        nm = str(it.get("name") or "").lower()
        buy = float(it.get("buy", 0) or 0)
        sell = float(it.get("sell", 0) or 0)
        net = it.get("buy_sell", None)
        try:
            net = float(net) if net is not None else (buy - sell)
        except Exception:
            net = buy - sell

        if "foreign" in nm:
            by_date[d]["foreign"] += net
        elif "investment_trust" in nm or "trust" in nm:
            by_date[d]["it"] += net
        elif "dealer" in nm:
            by_date[d]["dealer"] += net

    # 今日字串（台北時區）
    today_str = datetime.now(timezone(timedelta(hours=8))).date().isoformat()

    # 整理 rows
    rows = []
    for d in sorted(by_date.keys()):
        if not include_today and d == today_str:
            continue
        x = by_date[d]
        rows.append({
            "date": d,
            "stock_id": stock_id,
            "foreign": x["foreign"],
            "it": x["it"],
            "dealer": x["dealer"],
            "total": x["foreign"] + x["it"] + x["dealer"],
        })

    # 只留近 N 日
    rows = rows[-days:]

    # 單位轉換：張（四捨五入）
    if unit == "lot":
        for r in rows:
            for k in ("foreign", "it", "dealer", "total"):
                r[k] = int(round(r[k] / 1000))
    else:  # share
        for r in rows:
            for k in ("foreign", "it", "dealer", "total"):
                r[k] = int(round(r[k]))

    return jsonify({"stock_id": stock_id, "rows": rows, "unit": unit, "include_today": int(include_today)})

# ========= 預測用：列出可用模型 =========
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

MODEL_DIR = os.path.dirname(os.path.abspath(__file__))  # .keras 所在資料夾
_model_cache = {}  # 簡單快取

@app.get("/api/predict/models")
def list_available_models():
    try:
        items = []
        for fn in os.listdir(MODEL_DIR):
            if fn.lower().endswith(".keras"):
                code = os.path.splitext(fn)[0]
                if code.isdigit():  # 只收台股四碼
                    items.append(code)
        items = sorted(set(items), key=lambda x: (len(x), x))
        return jsonify({"ok": True, "models": items})
    except Exception as e:
        return jsonify({"ok": False, "error": f"{type(e).__name__}: {e}"}), 500

# ========= 預測用：抓 TWSE 並做特徵 =========
def _twse_fetch(stock_id: str, start_date: str, end_date: str) -> pd.DataFrame:
    """
    從 TWSE 月報抓日資料，日期格式 yyyymmdd；回傳欄位：Date, Close, High, Low, Volume, Change
    流程改寫自你的 實作.py。  # 來源：實作.py
    """
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    start = datetime.strptime(start_date, "%Y%m%d")
    end = datetime.strptime(end_date, "%Y%m%d")

    all_rows, fields = [], []
    cur = start.replace(day=1)
    while cur <= end:
        url = f"https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date={cur.strftime('%Y%m%d')}&stockNo={stock_id}"
        try:
            res = requests.get(url, timeout=12, verify=False)
            data = res.json()
            if "data" in data:
                all_rows.extend(data["data"])
                fields = data["fields"]
        except Exception as e:
            print("TWSE error:", e)

        # 下一個月
        if cur.month == 12:
            cur = cur.replace(year=cur.year + 1, month=1)
        else:
            cur = cur.replace(month=cur.month + 1)

    if not all_rows:
        return pd.DataFrame()

    df = pd.DataFrame(all_rows, columns=fields)
    df = df[["日期", "收盤價", "最高價", "最低價", "成交股數", "漲跌價差"]]

    def roc_to_ad(s):
        y, m, d = s.split("/")
        return f"{int(y)+1911}-{m}-{d}"

    df["日期"] = pd.to_datetime(df["日期"].apply(roc_to_ad), format="%Y-%m-%d")
    for col in ["收盤價", "最高價", "最低價", "成交股數", "漲跌價差"]:
        df[col] = pd.to_numeric(
            df[col].astype(str).str.replace(",", "").str.replace("X", "0"),
            errors="coerce"
        )
    m = (df["日期"] >= pd.to_datetime(start_date)) & (df["日期"] <= pd.to_datetime(end_date))
    df = df.loc[m].sort_values("日期").reset_index(drop=True)
    return df.rename(columns={
        "日期":"Date","收盤價":"Close","最高價":"High","最低價":"Low","成交股數":"Volume","漲跌價差":"Change"
    })

def _build_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # MA
    df["MA5"] = df["Close"].rolling(5).mean()
    df["MA10"] = df["Close"].rolling(10).mean()
    df["MA20"] = df["Close"].rolling(20).mean()
    # RSI
    delta = df["Close"].diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    rs = avg_gain / avg_loss
    df["RSI"] = 100 - (100 / (1 + rs))
    # MACD
    ema7 = df["Close"].ewm(span=7, adjust=False).mean()
    ema14 = df["Close"].ewm(span=14, adjust=False).mean()
    df["MACD"] = ema7 - ema14
    df["MACD_signal"] = df["MACD"].ewm(span=5, adjust=False).mean()
    return df.dropna().reset_index(drop=True)

_FEATURES = ["Close","High","Low","Volume","MA5","MA10","MA20","RSI","MACD","MACD_signal"]

def _last14_scaled(df: pd.DataFrame):
    latest = df[_FEATURES].iloc[-14:].values
    scaler = MinMaxScaler()
    return scaler.fit_transform(latest).reshape(1, 14, len(_FEATURES))

def _get_model(stock_id: str):
    if stock_id in _model_cache:
        return _model_cache[stock_id]
    path = os.path.join(MODEL_DIR, f"{stock_id}.keras")
    if not os.path.exists(path):
        raise FileNotFoundError(f"model not found: {path}")
    m = load_model(path)
    _model_cache[stock_id] = m
    return m

def _fetch_range_with_today_fallback(stock_id: str) -> pd.DataFrame:
    # 最近兩個月資料，先試含今天，不行就往前退到最近交易日
    today = datetime.now().date()
    start = (today.replace(day=1) - pd.DateOffset(months=2)).strftime("%Y%m%d")

    df = _twse_fetch(stock_id, start, today.strftime("%Y%m%d"))
    if not df.empty and df["Date"].max().date() == today:
        return df

    from datetime import timedelta
    d = today - timedelta(days=1)
    for _ in range(7):
        df2 = _twse_fetch(stock_id, start, d.strftime("%Y%m%d"))
        if not df2.empty and df2["Date"].max().date() <= d:
            return df2
        d -= timedelta(days=1)
    return df

@app.get("/api/predict")
def predict_stock():
    """
    ?stock_id=2330  依檔名載入 2330.keras
    回傳：{ok, stock_id, label(1/0), up_prob, down_prob, latest_date, recent[14筆]}
    """
    stock_id = (request.args.get("stock_id") or "").strip()
    if not (stock_id and stock_id.isdigit()):
        return jsonify({"ok": False, "error": "請提供正確的台股代碼，如 2330"}), 400

    try:
        raw = _fetch_range_with_today_fallback(stock_id)
        if raw.empty or len(raw) < 30:
            return jsonify({"ok": False, "error": "資料不足"}), 422

        feat = _build_features(raw)
        if len(feat) < 14:
            return jsonify({"ok": False, "error": "特徵不足"}), 422

        x = _last14_scaled(feat)
        model = _get_model(stock_id)
        p = model.predict(x, verbose=0)
        up = float(p[0][0]); down = float(1.0 - up); label = 1 if up > 0.5 else 0

        recent = (
            raw[["Date","Close"]]
            .tail(14)
            .assign(Date=lambda d: d["Date"].dt.strftime("%Y-%m-%d"))
            .to_dict(orient="records")
        )

        return jsonify({
            "ok": True,
            "stock_id": stock_id,
            "label": label,
            "up_prob": round(up, 6),
            "down_prob": round(down, 6),
            "latest_date": recent[-1]["Date"] if recent else None,
            "recent": recent
        })
    except FileNotFoundError as e:
        return jsonify({"ok": False, "error": str(e)}), 404
    except Exception as e:
        return jsonify({"ok": False, "error": f"{type(e).__name__}: {e}"}), 500


if __name__ == "__main__":
    # 建議在系統環境變數設定 FINMIND_TOKEN，避免把 token 寫死在程式
    # Windows PowerShell: $Env:FINMIND_TOKEN="你的token"
    # Linux / macOS: export FINMIND_TOKEN="你的token"
    app.run(host="0.0.0.0", port=5000, debug=True)
