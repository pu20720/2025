// 檔案路徑: Assets/Scripts/TargetIndicator.cs
using UnityEngine;
using UnityEngine.EventSystems;

public class TargetIndicator : MonoBehaviour, IPointerClickHandler
{
    [Header("Target Type")]
    [Tooltip("此目標的分類 (玩家、敵人、護甲槽、特殊...)")]
    [SerializeField] private TargetCategory targetCategory = TargetCategory.Enemy;

    [Tooltip("如果這是一個護甲槽，指定它是哪個部位")]
    [SerializeField] private ArmorPart targetArmorPart = ArmorPart.Armor;

    private Character character;
    private CardDisplay cardDisplayCache;

    private void Awake()
    {
    }

    private void Start()
    {
    }

    public void Initialize()
    {
        switch (targetCategory)
        {
            case TargetCategory.Enemy:
                character = GetComponentInParent<Character>();
                break;

            // ▼▼▼ 【這是我上次打錯的地方，現已修正】 ▼▼▼
            case TargetCategory.Player: // <-- 錯誤的 'TargetCode' 已修正為 'TargetCategory'
            // ▲▲▲ 【修正結束】 ▲▲▲
            case TargetCategory.PlayerArmorSlot:
                if (BattleManager.Instance != null)
                {
                    character = BattleManager.Instance.GetPlayerCharacter();
                }
                break;

            case TargetCategory.EnemyArmorSlot:
                EnemyUI enemyPanel = GetComponentInParent<EnemyUI>();
                if (enemyPanel != null)
                    character = enemyPanel.GetTargetCharacter();
                break;
            case TargetCategory.CardInHand:
                character = null;
                cardDisplayCache = GetComponent<CardDisplay>();
                break;
            case TargetCategory.Special:
                character = null;
                break;
        }

        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.RegisterTargetIndicator(this);
        }
    }

    private void OnDisable()
    {
        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.UnregisterTargetIndicator(this);
        }
    }

    public Character GetCharacter() => character;
    public TargetCategory GetCategory() => targetCategory;
    public ArmorPart GetArmorPart() => targetArmorPart;

    public CardDisplay GetCardDisplay()
    {
        if (cardDisplayCache == null)
        {
            Debug.LogWarning($"[TargetIndicator] cardDisplayCache is null on {gameObject.name}. Attempting to GetComponent...");
            cardDisplayCache = GetComponent<CardDisplay>();
        }
        return cardDisplayCache;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // 在執行任何動作前，先詢問 BattleManager 是否正在進行「應攔截點擊」的對話
        if (BattleManager.Instance != null && BattleManager.Instance.IsDialogueActiveAndIntercepting())
        {
            Debug.Log($"[TargetIndicator] OnPointerClick: 點擊 {gameObject.name} 被 BattleManager (對話) 攔截並忽略。");
            return; // 安靜地 return，不執行任何動作，也不顯示 "That's not what I should do"
        }


        Debug.Log($"[TargetIndicator] OnPointerClick: {gameObject.name}, 類別 {targetCategory}");

        if (BattleManager.Instance == null || !BattleManager.Instance.IsPlayerTurn())
        {
            Debug.LogError($"[TargetIndicator] OnPointerClick REJECTED: BattleManager is null or not player turn.");
            return;
        }

        if (targetCategory == TargetCategory.CardInHand)
        {
            CardDisplay thisCardDisplay = GetCardDisplay();
            if (thisCardDisplay == null)
            {
                Debug.LogError($"[TargetIndicator] OnPointerClick FAILED: thisCardDisplay is null on {gameObject.name}.");
                return;
            }

            CardData thisCardData = thisCardDisplay.GetCardData();
            if (thisCardData == null)
            {
                Debug.LogError($"[TargetIndicator] OnPointerClick FAILED: thisCardData is null on {gameObject.name}.");
                return;
            }

            CardDisplay currentlySelected = BattleManager.Instance.GetSelectedCardDisplay();

            Debug.Log($"[TargetIndicator] OnPointerClick PROCESSING: Card = {thisCardData.cardName}, CurrentlySelected = {(currentlySelected != null ? currentlySelected.GetCardData().cardName : "null")}");

            if (currentlySelected == null)
            {
                // 第一次點擊：選取這張卡 (例如 Sharpen)
                BattleManager.Instance.HandleCardClick(thisCardData, thisCardDisplay);
            }
            else if (currentlySelected == thisCardDisplay)
            {
                // 第二次點擊同一張卡：取消選取
                BattleManager.Instance.DeselectCard();
            }
            else
            {
                // 點擊另一張卡：將這張卡作為「目標」
                BattleManager.Instance.HandleTargetClick(this);
            }
        }
        else
        {
            // 點擊非手牌目標 (敵人、護甲槽、特殊區域)
            Debug.Log($"[TargetIndicator] OnPointerClick: 點擊了非手牌目標 {gameObject.name}");
            BattleManager.Instance.HandleTargetClick(this);
        }
    }
}