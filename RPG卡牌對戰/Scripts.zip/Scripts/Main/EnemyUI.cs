// 檔案路徑: Assets/Scripts/UI/EnemyUI.cs
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class EnemyUI : MonoBehaviour
{
    [Header("Enemy Info")]
    [SerializeField] private TMP_Text infoText;
    [SerializeField] private TMP_Text enemyAttackText;

    [Header("Enemy Armor Text (Values)")]
    [SerializeField] private TMP_Text helmetArmorText;
    [SerializeField] private TMP_Text armorArmorText;
    [SerializeField] private TMP_Text gauntletsArmorText;
    [SerializeField] private TMP_Text legArmorArmorText;

    // ▼▼▼ 【新增】敵人護甲的圖示 (用來生成覆蓋層的目標) ▼▼▼
    [Header("Enemy Armor Icons (UI Targets)")]
    [Tooltip("請將 UI 上顯示敵人頭盔圖案的 Image 拖曳到這裡")]
    [SerializeField] private Image helmetIcon;
    [Tooltip("請將 UI 上顯示敵人盔甲圖案的 Image 拖曳到這裡")]
    [SerializeField] private Image armorIcon;
    [Tooltip("請將 UI 上顯示敵人護手圖案的 Image 拖曳到這裡")]
    [SerializeField] private Image gauntletsIcon;
    [Tooltip("請將 UI 上顯示敵人腿甲圖案的 Image 拖曳到這裡")]
    [SerializeField] private Image legArmorIcon;
    // ▲▲▲ 【新增結束】 ▲▲▲

    [Header("Status Effects (General)")]
    [Tooltip("請在 EnemyUI 下建立一個空的 GameObject (設定 Horizontal Layout Group) 作為父物件")]
    [SerializeField] private Transform statusEffectParent;

    // --- 狀態圖示 Prefabs ---
    [Tooltip("BleedIcon_Prefab")]
    [SerializeField] private GameObject bleedStatusIconPrefab;

    [Tooltip("PoisonIcon_Prefab")]
    [SerializeField] private GameObject poisonStatusIconPrefab;

    [Tooltip("StunIcon_Prefab")]
    [SerializeField] private GameObject stunStatusIconPrefab;

    [Tooltip("PauseIcon_Prefab")]
    [SerializeField] private GameObject pauseStatusIconPrefab;

    // ▼▼▼ 【新增】腐化專用覆蓋層 Prefab ▼▼▼
    [Header("Corruption Specific")]
    [Tooltip("請使用與 PlayerUI 相同的 CorruptionOverlay_Prefab")]
    [SerializeField] private GameObject corruptionOverlayPrefab;
    // ▲▲▲ 【新增結束】 ▲▲▲

    private List<GameObject> activeStatusIcons = new List<GameObject>();

    // 用於追蹤「護甲腐化覆蓋層」的字典
    private Dictionary<ArmorPart, GameObject> activeCorruptionOverlays = new Dictionary<ArmorPart, GameObject>();

    private Character targetCharacter;
    private CharacterStats stats;

    public void Initialize(Character target)
    {
        targetCharacter = target;
        stats = target.stats;

        activeCorruptionOverlays.Clear();

        if (targetCharacter == null || stats == null)
        {
            gameObject.SetActive(false);
            return;
        }

        UpdateStats();
    }

    public void UpdateStats()
    {
        if (targetCharacter == null || stats == null) return;

        // 1. 更新文字資訊
        if (infoText != null)
            infoText.text = $"{targetCharacter.characterName}\n{stats.hp} / {stats.maxHp}";

        if (enemyAttackText != null)
            enemyAttackText.text = stats.attackValue.ToString();

        if (helmetArmorText != null) helmetArmorText.text = stats.helmet.currentArmor.ToString();
        if (armorArmorText != null) armorArmorText.text = stats.armor.currentArmor.ToString();
        if (gauntletsArmorText != null) gauntletsArmorText.text = stats.gauntlets.currentArmor.ToString();
        if (legArmorArmorText != null) legArmorArmorText.text = stats.legArmor.currentArmor.ToString();

        // 2. 更新一般狀態圖示 (流血/中毒/暈眩/暫停)
        UpdateStatusEffects();

        // 3. 【新增】更新腐化覆蓋層
        UpdateCorruptionOverlays();
    }

    // ▼▼▼ 【新增】處理特定部位腐化的邏輯 ▼▼▼
    private void UpdateCorruptionOverlays()
    {
        if (corruptionOverlayPrefab == null) return;

        // 檢查每個部位，前提是 Icon 欄位有綁定
        if (helmetIcon != null) HandleSlotOverlay(ArmorPart.Helmet, stats.helmet.corruptStacks, helmetIcon.transform);
        if (armorIcon != null) HandleSlotOverlay(ArmorPart.Armor, stats.armor.corruptStacks, armorIcon.transform);
        if (gauntletsIcon != null) HandleSlotOverlay(ArmorPart.Gauntlets, stats.gauntlets.corruptStacks, gauntletsIcon.transform);
        if (legArmorIcon != null) HandleSlotOverlay(ArmorPart.LegArmor, stats.legArmor.corruptStacks, legArmorIcon.transform);
    }

    private void HandleSlotOverlay(ArmorPart part, int stacks, Transform targetParent)
    {
        // 情況 A: 有腐化層數
        if (stacks > 0)
        {
            GameObject overlay;

            // 1. 檢查是否已經存在覆蓋層
            if (!activeCorruptionOverlays.ContainsKey(part) || activeCorruptionOverlays[part] == null)
            {
                // 不存在則生成，設為目標圖示的「子物件」
                overlay = Instantiate(corruptionOverlayPrefab, targetParent);
                activeCorruptionOverlays[part] = overlay;

                // 強制設定 RectTransform 填滿父物件 (Stretch)
                RectTransform rt = overlay.GetComponent<RectTransform>();
                if (rt != null)
                {
                    rt.anchorMin = Vector2.zero;
                    rt.anchorMax = Vector2.one;
                    rt.pivot = new Vector2(0.5f, 0.5f);
                    rt.sizeDelta = Vector2.zero;
                    rt.localPosition = Vector3.zero;
                    rt.localScale = Vector3.one;
                }
            }
            else
            {
                overlay = activeCorruptionOverlays[part];
            }

            // 2. 更新層數數字
            TMP_Text countText = overlay.GetComponentInChildren<TMP_Text>();
            if (countText != null)
            {
                countText.text = stacks.ToString();
            }
        }
        // 情況 B: 沒有腐化層數 (或已解除)
        else
        {
            if (activeCorruptionOverlays.ContainsKey(part))
            {
                if (activeCorruptionOverlays[part] != null)
                {
                    Destroy(activeCorruptionOverlays[part]);
                }
                activeCorruptionOverlays.Remove(part);
            }
        }
    }
    // ▲▲▲ 【新增結束】 ▲▲▲

    private void UpdateStatusEffects()
    {
        // 清除舊圖示
        foreach (GameObject icon in activeStatusIcons)
        {
            if (icon != null) Destroy(icon);
        }
        activeStatusIcons.Clear();

        if (stats == null || statusEffectParent == null) return;

        // 1. 流血
        if (stats.bleedStacks > 0 && bleedStatusIconPrefab != null)
        {
            CreateStatusIcon(bleedStatusIconPrefab, stats.bleedStacks);
        }

        // 2. 中毒
        if (stats.poisonStacks > 0 && poisonStatusIconPrefab != null)
        {
            CreateStatusIcon(poisonStatusIconPrefab, stats.poisonStacks);
        }

        // (註：舊的 "總腐化" 顯示邏輯已移除，改用上面的 Overlay)

        // 3. 暈眩
        if (stats.stunTurns > 0 && stunStatusIconPrefab != null)
        {
            CreateStatusIcon(stunStatusIconPrefab, stats.stunTurns);
        }

        // 4. 暫停
        if (stats.frozenTurns > 0 && pauseStatusIconPrefab != null)
        {
            CreateStatusIcon(pauseStatusIconPrefab, stats.frozenTurns);
        }
    }

    private void CreateStatusIcon(GameObject prefab, int number)
    {
        GameObject iconGO = Instantiate(prefab, statusEffectParent);
        TMP_Text stackText = iconGO.GetComponentInChildren<TMP_Text>();
        if (stackText != null)
        {
            stackText.text = number.ToString();
        }
        activeStatusIcons.Add(iconGO);
    }

    public Character GetTargetCharacter()
    {
        return targetCharacter;
    }
}