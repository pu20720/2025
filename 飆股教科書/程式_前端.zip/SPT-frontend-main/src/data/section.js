export const sections = [
    {
        id: 0,
        title: '投資策略總覽',
        slides: [
            {
                title: '價值投資（Value Investing）',
                content: '📈 長期持有、低估時買進，強調內在價值。',
            },
            {
                title: '成長投資（Growth Investing）',
                content: '🚀 找有爆發潛力的公司，著重營收與未來市場。',
            },
            {
                title: '測驗',
                quiz: {
                    question: '以下哪一個是「價值投資」的重點？',
                    options: ['追高殺低', '搶新聞消息', '內在價值評估'],
                    answer: 2,
                },
            },
        ],
    },
    {
        id: 1,
        title: '技術分析基礎',
        slides: [
            {
                title: 'K 線與成交量',
                content: '🔍 K 線包含價格資訊，成交量可確認趨勢有效性。',
            },
            {
                title: '技術指標入門',
                content: '📊 RSI、MACD 可用來觀察超買超賣、背離現象。',
            },
            {
                title: '測驗',
                quiz: {
                    question: 'RSI 是用來判斷什麼？',
                    options: ['營收成長', '公司負債', '超買超賣'],
                    answer: 2,
                },
            },
        ],
    },
]
