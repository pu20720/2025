<template>
    <div>
        <div class="flex justify-between text-sm text-gray-500 mb-1">
            <span>{{ min }}{{ unit }}</span>
            <span>{{ max }}{{ unit }}</span>
        </div>
        <div class="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
            <div
                class="h-full bg-violet-500 transition-all duration-300"
                :style="{ width: ratio + '%' }"
            ></div>
        </div>
    </div>
</template>

<script setup>
    import { computed } from 'vue'

    defineProps({
        min: Number,
        max: Number,
        current: Number,
        unit: {
            type: String,
            default: '',
        },
    })

    const ratio = computed(() => {
        const range = Math.max(1, max - min)
        return Math.min(100, Math.max(0, ((current - min) / range) * 100))
    })
</script>
