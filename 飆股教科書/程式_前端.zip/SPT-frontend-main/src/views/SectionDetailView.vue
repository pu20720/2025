<template>
    <!-- 顯示章節內容 -->
    <Section0 v-if="route.params.id === '0'" />
    <Section1 v-if="route.params.id === '1'" />
    <Section2 v-if="route.params.id === '2'" />
    <Section3 v-if="route.params.id === '3'" />
    <Section4 v-if="route.params.id === '4'" />
    <Section5 v-if="route.params.id === '5'" />
    <div v-else class="p-6">
        <h1 class="text-3xl font-bold mb-4">{{ section?.title }}</h1>
        <ul class="list-disc pl-5 space-y-2">
            <li v-for="(point, index) in section?.points || []" :key="index">
                {{ point }}
            </li>
        </ul>
    </div>

    <!-- 返回按鈕放在最外層底部，不論哪個章節都會顯示 -->
    <div class="mt-8 px-6">
        <router-link
            to="/learning"
            class="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-full shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out"
        >
            <svg
                class="h-5 w-5 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
            >
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M11 17l-5-5m0 0l5-5m-5 5h12"
                ></path>
            </svg>
            返回學習股票頁面
        </router-link>
    </div>
</template>

<script setup>
    import { computed } from 'vue'
    import { useRoute } from 'vue-router'
    import Section0 from '../data/section/Section0.vue'
    import Section1 from '../data/section/Section1.vue'
    import Section2 from '../data/section/Section2.vue'
    import Section3 from '../data/section/Section3.vue'
    import Section4 from '../data/section/Section4.vue'
    import Section5 from '../data/section/Section5.vue'

    const route = useRoute()
    const section = computed(() => route.params.id)
</script>
