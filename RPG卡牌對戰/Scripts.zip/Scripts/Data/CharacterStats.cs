﻿using UnityEngine;
using System;

[System.Serializable]
public class CharacterStats
{
    // ... (保留原本的事件與屬性) ...
    public event System.Action OnDied;
    private bool hasDied = false;
    public event System.Action OnDowned;
    public bool isDowned = false;
    private bool hasBeenDowned = false;
    public RPGStatsData data { get; private set; }
    public int hp;
    public int maxHp;
    public int mp;
    public int attackValue;
    public int turnCount = 1;
    public bool isDead = false;
    public bool isDying = false;
    public bool canChooseMercy = false;
    public int stunTurns = 0;
    public int frozenTurns = 0;
    public int bleedStacks = 0;
    public int poisonStacks = 0;
    public ArmorSlot helmet = new ArmorSlot("Helmet");
    public ArmorSlot armor = new ArmorSlot("Armor");
    public ArmorSlot gauntlets = new ArmorSlot("Gauntlets");
    public ArmorSlot legArmor = new ArmorSlot("LegArmor");
    private string characterNameForLog = "Character";

    public void Initialize(RPGStatsData statsData, int startMaxHp, int startAttack, string characterName)
    {
        // ... (保留初始化邏輯) ...
        this.data = statsData;
        this.maxHp = startMaxHp;
        this.hp = this.maxHp;
        this.attackValue = startAttack;
        this.characterNameForLog = characterName;
        this.turnCount = 1;
        if (this.data != null) { this.mp = this.data.mpInitial; } else { this.mp = 5; }
        this.isDead = false; this.isDying = false; this.canChooseMercy = false; this.hasDied = false;
        this.isDowned = false; this.hasBeenDowned = false;
        this.stunTurns = 0; this.frozenTurns = 0; this.bleedStacks = 0; this.poisonStacks = 0;
        ResetArmorSlot(this.helmet); ResetArmorSlot(this.armor);
        ResetArmorSlot(this.gauntlets); ResetArmorSlot(this.legArmor);
        UpdateHpState();
    }

    private void ResetArmorSlot(ArmorSlot slot) { slot.corruptStacks = 0; slot.corruptTurns = 0; }
    public void Heal(int amount) { if (this.isDead || amount <= 0) return; this.hp += amount; UpdateHpState(); }
    public void Repair(ArmorPart target, int amount) { if (amount <= 0) return; GetArmorSlot(target)?.Repair(amount); }
    public void EquipArmor(ArmorPart target, int defenseValue) { GetArmorSlot(target)?.EquipArmor(defenseValue); }
    public ArmorSlot GetArmorSlot(ArmorPart part)
    {
        return part switch { ArmorPart.Helmet => helmet, ArmorPart.Armor => armor, ArmorPart.Gauntlets => gauntlets, ArmorPart.LegArmor => legArmor, _ => armor };
    }

    // ==========================================
    // !重點修正: 減傷進位規則
    // ==========================================
    private int CalculateRoundedDamage(float rawDamage, float reductionMultiplier)
    {
        // 規則: 若有減傷，傷害無條件進位 (Ceil)
        float finalVal = rawDamage * reductionMultiplier;
        return Mathf.CeilToInt(finalVal);
    }

    public void AddStatus(StatusType type, int stacks, ArmorPart target = ArmorPart.Armor)
    {
        if (stacks <= 0 || this.isDead) return;
        switch (type)
        {
            case StatusType.Bleed: this.bleedStacks += stacks; break;
            case StatusType.Poison: this.poisonStacks += stacks; break;
            case StatusType.Corruption: GetArmorSlot(target)?.AddCorruption(stacks); break;
            case StatusType.Stun: this.stunTurns += stacks; break;
            case StatusType.Freeze: this.frozenTurns += stacks; break;
        }
    }

    public void CleanseDebuffs()
    {
        bleedStacks = 0; poisonStacks = 0; stunTurns = 0; frozenTurns = 0;
        CleanseArmorSlotCorruption(helmet); CleanseArmorSlotCorruption(armor);
        CleanseArmorSlotCorruption(gauntlets); CleanseArmorSlotCorruption(legArmor);
    }
    private void CleanseArmorSlotCorruption(ArmorSlot slot) { slot.corruptStacks = 0; slot.corruptTurns = 0; }

    public void UpdateStatuses()
    {
        if (this.data == null) return;
        float statusDamageMultiplier = 1.0f; // 預留減傷係數

        // 流血 (受進位規則影響)
        if (this.bleedStacks > 0)
        {
            float rawBleedDmg = this.bleedStacks * this.data.bleedDamagePerStack;
            int finalBleedDmg = CalculateRoundedDamage(rawBleedDmg, statusDamageMultiplier);
            this.hp -= finalBleedDmg;
            this.bleedStacks = Mathf.Max(0, this.bleedStacks - this.data.bleedDecayPerTurn);
        }

        // 中毒 (受進位規則影響)
        if (this.poisonStacks > 0)
        {
            float rawPoisonDmg = this.poisonStacks * this.data.poisonDamagePerStack;
            int finalPoisonDmg = CalculateRoundedDamage(rawPoisonDmg, statusDamageMultiplier);
            this.hp -= finalPoisonDmg;
            this.poisonStacks = Mathf.Max(0, this.poisonStacks - this.data.poisonDecayPerTurn);
            if (this.poisonStacks >= this.data.poisonDeathStacks) { this.isDead = true; }
        }

        // 腐化 (規則: 不受進位規則強制影響，通常計算整數)
        helmet.UpdateCorruption(this.data);
        armor.UpdateCorruption(this.data);
        gauntlets.UpdateCorruption(this.data);
        legArmor.UpdateCorruption(this.data);

        UpdateHpState();
    }

    public int GetOverloadLevel()
    {
        if (data == null) return 0;
        if (mp >= data.overloadThreshold3) return 3;
        if (mp >= data.overloadThreshold2) return 2;
        if (mp >= data.overloadThreshold1) return 1;
        return 0;
    }

    // 傷害計算
    public int TakeDamage(int damage, DamageType type, ArmorPart targetPart, int piercePercent = 0, float damageReductionPercent = 0f)
    {
        if (this.isDead || damage <= 0) return 0;

        // 1. 減傷計算 (進位規則)
        int incomingDamage = damage;
        if (damageReductionPercent > 0)
        {
            float multiplier = 1.0f - (damageReductionPercent / 100f);
            incomingDamage = CalculateRoundedDamage(damage, multiplier);
        }

        float overloadPierceRatio = 0f;
        // ... (保留 Overload 計算) ...
        int ovLevel = GetOverloadLevel();
        if (data != null)
        {
            if (ovLevel == 3) overloadPierceRatio = data.overloadPierceRatio3;
            else if (ovLevel == 2) overloadPierceRatio = data.overloadPierceRatio2;
            else if (ovLevel == 1) overloadPierceRatio = data.overloadPierceRatio1;
        }

        float basePierceRatio = piercePercent / 100f;
        float totalPierceRatio = Mathf.Clamp01(basePierceRatio + overloadPierceRatio);

        if (this.isDowned)
        {
            if (damage == 9999 && type == DamageType.True) { this.hp -= damage; UpdateHpState(); return damage; }
            return 0;
        }
        else
        {
            int actualDamageDealt = 0;
            if (type == DamageType.True)
            {
                this.hp -= incomingDamage;
                actualDamageDealt = incomingDamage;
            }
            else
            {
                int hpDamage = 0;
                int armorDamage = 0;
                if (totalPierceRatio > 0)
                {
                    hpDamage = Mathf.CeilToInt(incomingDamage * totalPierceRatio); // 穿刺也進位
                    if (hpDamage < 1) hpDamage = 1;
                    armorDamage = incomingDamage - hpDamage;
                }
                else
                {
                    armorDamage = incomingDamage;
                    hpDamage = 0;
                }
                var part = GetArmorSlot(targetPart);
                if (part != null && !part.isBroken)
                {
                    part.ApplyDamage(armorDamage);
                    this.hp -= hpDamage;
                    actualDamageDealt = incomingDamage;
                }
                else
                {
                    this.hp -= incomingDamage;
                    actualDamageDealt = incomingDamage;
                }
            }
            UpdateHpState();
            return actualDamageDealt;
        }
    }

    private void UpdateHpState()
    {
        // ... (保留狀態判定) ...
        bool wasDead = this.isDead;
        bool wasDowned = this.isDowned;
        this.isDowned = (this.hp > 0 && this.hp <= 10);
        this.isDead = (this.hp <= 0);
        if (this.hp < 0) this.hp = 0;
        if (this.data != null) this.isDying = (this.hp > 0 && this.hp < this.data.hpDyingThreshold && !this.isDead);
        this.canChooseMercy = (this.hp == 0 && !this.isDead);
        if (!this.isDead && this.hp > this.maxHp) this.hp = this.maxHp;
        if (this.isDowned && !wasDowned && !this.hasBeenDowned && !this.isDead) { this.hasBeenDowned = true; OnDowned?.Invoke(); }
        if (this.isDead && !wasDead && !this.hasDied) { this.hasDied = true; OnDied?.Invoke(); }
    }

    // ... (保留存檔與輔助方法) ...
    public CharacterSaveData GatherSaveData() { return new CharacterSaveData { /*...*/ }; } // 簡化顯示，請保留原內容
    public void LoadFromSave(CharacterSaveData data) { /*...*/ }
    public bool IsAnyArmorBroken() { return helmet.isBroken || armor.isBroken || gauntlets.isBroken || legArmor.isBroken; }
    public ArmorPart GetLowestArmorPart() { /*...*/ return ArmorPart.Armor; }
}